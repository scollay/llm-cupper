# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a basic technical indicator that plots the average price of a security over a specified number of periods. On a chart it appears as a smooth line that follows price action, often overlaid on the price series itself. While its exact origin is unclear, the concept of averaging prices to smooth volatility has been used in technical analysis since the early 20th century and is attributed to early market technicians who sought a straightforward way to identify trend direction.

## Details
### Calculation
The SMA for a given point in time is the arithmetic mean of the selected price (most commonly the closing price) over the previous *N* periods:

\[
\text{SMA}_t = \frac{1}{N}\sum_{i=0}^{N-1} P_{t-i}
\]

where \(P_{t-i}\) is the price at period \(t-i\). The indicator can be applied to any price series—open, high, low, or close—but the close is standard because it reflects the market’s final consensus for the period.

### Typical Interpretation
Traders use the SMA in several ways:

- **Trend identification** – When the price sits above its SMA, the market is considered to be in an uptrend; when below, a downtrend. The slope of the SMA line reinforces this view: a rising SMA suggests bullish momentum, a falling SMA suggests bearish momentum.
- **Support and resistance** – In an uptrend, the SMA often acts as a dynamic support level; in a downtrend, it can serve as resistance. Price bounces off the SMA are watched for entry or exit signals.
- **Crossovers** – A common tactic is to watch for a short‑term SMA crossing above a longer‑term SMA (a “golden cross”) as a buy signal, and the opposite crossing (a “death cross”) as a sell signal.
- **Trend strength** – The distance between price and the SMA can hint at momentum; a wide gap may indicate strong trend strength, while a narrow gap suggests weakening momentum.

### Where Interpretation Breaks Down
Despite its simplicity, the SMA has notable limitations:

- **Lag** – Because it averages past prices, the SMA reacts slowly to new information. In fast‑moving markets, signals can arrive after a significant portion of the move has already occurred.
- **Whipsaws** – In sideways or choppy markets, the price may repeatedly cross the SMA, generating false signals that lead to losses if acted upon mechanically.
- **Equal weighting** – Every period within the window receives the same weight, regardless of relevance. More recent prices are not given greater influence, which can make the SMA less responsive than exponentially weighted alternatives.
- **Choice of period** – The effectiveness of the SMA is highly dependent on the selected look‑back length. Too short a window yields a noisy line that mimics price; too long a window oversmooths and may miss meaningful turning points.

Traders often combine the SMA with other tools—such as volume analysis, oscillators, or price patterns—to mitigate these shortcomings and confirm signals.

## Text Formula
For a DataFrame containing columns `symbol`, `date`, `open`, `high`, `low`, `close`, the Simple Moving Average of the closing price over a window of *N* periods is calculated as:

```
SMA_N = (close_t + close_{t-1} + ... + close_{t-(N-1)}) / N
```

If a different price series is desired, replace `close` with the appropriate column name (e.g., `open`, `high`, `low`). The result is assigned to a new column, typically named `sma_N`.

## Python Code
```python
import pandas as pd

def calculate_sma(df: pd.DataFrame, window: int, price_col: str = 'close') -> pd.DataFrame:
    """
    Compute the Simple Moving Average (SMA) for each symbol in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input data with at least the columns: 'symbol', 'date', and the price column
        specified by `price_col` (default 'close'). The DataFrame may contain
        multiple symbols.
    window : int
        Number of periods over which to average. Must be >= 1.
    price_col : str, optional
        Name of the column to use for the SMA calculation (default 'close').

    Returns
    -------
    pd.DataFrame
        A copy of the original DataFrame with an additional column named
        'sma_<window>' containing the SMA values. The SMA is NaN for the first
        (window-1) rows of each symbol because insufficient data exist.
    """
    # Work on a copy to avoid side‑effects on the caller's DataFrame
    result = df.copy()

    # Ensure the price column exists
    if price_col not in result.columns:
        raise KeyError(f"Column '{price_col}' not found in DataFrame.")

    # Compute SMA per symbol using groupby and rolling mean.
    # min_periods=window guarantees that only full windows produce a value.
    sma_column_name = f'sma_{window}'
    result[sma_column_name] = (
        result.groupby('symbol')[price_col]
              .transform(lambda series: series.rolling(window, min_periods=window).mean())
    )

    return result
```

The function above respects the requirement to handle one or more symbols independently, returns the SMA as a new column, and uses only pandas operations that run efficiently on typical intraday or daily datasets. The code contains no simulated data; it merely documents the expected input format and the calculation logic.
```json
{ "model_code": "x6kp3hr9bln2", "topic": "Simple Moving Average", "timer_secs": 20.54, "tokens_in": 561, "tokens_out": 1183, "cost_tokens_in": 0.00005049, "cost_tokens_out": 0.00053235, "cost_tokens_tot": 0.00058284 }
```