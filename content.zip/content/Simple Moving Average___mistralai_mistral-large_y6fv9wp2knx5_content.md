# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is a foundational technical indicator that smooths price data by calculating the arithmetic mean of a security's closing prices over a specified number of periods. Displayed as a single line on price charts, the SMA helps traders identify trends, support/resistance levels, and potential reversal points by filtering out short-term price fluctuations.

The SMA has no single attributed creator, as its concept emerged organically from early technical analysis practices in the 20th century. It remains one of the most widely used indicators due to its simplicity and effectiveness in trend-following strategies.

## Details

### How the SMA Works
The SMA calculates the average closing price over `n` periods, where `n` is the lookback window chosen by the trader (common values include 20, 50, 100, or 200 periods). As each new period closes, the oldest price in the window is dropped, and the newest price is added, creating a "moving" average that progresses with the price series.

For example, a 20-period SMA on a daily chart sums the last 20 days' closing prices and divides by 20. This process repeats for each subsequent day, producing a smoothed line that lags behind the current price but reveals the underlying trend.

### Interpretation
Traders use the SMA in several key ways:

- **Trend Identification**: Prices above the SMA suggest an uptrend, while prices below indicate a downtrend. The slope of the SMA itself (rising, falling, or flat) also signals trend strength or weakness.
- **Support/Resistance**: In uptrends, the SMA often acts as dynamic support; in downtrends, it may serve as resistance. Price reactions to the SMA (e.g., bounces or breaks) can signal continuation or reversal.
- **Crossover Strategies**: When a shorter-term SMA (e.g., 20-period) crosses above a longer-term SMA (e.g., 50-period), it may signal a bullish "golden cross." The opposite, a "death cross," suggests bearish momentum.
- **Mean Reversion**: In ranging markets, prices may oscillate around the SMA, with deviations from the average potentially signaling overbought or oversold conditions.

### Limitations
While the SMA is versatile, its simplicity introduces drawbacks:

- **Lag**: Because the SMA incorporates past prices, it reacts slowly to new information. In fast-moving markets, this lag can result in late signals or whipsaws (false reversals).
- **Equal Weighting**: The SMA assigns equal importance to all prices in the lookback window, including outdated data. This can obscure recent price action, especially in volatile or trending markets.
- **False Signals in Ranges**: In sideways markets, SMA crossovers or price interactions with the SMA may generate frequent false signals, as the indicator lacks directional bias.
- **Parameter Sensitivity**: The choice of lookback period (`n`) significantly impacts the SMA's behavior. Short periods (e.g., 10) are more responsive but noisier, while long periods (e.g., 200) are smoother but laggier.

### Practical Considerations
- **Timeframe Alignment**: The SMA's effectiveness depends on the trading timeframe. A 50-period SMA on a daily chart may work well for swing traders, while intraday traders might prefer a 20-period SMA on a 1-hour chart.
- **Combination with Other Tools**: Traders often pair the SMA with other indicators (e.g., RSI, MACD) or price action patterns to confirm signals and reduce false positives.
- **Volume and Volatility**: In low-volume or highly volatile markets, the SMA may produce less reliable signals, as price movements can become erratic or disconnected from underlying trends.

## Text Formula

The Simple Moving Average for a given period `n` is calculated as:

```
SMA_t = (P_t + P_{t-1} + P_{t-2} + ... + P_{t-n+1}) / n
```

Where:
- `SMA_t` = Simple Moving Average at time `t`
- `P_t` = Closing price at time `t`
- `n` = Number of periods in the lookback window

For a rolling calculation across a dataset, the formula can be expressed recursively as:

```
SMA_t = SMA_{t-1} + (P_t / n) - (P_{t-n} / n)
```

This recursive form is computationally efficient for large datasets, as it avoids recalculating the sum from scratch for each new period.

## Python Code

```python
import pandas as pd

def calculate_sma(data: pd.DataFrame, window: int) -> pd.DataFrame:
    """
    Calculate the Simple Moving Average (SMA) for one or more symbols in a DataFrame.

    Parameters:
    -----------
    data : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Must be sorted by symbol and date.
    window : int
        Number of periods to use for the SMA calculation.

    Returns:
    --------
    pd.DataFrame
        Original DataFrame with an additional column: `sma_{window}`.
        The SMA is calculated independently for each symbol.

    Notes:
    ------
    - The SMA is calculated using closing prices.
    - NaN values are returned for the first `window - 1` periods of each symbol's data,
      as there is insufficient history to compute the SMA.
    - The function handles multiple symbols by grouping the data before calculation.
    """
    # Validate input
    required_columns = {'symbol', 'date', 'close'}
    if not required_columns.issubset(data.columns):
        raise ValueError(f"Input DataFrame must contain columns: {required_columns}")

    if window <= 0:
        raise ValueError("Window must be a positive integer")

    # Calculate SMA for each symbol
    data = data.copy()
    sma_column = f'sma_{window}'
    data[sma_column] = (
        data.groupby('symbol')['close']
        .transform(lambda x: x.rolling(window=window, min_periods=1).mean())
    )

    # Set NaN for the first `window - 1` periods of each symbol
    mask = data.groupby('symbol').cumcount() < window - 1
    data.loc[mask, sma_column] = float('nan')

    return data
```

### Code Explanation
1. **Input Validation**: The function checks for required columns (`symbol`, `date`, `close`) and ensures the window is a positive integer.
2. **Grouped Calculation**: The SMA is computed independently for each symbol using `groupby('symbol')` to avoid mixing data across different securities.
3. **Rolling Mean**: The `rolling()` method with `min_periods=1` calculates the mean over the specified window, but the subsequent mask ensures NaN values for the first `window - 1` periods (where full history is unavailable).
4. **Output**: The original DataFrame is returned with an additional column named `sma_{window}` (e.g., `sma_20` for a 20-period SMA).

This implementation efficiently handles large datasets and multiple symbols while adhering to the mathematical definition of the SMA.
```json
{ "model_code": "y6fv9wp2knx5", "topic": "Simple Moving Average", "timer_secs": 23.75, "tokens_in": 569, "tokens_out": 1555, "cost_tokens_in": 0.00113800, "cost_tokens_out": 0.00933000, "cost_tokens_tot": 0.01046800 }
```