# Simple Moving Average (SMA)

## Overview
The **Simple Moving Average (SMA)** is a widely used trend indicator that smooths price data by averaging the last *N* observations. On a chart, it appears as a single line that updates each time a new bar (candle) forms, typically drawn on top of the price series.

SMA has no single inventor; it’s an age-old, foundational technique in both technical analysis and time-series smoothing.

## Details
### What it is
An SMA of length *N* at time *t* is the arithmetic mean of the closing prices from the most recent *N* periods:

- If you’re using daily data, a `N=50` SMA is the mean of the last 50 daily closes.
- If you’re using intraday data, `N` corresponds to the number of bars, not calendar time.

### How traders interpret it
Most traders use SMA in a few common ways:

1. **Trend direction and smoothing**
   - When price is generally above the SMA and the SMA is rising, traders interpret that as an **uptrend**.
   - When price is below the SMA and the SMA is falling, that’s often treated as a **downtrend**.

2. **Dynamic support and resistance**
   - In many markets, the SMA can act like a “gravity” line: price sometimes mean-reverts toward it.
   - Short-term SMAs (e.g., 20) are often watched for faster reactions; longer SMAs (e.g., 200) are watched for regime/trend confirmation.

3. **Crossovers**
   A classic approach compares two SMAs:
   - A **bullish crossover** (short SMA rising above long SMA) can be interpreted as trend strengthening.
   - A **bearish crossover** can suggest trend weakening.
   
   Note: crossovers are essentially a timing overlay on a trend estimate—they can work, but they also create frequent whipsaws during sideways markets.

4. **Slope and distance**
   Traders may look at:
   - The **slope** of the SMA (e.g., positive vs. negative).
   - The **distance** between price and SMA to gauge momentum or extension. This is related to the idea of “overextension,” though SMA itself doesn’t define a statistical overbought/oversold level.

### Where interpretation breaks down
SMA is intentionally simple, which is both a strength and a limitation.

- **Lag is built in**
  Because SMA is an average over past prices, it reacts **after** moves occur. The longer the SMA window, the more lag you accept for smoother behavior.

- **Sideways markets can be noisy**
  In range-bound conditions, price oscillates around the SMA. That increases:
  - false crossover signals
  - “support/resistance” failures
  - whipsaw entries and exits

- **Averages are not guarantees**
  If you treat SMA as a deterministic level (e.g., “price will bounce off SMA”), you’ll eventually be wrong. SMA is a descriptive trend tool, not a law.

- **Choice of window matters**
  Different assets and regimes may favor different `N`. There’s no universal best SMA length; traders typically choose based on:
  - historical behavior
  - volatility and liquidity
  - their holding period and execution horizon

## Text Formula
Let `C_t` be the closing price on date `t`. For an SMA window of length `N`:

1. **SMA value**
   - `SMA_t(N) = (1/N) * Σ_{i=0 to N-1} C_{t-i}`

2. **Availability condition (practical detail)**
   - For any `t < N-1`, `SMA_t(N)` is undefined (often returned as `NaN` in implementations) because you don’t yet have `N` observations.

3. **Optional interpretation helpers (commonly computed alongside SMA)**
   - **SMA slope** over one bar:
     - `Slope_t(N) = SMA_t(N) - SMA_{t-1}(N)`
   - **Price vs. SMA spread**:
     - `Spread_t(N) = C_t - SMA_t(N)`
   - **Percent deviation from SMA**:
     - `PctDev_t(N) = (C_t / SMA_t(N)) - 1`

These helpers don’t change SMA itself, but they’re standard derived quantities used to interpret trend strength and extension.

## Python Code
```python
import pandas as pd

def compute_sma_features(df: pd.DataFrame, windows=(20, 50, 200)) -> pd.DataFrame:
    """
    Expected DataFrame columns:
      - 'symbol'
      - 'date'
      - 'open', 'high', 'low', 'close'

    Returns a DataFrame with SMA-related columns computed independently per symbol.
    For each window N in `windows`, this function computes:
      - 'sma_{N}': SMA of close over N periods
      - 'sma_slope_{N}': one-bar difference of the SMA
      - 'spread_{N}': close - SMA
      - 'pct_dev_{N}': (close / SMA) - 1
    """
    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Input df is missing required columns: {sorted(missing)}")

    # Work on a copy to avoid mutating caller data
    out = df.copy()

    # Ensure chronological order per symbol
    out = out.sort_values(["symbol", "date"])

    # Group by symbol so each symbol's SMA is independent
    g = out.groupby("symbol", group_keys=False)

    # Compute SMA and derived features for each requested window
    for N in windows:
        sma_col = f"sma_{N}"
        slope_col = f"sma_slope_{N}"
        spread_col = f"spread_{N}"
        pctdev_col = f"pct_dev_{N}"

        # SMA over the last N closes (NaN until there are enough rows)
        out[sma_col] = g["close"].transform(lambda s: s.rolling(window=N, min_periods=N).mean())

        # One-bar slope of the SMA (also NaN until SMA exists for that row)
        out[slope_col] = out.groupby("symbol")[sma_col].transform(lambda s: s.diff(1))

        # Spread and percent deviation from SMA
        out[spread_col] = out["close"] - out[sma_col]
        out[pctdev_col] = (out["close"] / out[sma_col]) - 1

    return out
```
```json
{ "model_code": "r6jq2vk9btx4", "topic": "Simple Moving Average", "timer_secs": 9.51, "tokens_in": 559, "tokens_out": 1422, "cost_tokens_in": 0.00011180, "cost_tokens_out": 0.00177750, "cost_tokens_tot": 0.00188930 }
```