# Bollinger Bands

## Overview
Bollinger Bands are a versatile, volatility-based technical analysis indicator designed to map an asset's price relative to its historical variance. Plotted directly over a price chart, the indicator consists of three lines: a central simple moving average (SMA) flanked by an upper and a lower band. The distance of the outer bands from the center line is determined by standard deviation, causing the channel to dynamically expand during periods of high market volatility and contract during periods of low volatility. Developed by technical analyst John Bollinger in the early 1980s, this tool is widely used by traders to identify overbought or oversold conditions, gauge trend strength, and anticipate imminent volatility breakouts.

## Details

### How the Indicator Works
The foundation of Bollinger Bands lies in the statistical concept of standard deviation, which measures the dispersion of a dataset relative to its mean. By default, the indicator uses a 20-period simple moving average as the middle band, with the upper and lower bands set two standard deviations above and below this average. 

Under a theoretical normal distribution, approximately 95% of price action should occur within these two standard deviations. While financial asset returns are notoriously non-normal and exhibit "fat tails" (leptokurtosis), the two-standard-deviation boundary still captures the vast majority of price action. When prices push outside these bands, it signals an extreme statistical deviation, suggesting the market is stretched.

### Key Trading Interpretations

Active traders primarily utilize Bollinger Bands to execute three core strategies:

#### 1. The Bollinger Squeeze
When market volatility drops to historically low levels, the upper and lower bands contract, tightening around the middle SMA. This structural compression is known as a "squeeze." Because periods of low volatility are invariably followed by periods of high volatility, a squeeze serves as a precursor to a major directional breakout. 

While the squeeze itself does not indicate the direction of the upcoming move, traders watch for a decisive candle close outside the compressed bands—accompanied by expanding volume—to signal the breakout's direction.

#### 2. The Bollinger Bounce (Mean Reversion)
In range-bound or sideways markets, the outer bands act as dynamic support and resistance levels. When price touches or penetrates the upper band, the asset is considered short-term overbought, and traders look for a reversal back toward the middle SMA. Conversely, a touch of the lower band indicates oversold conditions, prompting mean-reversion buy setups. 

#### 3. Riding the Bands (Trend Following)
During strong, sustained trends, the "bounce" strategy can fail catastrophically. In a powerful uptrend, price will frequently hug or "walk" up the upper band. Rather than indicating an overbought shorting opportunity, this behavior demonstrates strong upward momentum. Traders using trend-following systems will often enter long positions when price closes above the upper band, using the 20-period SMA as a trailing stop.

### Derived Indicators: %B and Bandwidth
To quantify Bollinger Band behavior for systematic trading, John Bollinger introduced two auxiliary indicators:
*   **%B (Percent B):** Measures where the current price is relative to the bands. A `%B` value of 1.0 represents the upper band, 0.5 represents the middle band, and 0.0 represents the lower band. Values above 1.0 or below 0.0 indicate price has broken outside the bands.
*   **Bandwidth:** Quantifies the normalized width of the bands. It is calculated by dividing the difference between the upper and lower bands by the middle band. Traders use Bandwidth to scan for historical lows to identify potential squeeze setups.

### Where Interpretation Breaks Down
Like all lagging indicators based on moving averages, Bollinger Bands have distinct limitations:
*   **Whipsaws in Squeezes:** False breakouts are common during a squeeze. Price may briefly break above the upper band, trapping breakout buyers, before reversing sharply to trend downward.
*   **Trending Markets:** Attempting to trade mean reversion (the "bounce") during a strong trend can lead to severe losses. In a runaway bull or bear market, price can remain extended outside the bands for prolonged periods.
*   **Lag:** Because the bands are anchored to a 20-period SMA, they react to price changes rather than predicting them. A sudden, violent price gap will not be immediately reflected in the bands' width, potentially delaying exit signals.

To mitigate these weaknesses, traders rarely use Bollinger Bands in isolation. They are typically paired with volume-based indicators (like On-Balance Volume) or momentum oscillators (like the Relative Strength Index) to confirm breakouts and identify bearish or bullish divergences.

## Text Formula

The calculation of Bollinger Bands involves three primary steps, followed by the derivation of `%B` and `Bandwidth`.

### 1. Middle Band (Simple Moving Average)
$$\text{Middle Band} = \text{SMA}(Close, N)$$

### 2. Upper and Lower Bands
$$\text{Upper Band} = \text{Middle Band} + (K \times \sigma)$$
$$\text{Lower Band} = \text{Middle Band} - (K \times \sigma)$$

### 3. Derived Metrics
$$\%B = \frac{Close - \text{Lower Band}}{\text{Upper Band} - \text{Lower Band}}$$
$$\text{Bandwidth} = \frac{\text{Upper Band} - \text{Lower Band}}{\text{Middle Band}}$$

Where:
*   $Close$ = The closing price of the current period.
*   $N$ = The lookback period for the moving average (typically 20).
*   $K$ = The standard deviation multiplier (typically 2).
*   $\sigma$ = The standard deviation of the closing price over the last $N$ periods:
$$\sigma = \sqrt{\frac{1}{N} \sum_{i=1}^{N} (Close_i - \text{Middle Band})^2}$$

## Python Code

```python
import numpy as np
import pandas as pd


def calculate_bollinger_bands(
    df: pd.DataFrame, period: int = 20, num_std: float = 2.0
) -> pd.DataFrame:
    """Calculates Bollinger Bands, %B, and Bandwidth for a multi-symbol DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame containing columns: 'symbol', 'date', 'open', 'high',
        'low', 'close'.
    period : int, default 20
        The lookback window for the simple moving average and standard
        deviation.
    num_std : float, default 2.0
        The multiplier for the standard deviation bands.

    Returns:
    --------
    pd.DataFrame
        The original DataFrame sorted by symbol and date, with the following
        additional columns:
        - 'middle_band': The 20-period simple moving average.
        - 'upper_band': The upper volatility band.
        - 'lower_band': The lower volatility band.
        - 'percent_b': The position of the close price relative to the bands.
        - 'bandwidth': The normalized width of the bands.
    """
    # Ensure the DataFrame is sorted chronologically within each symbol
    df_sorted = df.sort_values(by=["symbol", "date"]).copy()

    # Group by symbol to isolate calculations per asset
    grouped = df_sorted.groupby("symbol")["close"]

    # Calculate Middle Band (SMA) and Rolling Standard Deviation
    df_sorted["middle_band"] = grouped.transform(
        lambda x: x.rolling(window=period).mean()
    )
    rolling_std = grouped.transform(lambda x: x.rolling(window=period).std())

    # Calculate Upper and Lower Bands
    df_sorted["upper_band"] = df_sorted["middle_band"] + (
        num_std * rolling_std
    )
    df_sorted["lower_band"] = df_sorted["middle_band"] - (
        num_std * rolling_std
    )

    # Calculate the total width of the channel
    band_range = df_sorted["upper_band"] - df_sorted["lower_band"]

    # Calculate %B (handle division by zero if bands collapse to the same value)
    df_sorted["percent_b"] = np.where(
        band_range != 0,
        (df_sorted["close"] - df_sorted["lower_band"]) / band_range,
        0.5,  # Default to midpoint if range is zero
    )

    # Calculate Bandwidth (handle division by zero if middle band is zero)
    df_sorted["bandwidth"] = np.where(
        df_sorted["middle_band"] != 0,
        band_range / df_sorted["middle_band"],
        0.0,
    )

    return df_sorted
```
```json
{ "model_code": "f9hk3bx7lwn2", "topic": "Bollinger Bands", "timer_secs": 20.97, "tokens_in": 564, "tokens_out": 4079, "cost_tokens_in": 0.00084600, "cost_tokens_out": 0.03671100, "cost_tokens_tot": 0.03755700 }
```