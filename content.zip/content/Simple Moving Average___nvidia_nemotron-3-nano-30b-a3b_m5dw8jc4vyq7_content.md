# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a foundational technical indicator that smooths price data by averaging a fixed number of recent closing prices. On a chart it appears as a clean line that moves steadily with the underlying price, providing a visual reference for trend direction. Although the SMA has been used by traders for centuries, its modern formulation was popularized in the early 20th century with the rise of technical analysis in the West. Because it treats every price equally within the chosen window, the SMA is prized for its simplicity and ease of calculation, making it a staple on virtually every trading platform.

## Details
### Calculation Mechanics
The SMA is computed by summing the closing prices over a specified period and dividing by that period’s length. For a 20‑day SMA, the formula adds the last 20 closing prices and divides by 20. This process is repeated as each new bar forms, resulting in a rolling average that updates continuously. The calculation can be applied separately to each symbol in a multi‑symbol DataFrame, ensuring that the average reflects only the price history of that particular asset.

### Common Uses
Traders typically interpret the SMA in three complementary ways:

- **Trend identification** – Prices above the SMA suggest bullish momentum, while prices below indicate bearish pressure.
- **Support and resistance** – The SMA often acts as a dynamic level where price may bounce or stall.
- **Crossovers** – When a shorter‑term SMA crosses above a longer‑term SMA, it signals a potential buy; the opposite crossing signals a sell.

Bulleted lists help keep these points concise and memorable.

### When It Fails
Despite its popularity, the SMA has notable limitations:

- **Lag** – Because it is a backward‑looking average, the SMA reacts slowly to sudden price changes, which can delay entry or exit signals.
- **Whipsaws** – In choppy or sideways markets, the SMA can generate false crossovers that lead to unprofitable trades.
- **Uniform weighting** – Every price in the window contributes equally, so extreme outliers can distort the average without being filtered out.

Understanding these caveats prevents overreliance on the SMA as a standalone decision tool.

## Text Formula
For a window length **n**, the SMA is calculated as:

```
SMA_n = (C_1 + C_2 + ... + C_n) / n
```

where **C_i** represents the closing price of the i‑th bar in the window. When applied to multiple symbols, the same formula is computed independently for each symbol’s price series.

## Python Code
```python
# Simple Moving Average calculation for one or more symbols
# Input: DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
# Output: DataFrame with original columns plus SMA columns for each window

def calculate_sma(df, windows=None):
    """
    Compute Simple Moving Averages for each symbol independently.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Must contain at least ['symbol', 'date', 'close'].
    windows : list of int, optional
        List of window lengths. If None, defaults to [20, 50, 100, 200].
    
    Returns
    -------
    pandas.DataFrame
        Original DataFrame augmented with SMA columns named 'sma_{window}'.
    """
    # Default windows if none supplied
    if windows is None:
        windows = [20, 50, 100, 200]
    
    # Ensure deterministic ordering
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Prepare a copy to avoid modifying the original
    result = df.copy()
    
    # Compute SMA for each window size
    for w in windows:
        result[f'sma_{w}'] = (
            result.groupby('symbol')['close']
            .rolling(window=w, min_periods=1)
            .mean()
            .reset_index(level=0, drop=True)
        )
    
    return result
```
```json
{ "model_code": "m5dw8jc4vyq7", "topic": "Simple Moving Average", "timer_secs": 33.99, "tokens_in": 581, "tokens_out": 2839, "cost_tokens_in": 0.00002905, "cost_tokens_out": 0.00056780, "cost_tokens_tot": 0.00059685 }
```