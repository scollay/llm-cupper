# Clenow Momentum

## Overview
Clenow Momentum is a trend-following indicator developed by Andreas Clenow, detailed in his book *Stocks on the Move*. It measures the momentum of a security's price movement by fitting a linear regression to the logarithm of the closing prices over a specified lookback period. The slope of this regression line, annualized, represents the momentum of the trend.

On a chart, Clenow Momentum is typically displayed as a line below the price chart, showing the strength and direction of price momentum over time. A positive value indicates upward momentum, while a negative value indicates downward momentum.

## Details
Clenow Momentum is calculated by performing a linear regression on the natural logarithm of closing prices over a defined lookback window (commonly 90 days). The slope of the regression line reflects the rate of change in log price, which is then annualized to make it comparable across different time frames.

Traders use Clenow Momentum to identify securities with strong, consistent momentum — a key component of trend-following strategies. A high positive momentum suggests the asset is in a strong uptrend and may be a candidate for long positions. Conversely, negative momentum may signal a downtrend.

However, like all momentum indicators, Clenow Momentum can produce false signals in choppy or sideways markets. It also tends to lag during the early stages of a trend reversal, meaning traders may enter or exit positions later than optimal. As such, it is best used in combination with other tools such as volatility filters or breakout confirmation.

Another limitation is sensitivity to the lookback period. A shorter window may be more responsive but noisier, while a longer window smooths the signal but may delay entry and exit points.

## Text Formula
To calculate Clenow Momentum:

1. Take the natural logarithm of the closing prices over a specified period `n` (e.g., 90 days).
2. Perform a linear regression of the log prices against time (e.g., indexed from 0 to n-1).
3. Extract the slope of the regression line.
4. Annualize the slope by multiplying by the number of trading periods in a year (typically 252 for daily data).
5. The result is the Clenow Momentum.

Let `ln_close` be the natural log of closing prices over `n` periods, and `t` be the time index (0 to n-1). The slope `β` is calculated using linear regression:

```
β = Cov(t, ln_close) / Var(t)
```

Then, annualized momentum is:

```
Clenow Momentum = β * 252
```

## Python Code
```python
import pandas as pd
import numpy as np

def clenow_momentum(df, lookback=90):
    """
    Calculate Clenow Momentum for one or more symbols in a DataFrame.
    
    Parameters:
    df (pd.DataFrame): DataFrame with columns ['symbol', 'date', 'close']
    lookback (int): Number of periods to use for momentum calculation
    
    Returns:
    pd.DataFrame: Original DataFrame with added 'clenow_momentum' column
    """
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Calculate log of closing prices
    df['log_close'] = np.log(df['close'])
    
    # Create time index for regression (0 to lookback-1)
    df['time_index'] = df.groupby('symbol').cumcount()
    
    def calc_momentum(group):
        group = group.copy()
        group['clenow_momentum'] = np.nan
        
        for i in range(lookback - 1, len(group)):
            # Get the lookback window
            window = group.iloc[i - lookback + 1:i + 1]
            if len(window) < lookback:
                continue
            
            # Time index for regression
            t = np.arange(lookback)
            # Log prices
            y = window['log_close'].values
            
            # Calculate slope using linear regression
            slope = np.cov(t, y)[0, 1] / np.var(t)
            
            # Annualize the slope
            annualized_slope = slope * 252
            group.loc[group.index[i], 'clenow_momentum'] = annualized_slope
            
        return group
    
    result = df.groupby('symbol').apply(calc_momentum)
    
    # Clean up temporary columns
    result = result.drop(columns=['log_close', 'time_index'])
    
    return result.reset_index(drop=True)
```
```json
{ "model_code": "vw312t6jbr6k", "topic": "Clenow Momentum", "timer_secs": 25.26, "tokens_in": 564, "tokens_out": 971, "cost_tokens_in": 0.00012408, "cost_tokens_out": 0.00174780, "cost_tokens_tot": 0.00187188 }
```