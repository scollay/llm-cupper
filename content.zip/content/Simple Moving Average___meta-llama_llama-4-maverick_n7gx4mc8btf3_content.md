# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that smooths out price data by averaging it over a specified period. It appears on a chart as a line that follows the price action, helping traders identify trends and potential support or resistance levels. The SMA is a basic yet versatile tool that has been used by traders for decades, with its origins dating back to the early days of technical analysis.

## Details
The SMA works by calculating the average price of a security over a specified number of periods, which can be minutes, hours, days, or any other time frame. The most common periods used are 50, 100, and 200 days. As new price data becomes available, the oldest data point is dropped, and the new one is added, hence the term "moving" average. This process helps to reduce the noise in the price data and provides a clearer picture of the underlying trend.

Traders typically use the SMA to identify trends, with a rising SMA indicating an uptrend and a falling SMA indicating a downtrend. They also use SMAs to identify potential support and resistance levels. For example, if the price is above a rising SMA, it can be seen as a bullish sign, while a price below a falling SMA is considered bearish. The SMA can also be used to generate trading signals, such as when the price crosses above or below the SMA.

However, the SMA has its limitations. It is a lagging indicator, meaning it is based on past data, and therefore may not respond quickly to changes in the market. It can also be affected by outliers, such as a single day with an unusually high or low price. To mitigate these issues, traders often use multiple SMAs with different periods or combine the SMA with other indicators.

## Text Formula
To calculate the Simple Moving Average, the following formula is used:
SMA = (Sum of prices over n periods) / n

Where:
- SMA is the Simple Moving Average
- n is the number of periods
- Sum of prices is the sum of the closing prices (or other relevant prices) over the n periods

For example, to calculate a 50-day SMA, you would sum the closing prices of the last 50 days and divide by 50.

## Python Code
```python
import pandas as pd

def calculate_sma(df, column='close', window=50):
    """
    Calculate Simple Moving Average.

    Parameters:
    df (DataFrame): DataFrame containing symbol, date, open, high, low, close.
    column (str): Column to use for SMA calculation. Defaults to 'close'.
    window (int): Number of periods for SMA. Defaults to 50.

    Returns:
    DataFrame: Original DataFrame with 'sma' column added.
    """
    df['sma'] = df.groupby('symbol')[column].transform(lambda x: x.rolling(window).mean())
    return df

# Example usage assumes a DataFrame 'df' with columns: symbol, date, open, high, low, close.
# df = calculate_sma(df, window=50)  # Calculate 50-period SMA
# df = calculate_sma(df, column='close', window=200)  # Calculate 200-period SMA on 'close' prices
```
```json
{ "model_code": "n7gx4mc8btf3", "topic": "Simple Moving Average", "timer_secs": 14.31, "tokens_in": 561, "tokens_out": 684, "cost_tokens_in": 0.00008415, "cost_tokens_out": 0.00041040, "cost_tokens_tot": 0.00049455 }
```