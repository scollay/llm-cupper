# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that smooths out price data by creating a constantly updated average price over a specified number of periods. On a chart, the SMA appears as a single line that moves in the direction of the trend, lagging behind the actual price. It was not invented by a single person but has been in use since the early days of technical analysis, becoming a foundational tool for traders and analysts.

## Details
The Simple Moving Average calculates the arithmetic mean of a given set of closing prices over a specified time window. For example, a 10-day SMA sums up the closing prices for the past 10 days and divides the total by 10. As each new period ends, the oldest price is dropped from the calculation and the newest one is added.

Traders typically use SMAs to:
- Identify trend direction: When the price is above the SMA, the trend is considered bullish; when below, it is bearish.
- Spot potential support or resistance levels: The SMA line often acts as dynamic support during uptrends and resistance during downtrends.
- Generate trade signals: Crossovers between short-term and long-term SMAs (e.g., 50-day and 200-day) are commonly used to signal trend changes.

However, the SMA has limitations:
- **Lagging nature**: Because it is based on past prices, it reacts slowly to recent price changes, potentially causing late entry or exit points.
- **Whipsaw sensitivity**: In sideways markets, frequent crossovers can generate false signals.
- **Equal weighting**: All periods in the average are weighted equally, which may not reflect the importance of more recent data.

Despite these drawbacks, the SMA remains popular due to its simplicity and effectiveness in trending markets.

## Text Formula
The Simple Moving Average is calculated using the following formula:

```
SMA = (P1 + P2 + ... + Pn) / n
```

Where:
- `P1`, `P2`, ..., `Pn` are the closing prices for each of the `n` periods.
- `n` is the number of time periods included in the moving average.

For example, a 5-period SMA would be:

```
SMA(5) = (Close_1 + Close_2 + Close_3 + Close_4 + Close_5) / 5
```

Each subsequent value drops the oldest price and adds the newest one.

## Python Code
```python
import pandas as pd

def calculate_sma(df, window):
    """
    Calculate the Simple Moving Average (SMA) for one or more symbols.
    
    Parameters:
    df (pd.DataFrame): DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    window (int): Number of periods for the moving average
    
    Returns:
    pd.DataFrame: Original DataFrame with added 'sma_<window>' column
    """
    # Sort data to ensure proper order
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate SMA per symbol
    df[f'sma_{window}'] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=window, min_periods=window).mean()
    )
    
    return df
```
```json
{ "model_code": "vw312t6jbr6k", "topic": "Simple Moving Average", "timer_secs": 4.09, "tokens_in": 563, "tokens_out": 699, "cost_tokens_in": 0.00012386, "cost_tokens_out": 0.00125820, "cost_tokens_tot": 0.00138206 }
```