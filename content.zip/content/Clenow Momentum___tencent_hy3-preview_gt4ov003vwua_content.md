# Clenow Momentum

## Overview
Clenow Momentum is a trend-following momentum indicator developed by hedge fund manager Andreas Clenow, first published in his 2014 trading guide *Stocks on the Move: A Guide to Stock Market Analysis and Trading*. It appears as a single oscillating line plotted in a separate chart pane, with values that can be positive (upward trending momentum) or negative (downward trending momentum). Unlike simple momentum metrics that only measure the magnitude of recent price changes, Clenow Momentum adjusts raw trend strength by the consistency of the price move, filtering out noisy, poorly fitting trends.

## Details
Clenow Momentum is designed to quantify the strength and reliability of a price trend, making it a core tool for medium-term momentum rotation strategies. It addresses a key flaw in simple momentum indicators like Rate of Change (ROC): a large price jump followed by sideways chop can produce a high ROC value, even though the trend is not sustained. Clenow Momentum avoids this by requiring that price moves fit a consistent linear trend over the lookback period.

### Core Calculation Logic
The indicator is built on four sequential steps, applied over a user-defined lookback period (Clenow’s default is 90 trading days, ~4.5 months):
1. **Log price transformation**: Take the natural logarithm of all `close` prices in the lookback window. Log prices are used because they represent continuous compounded returns, which are additive and better reflect long-term growth than raw price levels.
2. **Linear regression**: Fit a simple linear regression model with time (sequential integers 0 to n-1 for the window) as the independent variable and log `close` prices as the dependent variable. The slope of this regression line represents the average daily log return of the asset over the lookback period.
3. **Annualization**: Multiply the daily regression slope by 252 (the standard number of trading days in a year) to get the annualized trend return.
4. **R-squared adjustment**: Multiply the annualized slope by the R-squared value of the regression. R-squared ranges from 0 to 1, measuring the proportion of price variance explained by the regression line. A value of 1 means the regression perfectly fits all price moves; 0 means the regression explains none of the variance. This step penalizes high raw momentum that comes from choppy, inconsistent price action.

### Common Interpretation
Traders use Clenow Momentum primarily for two use cases:
- **Asset ranking**: For momentum rotation strategies, traders calculate Clenow Momentum for all assets in a universe (e.g., S&P 500 constituents), sort them by the indicator’s value, and allocate capital to the top 10-20% of assets with the highest positive values. Clenow’s original strategy rebalances this portfolio monthly. Positive values indicate upward trending momentum, with higher values signaling stronger, more consistent uptrends. Negative values indicate downward trending momentum, with more negative values signaling stronger, more consistent downtrends.
- **Signal generation**: Some traders use zero crossovers as entry/exit signals: buy when Clenow Momentum crosses above 0, sell or short when it crosses below 0. Others use absolute thresholds (e.g., only take long positions if Clenow Momentum is above 0.2) to avoid weak, low-conviction uptrends. Divergences between price and Clenow Momentum can also signal trend weakness: if price makes a new high while Clenow Momentum makes a lower high, the uptrend may be losing steam even if the indicator remains positive.

Clenow Momentum is not a mean-reversion indicator: it is not used to identify overbought or oversold conditions, unlike the Relative Strength Index (RSI) or Stochastic Oscillator. It is strictly a trend-strength tool for momentum-focused strategies.

### Key Limitations
Interpretation of Clenow Momentum breaks down in several common scenarios:
1. **Lagging nature**: Like all regression-based indicators, Clenow Momentum uses historical data and cannot predict future price moves. It will always confirm a trend after it has already begun, leading to late entries in fast-moving markets.
2. **Lookback sensitivity**: The indicator is highly sensitive to the lookback period. The default 90-day window is optimized for medium-term strategies; shorter windows (30-60 days) are more responsive but noisier, while longer windows (180+ days) are smoother but slower to react to trend changes.
3. **Weak early trends**: In the early stages of a new trend, the R-squared value will be low even if momentum is building, as there are not enough data points to confirm a consistent linear move. This can cause traders to miss the start of strong trends.
4. **Sideways markets**: In range-bound, choppy markets, R-squared values will be near 0 for all assets, producing Clenow Momentum values near 0. The indicator will not generate useful signals until a clear, sustained trend emerges.
5. **No volatility adjustment**: Clenow Momentum does not account for price volatility. An asset with high annualized momentum and extreme price swings will receive the same score as a lower-volatility asset with identical regression and R-squared values, potentially leading to overallocation to high-risk positions.
6. **Constant price edge case**: If an asset’s price is constant over the lookback period, the regression slope will be 0, and R-squared is undefined. Most implementations set R-squared to 0 in this scenario, producing a Clenow Momentum value of 0.

## Text Formula
The following variables are defined for a single lookback window of `n` trading days (default 90):
- `t`: Array of sequential integers representing relative time steps in the window: `t = [0, 1, 2, ..., n-1]`
- `P`: Array of `close` prices over the window
- `ln(P)`: Natural logarithm of each value in `P`
- `β`: Slope coefficient of the linear regression of `ln(P)` against `t`
- `α`: Intercept coefficient of the linear regression of `ln(P)` against `t`
- `R²`: Coefficient of determination (R-squared) of the regression
- `T`: Number of trading days per year (default 252)

### Step 1: Calculate Regression Slope (β)
The slope of the regression line is the sample covariance between `t` and `ln(P)` divided by the sample variance of `t`:
`β = Cov(t, ln(P)) / Var(t)`

Where:
- `Cov(t, ln(P))` = `Σ[(t_i - mean(t))(ln(P)_i - mean(ln(P)))] / (n-1)`
- `Var(t)` = `Σ(t_i - mean(t))² / (n-1)`

### Step 2: Calculate R-Squared (R²)
R-squared measures the proportion of variance in `ln(P)` explained by the regression line:
`R² = 1 - (SS_res / SS_tot)`

Where:
- `SS_res` (sum of squared residuals) = `Σ(ln(P)_i - (β * t_i + α))²`
- `SS_tot` (total sum of squares) = `Σ(ln(P)_i - mean(ln(P)))²`

### Step 3: Annualize the Slope
Convert the daily slope to an annualized value by multiplying by the number of trading days per year:
`Annualized Slope = β *
```json
{ "model_code": "gt4ov003vwua", "topic": "Clenow Momentum", "timer_secs": 147.00, "tokens_in": 566, "tokens_out": 10000, "cost_tokens_in": 0.00003566, "cost_tokens_out": 0.00210000, "cost_tokens_tot": 0.00213566 }
```