# Bollinger Bands

## Overview

Bollinger Bands are a volatility-based technical indicator consisting of three lines plotted on a price chart: a simple moving average in the middle, with an upper band and lower band positioned at a fixed number of standard deviations above and below that average. Created by John Bollinger in the 1980s, the indicator appears as a dynamic envelope around price action that expands during volatile periods and contracts during quiet ones. Bollinger Bands are among the most widely used indicators in technical analysis, applied across all timeframes and asset classes.

## Details

**How Bollinger Bands Work**

Bollinger Bands measure volatility by calculating how far price typically deviates from its average. The middle band is a simple moving average (SMA), most commonly set to 20 periods. The upper and lower bands sit at a distance equal to two standard deviations of price movement above and below that average.

The logic is intuitive: when volatility increases, price swings become larger, so the bands widen. When volatility decreases, price action tightens, and the bands narrow. This dynamic adjustment makes Bollinger Bands responsive to changing market conditions without requiring manual adjustment.

**Interpreting Bollinger Bands**

Traders use Bollinger Bands in several ways:

- **Mean reversion signals**: Price that touches or crosses the upper band may be considered overbought; price at the lower band may be oversold. Many traders interpret these extremes as signals to fade the move or expect a reversal toward the middle band.

- **Volatility expansion and contraction**: A squeeze—when the bands narrow significantly—often precedes a breakout. Conversely, band expansion signals heightened volatility and potentially stronger directional moves.

- **Support and resistance**: The bands themselves often act as dynamic support (lower band) and resistance (upper band), with price bouncing between them during ranging markets.

- **Trend confirmation**: In strong uptrends, price may "walk" along the upper band; in downtrends, it may hug the lower band. This behavior can confirm trend strength.

**Limitations and Breakdown Points**

Despite their popularity, Bollinger Bands have important limitations:

- **Lagging nature**: The indicator is based on a moving average, which lags price. By the time bands signal a reversal, price may have already moved significantly.

- **Whipsaws in choppy markets**: During sideways or choppy price action, bands can generate false signals as price oscillates between them without clear directional intent.

- **Parameter sensitivity**: The standard 20-period SMA and 2 standard deviations work well in many contexts but are arbitrary. Different markets, timeframes, and trading styles may benefit from different settings, and changing parameters can lead to curve-fitting.

- **No directional bias**: Bollinger Bands measure volatility and extremes but do not inherently indicate direction. A band touch does not guarantee reversal; price can continue in the same direction.

- **Overbought/oversold confusion**: Price can remain at or beyond the bands for extended periods during strong trends, making "overbought" or "oversold" signals unreliable as standalone trade triggers.

**Best Practices**

Experienced traders typically use Bollinger Bands as one tool among many, combining them with trend analysis, volume, support/resistance levels, or other indicators. The squeeze setup—waiting for bands to narrow and then trading the breakout—is one of the more reliable applications. Bands are also useful for setting dynamic stop-loss levels or profit targets based on volatility.

## Text Formula

**Bollinger Bands Calculation:**

1. **Middle Band (SMA):**
   - `Middle Band = SMA(close, n)`
   - Where `n` is the period (typically 20)

2. **Standard Deviation:**
   - `StdDev = standard deviation of close over n periods`

3. **Upper Band:**
   - `Upper Band = Middle Band + (k × StdDev)`
   - Where `k` is the number of standard deviations (typically 2)

4. **Lower Band:**
   - `Lower Band = Middle Band − (k × StdDev)`

**Example with default parameters (n=20, k=2):**
- Calculate the 20-period simple moving average of closing prices.
- Calculate the 20-period standard deviation of closing prices.
- Upper Band = SMA + (2 × StdDev)
- Lower Band = SMA − (2 × StdDev)

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_bollinger_bands(df, period=20, num_std=2):
    """
    Calculate Bollinger Bands for a DataFrame containing one or more symbols.
    
    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame with columns: symbol, date, open, high, low, close
    period : int
        Period for the simple moving average (default 20)
    num_std : float
        Number of standard deviations for band width (default 2)
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with added columns:
        - bb_middle: Middle band (SMA)
        - bb_upper: Upper band
        - bb_lower: Lower band
        - bb_width: Distance between upper and lower bands
        - bb_position: Position of close relative to bands (0-1 scale)
    """
    
    df = df.copy()
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Group by symbol to handle multiple symbols independently
    grouped = df.groupby('symbol')
    
    # Initialize output columns
    df['bb_middle'] = np.nan
    df['bb_upper'] = np.nan
    df['bb_lower'] = np.nan
    df['bb_width'] = np.nan
    df['bb_position'] = np.nan
    
    for symbol, group_df in grouped:
        symbol_idx = group_df.index
        
        # Calculate simple moving average (middle band)
        sma = group_df['close'].rolling(window=period).mean()
        
        # Calculate standard deviation
        std_dev = group_df['close'].rolling(window=period).std()
        
        # Calculate upper and lower bands
        upper_band = sma + (num_std * std_dev)
        lower_band = sma - (num_std * std_dev)
        
        # Calculate band width
        band_width = upper_band - lower_band
        
        # Calculate position: where close sits between lower and upper band
        # 0 = at lower band, 1 = at upper band, 0.5 = at middle
        band_position = (group_df['close'] - lower_band) / band_width
        band_position = band_position.clip(0, 1)  # Clip to 0-1 range
        
        # Assign values back to original dataframe
        df.loc[symbol_idx, 'bb_middle'] = sma.values
        df.loc[symbol_idx, 'bb_upper'] = upper_band.values
        df.loc[symbol_idx, 'bb_lower'] = lower_band.values
        df.loc[symbol_idx, 'bb_width'] = band_width.values
        df.loc[symbol_idx, 'bb_position'] = band_position.values
    
    return df
```
```json
{ "model_code": "x2vp7k8nm4rj", "topic": "Bollinger Bands", "timer_secs": 13.64, "tokens_in": 610, "tokens_out": 1752, "cost_tokens_in": 0.00061000, "cost_tokens_out": 0.00876000, "cost_tokens_tot": 0.00937000 }
```