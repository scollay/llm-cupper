# T3 Moving Average

## Overview
The T3 Moving Average is a sophisticated trend-following indicator designed to provide a smoother curve than traditional moving averages while significantly reducing the lag typically associated with price smoothing. On a chart, it appears as a single, continuous line overlaid directly onto price action, much like a standard Simple Moving Average (SMA) or Exponential Moving Average (EMA). The indicator was created by technical analyst Tim Tillson and introduced to the public in 1998 through an article in *Technical Analysis of Stocks & Commodities* magazine. 

## Details

### The Mechanics of T3
Traditional moving averages force traders into a frustrating compromise: choose a short lookback period to make the indicator responsive (which introduces false signals and "noise"), or choose a long lookback period to smooth out the noise (which introduces significant lag). 

Tillson sought to solve this dilemma by building upon the concept of the Double Exponential Moving Average (DEMA). A standard DEMA attempts to remove lag by doubling a standard EMA and then subtracting a smoothed version of that EMA to correct for the offset. Tillson generalized this mathematical concept, introducing a variable he called the "volume factor" (often denoted as `a` or `v`) to control exactly how aggressively the lag is removed. 

The T3 indicator takes this Generalized DEMA and runs it through three complete iterations. Because the formula requires calculating an EMA of an EMA of an EMA, all the way down to six levels of smoothing, the resulting line is remarkably smooth. However, because of Tillson's proprietary weighting scheme, the mathematical blending cancels out the severe lag that would normally paralyze a six-times-smoothed moving average.

### The Role of the Volume Factor
The volume factor, `a`, is the engine of the T3 indicator. It dictates how aggressively the indicator attempts to predict and align with the underlying EMA curve. 

*   **Default Setting:** The standard value for `a` is 0.7. Tillson found this to be the optimal sweet spot for balancing smoothness and responsiveness.
*   **Lower Bounds:** If `a` is set to 0, the lag-canceling mechanics are disabled, and the T3 simply becomes a standard Triple Exponential Moving Average (EMA3), which carries significant lag.
*   **Upper Bounds:** If `a` is set to 1.0, the indicator operates as a pure, fully aggressive DEMA cubed. 

### Trading Interpretations
Active traders utilize the T3 Moving Average in several distinct ways:

*   **Trend Identification:** Because the T3 is exceptionally smooth, its slope is a highly reliable indicator of the prevailing trend. An upward-sloping T3 indicates a bullish environment, while a downward-sloping T3 indicates a bearish environment. Traders often stay in positions as long as the slope remains unchanged, ignoring minor price fluctuations.
*   **Price Crossovers:** Traders may use the price crossing above the T3 line as a buy signal, and price crossing below as a sell or short signal. Because of the reduced lag, these crossover signals often occur earlier than they would with a standard SMA or EMA.
*   **Dual T3 Systems:** A popular strategy involves plotting a "fast" T3 (e.g., a 5-period or 8-period) alongside a "slow" T3 (e.g., a 21-period). A bullish crossover occurs when the fast T3 crosses above the slow T3, providing a clear, objective entry trigger.
*   **Dynamic Support and Resistance:** In strongly trending markets, the T3 line frequently acts as a dynamic floor (support) or ceiling (resistance) for price pullbacks.

### Limitations and Breakdowns
Despite its mathematical elegance, the T3 Moving Average is not infallible and breaks down under specific market conditions:

*   **Whipsaws in Ranging Markets:** Like all moving averages, the T3 is inherently a trend-following tool. In sideways, choppy, or trendless markets, the indicator will flatten out, and price will frequently cross back and forth over the line. This generates false signals, or "whipsaws," which can quickly erode a trader's capital.
*   **Overshooting:** The volume factor `a` is highly sensitive. If a trader adjusts `a` too high (typically above 0.8 or 0.9), the aggressive lag-canceling math can cause the T3 line to actually overshoot the price data during sharp reversals. This creates artificial peaks and valleys on the chart that do not exist in the underlying price action, leading to confusing or premature signals.
*   **Lag is Reduced, Not Eliminated:** While T3 is vastly superior to an SMA in terms of responsiveness, it still relies on historical data. During sudden, massive volatility spikes or black-swan events, the T3 will still trail behind the actual price action.

## Text Formula

Calculating the T3 Moving Average requires a specific lookback period ($n$) and a volume factor ($a$). The calculation is performed in three distinct steps.

**Step 1: Calculate six levels of Exponential Moving Averages (EMAs)**
*   $e1 = EMA(Close, n)$
*   $e2 = EMA(e1, n)$
*   $e3 = EMA(e2, n)$
*   $e4 = EMA(e3, n)$
*   $e5 = EMA(e4, n)$
*   $e6 = EMA(e5, n)$

**Step 2: Calculate the four weighting constants based on the volume factor ($a$)**
*   $c1 = -a^3$
*   $c2 = 3a^2 + 3a^3$
*   $c3 = -6a^2 - 3a - 3a^3$
*   $c4 = 1 + 3a + a^3 + 3a^2$

*(Note: To verify the math, the sum of $c1$, $c2$, $c3$, and $c4$ will always equal exactly 1.0).*

**Step 3: Calculate the final T3 value**
*   $T3 = (c1 \times e6) + (c2 \times e5) + (c3 \times e4) + (c4 \times e3)$

## Python Code

```python
import pandas as pd

def calculate_t3(df: pd.DataFrame, period: int = 5, a: float = 0.7) -> pd.DataFrame:
    """
    Calculates the Tillson T3 Moving Average for a given DataFrame.
    
    Expected DataFrame format:
    The input DataFrame must contain the following columns:
    'symbol', 'date', 'open', 'high', 'low', 'close'
    
    The function groups by 'symbol' to ensure calculations are strictly 
    independent for each asset, preventing data leakage between symbols.
    
    Parameters:
    df (pd.DataFrame): The input dataframe containing price data.
    period (int): The lookback period for the EMAs (default is 5).
    a (float): The volume factor / smoothing constant (default is 0.7).
    
    Returns:
    pd.DataFrame: The original dataframe with a new 't3' column added.
    """
    
    # Create a copy to avoid modifying the original dataframe directly
    result_df = df.copy()
    
    # Define the core T3 logic to be applied to each symbol's close price
    def t3_logic(series: pd.Series, n: int, v_factor: float) -> pd.Series:
        # Step 1: Calculate the 6 levels of EMAs
        # adjust=False is used to match standard charting platform EMA calculations
        e1 = series.ewm(span=n, adjust=False).mean()
        e2 = e1.ewm(span=n, adjust=False).mean()
        e3 = e2.ewm(span=n, adjust=False).mean()
        e4 = e3.ewm(span=n, adjust=False).mean()
        e5 = e4.ewm(span=n, adjust=False).mean()
        e6 = e5.ewm(span=n, adjust=False).mean()
        
        # Step 2: Calculate the weighting constants
        c1 = -(v_factor ** 3)
        c2 = (3 * (v_factor ** 2)) + (3 * (v_factor ** 3))
        c3 = -(6 * (v_factor ** 2)) - (3 * v_factor) - (3 * (v_factor ** 3))
        c4 = 1 + (3 * v_factor) + (v_factor ** 3) + (3 * (v_factor ** 2))
        
        # Step 3: Combine to create the T3 line
        t3_line = (c1 * e6) + (c2 * e5) + (c3 * e4) + (c4 * e3)
        
        return t3_line

    # Apply the logic grouped by symbol to handle multi-symbol dataframes safely
    result_df['t3'] = result_df.groupby('symbol')['close'].transform(
        lambda x: t3_logic(x, period, a)
    )
    
    return result_df
```
```json
{ "model_code": "t5pz4nm8vqj7", "topic": "T3", "timer_secs": 45.98, "tokens_in": 565, "tokens_out": 5968, "cost_tokens_in": 0.00113000, "cost_tokens_out": 0.07161600, "cost_tokens_tot": 0.07274600 }
```