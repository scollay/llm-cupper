# T3

## Overview
The T3 moving average is a smoothing filter designed to reduce lag while preserving responsiveness to price changes. Developed by Tim Tillson in the early 1990s, it appears on a price chart as a single line that tracks the underlying series more closely than a simple or exponential moving average of the same period. Traders use T3 to identify trend direction, potential support/resistance levels, and to generate crossover signals with price or other moving averages.

## Details
### How T3 works
T3 applies a generalized double exponential moving average (GD) three times in succession. The GD itself blends an exponential moving average (EMA) with a smoothed version of that EMA, controlled by a volume factor *v* (typically 0.618 – 0.7). By nesting GD three times, T3 achieves a higher‑order smoothing that cancels out much of the lag inherent in lower‑order averages while still reacting quickly to new information.

The calculation proceeds as follows for a chosen look‑back period *n* and factor *v*:

1. Compute six successive EMAs of the input series (usually the closing price):
   - E1 = EMA(price, n)  
   - E2 = EMA(E1, n)  
   - E3 = EMA(E2, n)  
   - E4 = EMA(E3, n)  
   - E5 = EMA(E4, n)  
   - E6 = EMA(E5, n)

2. Derive four coefficients that depend only on *v*:
   - c1 = –v³  
   - c2 = 3v² + 3v³  
   - c3 = –6v² – 3v – 3v³  
   - c4 = 1 + 3v + v³ + 3v²

3. Combine the EMAs linearly:
   \[
   \text{T3} = c1·E6 + c2·E5 + c3·E4 + c4·E3
   \]

### Interpretation
Traders treat T3 much like any other moving average:
- **Trend identification** – When price sits above a rising T3, the bias is upward; below a falling T3 suggests a downtrend.
- **Crossovers** – A bullish signal occurs when price crosses above T3 (or when a faster MA crosses above T3); a bearish signal when the opposite occurs.
- **Support/resistance** – In strong trends, T3 often acts as dynamic support (in an uptrend) or resistance (in a downtrend).

### Limitations
- **Parameter sensitivity** – The chosen *n* and *v* significantly affect smoothness and lag. Too small *n* yields a noisy line; too large *n* defeats the purpose of reduced lag. The factor *v* must stay in the (0, 1) range; values near 1 produce almost no extra smoothing, while values near 0 can over‑smooth and introduce lag.
- **Whipsaws in choppy markets** – Like all moving averages, T3 can generate false signals when price oscillates around a flat trend.
- **Not a standalone system** – T3 is best used alongside other tools (e.g., momentum oscillators, volume analysis) to filter signals.

## Text Formula
Given a price series *Pₜ* (typically close), look‑back *n*, and volume factor *v*:

```
E1ₜ = EMA(Pₜ, n)
E2ₜ = EMA(E1ₜ, n)
E3ₜ = EMA(E2ₜ, n)
E4ₜ = EMA(E3ₜ, n)
E5ₜ = EMA(E4ₜ, n)
E6ₜ = EMA(E5ₜ, n)

c1 = -v³
c2 = 3v² + 3v³
c3 = -6v² - 3v - 3v³
c4 = 1 + 3v + v³ + 3v²

T3ₜ = c1·E6ₜ + c2·E5ₜ + c3·E4ₜ + c4·E3ₜ
```

Where EMA(x, n) denotes the exponential moving average of series *x* with span *n* (using the recursive formula EMAₜ = α·xₜ + (1‑α)·EMAₜ₋₁, α = 2/(n+1)).

## Python Code
```python
import pandas as pd

def compute_t3(df: pd.DataFrame, n: int = 14, v: float = 0.7) -> pd.DataFrame:
    """
    Calculate the T3 moving average for each symbol in the dataframe.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
        The dataframe can hold data for one or multiple symbols.
    n : int, default 14
        Look‑back period for the underlying EMAs.
    v : float, default 0.7
        Volume factor (0 < v < 1) controlling the degree of smoothing.

    Returns
    -------
    pd.DataFrame
        Input dataframe with an additional column 'T3' containing the indicator
        values aligned with the original rows.
    """
    # Make a copy to avoid SettingWithCopyWarning on slices
    df = df.copy()

    # Define a function to compute T3 for a single series (e.g., close prices)
    def _t3_series(series: pd.Series) -> pd.Series:
        # Helper for EMA with given span
        def ema(x, span):
            return x.ewm(span=span, adjust=False).mean()

        # Successive EMAs
        e1 = ema(series, n)
        e2 = ema(e1, n)
        e3 = ema(e2, n)
        e4 = ema(e3, n)
        e5 = ema(e4, n)
        e6 = ema(e5, n)

        # Coefficients based on v
        c1 = -v ** 3
        c2 = 3 * v ** 2 + 3 * v ** 3
        c3 = -6 * v ** 2 - 3 * v - 3 * v ** 3
        c4 = 1 + 3 * v + v ** 3 + 3 * v ** 2

        # Linear combination
        return c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3

    # Apply the calculation per symbol
    df['T3'] = df.groupby('symbol')['close'].transform(_t3_series)

    return df
```

**Usage example**

```python
# Assuming `price_df` already contains the required columns
price_df_with_t3 = compute_t3(price_df, n=14, v=0.618)
```

The function respects each symbol’s independence via `groupby`, computes the six nested EMAs, derives the coefficients from the supplied *v*, and returns the T3 value for every row. The result can be plotted directly against price or used in further signal generation logic.
```json
{ "model_code": "x6kp3hr9bln2", "topic": "T3", "timer_secs": 10.81, "tokens_in": 580, "tokens_out": 2204, "cost_tokens_in": 0.00005220, "cost_tokens_out": 0.00099180, "cost_tokens_tot": 0.00104400 }
```