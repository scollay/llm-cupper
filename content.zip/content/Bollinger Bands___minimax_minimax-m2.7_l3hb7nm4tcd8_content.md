# Bollinger Bands

## Overview
Bollinger Bands are a technical‑analysis tool that plots three lines around a security’s price: a simple moving average (SMA) of the close price and two bands placed a fixed number of standard deviations above and below the SMA. The bands expand and contract with changes in volatility, giving traders a visual sense of where price is relative to recent trading ranges. The indicator was introduced by John Bollinger in the early 1980s.

## Details

### Calculation
- **Middle Band** – a 20‑period SMA of the closing price (the period can be adjusted; 20 is the most common default).  
- **Upper Band** – Middle Band + ( k × σ), where σ is the 20‑period standard deviation of the close and k is typically 2.  
- **Lower Band** – Middle Band − ( k × σ).  
- **Bandwidth** – (Upper − Lower) / Middle; measures the width of the bands as a fraction of the middle line.  
- **%B** – (Close − Lower) / (Upper − Lower); quantifies where the close sits within the bands (0 = at the lower band, 1 = at the upper band).

### Interpretation
- **Overbought/Oversold**: When price touches or exceeds the upper band, some traders view it as a potential overbought condition; a touch of the lower band may signal oversold conditions.  
- **Volatility**: Wide bands indicate high volatility; narrow bands suggest low volatility or a potential “squeeze” that may precede a sharp move.  
- **Trend Confirmation**: In a strong uptrend, price often rides the upper band; in a downtrend, price tends to stay near the lower band.  
- **Mean‑Reversion**: The bands act as dynamic support/resistance; price returning toward the middle band after a band touch can be seen as a pull‑back within the trend.

### Limitations
- **Reactive, Not Predictive**: Bands reflect past price behavior; they do not forecast future direction.  
- **False Signals in Trending Markets**: During strong trends, price can remain against a band for extended periods, making “overbought/oversold” calls misleading.  
- **Parameter Sensitivity**: The default 20‑period SMA and 2‑σ multiplier may not suit all assets; shorter windows increase sensitivity, longer windows smooth noise.  
- **No Price‑Context**: %B and bandwidth alone ignore fundamental drivers; they work best when combined with other analysis (e.g., volume, momentum indicators).

## Text Formula
Given a series of closing prices \(C_1, C_2, \dots, C_N\) over \(N\) periods:

1. **Middle Band (SMA)**  
\[
\text{SMA}_N = \frac{1}{N}\sum_{i=1}^{N} C_i
\]

2. **Standard Deviation** (population)  
\[
\sigma_N = \sqrt{\frac{1}{N}\sum_{i=1}^{N}\bigl(C_i - \text{SMA}_N\bigr)^2}
\]

3. **Upper Band**  
\[
\text{Upper}_N = \text{SMA}_N + k \times \sigma_N \quad (k = 2 \text{ by default})
\]

4. **Lower Band**  
\[
\text{Lower}_N = \text{SMA}_N - k \times \sigma_N
\]

5. **Bandwidth**  
\[
\text{Bandwidth} = \frac{\text{Upper}_N - \text{Lower}_N}{\text{SMA}_N}
\]

6. **%B**  
\[
\%B = \frac{C_{\text{current}} - \text{Lower}_N}{\text{Upper}_N - \text{Lower}_N}
\]

## Python Code
```python
import pandas as pd
import numpy as np

def bollinger_bands(df: pd.DataFrame,
                    window: int = 20,
                    num_std: float = 2.0,
                    price_col: str = 'close') -> pd.DataFrame:
    """
    Calculate Bollinger Bands, Bandwidth, and %B for each symbol in `df`.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
    window : int, optional
        Number of periods for SMA and rolling std (default 20).
    num_std : float, optional
        Number of standard deviations for band offset (default 2.0).
    price_col : str, optional
        Column name to use for price (default 'close').

    Returns
    -------
    pd.DataFrame
        Same rows as `df` with additional columns:
        middle_band, upper_band, lower_band, bandwidth, percent_b.
        Values before `window` periods are NaN for each symbol.
    """
    # Ensure input is sorted by symbol and date for correct rolling windows
    df = df.sort_values(['symbol', 'date']).copy()

    # Helper to compute Bollinger values for a single symbol
    def _calc(group: pd.DataFrame) -> pd.DataFrame:
        # Rolling simple moving average (middle band)
        sma = group[price_col].rolling(window=window, min_periods=window).mean()

        # Rolling standard deviation (population std, ddof=0)
        std = group[price_col].rolling(window=window, min_periods=window).std(ddof=0)

        # Upper and lower bands
        upper = sma + num_std * std
        lower = sma - num_std * std

        # Bandwidth and %B
        bandwidth = (upper - lower) / sma
        percent_b = (group[price_col] - lower) / (upper - lower)

        # Assign back to the group DataFrame
        group['middle_band'] = sma
        group['upper_band'] = upper
        group['lower_band'] = lower
        group['bandwidth'] = bandwidth
        group['percent_b'] = percent_b
        return group

    # Apply per symbol; group_keys=False avoids adding a multi‑index level
    result = df.groupby('symbol', group_keys=False).apply(_calc)

    # Restore original order if needed (optional)
    result = result.sort_index()
    return result
```
```json
{ "model_code": "l3hb7nm4tcd8", "topic": "Bollinger Bands", "timer_secs": 6.77, "tokens_in": 587, "tokens_out": 2656, "cost_tokens_in": 0.00017610, "cost_tokens_out": 0.00318720, "cost_tokens_tot": 0.00336330 }
```