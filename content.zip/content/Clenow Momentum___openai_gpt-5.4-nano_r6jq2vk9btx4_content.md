# Clenow Momentum

## Overview
Clenow Momentum is a momentum indicator built to help traders identify strengthening or weakening trends by measuring the tendency of price to keep moving in one direction, then optionally smoothing and scaling that movement for better chart readability. It typically appears as an oscillator-like line under the price chart, often compared to a zero line and/or a signal line.

The indicator is commonly attributed to Steve Clenow (author and active market educator) and gained popularity in trading circles in the context of trend-following and mean-reversion blends—especially among traders who like momentum signals that are less “noisy” than raw returns.

## Details
Clenow Momentum is best understood as a *two-step* idea:

1. **Convert price into a momentum series** using a lookback window.  
2. **Transform that momentum into a bounded oscillator** by comparing the momentum to its recent range, producing a value that behaves predictably across different regimes.

### 1) The momentum component
For each bar, you compute the **rate of change over `n` periods** (often implemented as a percent change or a relative difference). Conceptually:

- If price is rising over the last `n` bars, momentum is positive.
- If price is falling over the last `n` bars, momentum is negative.
- If price is flat-ish, momentum hovers near zero.

This raw momentum already helps, but it can be difficult to compare across assets and time because its scale depends on volatility and price level.

### 2) The ranking/normalization component
To make the indicator more comparable, Clenow’s approach normalizes momentum by looking at the **highest and lowest values of the momentum series over a longer window** (commonly `m` periods).

The result is an oscillator that roughly answers:

- “Where is today’s momentum relative to the last `m` momentum observations?”
- Values near the top of the range suggest momentum is unusually strong for that asset/period.
- Values near the bottom suggest unusually weak (bearish) momentum.

In many charting implementations, this normalization yields a scale that runs from **-100 to +100** (or equivalently 0 to 100 if you offset it). The commonly used interpretation is centered around **zero** (bullish vs bearish).

### How traders typically interpret it
Because Clenow Momentum is normalized and behaves like a bounded oscillator, traders often use it in two complementary ways:

- **Direction / regime**
  - Values **above 0** imply momentum is positive relative to recent history.
  - Values **below 0** imply momentum is negative relative to recent history.

- **Signal (crossings and extremes)**
  - **Crossing above 0** can be treated as a bullish “momentum regime shift.”
  - **Crossing below 0** can be treated as a bearish “momentum regime shift.”
  - Traders may also watch for momentum values approaching **+100** (very strong) or **-100** (very weak) and use those extremes to time entries, exits, or risk reduction.

Because it’s normalized, “extreme” values tend to be more meaningful than raw returns alone.

### Where interpretation breaks down
Clenow Momentum is not magic; several failure modes are common:

1. **Range-bound markets**
   - In choppy conditions, momentum can oscillate around zero frequently.
   - That may generate many signals that look correct “on paper” but fail in practice due to noise and mean reversion.

2. **Sudden volatility shocks**
   - The normalization window can suddenly expand the observed momentum range.
   - If price gaps or whipsaws, the oscillator may lag or “stick” until it re-estimates the min/max range.

3. **Parameter sensitivity**
   - The choice of `n` (momentum lookback) and `m` (normalization lookback) matters.
   - Short `n` and long `m` can overemphasize relative positioning; long `n` can blunt responsiveness.

4. **No inherent protection against trend reversals**
   - Momentum-based indicators can remain positive while price starts to revert, especially if the normalization still reflects recent highs in momentum.
   - Traders should pair momentum with a risk plan (stops, time-based exits, or trend filters).

### Practical usage notes
Active traders often combine Clenow Momentum with:

- A **trend filter** (e.g., only trade long when a broader trend measure agrees).
- A **volatility/risk framework** (position sizing, stop placement).
- A **confirmation rule** (e.g., wait for a close above/below zero rather than intrabar signals).

## Text Formula
Let:
- `C_t` be the close at time `t`
- `n` be the momentum lookback
- `m` be the normalization lookback

**Step 1: Raw momentum**
- Using percent change:
  - `M_t = (C_t / C_{t-n} - 1) * 100`

**Step 2: Rolling min/max of momentum**
- `Mmin_t = min(M_{t-m+1} ... M_t)`
- `Mmax_t = max(M_{t-m+1} ... M_t)`

**Step 3: Normalized oscillator (bounded)**
- If `Mmax_t != Mmin_t`:
  - `CM_t = 200 * (M_t - Mmin_t) / (Mmax_t - Mmin_t) - 100`
- Else (flat momentum range):
  - `CM_t = 0`

Where `CM_t` is the **Clenow Momentum** value. The oscillator is intended to sit between **-100 and +100** when the rolling range is non-zero.

## Python Code
```python
import pandas as pd
import numpy as np

def clenow_momentum(df: pd.DataFrame, n: int = 10, m: int = 40) -> pd.DataFrame:
    """
    Expected DataFrame columns:
      - 'symbol'
      - 'date'
      - 'open', 'high', 'low', 'close'

    Returns a DataFrame with (per symbol/date) computed:
      - 'momentum_raw_pct'  : M_t = ((close / close.shift(n)) - 1) * 100
      - 'momentum_min'      : rolling min of M_t over window m
      - 'momentum_max'      : rolling max of M_t over window m
      - 'clenow_momentum'   : CM_t in range [-100, +100] using normalization to min/max over m
    """
    required = {'symbol', 'date', 'open', 'high', 'low', 'close'}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Input df missing required columns: {sorted(missing)}")

    out = df.copy()

    # Ensure stable ordering per symbol for shifts/rolling
    out = out.sort_values(['symbol', 'date'])

    # Compute per-symbol raw momentum (percent change over n)
    grp = out.groupby('symbol', sort=False)
    out['momentum_raw_pct'] = grp['close'].apply(lambda s: (s / s.shift(n) - 1.0) * 100.0)

    # Rolling min/max of raw momentum over window m (per symbol)
    out['momentum_min'] = grp['momentum_raw_pct'].apply(lambda s: s.rolling(window=m, min_periods=m).min())
    out['momentum_max'] = grp['momentum_raw_pct'].apply(lambda s: s.rolling(window=m, min_periods=m).max())

    # Normalized oscillator in [-100, +100]
    denom = (out['momentum_max'] - out['momentum_min'])
    numer = (out['momentum_raw_pct'] - out['momentum_min'])

    # Where denom is 0 (or NaN due to insufficient history), set to 0 as specified
    out['clenow_momentum'] = np.where(
        denom.notna() & (denom != 0),
        200.0 * numer / denom - 100.0,
        0.0
    )

    return out[['symbol', 'date',
                'momentum_raw_pct', 'momentum_min', 'momentum_max', 'clenow_momentum']]
```
```json
{ "model_code": "r6jq2vk9btx4", "topic": "Clenow Momentum", "timer_secs": 13.57, "tokens_in": 560, "tokens_out": 1760, "cost_tokens_in": 0.00011200, "cost_tokens_out": 0.00220000, "cost_tokens_tot": 0.00231200 }
```