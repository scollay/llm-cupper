# Bollinger Bands

## Overview
Bollinger Bands are a technical analysis tool used to measure market volatility and identify potential overbought or oversold conditions. Developed by John Bollinger in the 1980s, the indicator consists of three distinct lines plotted directly on a price chart: a central moving average and two outer bands that expand and contract based on price volatility.

## Details
Bollinger Bands function by creating a dynamic envelope around price action. Because the bands are based on standard deviation—a statistical measure of dispersion—they adapt to changing market conditions in real-time.

### The Components
The indicator is composed of three specific lines:
1.  **Middle Band:** Typically a Simple Moving Average (SMA), usually set to a 20-period duration.
2.  **Upper Band:** The middle band plus a specified number of standard deviations (commonly two).
3.  **Lower Band:** The middle band minus the same number of standard deviations.

### Market Interpretation
Traders use Bollinger Bands to gauge the "width" of the market and the relative position of price.

*   **Volatility Squeezes:** When the upper and lower bands contract significantly, it indicates low volatility. Traders often view a "squeeze" as a precursor to a major price breakout or trend reversal.
*   **Overbought and Oversold Conditions:** When price touches or pierces the upper band, the asset may be considered overbought. Conversely, touching the lower band may suggest the asset is oversold.
*   **Walking the Bands:** In a strong trending market, price may "walk" along the upper or lower band for an extended period. In these scenarios, a touch of the band is not a signal to fade the move, but rather a sign of momentum.

### Limitations and Failures
Bollinger Bands are not predictive; they are reactive. A common mistake is treating the bands as fixed support and resistance levels. In a high-momentum environment, price can remain outside the bands for a long time, leading to "false" reversal signals if a trader relies solely on the bands without considering trend strength or volume. Furthermore, the indicator does not indicate the *direction* of a breakout from a squeeze; it only indicates that volatility is increasing.

## Text Formula
To calculate Bollinger Bands, follow these steps:

1.  **Middle Band** = `SMA(close, n)`
    *   Where `n` is the period (typically 20).
2.  **Standard Deviation** = `SD(close, n)`
    *   The standard deviation of the price over the same `n` period.
3.  **Upper Band** = `Middle Band + (k * Standard Deviation)`
    *   Where `k` is the multiplier (typically 2).
4.  **Lower Band** = `Middle Band - (k * Standard Deviation)`

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculates Bollinger Bands for a DataFrame containing one or more symbols.
    
    Input DataFrame requirements:
    - Columns: 'symbol', 'date', 'open', 'high', 'low', 'close'
    - 'symbol' must be used to group data to ensure calculations 
      do not bleed across different assets.
    
    Returns:
    - DataFrame with added columns: 'middle_band', 'upper_band', 'lower_band'
    """
    
    # Ensure the dataframe is sorted by symbol and date for correct rolling calculations
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Define a helper function to apply calculations per group
    def apply_bands(group):
        # Calculate the Simple Moving Average (Middle Band)
        group['middle_band'] = group['close'].rolling(window=window).mean()
        
        # Calculate the rolling standard deviation
        rolling_std = group['close'].rolling(window=window).std()
        
        # Calculate Upper and Lower Bands
        group['upper_band'] = group['middle_band'] + (num_std * rolling_std)
        group['lower_band'] = group['middle_band'] - (num_std * rolling_std)
        
        return group

    # Group by 'symbol' and apply the calculation to each asset independently
    df = df.groupby('symbol', group_keys=False).apply(apply_bands)
    
    return df

# Example usage documentation:
# df = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL', 'AAPL', 'TSLA', 'TSLA', 'TSLA'],
#     'date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-01', '2023-01-02', '2023-01-03']),
#     'open': [150, 152, 151, 200, 210, 205],
#     'high': [153, 154, 153, 215, 212, 208],
#     'low': [149, 151, 150, 195, 205, 202],
#     'close': [152, 151, 152, 210, 205, 206]
# })
# result = calculate_bollinger_bands(df)
```
```json
{ "model_code": "s3lr8jk7nbm5", "topic": "Bollinger Bands", "timer_secs": 35.92, "tokens_in": 577, "tokens_out": 1255, "cost_tokens_in": 0.00003462, "cost_tokens_out": 0.00041415, "cost_tokens_tot": 0.00044877 }
```