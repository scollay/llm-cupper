# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator consisting of a **middle band** (a simple moving average) and two **outer bands** set above and below it at a fixed number of standard deviations. The bands widen and contract based on market volatility, providing a dynamic view of price dispersion around the average. Developed by John Bollinger in the early 1980s, the indicator is widely used to identify overbought or oversold conditions, volatility shifts, and potential breakout opportunities.

On a price chart, Bollinger Bands appear as three lines: the middle band (typically a 20-period SMA), an upper band, and a lower band. Price touching or exceeding the outer bands often signals extreme conditions, while band width reflects volatility.

## Details
Bollinger Bands operate on the principle that prices tend to stay within a predictable range relative to their average, with volatility expanding and contracting over time. The middle band (`middle_band`) is a simple moving average (SMA) of closing prices, usually over 20 periods. The upper and lower bands are calculated by adding and subtracting a multiple (typically 2) of the standard deviation of those closing prices from the middle band.

Traders interpret Bollinger Bands in several ways:
- **Squeeze**: When the bands narrow significantly, indicating low volatility and a potential for a sharp price move.
- **Breakouts**: When price moves outside the bands, suggesting continuation of the trend or a reversal, depending on context.
- **Overbought/Oversold**: Price touching the upper band may signal overbought conditions, while touching the lower band may signal oversold conditions. However, in strong trends, prices can remain near the bands for extended periods.
- **Support/Resistance**: The bands can act as dynamic support or resistance levels, especially during ranging markets.

**Limitations**:
- The indicator is reactive, not predictive. Bands adjust only after volatility changes.
- In strong trending markets, prices can hug the bands for long periods, leading to false signals.
- The choice of period and standard deviation multiplier is subjective and may not suit all instruments or timeframes.

## Text Formula
Given a time series of closing prices `C` over `n` periods, with a standard deviation multiplier `k` (commonly 2):

1. Compute the middle band:
   `middle_band = SMA(C, n)`
2. Compute the standard deviation of `C` over `n` periods:
   `stdev = std(C, n)`
3. Compute the upper band:
   `upper_band = middle_band + k * stdev`
4. Compute the lower band:
   `lower_band = middle_band - k * stdev`

Where:
- `SMA(C, n)` is the simple moving average of `C` over `n` periods.
- `std(C, n)` is the standard deviation of `C` over `n` periods.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculate Bollinger Bands for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Must be sorted by symbol and date.
    window : int, optional
        Lookback period for the moving average and standard deviation (default: 20).
    num_std : float, optional
        Number of standard deviations for the band width (default: 2).

    Returns:
    --------
    pd.DataFrame
        Original DataFrame with added columns:
        - `middle_band`: Simple moving average of `close` over `window` periods.
        - `upper_band`: `middle_band` + `num_std` * standard deviation.
        - `lower_band`: `middle_band` - `num_std` * standard deviation.
        - `band_width`: Distance between upper and lower bands.
        - `percent_b`: Percentage of price relative to the band width.
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(by=['symbol', 'date']).copy()

    # Group by symbol to compute bands independently
    def _compute_bands(group):
        closes = group['close']
        group['middle_band'] = closes.rolling(window=window).mean()
        rolling_std = closes.rolling(window=window).std()
        group['upper_band'] = group['middle_band'] + num_std * rolling_std
        group['lower_band'] = group['middle_band'] - num_std * rolling_std
        group['band_width'] = group['upper_band'] - group['lower_band']
        group['percent_b'] = ((closes - group['lower_band']) / group['band_width']) * 100
        return group

    df = df.groupby('symbol', group_keys=False).apply(_compute_bands)
    return df
```
```json
{ "model_code": "k9nw5bp6vzx2", "topic": "Bollinger Bands", "timer_secs": 7.72, "tokens_in": 581, "tokens_out": 1068, "cost_tokens_in": 0.00008715, "cost_tokens_out": 0.00064080, "cost_tokens_tot": 0.00072795 }
```