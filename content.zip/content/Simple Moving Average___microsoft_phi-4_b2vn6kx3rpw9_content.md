# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is a widely used technical analysis indicator that helps smooth out price data by creating a constantly updated average price. It is calculated by taking the arithmetic mean of a given set of prices over a specific number of periods. The SMA is typically represented as a line on a chart, which traders use to identify trends and potential reversals. This indicator was developed by Charles Dow, the founder of Dow Jones & Company, and is a fundamental component of the Dow Jones Industrial Average.

## Details

The Simple Moving Average is a straightforward indicator that calculates the average price of a security over a specified number of periods. It is often used to smooth out price fluctuations and identify trends. Traders typically interpret the SMA as a trend-following indicator, where the price crossing above the SMA suggests a bullish trend and crossing below indicates a bearish trend.

The SMA is calculated by summing up the prices over a certain number of periods and then dividing by the number of periods. This process is repeated for each period in the dataset, moving forward one period at a time. The interpretation of the SMA can break down in volatile markets where the price fluctuates rapidly, making the SMA less reliable as a trend indicator.

## Text Formula

The Simple Moving Average for a given period \( n \) is calculated as:

\[ \text{SMA}_n = \frac{\sum_{i=0}^{n-1} \text{Price}_i}{n} \]

Where \( \text{Price}_i \) is the price at period \( i \).

## Python Code

```python
python
import pandas as pd

def simple_moving_average(dataframe, period):
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the DataFrame.

    Parameters:
    - dataframe: A Pandas DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    - period: The number of periods over which to calculate the SMA

    Returns:
    - A Pandas DataFrame with an additional column 'SMA' containing the calculated SMA values.
    """
    # Initialize a list to store the SMA values
    sma_values = []

    # Iterate over each symbol in the DataFrame
    for symbol in dataframe['symbol'].unique():
        # Filter the data for the current symbol
        symbol_data = dataframe[dataframe['symbol'] == symbol]
        
        # Calculate the SMA for each period
        sma = symbol_data['close'].rolling(window=period).mean()
        
        # Append the symbol and its SMA to the list
        sma_values.append(sma)

    # Concatenate the SMA values back to the original DataFrame
    sma_df = pd.concat(sma_values, axis=1)
    sma_df.columns = ['SMA_' + str(i) for i in range(1, period + 1)]
    
    # Merge the SMA DataFrame with the original DataFrame
    result_df = pd.concat([dataframe, sma_df], axis=1)
    
    return result_df
```

This Python code calculates the Simple Moving Average for each symbol independently, ensuring that the SMA values are computed correctly for each period. The code assumes a Pandas DataFrame input with columns: `symbol`, `date`, `open`, `high`, `low`, and `close`. The output DataFrame includes an additional column for each period's SMA, labeled as `SMA_<period_number>`.
```json
{ "model_code": "b2vn6kx3rpw9", "topic": "Simple Moving Average", "timer_secs": 15.98, "tokens_in": 586, "tokens_out": 718, "cost_tokens_in": 0.00003809, "cost_tokens_out": 0.00010052, "cost_tokens_tot": 0.00013861 }
```