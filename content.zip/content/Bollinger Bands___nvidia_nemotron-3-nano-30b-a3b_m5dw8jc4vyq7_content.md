# Bollinger Bands

## Overview
Bollinger Bands are a volatility‑based envelope that frames price movement on a chart. The indicator consists of three lines: a middle band that tracks a simple moving average (SMA) of the price, and an upper and lower band that lie a fixed number of standard deviations away from the middle band. When the bands contract, market volatility is low; when they expand, volatility is high. John Bollinger introduced the concept in the early 1980s while at the Chicago Board of Trade, and the tool is now a standard feature on most charting platforms. On a price chart the bands appear as a colored channel that expands and contracts with each new bar, making it easy to see when price is relatively high or low relative to recent volatility.

## Details
The classic construction uses a 20‑period SMA for the middle band and a 2‑standard‑deviation multiplier for the outer bands, but traders often tweak both the window length and the multiplier to suit different assets or timeframes. The calculation proceeds as follows:

- **Middle Band** = SMA(`close`, N)  
- **Standard Deviation** = STDDEV(`close`, N)  
- **Upper Band** = Middle Band + K × Standard Deviation  
- **Lower Band** = Middle Band – K × Standard Deviation  

Typical interpretations include:

- **Band‑bounce**: price rebounds off the middle band after touching an outer band.  
- **Band‑breakout**: price closes beyond an outer band, suggesting continuation of the current trend.  
- **Squeeze**: the distance between the upper and lower bands narrows dramatically, often preceding a sharp volatility expansion.

**Common uses**

- Identify overbought/oversold conditions when price repeatedly hits the upper or lower band.  
- Spot potential reversals when price diverges from the band direction.  
- Anticipate breakout moves by watching for a squeeze followed by a rapid band widening.

**Caveats**

- **Lag**: the SMA is backward‑looking, so signals lag actual price changes.  
- **False positives**: in ranging markets price may oscillate between bands without a clear trend.  
- **Parameter sensitivity**: altering N or K changes how often signals appear; robust strategies usually back‑test multiple settings.

## Text Formula
The full textual formula for Bollinger Bands is:

```
Middle = SMA(close, N)
StdDev   = STDDEV(close, N)
Upper    = Middle + K × StdDev
Lower    = Middle – K × StdDev
```

where **N** is the look‑back period (commonly 20) and **K** is the number of standard deviations (commonly 2). The bands are recalculated each bar as new price data become available.

## Python Code
```python
```python
# Compute Bollinger Bands for a DataFrame that includes the columns:
#   symbol, date, open, high, low, close
# The function returns the input DataFrame with three new columns:
#   bb_middle, bb_upper, bb_lower
# Each symbol is processed independently using its own rolling window.

def add_bb(df, window=20, num_std=2):
    # Ensure proper ordering for rolling calculations
    df = df.sort_values(['symbol', 'date'])
    # Middle band: rolling simple moving average of close price per symbol
    df['bb_middle'] = df.groupby('symbol')['close'].rolling(window).mean()
    # Standard deviation of close price per symbol
    df['bb_std'] = df.groupby('symbol')['close'].rolling(window).std()
    # Upper and lower bands
    df['bb_upper'] = df['bb_middle'] + num_std * df['bb_std']
    df['bb_lower'] = df['bb_middle'] - num_std * df['bb_std']
    # Clean up: drop the temporary std column if not needed elsewhere
    df = df.drop(columns=['bb_std'])
    return df
```
```
```json
{ "model_code": "m5dw8jc4vyq7", "topic": "Bollinger Bands", "timer_secs": 34.60, "tokens_in": 581, "tokens_out": 3606, "cost_tokens_in": 0.00002905, "cost_tokens_out": 0.00072120, "cost_tokens_tot": 0.00075025 }
```