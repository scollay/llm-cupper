# Coppock Curve
## Overview
The Coppock Curve is a long-term momentum indicator designed to identify sustained trend shifts in broad market assets, most famously the S&P 500. It appears on charts as a single line plotted below price action, with a horizontal zero line serving as a key signal threshold. The indicator was created by economist E.S.C. Coppock and first published in *Barron's* in 1962, originally built to generate low-false-positive buy signals for secular bull markets. While it was initially intended for monthly price data, active traders often adapt its parameters for daily or weekly timeframes to suit shorter trading horizons.

## Details
### Core Construction
The Coppock Curve is built to filter out short-term market noise by combining two medium-term momentum readings with a smoothing moving average. It first calculates the percentage rate of change (ROC) for two distinct lookback periods: 14 periods and 11 periods. These two ROC values are summed to create a raw momentum reading, which is then smoothed with a 10-period weighted moving average (WMA) to reduce whipsaws from minor price fluctuations.

### Standard Interpretation
Coppock designed the indicator exclusively for long-term market timing, with its primary signal being a **cross above the zero line**. This signal is intended to mark the start of a new sustained uptrend, typically occurring after a bear market bottom. While the original specification did not include sell signals, many modern traders use a cross below the zero line as a signal for the start of a downtrend, though this modification is less reliable than the original buy signal. The indicator is most effective when applied to broad market indices (e.g., S&P 500, total stock market ETFs) on monthly or weekly timeframes, as these timeframes align with its original design for capturing multi-year secular trends.

### Common Limitations and Signal Breakdowns
The Coppock Curve’s deliberate lag to filter noise creates consistent weaknesses in certain market conditions:
- **Lagging entries**: Because it uses a 14-period ROC, 11-period ROC, and 10-period WMA, buy signals often occur 1–3 months after a trend has already begun, meaning traders enter positions well after the lowest prices of the move.
- **Poor performance in sideways markets**: In range-bound or choppy markets with no clear trend, the indicator generates frequent false zero-line crosses as short-term momentum oscillates without follow-through.
- **Timeframe sensitivity**: Applying the standard monthly parameters (14/11/10) to intraday or short-term daily timeframes drastically increases false signals, as the indicator is calibrated for a 3–4 year lookback horizon. Traders using shorter timeframes must scale parameters proportionally (e.g., 140/110/100 for daily data) to match the original intended lookback.
- **No built-in exit logic**: The indicator only generates entry signals, so it must be paired with separate risk management rules (e.g., trailing stops, trendline breaks) to manage exits.
- **Distortion from unadjusted data**: When applied to individual stocks, unadjusted closing prices will skew ROC calculations for assets with splits, dividends, or spin-offs, leading to inaccurate signals. Adjusted close prices are required for individual equity analysis.

## Text Formula
First, define the percentage rate of change (ROC) for a lookback period `n` at time `t`:
`ROC_n(t) = ((Close_t / Close_{t - n}) - 1) * 100`
Where `Close_t` is the closing price at time `t`, and `Close_{t-n}` is the closing price `n` periods prior.

The Coppock Curve (`CC`) at time `t` is the 10-period weighted moving average (WMA) of the sum of the 14-period and 11-period ROC values:
`CC(t) = WMA_10( ROC_14(t) + ROC_11(t) )`

The 10-period WMA uses linearly increasing weights for values in its lookback window, with the oldest value receiving a weight of 1 and the most recent value receiving a weight of 10. The sum of all 10 weights is 55 (1 + 2 + ... + 10 = 55), so the WMA is calculated as:
`WMA_10(x) = ( (1 * x_{t-9}) + (2 * x_{t-8}) + ... + (10 * x_t) ) / 55`
Where `x` is the input series (the sum of `ROC_14` and `ROC_11` in this case). All values are expressed as percentages, so the zero line represents no net momentum from the two ROC inputs.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock_curve(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate Coppock Curve values for a DataFrame of price data.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with required columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
                       Data is automatically sorted by date ascending within each symbol to ensure correct time-ordered calculations.
    
    Returns:
    pd.DataFrame: Input DataFrame with an added 'coppock_curve' column containing calculated indicator values.
                  NaN values are returned for rows with insufficient lookback data to compute the indicator.
    """
    # Sort data by symbol and ascending date to avoid cross-symbol or out-of-order calculations
    df = df.sort_values(by=['symbol', 'date'], ascending=[True, True]).reset_index(drop=True)
    
    # Helper function to calculate a weighted moving average (WMA) for a given window
    def wma(series: pd.Series, window: int) -> pd.Series:
        # Create linearly increasing weights from 1 (oldest) to window (most recent)
        weights = np.arange(1, window + 1)
        # Rolling calculation: apply weighted average only when full window of data is available
        return series.rolling(window=window, min_periods=window).apply(
            lambda x: np.dot(x, weights) / weights.sum(), raw=True
        )
    
    # Calculate Coppock Curve per symbol to prevent data leakage between assets
    df['coppock_curve'] = df.groupby('symbol').apply(
        lambda g: wma(
            # Sum 14-period and 11-period percentage rate of change (ROC) of closing prices
            (g['close'].pct_change(periods=14) * 100) + (g['close'].pct_change(periods=11) * 100),
            window=10  # 10-period WMA smoothing as per standard Coppock Curve specification
        )
    ).reset_index(level=0, drop=True)  # Align result with original DataFrame index
    
    return df
```
```json
{ "model_code": "rps2b8a4fpay", "topic": "Coppock Curve", "timer_secs": 51.74, "tokens_in": 567, "tokens_out": 9522, "cost_tokens_in": 0.00011340, "cost_tokens_out": 0.01095030, "cost_tokens_tot": 0.01106370 }
```