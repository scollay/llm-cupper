# Clenow Momentum

## Overview
Clenow Momentum is a risk‑adjusted momentum indicator developed by trader and author Andreas Clenow. It appears on a chart as a single line (often plotted in a separate pane) that quantifies how much price has moved over a look‑back period relative to the market’s volatility during that same period. The indicator is intended to help traders identify instruments with strong, sustained price trends while filtering out moves that occur in low‑volatility, noisy environments.

## Details
### How it works
The core idea is to compare the absolute price change over *N* periods to a volatility measure scaled by the square root of *N*. By dividing the price change by volatility, the result approximates a Sharpe‑like ratio: a higher value means the price move is large compared to the expected noise, suggesting a genuine trend.

1. **Price change** – `ΔClose = Close_t – Close_{t‑N}`  
2. **Volatility proxy** – the Average True Range (ATR) over the same *N* periods:  
   `ATR_t = (1/N) * Σ_{i=0}^{N-1} TR_{t-i}` where each true range `TR` is  
   `max(High_i – Low_i, |High_i – Close_{i-1}|, |Low_i – Close_{i-1}|)`.  
3. **Momentum score** – `Momentum_t = ΔClose / (ATR_t * √N)`

Common choices for *N* are 126 trading days (≈6 months) or 252 trading days (≈12 months). The indicator can be calculated on any time frame (daily, weekly, etc.) as long as the same look‑back is used consistently.

### Interpretation
- **Positive values** indicate upward momentum; the larger the value, the stronger the trend relative to volatility.  
- **Values near zero** suggest little directional movement after adjusting for noise.  
- **Negative values** reflect downward momentum (price decline exceeding volatility).  

Traders often use thresholds such as:
- `Momentum > 1.0` → strong bullish candidate  
- `Momentum < -1.0` → strong bearish candidate  
- `-1.0 ≤ Momentum ≤ 1.0` → neutral or choppy market

### Where the interpretation can break down
1. **Low‑volatility environments** – When ATR becomes very small, the denominator shrinks and the momentum score can inflate, producing false signals.  
2. **Sudden volatility spikes** – A sharp increase in ATR (e.g., after a news event) can depress the score even if the price trend remains intact, causing premature exits.  
3. **Non‑stationary volatility** – ATR assumes volatility is roughly stable over the look‑back; regime changes can make the indicator lag or overreact.  
4. **Look‑back length** – Too short a window makes the indicator noisy; too long a window smooths out genuine short‑term trends. Traders must tune *N* to their trading horizon and the instrument’s characteristics.  
5. **Gap risk** – The true range calculation incorporates gaps via the prior close, but extreme gaps can distort ATR temporarily.

Despite these caveats, Clenow Momentum remains popular because it blends price direction with a volatility filter, offering a simple way to rank assets by the quality of their momentum rather than just its magnitude.

## Text Formula
Let  

- `Close_t` be the closing price at time *t*  
- `Open_t, High_t, Low_t` be the open, high, low at time *t*  
- `N` be the look‑back period (in same units as the data)  

Then  

```
TR_t = max( High_t - Low_t,
            abs(High_t - Close_{t-1}),
            abs(Low_t - Close_{t-1}) )

ATR_t = (1/N) * Σ_{i=0}^{N-1} TR_{t-i}

ΔClose_t = Close_t - Close_{t-N}

Momentum_t = ΔClose_t / (ATR_t * sqrt(N))
```

All sums are over the most recent *N* completed periods, including the current period *t* for ATR and excluding the current period for the price change (which uses the close *N* periods ago).

## Python Code
```python
import pandas as pd
import numpy as np

def clenow_momentum(df: pd.DataFrame, lookback: int = 252) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for each symbol in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
        Data should be sorted by date ascending for each symbol.
    lookback : int, optional
        Number of periods for the momentum look‑back (default 252 ≈ 12 months trading days).

    Returns
    -------
    pd.DataFrame
        Original DataFrame with an added 'momentum' column.
    """
    # Ensure chronological order per symbol
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Prior close needed for true range calculation
    df['prev_close'] = df.groupby('symbol')['close'].shift(1)

    # True range components
    df['tr1'] = df['high'] - df['low']
    df['tr2'] = (df['high'] - df['prev_close']).abs()
    df['tr3'] = (df['low'] - df['prev_close']).abs()
    df['true_range'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)

    # Average True Range over the lookback window
    df['atr'] = (
        df.groupby('symbol')['true_range']
          .rolling(window=lookback, min_periods=lookback)
          .mean()
          .reset_index(level=0, drop=True)
    )

    # Price change over the lookback window
    df['price_change'] = (
        df.groupby('symbol')['close']
          .diff(periods=lookback)
    )

    # Clenow Momentum
    df['momentum'] = df['price_change'] / (df['atr'] * np.sqrt(lookback))

    # Drop helper columns if desired; keep them for transparency
    df = df.drop(columns=['prev_close', 'tr1', 'tr2', 'tr3', 'true_range', 'atr', 'price_change'])

    return df
```

**Usage example**

```python
# Assume `df` is a DataFrame with the required columns
momentum_df = clenow_momentum(df, lookback=252)   # 12‑month momentum
# The resulting DataFrame now includes a 'momentum' column for each symbol.
```

The function works for single‑symbol or multi‑symbol inputs, computes each symbol’s ATR and price change independently, and returns the momentum value for every row where sufficient look‑back data exists (the first `lookback‑1` rows per symbol will contain NaN). This matches the mathematical definition presented above and can be directly plugged into further analysis or signal generation pipelines.
```json
{ "model_code": "x6kp3hr9bln2", "topic": "Clenow Momentum", "timer_secs": 43.91, "tokens_in": 583, "tokens_out": 2712, "cost_tokens_in": 0.00005247, "cost_tokens_out": 0.00122040, "cost_tokens_tot": 0.00127287 }
```