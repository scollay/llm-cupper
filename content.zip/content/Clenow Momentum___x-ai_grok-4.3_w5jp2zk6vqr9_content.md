# Clenow Momentum

## Overview
Clenow Momentum quantifies the annualized rate of price change to identify trend strength. On a chart it is typically displayed as a single oscillating line or numeric value beneath price, crossing above or below zero. Portfolio manager Andreas Clenow introduced the measure in his systematic-trading framework around 2013.

## Details
The indicator compares the most recent close to the close n periods earlier, then annualizes the ratio using a 365-day year. A positive reading signals upward price momentum while a negative reading signals downward momentum. Traders commonly rank a universe of instruments by this value and hold the highest-ranked names, entering when momentum exceeds a chosen threshold such as zero or 0.20. Because the calculation is purely retrospective, the signal lags at trend reversals and produces whipsaws when prices move sideways. It also ignores volatility, so two assets with identical momentum readings can exhibit very different risk profiles.

## Text Formula
M_t = (C_t / C_{t-n})^{365/n} - 1  
where C_t is today’s close, C_{t-n} is the close n periods ago, and n is the chosen lookback (commonly 90).

## Python Code
```python
import pandas as pd
import numpy as np

def clenow_momentum(df, period=90):
    df = df.sort_values(['symbol', 'date']).copy()
    df['clenow_momentum'] = (
        df.groupby('symbol')['close']
        .transform(lambda x: (x / x.shift(period)) ** (365.0 / period) - 1)
    )
    return df
```
```json
{ "model_code": "w5jp2zk6vqr9", "topic": "Clenow Momentum", "timer_secs": 8.47, "tokens_in": 678, "tokens_out": 1289, "cost_tokens_in": 0.00084750, "cost_tokens_out": 0.00322250, "cost_tokens_tot": 0.00407000 }
```