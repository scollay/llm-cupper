# Coppock Curve

## Overview

The **Coppock Curve** is a long-term momentum oscillator designed to identify major bottoms in stock market indexes. It appears beneath a price chart as a single line that oscillates above and below a zero baseline, typically rising and falling in slow, smooth waves. Developed by economist Edwin "Sedge" Coppock and introduced in a 1962 article in *Barron's*, the indicator was originally built for monthly data on broad equity indexes such as the S&P 500. Coppock reportedly conceived the smoothing periods after consulting Episcopal church officials about the average mourning period following a bereavement—roughly 11 to 14 months—reasoning that markets recover from downturns on a similar emotional timeline.

## Details

The Coppock Curve combines two rates of change (ROC) with a weighted moving average to produce a slow-moving momentum line. The calculation proceeds in three steps:

1. Compute the 14-period rate of change of the closing price.
2. Compute the 11-period rate of change of the closing price.
3. Sum the two ROC values, then apply a 10-period **weighted moving average (WMA)** to that sum.

The result is a smoothed momentum reading that crosses above and below zero infrequently, which is precisely the point: Coppock intended it as a buy-signal generator for long-term investors, not a tool for frequent trading.

### How traders interpret it

- **Bullish signal:** The classic signal occurs when the curve turns up from *below* zero. Coppock's original method did not even require a zero-line crossing—simply a trough forming in negative territory followed by an upturn was the trigger to buy.
- **Zero-line crossings:** Many modern traders treat a cross above zero as confirmation of a new uptrend and a cross below zero as a warning of weakening momentum.
- **Direction changes:** Because the curve is so smooth, a change in slope (peak or trough) is itself meaningful, signaling a shift in long-term momentum.

The indicator was conceived as a **buy-only** tool. Coppock did not design a corresponding sell signal, though practitioners have since adapted downturns from above zero as exit or short signals.

### Where interpretation breaks down

The Coppock Curve has well-known limitations:

- **It is a lagging indicator.** The heavy smoothing that filters out noise also delays signals. By the time the curve turns up, a meaningful portion of a rally may already be complete.
- **Whipsaws on shorter timeframes.** Applying the curve to daily or weekly data—rather than the monthly data it was built for—produces more frequent and less reliable signals.
- **No sell discipline.** Without a native exit rule, traders must overlay their own risk management.
- **Choppy markets.** In range-bound conditions the curve can hover near zero, generating repeated false crossings.
- **Single-asset focus.** It was designed for broad indexes; on individual, volatile stocks the signals tend to be noisier.

Because of these traits, the Coppock Curve is best used as a confirming tool for long-horizon positioning rather than as a standalone timing system.

## Text Formula

```
ROC(n) at time t = ((Close_t - Close_(t-n)) / Close_(t-n)) * 100

Coppock Sum_t = ROC(14)_t + ROC(11)_t

Weighted Moving Average over 10 periods, where the most recent
value receives weight 10 and the oldest receives weight 1:

WMA_t = (10*X_t + 9*X_(t-1) + 8*X_(t-2) + ... + 1*X_(t-9))
        / (10 + 9 + 8 + ... + 1)

where X = Coppock Sum, and (10 + 9 + ... + 1) = 55

Coppock Curve_t = WMA(10) of Coppock Sum_t
```

Default parameters are the 14-period and 11-period ROC values smoothed by a 10-period WMA.

## Python Code

```python
import pandas as pd
import numpy as np


def coppock_curve(df, roc_long=14, roc_short=11, wma_period=10):
    """
    Calculate the Coppock Curve for one or more symbols.

    Expected input: a Pandas DataFrame with the following columns:
        symbol : str   -- ticker/identifier for the instrument
        date   : datetime-like or sortable date
        open   : float
        high   : float
        low    : float
        close  : float

    The DataFrame may contain rows for multiple symbols. Each symbol
    is processed independently.

    Parameters
    ----------
    roc_long  : long rate-of-change lookback (default 14)
    roc_short : short rate-of-change lookback (default 11)
    wma_period: weighted moving average length (default 10)

    Returns
    -------
    A copy of the input DataFrame sorted by symbol and date with these
    added columns:
        roc_long    : rate of change over `roc_long` periods (percent)
        roc_short   : rate of change over `roc_short` periods (percent)
        coppock_sum : roc_long + roc_short
        coppock     : the Coppock Curve (WMA of coppock_sum)
    """

    df = df.copy()

    # Ensure correct ordering so time-series math is valid per symbol.
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Precompute the weights for the weighted moving average.
    # Most recent observation gets the largest weight.
    weights = np.arange(1, wma_period + 1)  # [1, 2, ..., wma_period]
    weight_sum = weights.sum()

    def _wma(series):
        # Apply a rolling weighted moving average to a single series.
        return series.rolling(window=wma_period).apply(
            lambda x: np.dot(x, weights) / weight_sum,
            raw=True,
        )

    def _per_symbol(group):
        close = group["close"]

        # Rate of change (percent) over the two lookback periods.
        group["roc_long"] = (close / close.shift(roc_long) - 1.0) * 100.0
        group["roc_short"] = (close / close.shift(roc_short) - 1.0) * 100.0

        # Sum of the two ROC series.
        group["coppock_sum"] = group["roc_long"] + group["roc_short"]

        # Coppock Curve = weighted moving average of the ROC sum.
        group["coppock"] = _wma(group["coppock_sum"])

        return group

    # Process each symbol independently.
    df = (
        df.groupby("symbol", group_keys=False)
        .apply(_per_symbol)
        .reset_index(drop=True)
    )

    return df
```
```json
{ "model_code": "r8f5wn2cv6tj", "topic": "Coppock Curve", "timer_secs": 28.61, "tokens_in": 845, "tokens_out": 2249, "cost_tokens_in": 0.00422500, "cost_tokens_out": 0.05622500, "cost_tokens_tot": 0.06045000 }
```