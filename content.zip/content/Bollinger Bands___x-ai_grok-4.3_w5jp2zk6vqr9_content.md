# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator that plots three lines directly on a price chart: a simple moving average in the center and two outer bands set at a fixed number of standard deviations above and below that average. The bands expand and contract with market volatility, creating a dynamic envelope around price. John Bollinger introduced the tool in the early 1980s.

## Details
The middle band is typically a 20-period simple moving average of closing prices. The upper and lower bands are placed two standard deviations away from this average, capturing roughly 95 percent of price action under a normal distribution assumption. Traders watch the width of the bands for volatility signals: a period of unusually narrow bands, often called a squeeze, frequently precedes a sharp directional move. When price touches or exceeds the upper band, the market is viewed as overextended to the upside; touches of the lower band suggest oversold conditions. Mean-reversion strategies sell rallies into the upper band and buy dips into the lower band, while breakout traders wait for a decisive close outside the bands accompanied by expanding bandwidth.

Interpretation weakens in strong trends. During a persistent uptrend, price can ride the upper band for extended periods, generating repeated overbought signals that prove misleading. The same occurs with the lower band in downtrends. Because the bands are based on historical volatility, they lag sudden regime changes and can remain wide after volatility has already collapsed. False signals also increase in low-volume or news-driven markets where price spikes briefly outside the bands without follow-through. Many practitioners combine Bollinger Bands with volume, momentum oscillators, or candlestick patterns to filter low-quality signals.

## Text Formula
```
Middle Band = SMA(Close, n)
StdDev = StandardDeviation(Close, n)
Upper Band = Middle Band + (k * StdDev)
Lower Band = Middle Band - (k * StdDev)
```
where n is the lookback period (commonly 20) and k is the number of standard deviations (commonly 2).

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, period=20, num_std=2):
    """
    Calculate Bollinger Bands for one or more symbols.
    Expects DataFrame with columns: symbol, date, open, high, low, close.
    Returns DataFrame with added columns: middle_band, upper_band, lower_band.
    """
    df = df.sort_values(['symbol', 'date']).copy()
    
    def _bb_group(group):
        group = group.sort_values('date')
        sma = group['close'].rolling(window=period).mean()
        std = group['close'].rolling(window=period).std(ddof=0)
        group['middle_band'] = sma
        group['upper_band'] = sma + (num_std * std)
        group['lower_band'] = sma - (num_std * std)
        return group
    
    result = df.groupby('symbol', group_keys=False).apply(_bb_group)
    return result
```
```json
{ "model_code": "w5jp2zk6vqr9", "topic": "Bollinger Bands", "timer_secs": 9.91, "tokens_in": 677, "tokens_out": 939, "cost_tokens_in": 0.00084625, "cost_tokens_out": 0.00234750, "cost_tokens_tot": 0.00319375 }
```