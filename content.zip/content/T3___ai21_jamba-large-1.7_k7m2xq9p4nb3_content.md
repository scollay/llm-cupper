# T3

## Overview
T3 is a modified moving average indicator designed to reduce lag and provide smoother signals compared to traditional moving averages like the EMA or SMA. It was created by Tim Tillson in the 1990s and is often used by traders to identify trends and potential reversals. On a chart, T3 appears as a line that closely tracks price action with less delay than other moving averages.

## Details
T3 is based on a weighted combination of exponential moving averages (EMAs) and uses a "smoothing factor" to achieve its reduced lag. The key feature of T3 is its use of the **Gain factor (g)**, which determines the degree of smoothing. A higher Gain factor results in a more responsive T3 line, while a lower Gain factor makes it smoother but potentially slower to react.

The T3 line is often interpreted similarly to other moving averages:

- When the price is above the T3 line, it may indicate an uptrend.
- When the price is below the T3 line, it may indicate a downtrend.
- Crossovers between the price and the T3 line or between T3 and other moving averages can signal potential entry or exit points.

However, T3 is not without limitations. Its responsiveness can lead to **whipsaws** in choppy or sideways markets, where rapid changes in direction might generate false signals. Additionally, the complexity of its calculation can make it harder for some traders to intuitively understand compared to simpler moving averages.

## Text Formula
The T3 indicator is calculated as follows:

1. Compute the **EMA1** (first exponential moving average) of the closing prices with a specified period $n$:

$$EMA1 = EMA(close, n)$$

1. Calculate successive EMAs using $EMA1$ as input:

$$EMA2 = EMA(EMA1, n)$$
$$EMA3 = EMA(EMA2, n)$$
$$EMA4 = EMA(EMA3, n)$$
$$EMA5 = EMA(EMA4, n)$$
$$EMA6 = EMA(EMA5, n)$$

1. Combine these into the T3 formula using the **Gain factor (g)**:

$$T3 = EMA6 \times (1 + g) - EMA5 \times g$$

where $g$ is defined as:

$$g = 2 / (N + 1)$$

and $N$ is the user-defined period for the EMA.

## Python Code

```python
import pandas as pd

def t3(data, period, gain_factor):
    """
    Calculate the T3 indicator for a given DataFrame.
    
    Parameters:
    data (DataFrame): Input DataFrame with columns: symbol, date, open, high, low, close.
    period (int): The period for the EMA calculations.
    gain_factor (float): The Gain factor (g) used in the T3 formula.
    
    Returns:
    DataFrame: The input DataFrame with an added column `t3` containing the T3 values.
    """
    # Ensure the DataFrame is sorted by date for each symbol
    data = data.sort_values(by=['symbol', 'date'])
    
    # Initialize a column for T3 with default NaN values
    data['t3'] = float('nan')
    
    for symbol in data['symbol'].unique():
        # Filter data for the current symbol
        symbol_data = data[data['symbol'] == symbol]
        
        # Calculate the first EMA
        ema1 = symbol_data['close'].ewm(span=period, adjust=False).mean()
        
        # Calculate successive EMAs
        ema2 = ema1.ewm(span=period, adjust=False).mean()
        ema3 = ema2.ewm(span=period, adjust=False).mean()
        ema4 = ema3.ewm(span=period, adjust=False).mean()
        ema5 = ema4.ewm(span=period, adjust=False).mean()
        ema6 = ema5.ewm(span=period, adjust=False).mean()
        
        # Compute T3 using the formula
        symbol_data['t3'] = (ema6 * (1 + gain_factor)) - (ema5 * gain_factor)
    
        # Update the main DataFrame with the calculated T3 values for this symbol
        data.loc[symbol_data.index, 't3'] = symbol_data['t3']
    
    return data

# Example usage:
# Assume `df` is a DataFrame with the required columns: symbol, date, open, high, low, close.
# result = t3(df, period=10, gain_factor=0.7)
# The resulting DataFrame will include a new column `t3` with the T3 values for each symbol.
```

This code calculates T3 independently for each symbol in the DataFrame, ensuring that the EMA chains and T3 values are computed per symbol. The `gain_factor` should typically be in the range of 0 to 1, with common defaults around 0.7.
```json
{ "model_code": "k7m2xq9p4nb3", "topic": "T3", "timer_secs": 19.66, "tokens_in": 601, "tokens_out": 1177, "cost_tokens_in": 0.00120200, "cost_tokens_out": 0.00941600, "cost_tokens_tot": 0.01061800 }
```