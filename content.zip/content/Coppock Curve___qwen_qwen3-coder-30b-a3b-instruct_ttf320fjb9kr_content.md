# Coppock Curve

## Overview
The **Coppock Curve** is a momentum indicator designed to identify long-term bullish trends in the stock market. It was developed by economist **Eugene F. Coppock** in the late 1960s. The indicator combines both price momentum and rate-of-change to detect early signs of market reversals, particularly useful for identifying bottoming patterns in major market indices. On charts, the Coppock Curve appears as a line that oscillates above and below zero, often used alongside other technical tools for confirmation.

## Details
The Coppock Curve is a specialized momentum oscillator that tracks the growth rate of the sum of two moving averages: a 14-period and a 11-period. It is especially effective in detecting long-term market trends and can be interpreted similarly to other momentum indicators—values above zero suggest bullish momentum, while values below zero indicate bearish momentum. Traders often look for crossovers of the zero line or signal lines to generate buy/sell signals. However, the indicator’s lagging nature means it may miss early moves, and its effectiveness can vary across different market conditions and timeframes.

Unlike many momentum indicators, the Coppock Curve is not based on price alone but rather on the rate of change of a composite index derived from two separate moving averages. This makes it less sensitive to short-term volatility and more focused on longer-term shifts in investor sentiment. Some traders also use the curve's slope to assess the strength of momentum, with steep upward slopes indicating strong buying pressure and downward slopes signaling selling pressure.

One limitation of the Coppock Curve is that it can produce false signals during volatile or sideways markets, and its reliance on historical data means it may not react quickly to sudden changes in market dynamics. Additionally, because it is a lagging indicator, it is best used in conjunction with leading indicators or price action analysis to improve accuracy.

## Text Formula
The Coppock Curve is calculated using the following steps:

1. Compute the 14-period and 11-period **Simple Moving Averages (SMAs)** of the closing prices.
2. Calculate the **rate of change (ROC)** for both SMAs:
   - `ROC_14 = (SMA_14[t] - SMA_14[t-14]) / SMA_14[t-14]`
   - `ROC_11 = (SMA_11[t] - SMA_11[t-11]) / SMA_11[t-11]`
3. Sum the two ROC values:
   - `ROC_Sum = ROC_14 + ROC_11`
4. Apply a **3-month (65-day)** **Simple Moving Average** to the ROC_Sum to smooth the curve:
   - `Coppock_Curve = SMA_65(ROC_Sum)`

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock_curve(df):
    """
    Calculates the Coppock Curve for each symbol in the DataFrame.
    
    Parameters:
    df (DataFrame): Must contain columns: 'symbol', 'date', 'close'
    
    Returns:
    DataFrame: Original DataFrame with added 'coppock_curve' column
    """
    # Ensure data is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Group by symbol to handle multiple symbols independently
    def compute_coppock(group):
        # Calculate 14-period and 11-period SMAs
        sma_14 = group['close'].rolling(window=14).mean()
        sma_11 = group['close'].rolling(window=11).mean()

        # Calculate ROC for both SMAs
        roc_14 = (sma_14 - sma_14.shift(14)) / sma_14.shift(14)
        roc_11 = (sma_11 - sma_11.shift(11)) / sma_11.shift(11)

        # Sum ROC values
        roc_sum = roc_14 + roc_11

        # Apply 65-period SMA to smooth the ROC sum
        coppock_curve = roc_sum.rolling(window=65).mean()

        return coppock_curve
    
    # Apply calculation per symbol
    df['coppock_curve'] = df.groupby('symbol').apply(compute_coppock).reset_index(level=0, drop=True)
    
    return df
```
```json
{ "model_code": "ttf320fjb9kr", "topic": "Coppock Curve", "timer_secs": 9.37, "tokens_in": 563, "tokens_out": 946, "cost_tokens_in": 0.00003941, "cost_tokens_out": 0.00025542, "cost_tokens_tot": 0.00029483 }
```