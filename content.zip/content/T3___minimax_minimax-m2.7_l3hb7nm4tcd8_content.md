# T3

## Overview
T3, also known as Tilson’s Triple Exponential Moving Average, is a technical indicator that smooths price data with a series of exponential moving averages (EMAs) and a final smoothing pass. It appears on a chart as a single line that closely tracks the price direction while reducing short‑term noise. The indicator was introduced by Tim Tilson in the early 1990s as an improvement over simple moving averages, aiming to provide a faster response to market moves without the excessive lag of conventional EMAs.

## Details
### How the indicator is calculated
T3 is built from three successive EMAs of the price series, followed by a fourth EMA that applies the same smoothing factor. The process can be broken down into the following steps:

1. **Smoothing factor (a).**  
   `a = 2 / (period + 1)`  
   The period is a user‑selected integer (default 5). Larger values produce a smoother line; smaller values respond more quickly.

2. **First EMA (EMA1).**  
   `EMA1[t] = (1 - a) * EMA1[t‑1] + a * price[t]`  
   EMA1 is the standard exponential moving average of the close (or any selected price).

3. **Second EMA (EMA2).**  
   `EMA2[t] = (1 - a) * EMA2[t‑1] + a * EMA1[t]`  
   EMA2 is an EMA of EMA1, further smoothing the series.

4. **Third EMA (EMA3).**  
   `EMA3[t] = (1 - a) * EMA3[t‑1] + a * EMA2[t]`  
   EMA3 is an EMA of EMA2.

5. **Final smoothing (T3).**  
   `T3[t] = (1 - a) * T3[t‑1] + a * EMA3[t]`  
   The same factor `a` is applied once more, giving T3 a quadruple‑smoothed characteristic while retaining the responsiveness of an exponential average.

### Typical interpretation
Traders watch the T3 line for direction changes and momentum shifts:

- **Trend confirmation:** When T3 is rising, the short‑term trend is considered bullish; a falling T3 signals a bearish bias.  
- **Crossover systems:** Some traders buy when the price crosses above T3 and sell when it falls below. Others use a shorter‑period T3 as a trigger line and a longer‑period T3 as a filter.  
- **Dynamic support/resistance:** In strong trends, T3 often acts as a moving support line; the price tends to bounce off the T3 during pullbacks.

Because T3 smooths data three times before the final pass, it reacts faster than a simple moving average of the same period but still lags the price. The lag is reduced enough to make the indicator useful for identifying turning points, especially on intraday charts.

### Where the interpretation tends to break down
- **Ranging markets:** In sideways markets, price repeatedly crossing T3 generates many false signals. Adding a volatility filter (such as ATR or Bollinger Band width) can reduce whipsaws.  
- **Parameter sensitivity:** Changing the period dramatically alters the behavior. A period that works well on one asset may be unsuitable for another; traders often optimize the period on a per‑instrument basis.  
- **Extreme spikes:** Sudden news‑driven price jumps can cause T3 to overshoot, producing a brief reversal sign that does not reflect a genuine trend change.

### Practical tips
- Start with the default period of 5 and adjust only after observing how the indicator responds to the specific instrument’s volatility.  
- Combine T3 with another non‑correlated indicator (e.g., RSI or MACD) to confirm signals.  
- Use the indicator on higher time frames when the noise on lower frames makes the line less reliable.

## Text Formula
```
a = 2 / (period + 1)

EMA1[t] = (1 - a) * EMA1[t‑1] + a * price[t]
EMA2[t] = (1 - a) * EMA2[t‑1] + a * EMA1[t]
EMA3[t] = (1 - a) * EMA3[t‑1] + a * EMA2[t]
T3[t]   = (1 - a) * T3[t‑1]   + a * EMA3[t]
```
The final value `T3[t]` is the indicator output for the current bar.

## Python Code

```python
import pandas as pd

def compute_t3(df: pd.DataFrame, period: int = 5) -> pd.DataFrame:
    """
    Compute Tilson's T3 (triple exponential moving average) for each symbol in `df`.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain the columns ``symbol``, ``date``, ``close``.
    period : int, default 5
        Number of periods for the exponential smoothing.

    Returns
    -------
    pd.DataFrame
        DataFrame identical to ``df`` with an additional ``t3`` column.
        Values are NaN for the first ``period`` rows of each symbol
        because the smoothing requires enough history.
    """
    # smoothing constant
    a = 2.0 / (period + 1)

    def t3_for_series(close: pd.Series) -> pd.Series:
        # First EMA of the price series
        ema1 = close.ewm(alpha=a, adjust=False).mean()
        # Second EMA of the first EMA
        ema2 = ema1.ewm(alpha=a, adjust=False).mean()
        # Third EMA of the second EMA
        ema3 = ema2.ewm(alpha=a, adjust=False).mean()
        # Final smoothing – another EMA pass with the same alpha
        t3 = ema3.ewm(alpha=a, adjust=False).mean()
        return t3

    # Apply the calculation independently for each symbol
    result = (
        df.groupby("symbol", group_keys=False)
        .apply(lambda grp: grp.assign(t3=t3_for_series(grp["close"])))
    )
    return result
```
```json
{ "model_code": "l3hb7nm4tcd8", "topic": "T3", "timer_secs": 35.41, "tokens_in": 585, "tokens_out": 7303, "cost_tokens_in": 0.00017550, "cost_tokens_out": 0.00876360, "cost_tokens_tot": 0.00893910 }
```