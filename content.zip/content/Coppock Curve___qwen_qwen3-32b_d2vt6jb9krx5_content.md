# Coppock Curve

## Overview  
The Coppock Curve is a technical momentum indicator designed to identify long-term buy points in financial markets. Developed by Edwin Coppock in the 1960s, it is particularly popular among investors analyzing broad market indices like the S&P 500. The indicator appears as a single line on a chart, typically plotted below price action. It combines smoothed rate-of-change calculations to generate signals for potential bullish or bearish trends.

## Details  
The Coppock Curve is constructed by summing two rate-of-change (ROC) values—14-period and 11-period—and then applying a 10-period weighted moving average (WMA) to the result. This creates a lagging, smoothed oscillator that emphasizes long-term momentum shifts.  

Traders interpret the Coppock Curve in the following ways:  
- **Buy Signal**: When the curve crosses above zero after trending downward, it suggests a potential long-term buying opportunity.  
- **Sell Signal**: A cross below zero after an upward trend may indicate a market top.  

However, the indicator’s effectiveness is limited in choppy or sideways markets due to its inherent lag. It is best suited for trending environments and should be used alongside other tools to confirm signals. False positives can occur during periods of low volatility or structural market changes.  

Key considerations:  
- The indicator is **not ideal for short-term trading** (e.g., day trading) due to its slow response.  
- It works best on **weekly or monthly charts** but can be adapted for daily data with adjusted parameters.  
- Divergences between the Coppock Curve and price action may hint at weakening trends.  

## Text Formula  
The Coppock Curve is calculated in three steps:  

1. **Rate of Change (ROC)**:  
   $$
   \text{ROC}(n) = \left( \frac{\text{Current Close}}{\text{Close}_{n \text{ periods ago}}} \right) - 1
   $$  
   Compute for $ n = 14 $ and $ n = 11 $.  

2. **Sum of ROCs**:  
   $$
   \text{ROC Sum} = \text{ROC}(14) + \text{ROC}(11)
   $$  

3. **Weighted Moving Average (WMA)**:  
   Apply a 10-period WMA to the ROC Sum. Weights are assigned as $ 1, 2, \dots, 10 $ for the oldest to newest periods.  
   $$
   \text{Coppock Curve} = \frac{\sum_{i=1}^{10} (\text{ROC Sum}_i \times \text{Weight}_i)}{\sum_{i=1}^{10} \text{Weight}_i}
   $$  

## Python Code  
```python
import pandas as pd
import numpy as np

def calculate_coppock(df):
    # Sort by symbol and date
    df = df.sort_values(['symbol', 'date'])
    
    # Calculate 14-period and 11-period ROC
    df['roc14'] = (df['close'] / df['close'].shift(14)) - 1
    df['roc11'] = (df['close'] / df['close'].shift(11)) - 1
    
    # Sum of ROCs
    df['roc_sum'] = df['roc14'] + df['roc11']
    
    # Define weights for 10-period WMA (1 to 10)
    weights = np.arange(1, 11)
    
    # Apply 10-period WMA to ROC Sum
    def wma(values):
        return np.dot(values, weights) / weights.sum()
    
    df['coppock_curve'] = df.groupby('symbol')['roc_sum'].rolling(10).apply(wma, raw=False).reset_index(level=0, drop=True)
    
    return df
```  

**Input Requirements**:  
- A Pandas DataFrame with columns: `symbol`, `date`, `open`, `high`, `low`, `close`.  
- Data must be sorted by `symbol` and `date` before passing to the function.  

**Output**:  
- The original DataFrame with additional columns:  
  - `roc14`: 14-period ROC  
  - `roc11`: 11-period ROC  
  - `roc_sum`: Sum of ROCs  
  - `coppock_curve`: Final Coppock Curve values  

The code handles multiple symbols independently using `groupby`, ensuring accurate calculations for each security.
```json
{ "model_code": "d2vt6jb9krx5", "topic": "Coppock Curve", "timer_secs": 8.63, "tokens_in": 563, "tokens_out": 3873, "cost_tokens_in": 0.00004504, "cost_tokens_out": 0.00092952, "cost_tokens_tot": 0.00097456 }
```