# Bollinger Bands

## Overview

Bollinger Bands are a widely used technical analysis indicator designed to measure market volatility and identify overbought or oversold conditions. On a price chart, the indicator appears as three distinct lines overlaid on the price action: a central moving average flanked by an upper and lower band. The indicator was developed by financial analyst John Bollinger in the early 1980s and has since become a staple in the toolkits of both retail and institutional traders.

## Details

### Mechanics and Construction
Bollinger Bands are constructed using a simple moving average (SMA) and standard deviations. The default parameters established by Bollinger are a 20-period SMA for the middle band, and two standard deviations for the upper and lower bands. Because standard deviation is a mathematical measure of volatility, the bands dynamically adjust to market conditions. They widen during periods of high volatility and contract during periods of low volatility. 

In a normal statistical distribution, two standard deviations encompass approximately 95% of the data. Therefore, the theoretical premise is that 95% of price action should remain within the upper and lower bands. 

### Trading Interpretations
Active traders utilize Bollinger Bands for several distinct strategies:

*   **The Bollinger Squeeze:** This is the most prominent volatility-based signal. When the bands contract tightly around the price, it indicates a period of low volatility. Traders interpret a squeeze as a precursor to a significant volatility expansion and a potential breakout. The direction of the breakout is typically confirmed by price closing outside the bands or by secondary momentum indicators.
*   **Mean Reversion:** In ranging or sideways markets, traders use the bands as dynamic support and resistance levels. A price touching the lower band may be viewed as oversold, presenting a buying opportunity, while a touch of the upper band may be viewed as overbought, presenting a shorting opportunity. 
*   **Walking the Bands:** In strong trending markets, price can "walk" or ride the upper or lower band for extended periods. A series of candles closing near or slightly outside the upper band indicates strong bullish momentum, not necessarily an overbought condition requiring a reversal trade.
*   **Pattern Recognition:** Bollinger popularized the use of the bands to identify W-bottoms and M-tops. For a W-bottom, the first low touches or pierces the lower band, but the second low remains above the lower band, indicating waning bearish momentum despite a lower price. The inverse logic applies to M-tops at the upper band.

### Limitations and Breakdowns
The primary flaw in amateur interpretations of Bollinger Bands is treating band touches as automatic reversal signals. The indicator is purely a measure of volatility, not directional momentum. 

The interpretation breaks down severely in strongly trending markets. Mean-reversion traders who short an asset simply because it touched the upper band will frequently suffer heavy losses during a sustained uptrend as the price "walks" the upper band. Furthermore, because the middle band is a moving average, the entire indicator is inherently lagging. It reacts to price changes rather than predicting them. Consequently, Bollinger Bands should rarely be used in isolation; they are most effective when combined with volume analysis, momentum oscillators like the RSI, or broader market context.

## Text Formula

The calculation for Bollinger Bands requires the closing price, a lookback period (n), and a standard deviation multiplier (m). The default values are n = 20 and m = 2.

Middle Band = Simple Moving Average (Close, n)
Upper Band = Middle Band + (m * Standard Deviation (Close, n))
Lower Band = Middle Band - (m * Standard Deviation (Close, n))
Bandwidth = (Upper Band - Lower Band) / Middle Band

*Note: Bandwidth is a derived metric used to quantify the squeeze. A lower Bandwidth value indicates tighter bands and lower volatility.*

## Python Code

```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculates Bollinger Bands and Bandwidth for a Pandas DataFrame.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame containing the columns 
                       'symbol', 'date', 'open', 'high', 'low', 'close'.
    window (int): Lookback period for the moving average and standard deviation.
    num_std (float): Number of standard deviations for the upper and lower bands.
    
    Returns:
    pd.DataFrame: DataFrame with added columns: 'bb_middle', 'bb_upper', 
                  'bb_lower', and 'bb_bandwidth'.
    """
    # Ensure the data is sorted chronologically within each symbol
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Group by symbol to ensure calculations are performed independently per asset
    grouped_close = df.groupby('symbol')['close']
    
    # Calculate the Middle Band (Simple Moving Average)
    df['bb_middle'] = grouped_close.transform(
        lambda x: x.rolling(window=window, min_periods=window).mean()
    )
    
    # Calculate the rolling standard deviation
    # ddof=0 is used for population standard deviation, standard in many charting platforms
    rolling_std = grouped_close.transform(
        lambda x: x.rolling(window=window, min_periods=window).std(ddof=0)
    )
    
    # Calculate the Upper and Lower Bands
    df['bb_upper'] = df['bb_middle'] + (num_std * rolling_std)
    df['bb_lower'] = df['bb_middle'] - (num_std * rolling_std)
    
    # Calculate Bandwidth to measure volatility squeezes
    df['bb_bandwidth'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
    
    return df
```
```json
{ "model_code": "l8nf5cm3wph7", "topic": "Bollinger Bands", "timer_secs": 68.88, "tokens_in": 580, "tokens_out": 4272, "cost_tokens_in": 0.00072500, "cost_tokens_out": 0.01602000, "cost_tokens_tot": 0.01674500 }
```