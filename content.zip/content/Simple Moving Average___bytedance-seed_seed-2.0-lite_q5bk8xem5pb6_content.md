# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is the most foundational trend-following technical indicator, designed to filter out short-term price volatility and highlight sustained directional moves in an asset’s price. It plots as a single continuous line overlaid directly on an asset’s price chart, updating at the end of each trading period to reflect the most recent window of historical prices. Unlike many modern technical indicators, the SMA has no single attributed creator, with roots in the early 20th century formalization of technical analysis, and it remains a core tool for retail and institutional traders alike.

## Details
### Core Mechanics
Unlike weighted moving averages that prioritize recent price data, the SMA assigns equal weight to every price in its calculation window, making it the most straightforward moving average variant. Traders use standardized window lengths aligned with their time horizon: 20-day SMAs for short-term swing trading, 50-day SMAs for medium-term trend tracking, and 200-day SMAs for long-term market analysis. The SMA only updates once per period, dropping the oldest price in the window and adding the most recent period’s close to maintain a fixed lookback period.

### Standard Interpretation
Traders use SMAs for three core use cases:
1. **Trend confirmation**: An asset trading above its 200-day SMA is broadly considered to be in a long-term uptrend, while a price below that SMA signals a sustained downtrend. Many traders avoid long positions in assets trading below their 200-day SMA to reduce broad downside exposure.
2. **Dynamic support and resistance**: In consistent uptrends, price pullbacks often find support at the SMA, as buyers step in at the widely followed average historical price. In downtrends, the SMA acts as dynamic resistance, with price rallies frequently failing at the SMA level as sellers enter.
3. **Crossover signals**: The most widely followed crossover signals are the *golden cross* (50-day SMA crossing above the 200-day SMA, interpreted as a long-term bullish signal) and the *death cross* (50-day SMA crossing below the 200-day SMA, a long-term bearish signal). Shorter-term crossovers, such as a 20-day SMA crossing above a 50-day SMA, are used to time entries for swing trades.

### Common Limitations
SMA interpretation breaks down in four key scenarios:
1. **Inherent lag**: As a lagging indicator, the SMA only confirms a trend after it has begun, meaning traders entering positions based on SMA crossovers often miss 10-20% of a new trend’s initial price move.
2. **Whipsaws in sideways markets**: In range-bound markets where price fluctuates within a narrow band, SMA crossovers occur frequently, generating false signals that lead to repeated small losses from excessive trading.
3. **Equal weighting flaw**: The SMA’s equal weighting of all prices in its window means a one-off volatile price spike 19 days prior impacts a 20-day SMA as much as the previous day’s close, distorting current trend strength.
4. **Overfitting risk**: There is no universal "correct" SMA window length, so traders often backtest window lengths that fit historical data, leading to overfitting and poor performance in untested future market conditions.

## Text Formula
The SMA is calculated by summing the closing prices of all periods in a fixed window, then dividing that sum by the number of periods in the window. All prices receive equal weight.
First, define core terms:
- `SMAₙ`: Simple Moving Average calculated for an n-period window
- `P₁`: Closing price (`close`) of the most recent period in the window
- `Pᵢ`: Closing price of the i-th period in the window, counting backward from the most recent period
- `Pₙ`: Closing price of the oldest period in the window

The full formula is:
`SMAₙ = (P₁ + P₂ + ... + Pₙ) / n`

As each new trading period closes, the window rolls forward: the oldest price from the prior calculation is dropped, the new period’s close is added as the new `P₁`, and the SMA is recalculated to produce a continuous line.

## Python Code
```python
import pandas as pd

def calculate_sma(df, windows=[20, 50, 200]):
    """
    Calculate Simple Moving Averages (SMA) for one or more assets, processing each symbol independently.
    
    Required input DataFrame columns:
        `symbol`: Unique identifier for the asset (e.g., 'AAPL')
        `date`: Datetime or string representing the period's date, sorted ascending
        `open`: Period opening price
        `high`: Period highest price
        `low`: Period lowest price
        `close`: Period closing price, used for SMA calculations
    
    Args:
        df (pd.DataFrame): Input DataFrame of OHLC data for one or more symbols
        windows (list): List of integers representing the period windows to calculate SMA for
    
    Returns:
        pd.DataFrame: Original DataFrame with new `sma_{n}` columns added for each window length
    """
    # Validate input contains all required columns
    required_cols = ['symbol', 'date', 'open', 'high', 'low', 'close']
    if not all(col in df.columns for col in required_cols):
        raise ValueError(f"Input DataFrame missing required columns: {required_cols}")
    
    # Ensure data is sorted by symbol and date to calculate accurate rolling averages
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate SMA for each window, grouped by symbol to avoid cross-contamination between assets
    for window in windows:
        df[f'sma_{window}'] = df.groupby('symbol')['close'].transform(
            lambda x: x.rolling(window=window).mean()
        )
    
    return df
```
```json
{ "model_code": "q5bk8xem5pb6", "topic": "Simple Moving Average", "timer_secs": 198.46, "tokens_in": 627, "tokens_out": 4831, "cost_tokens_in": 0.00015675, "cost_tokens_out": 0.00966200, "cost_tokens_tot": 0.00981875 }
```