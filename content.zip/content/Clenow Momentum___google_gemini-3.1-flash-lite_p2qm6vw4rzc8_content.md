# Clenow Momentum

## Overview
Clenow Momentum, often referred to as "Risk-Adjusted Momentum," is a trend-following indicator popularized by quantitative trader Andreas Clenow in his book *Stocks on the Move*. Unlike simple price-rate-of-change indicators, Clenow Momentum measures the consistency of a trend by calculating the annualized slope of a linear regression line fitted to the log-transformed closing prices, then multiplying that slope by the coefficient of determination ($R^2$). This approach filters out volatile, erratic price moves in favor of smooth, persistent trends.

## Details
The core philosophy behind Clenow Momentum is that a stock’s future performance is better predicted by the quality of its past trend than by the raw magnitude of its price increase. A stock that climbs steadily with low variance is considered a higher-quality momentum candidate than one that achieves the same total return through violent, high-volatility swings.

### How it Works
The calculation involves three distinct steps:
1. **Log Transformation:** The closing prices are converted to their natural logarithms. This transforms percentage changes into additive changes, ensuring that the regression slope represents a constant percentage growth rate.
2. **Linear Regression:** A linear regression is performed on the log-transformed prices over a lookback period (typically 90 trading days). The slope of this line represents the average daily growth rate.
3. **Annualization and Adjustment:** The slope is annualized to provide a standard metric. Finally, the result is multiplied by the $R^2$ value of the regression. The $R^2$ acts as a "penalty" for volatility; if the price action is noisy and deviates significantly from the regression line, the $R^2$ will be low, effectively discounting the momentum score.

### Interpretation
Traders use this indicator to rank assets within a universe. A high positive value indicates a strong, consistent uptrend. When building a portfolio, traders typically select the top-ranked assets by Clenow Momentum, as these stocks have demonstrated the highest probability of continuing their current trajectory.

### Limitations
The primary breakdown occurs during regime shifts. Because the indicator relies on a fixed lookback period, it is inherently lagging. In a sudden market reversal, the indicator will remain positive until the regression line begins to tilt downward, which may take several days or weeks. Furthermore, the $R^2$ component can be misleading in assets that exhibit "step-function" growth—where a stock gaps up and then consolidates—as the lack of continuous data points can artificially lower the $R^2$ despite a strong overall trend.

## Text Formula
To calculate the Clenow Momentum for a given lookback period $n$:

1. Let $P$ be the series of closing prices.
2. Calculate the log-transformed series: $L = \ln(P)$.
3. Perform a linear regression of $L$ against the index $x = [0, 1, 2, ..., n-1]$.
4. The regression yields a slope $m$ and a coefficient of determination $R^2$.
5. Annualize the slope: $Annualized Slope = (e^m - 1) \times 252$.
6. Calculate Clenow Momentum: $Momentum = Annualized Slope \times R^2$.

## Python Code
```python
import numpy as np
import pandas as pd
from scipy.stats import linregress

def calculate_clenow_momentum(df, lookback=90):
    """
    Calculates Clenow Momentum for symbols in a DataFrame.
    
    Input DataFrame columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    Returns a Series of momentum values aligned with the input DataFrame.
    """
    
    def get_momentum(prices):
        if len(prices) < lookback:
            return np.nan
        
        # Log transform the prices
        log_prices = np.log(prices)
        x = np.arange(len(log_prices))
        
        # Linear regression
        slope, intercept, r_value, p_value, std_err = linregress(x, log_prices)
        
        # Annualize the slope
        # (exp(slope) - 1) gives the daily return, 252 is trading days per year
        annualized_slope = (np.exp(slope) - 1) * 252
        
        # Multiply by R-squared (coefficient of determination)
        r_squared = r_value ** 2
        return annualized_slope * r_squared

    # Group by symbol to ensure independent calculation
    results = df.groupby('symbol')['close'].rolling(window=lookback).apply(get_momentum, raw=True)
    
    # Reset index to match original dataframe structure
    return results.reset_index(level=0, drop=True)

# Example usage:
# df['clenow_mom'] = calculate_clenow_momentum(df, lookback=90)
```
```json
{ "model_code": "p2qm6vw4rzc8", "topic": "Clenow Momentum", "timer_secs": 5.09, "tokens_in": 566, "tokens_out": 1090, "cost_tokens_in": 0.00014150, "cost_tokens_out": 0.00163500, "cost_tokens_tot": 0.00177650 }
```