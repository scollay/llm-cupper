# Bollinger Bands

## Overview
Bollinger Bands are a widely used technical indicator that plots three dynamic volatility bands around an asset’s price action, adapting to shifting market conditions to contextualize price levels and trend strength. Created by financial analyst John Bollinger in the early 1980s, they were designed to address flaws in fixed-percentage trading bands, which failed to account for changing volatility across assets and time periods. On a price chart, the three bands overlay a candlestick or line plot: a middle line that acts as the indicator’s baseline, an upper band that caps typical high prices, and a lower band that sets a typical low price. The distance between the upper and lower bands expands and contracts as volatility rises or falls.

## Details
### Core Mechanics
Bollinger Bands’ default settings use a 20-period simple moving average (SMA) for the middle band, with the upper and lower bands set 2 standard deviations away from this baseline. Statistically, 2 standard deviations capture roughly 95% of normal price action for most assets, so any close outside the bands is considered a notable, non-random event. When volatility spikes (for example, around earnings releases or central bank announcements), bands widen to reflect the expanded range of plausible price moves. During periods of low volatility, bands contract, creating the well-known "Bollinger Squeeze" setup that traders use to identify impending breakouts.

### Common Trading Interpretations
Traders use Bollinger Bands for four core use cases:
1. **Overbought/oversold context**: A price touch at the upper band is often interpreted as a sign the asset is overbought (at risk of a pullback), while a touch at the lower band signals it may be oversold (primed for a bounce). This works best in range-bound markets where price oscillates between the bands.
2. **Squeeze breakout trading**: Narrow, multi-period band contraction (the squeeze) signals suppressed volatility that almost always precedes a large, sustained trend. Traders watch for a decisive close outside the upper or lower band to confirm the breakout’s direction, pairing the signal with volume data to validate follow-through.
3. **Trend continuation confirmation**: Contrary to overbought/oversold logic, a close outside the upper band during an established uptrend, or below the lower band during a downtrend, usually signals the trend is accelerating rather than overextending. Strong trends often see price "ride" one band for weeks or months as it climbs or falls.
4. **Reversal pattern validation**: Double bottoms that touch the lower band twice before reversing higher, or double tops that test the upper band twice before turning down, are considered high-probability reversals when confirmed by Bollinger Bands.

### Key Interpretation Pitfalls
Bollinger Bands are reliable only when used correctly, and common misinterpretations lead to consistent losses:
- Treating overbought/oversold readings as automatic reversal signals is the costliest mistake. Price can stick to a band for months during strong trends, leading traders to exit winning positions early or enter countertrend trades that get stopped out.
- Using the default 20-period/2-standard-deviation settings for all timeframes and assets. Day traders on 15-minute charts need shorter lookback periods to capture intraday volatility, while long-term swing traders on weekly charts often use a 50-period SMA and 2.5 standard deviations to account for slower, larger price moves.
- Relying on squeeze signals without confirmation. False breakouts are common: bands may contract, trigger a small fakeout that lures traders into a position, then reverse in the opposite direction. Squeezes require validation from momentum indicators like RSI or MACD to reduce false positives.
- The indicator is inherently lagging, as it relies on past price data. It cannot predict uncorrelated volatility shocks like unexpected regulatory news or geopolitical events that cause price gaps far outside the bands.

## Text Formula
Bollinger Bands are calculated for each time period `t`, using a user-defined lookback period `n` (default 20) and standard deviation multiplier `m` (default 2). For any period `t`, the input set is the `n` most recent closing prices, ranging from period `t-n+1` to the current period `t`:
1. **Middle Band (`MB_t`)**: The n-period SMA of closing prices, calculated as `MB_t = (sum of closing prices from t-n+1 to t) / n`
2. **Rolling Standard Deviation (`σ_t`)**: The sample standard deviation of the same n-period set of closing prices, measuring price dispersion around the SMA
3. **Upper and Lower Bands**: Calculated by scaling the standard deviation and offsetting from the middle band: `UB_t = MB_t + (m * σ_t)` and `LB_t = MB_t - (m * σ_t)`

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, n=20, m=2):
    """
    Calculates Bollinger Bands for a time series DataFrame of asset prices.
    Input DataFrame must contain columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    Input DataFrame must be sorted by `symbol` then `date` (ascending) to ensure valid rolling window calculations.
    Handles multiple symbols by calculating bands independently for each asset's time series.
    
    Parameters:
        df (pd.DataFrame): Input price DataFrame
        n (int): Lookback period for SMA and standard deviation calculation, default 20
        m (float): Standard deviation multiplier for upper/lower bands, default 2
    
    Returns:
        pd.DataFrame: Input DataFrame with three new columns added:
            bollinger_mid: Middle band (n-period SMA of close)
            bollinger_upper: Upper Bollinger Band
            bollinger_lower: Lower Bollinger Band
    """
    # Validate required columns exist
    required_cols = ['symbol', 'date', 'open', 'high', 'low', 'close']
    if not all(col in df.columns for col in required_cols):
        raise ValueError(f"Input DataFrame missing one or more required columns: {required_cols}")
    
    # Calculate bands per symbol to avoid cross-contamination between assets
    def add_bands(group):
        # Calculate rolling SMA (middle band)
        group['bollinger_mid'] = group['close'].rolling(window=n).mean()
        # Calculate rolling standard deviation of close
        rolling_std = group['close'].rolling(window=n).std()
        # Calculate upper and lower bands
        group['bollinger_upper'] = group['bollinger_mid'] + (m * rolling_std)
        group['bollinger_lower'] = group['bollinger_mid'] - (m * rolling_std)
        return group
    
    # Apply band calculation to each symbol's time series
    df = df.groupby('symbol', group_keys=False).apply(add_bands)
    return df
```
```json
{ "model_code": "q5bk8xem5pb6", "topic": "Bollinger Bands", "timer_secs": 286.41, "tokens_in": 627, "tokens_out": 4721, "cost_tokens_in": 0.00015675, "cost_tokens_out": 0.00944200, "cost_tokens_tot": 0.00959875 }
```