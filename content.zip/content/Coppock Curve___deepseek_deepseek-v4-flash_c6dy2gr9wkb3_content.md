# Coppock Curve

## Overview
The Coppock Curve is a long‑term momentum oscillator developed by economist Edwin Coppock in 1962. It was originally designed to identify major buying opportunities in the S&P 500 following deep bear markets. On a chart, the indicator appears as a single line that oscillates above and below a zero level. A buy signal is generated when the line crosses up from below zero, and a sell signal when it crosses down from above zero. The indicator is best used on monthly closing prices and is known for its lagging, trend‑following nature.

## Details
The Coppock Curve is calculated in three steps: First, compute the 14‑month and 11‑month Rates of Change (ROC) of the closing price. Second, sum these two ROC values. Third, apply a 10‑period **weighted moving average** (WMA) to the summed series. The WMA assigns the heaviest weight to the most recent period (weight = 10) and the lightest to the oldest (weight = 1).

| WMA period | Weight |
|------------|--------|
| t – 9      | 1      |
| t – 8      | 2      |
| …          | …      |
| t          | 10     |

The resulting curve is typically interpreted as follows:

- **Buy signal**: The curve turns upward and crosses above the zero line. This suggests that long‑term momentum has shifted from negative to positive, often after a sustained decline.
- **Sell signal**: The curve turns downward and crosses below the zero line. This is less frequently used; many traders rely on the buy signal only because the indicator was built for entry timing.
- **Divergence**: If price makes a new low but the Coppock Curve makes a higher low, a bullish divergence is present. Similarly, bearish divergence can occur at market tops, but the indicator is slow.

**Where interpretation breaks down**:

- The indicator is inherently lagging; by the time it turns up, a significant portion of the recovery may have already occurred.
- False signals happen in choppy, sideways markets when the curve oscillates around zero without a clear trend.
- Because it uses monthly data, it reacts slowly to weekly or daily events. Attempting to use it on shorter timeframes (e.g., daily) introduces noise and violates Coppock’s original design.
- The indicator is not suitable for short‑term trading or for instruments that lack a clear cyclical pattern.
- Parameter values (14‑month and 11‑month ROC, 10‑period WMA) are fixed; tweaking them changes the nature of the signal and can lead to overfitting.

## Text Formula

Let \( C_t \) be the monthly closing price at month \( t \).

**Step 1 – 14‑month and 11‑month Rate of Change**  
\[
ROC14_t = \frac{C_t - C_{t-14}}{C_{t-14}} \times 100
\]  
\[
ROC11_t = \frac{C_t - C_{t-11}}{C_{t-11}} \times 100
\]

**Step 2 – Sum**  
\[
S_t = ROC14_t + ROC11_t
\]

**Step 3 – 10‑period Weighted Moving Average**  
\[
CoppockCurve_t = \frac{ \sum_{i=0}^{9} (10 - i) \times S_{t-i} }{ \sum_{i=0}^{9} (10 - i) }
\]

The denominator is the sum of weights: \( 1 + 2 + \cdots + 10 = 55 \).

Thus,  
\[
CoppockCurve_t = \frac{10 \cdot S_t + 9 \cdot S_{t-1} + \cdots + 1 \cdot S_{t-9}}{55}
\]

## Python Code

The function below computes the Coppock Curve for one or more symbols. It expects a pandas DataFrame with columns: `symbol`, `date`, `close` (and optionally `open`, `high`, `low`). Data can be daily; the function resamples to month‑end closing prices before calculation. It returns a DataFrame with columns `symbol`, `date` (month‑end), and `coppock_curve`. The computation is performed independently per symbol using `groupby`.

```python
import pandas as pd
import numpy as np

def coppock_curve(df: pd.DataFrame, 
                  roc_fast: int = 11, 
                  roc_slow: int = 14, 
                  wma_period: int = 10) -> pd.DataFrame:
    """
    Compute the Coppock Curve for one or more symbols.

    Parameters
    ----------
    df : pandas.DataFrame
        Must contain columns: 'symbol', 'date', 'close'. 
        Data can be daily or any frequency; the function will 
        resample to month-end (last available close per month).
        Additional columns (open, high, low) are ignored.
    roc_fast : int, default 11
        Short-term ROC period (in months).
    roc_slow : int, default 14
        Long-term ROC period (in months).
    wma_period : int, default 10
        Period for the weighted moving average (in months).

    Returns
    -------
    pandas.DataFrame
        Columns: 'symbol', 'date' (month-end), 'coppock_curve'.
        Rows for which the indicator cannot be computed are excluded.
    """
    # Ensure date column is datetime
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])

    # Resample to month-end: take last close of each month per symbol
    df_monthly = (df
                  .set_index('date')
                  .groupby('symbol')
                  .resample('M')
                  .last()
                  .reset_index(level=1)  # keep month-end date as column
                  .reset_index(drop=True))

    # Sort for time series operations
    df_monthly.sort_values(['symbol', 'date'], inplace=True)

    # Compute 14-month and 11-month ROC as percentage
    df_monthly['roc_slow'] = (df_monthly.groupby('symbol')['close']
                              .transform(lambda x: x.pct_change(periods=rocf_slow) * 100))
    df_monthly['roc_fast'] = (df_monthly.groupby('symbol')['close']
                              .transform(lambda x: x.pct_change(periods=roc_fast) * 100))

    # Sum the two ROC values
    df_monthly['raw_sum'] = df_monthly['roc_slow'] + df_monthly['roc_fast']

    # Apply 10-period weighted moving average per symbol
    def wma(series: pd.Series, period: int) -> pd.Series:
        """Weighted moving average: weights = period down to 1."""
        weights = np.arange(1, period + 1)
        return series.rolling(window=period).apply(
            lambda x: np.dot(x, weights) / weights.sum(), raw=True
        )

    df_monthly['coppock_curve'] = (df_monthly.groupby('symbol')['raw_sum']
                                   .transform(lambda x: wma(x, wma_period)))

    # Drop rows with NaN caused by ROC or WMA lookback
    result = df_monthly.dropna(subset=['coppock_curve'])

    return result[['symbol', 'date', 'coppock_curve']].reset_index(drop=True)
```
```json
{ "model_code": "c6dy2gr9wkb3", "topic": "Coppock Curve", "timer_secs": 53.90, "tokens_in": 560, "tokens_out": 1958, "cost_tokens_in": 0.00007840, "cost_tokens_out": 0.00054824, "cost_tokens_tot": 0.00062664 }
```