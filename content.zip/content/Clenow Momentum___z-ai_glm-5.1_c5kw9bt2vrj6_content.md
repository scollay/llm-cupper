# Clenow Momentum

## Overview

Clenow Momentum is a trend-following indicator that measures the annualized rate of return of a security, adjusted for the smoothness of its trend. Developed by quantitative trader and author Andreas Clenow and introduced in his 2012 book "Following the Trend," it aims to solve a common problem in trend analysis: distinguishing between a clean, tradeable trend and a noisy, volatile one. On a chart, the indicator typically appears as a histogram or a line oscillating around a zero line, with positive values indicating an uptrend and negative values indicating a downtrend. It is most commonly used as a ranking tool for a universe of assets rather than as an overbought or oversold oscillator.

## Details

The indicator works by running a linear regression on the natural logarithm of closing prices over a specified lookback period, typically 90 days. Taking the natural log of prices is a crucial step; it transforms compounding percentage moves into linear arithmetic moves. In finance, price changes are typically measured in percentages. A $10 move on a $100 stock is a 10% return, but a $10 move on a $1,000 stock is a 1% return. If you run a linear regression on raw prices, the slope will be heavily dependent on the absolute price level, making it impossible to compare momentum across different assets. By taking the natural log, percentage changes become linear. A constant percentage growth rate translates into a straight line on a log chart, allowing the regression slope to represent a standardized growth rate regardless of the asset's price.

The slope of this regression line represents the daily exponential growth rate. To make this number intuitive, the slope is annualized, converting it into a percentage return that traders can easily grasp. However, a steep slope alone does not make a good trend. A stock experiencing high volatility might have a steep overall trajectory but with massive drawdowns along the way. 

This is where the indicator's second component comes in: the R-squared (coefficient of determination) of the regression. R-squared measures how closely the price data fits the regression line, ranging from 0 to 1. A high R-squared indicates a clean, smooth trend, while a low R-squared indicates a noisy, erratic chart. 

Clenow Momentum multiplies the annualized slope by the R-squared. This multiplication acts as a penalty factor. Consider two stocks, both showing a 30% annualized slope. Stock A has an R-squared of 0.95, meaning its price action is exceptionally clean and follows a tight linear path on the log chart. Stock B has an R-squared of 0.20, meaning its path is highly erratic, with violent swings away from the regression line. While both have the same theoretical growth rate, Stock A is far more tradeable. Clenow Momentum assigns Stock A a score of 28.5 and Stock B a score of 6.0. The indicator effectively filters out high-volatility noise, prioritizing the smoothness of the trend.

Traders typically use Clenow Momentum to rank a universe of stocks or futures. A common systematic strategy involves going long the top decile of assets ranked by Clenow Momentum and shorting the bottom decile, rebalancing on a weekly or monthly basis. When used on a single asset, a cross above zero signals a nascent uptrend, while a cross below zero signals a downtrend.

Where interpretation tends to break down:

*   **Lagging Nature:** Because it relies on a 90-day regression, the indicator is inherently lagging. It will not catch market tops or bottoms and will only signal a trend change well after the price has reversed.
*   **R-Squared Volatility:** R-squared can deteriorate very quickly with just a few outlier days. A stock in a steady uptrend might experience a sudden, sharp bearish reversal day. While the slope might still be positive, that single outlier can drastically pull down the R-squared, collapsing the Clenow Momentum score. The trend might still be structurally intact, but the indicator will flash a severe warning.
*   **Mean-Reverting Markets:** Like all trend-following tools, Clenow Momentum performs poorly in choppy, mean-reverting markets. It will generate false signals as prices oscillate without a clear directional bias, leading to whipsaws.

## Text Formula

Let `N` be the lookback period (typically 90).
Let `x` be the time index, ranging from `1` to `N`.
Let `y` be the natural logarithm of the closing prices: `y = ln(close)`.

1. Calculate the slope of the linear regression of `y` on `x`:
   `slope = (N * Σ(x * y) - Σx * Σy) / (N * Σ(x^2) - (Σx)^2)`

2. Calculate the R-squared of the regression:
   `R^2 = (Correlation(x, y))^2`

3. Annualize the slope to represent the annualized exponential growth rate (assuming 252 trading days in a year):
   `Annualized Slope = (e^(slope * 252) - 1)`

4. Calculate Clenow Momentum:
   `Clenow Momentum = Annualized Slope * R^2`

## Python Code

```python
import numpy as np
import pandas as pd
from scipy.stats import linregress

def calculate_clenow_momentum(df, lookback=90):
    """
    Calculates Clenow Momentum for one or more symbols.
    
    Parameters:
    df (pd.DataFrame): Must contain columns: symbol, date, open, high, low, close
    lookback (int): The regression lookback period, typically 90.
    
    Returns:
    pd.DataFrame: Original dataframe with added columns:
                  'slope', 'r_squared', 'annualized_slope', 'clenow_momentum'
    """
    # Ensure data is sorted chronologically for each symbol
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Calculate natural log of closing prices
    df['log_close'] = np.log(df['close'])
    
    # Define helper functions for the rolling window
    def rolling_slope(y):
        # x is simply the time index 1, 2, 3... N
        x = np.arange(1, len(y) + 1)
        # linregress returns: slope, intercept, r_value, p_value, std_err
        return linregress(x, y).slope
        
    def rolling_r_squared(y):
        x = np.arange(1, len(y) + 1)
        # r_value squared gives R-squared
        return linregress(x, y).rvalue ** 2

    # Apply rolling calculations independently for each symbol
    df['slope'] = df.groupby('symbol')['log_close'].transform(
        lambda x: x.rolling(window=lookback, min_periods=lookback).apply(rolling_slope, raw=True)
    )
    
    df['r_squared'] = df.groupby('symbol')['log_close'].transform(
        lambda x: x.rolling(window=lookback, min_periods=lookback).apply(rolling_r_squared, raw=True)
    )
    
    # Calculate annualized slope
    # Assuming 252 trading days in a year
    df['annualized_slope'] = (np.exp(df['slope'] * 252) - 1)
    
    # Calculate final Clenow Momentum score
    df['clenow_momentum'] = df['annualized_slope'] * df['r_squared']
    
    # Drop intermediate column
    df.drop(columns=['log_close'], inplace=True)
    
    return df
```
```json
{ "model_code": "c5kw9bt2vrj6", "topic": "Clenow Momentum", "timer_secs": 114.28, "tokens_in": 560, "tokens_out": 6914, "cost_tokens_in": 0.00054880, "cost_tokens_out": 0.02129512, "cost_tokens_tot": 0.02184392 }
```