# Tillson T3

## Overview
The **Tillson T3**, developed by technical analyst Tim Tillson in 1998, is a smoothed moving average designed to reduce lag and filter out price noise more effectively than standard **simple moving averages (SMA)** or **exponential moving averages (EMA)**. It appears on price charts as a single, smooth line that tracks price action with minimal choppiness, and is commonly used for trend identification, entry/exit signal generation, and confirming price momentum. Unlike traditional moving averages, the T3 incorporates an adjustable **volume factor** to balance responsiveness and smoothing for different trading timeframes and asset classes.

## Details
### Core Calculation Logic
The T3 is built on a series of nested exponential moving average (EMA) calculations, followed by a weighted sum of these EMAs using coefficients derived from a user-defined volume factor (`v`). The standard lookback period for the underlying EMAs is 14 periods, though traders adjust this to match their strategy (e.g., 20 for daily swing trades, 10 for intraday scalping). The volume factor `v` defaults to 0.7, and must fall between 0 and 1: lower values increase smoothing and lag, while higher values make the indicator more responsive to price changes but more prone to whipsaws.

### Typical Trader Interpretation
Traders use the T3 in three primary ways:
1. **Trend identification**: When price trades above the T3 line, the asset is considered to be in an uptrend; price below the T3 signals a downtrend. A flat T3 line indicates a consolidation or sideways market.
2. **Crossover signals**: A price close above the T3 generates a bullish entry signal, while a close below generates a bearish exit or short signal. Many traders also pair the T3 with a shorter-period moving average (e.g., a 10-period T3) and take long positions when the faster T3 crosses above the slower T3, and short positions on the reverse crossover.
3. **Momentum confirmation**: The slope of the T3 line indicates trend strength: a steep upward slope signals strong bullish momentum, while a steep downward slope signals strong bearish momentum. A flattening
```json
{ "model_code": "rps2b8a4fpay", "topic": "T3", "timer_secs": 49.42, "tokens_in": 566, "tokens_out": 10000, "cost_tokens_in": 0.00011320, "cost_tokens_out": 0.01150000, "cost_tokens_tot": 0.01161320 }
```