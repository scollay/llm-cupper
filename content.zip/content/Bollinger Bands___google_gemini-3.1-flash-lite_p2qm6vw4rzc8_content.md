# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical analysis tool developed by John Bollinger in the early 1980s. They consist of a set of three lines plotted in relation to a security's price: a middle band, which is typically a simple moving average (SMA), and two outer bands representing standard deviations above and below that average. On a chart, these bands expand and contract based on market volatility, providing a dynamic envelope that helps traders identify overbought or oversold conditions and potential trend reversals.

## Details
Bollinger Bands function on the principle that price action is relative to its recent history. By using standard deviation, the bands automatically adjust to changing market conditions. When volatility increases, the bands widen; when volatility decreases, the bands contract.

### Interpretation
Traders typically interpret the bands through three primary lenses:

*   **The Squeeze:** This occurs when the bands contract significantly, indicating a period of low volatility. Traders often view the squeeze as a precursor to a sharp breakout, as low-volatility environments are historically followed by high-volatility expansions.
*   **Mean Reversion:** In a range-bound market, the bands act as dynamic support and resistance levels. Prices touching the upper band are often considered overbought, while prices touching the lower band are considered oversold. Traders may look for reversal signals when the price hits these extremes.
*   **Trend Following:** In a strong trend, price often "rides the bands." A series of closes outside the bands does not necessarily signal a reversal; rather, it can indicate that the trend is accelerating. Conversely, if the price fails to reach the upper band during an uptrend, it may signal a loss of momentum.

### Limitations
The primary weakness of Bollinger Bands is that they are reactive, not predictive. Because they are based on a moving average, they inherently lag behind current price action. Furthermore, a price touching an outer band is not a standalone signal to buy or sell. In a strong trending market, a security can remain "overbought" or "oversold" for extended periods, leading to premature entries or exits if a trader relies solely on the bands without confirming momentum or volume indicators.

## Text Formula
The calculation for Bollinger Bands is derived from a simple moving average and the standard deviation of the closing price over a specified period (typically 20 periods).

1.  **Middle Band** = `SMA(Close, n)`
2.  **Upper Band** = `Middle Band + (k * Standard Deviation(Close, n))`
3.  **Lower Band** = `Middle Band - (k * Standard Deviation(Close, n))`

Where:
*   `n` = number of periods (default is 20).
*   `k` = number of standard deviations (default is 2).
*   `SMA` = Simple Moving Average.

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculates Bollinger Bands for a DataFrame.
    
    Expected DataFrame columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    The function handles multiple symbols by grouping by the 'symbol' column.
    """
    
    def compute_bands(group):
        # Calculate the middle band (Simple Moving Average)
        group['middle_band'] = group['close'].rolling(window=window).mean()
        
        # Calculate the standard deviation
        std_dev = group['close'].rolling(window=window).std()
        
        # Calculate upper and lower bands
        group['upper_band'] = group['middle_band'] + (num_std * std_dev)
        group['lower_band'] = group['middle_band'] - (num_std * std_dev)
        
        return group

    # Apply the calculation independently for each symbol
    df = df.groupby('symbol', group_keys=False).apply(compute_bands)
    
    return df

# Example usage:
# df = pd.read_csv('market_data.csv')
# df_with_bands = calculate_bollinger_bands(df)
```
```json
{ "model_code": "p2qm6vw4rzc8", "topic": "Bollinger Bands", "timer_secs": 4.13, "tokens_in": 564, "tokens_out": 907, "cost_tokens_in": 0.00014100, "cost_tokens_out": 0.00136050, "cost_tokens_tot": 0.00150150 }
```