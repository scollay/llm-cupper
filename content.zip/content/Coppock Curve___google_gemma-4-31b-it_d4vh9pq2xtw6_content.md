# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum indicator designed to identify the primary turning point of a bear market into a bull market. Developed by economist Edwin Coppock in 1962, it appears as a single oscillating line that fluctuates above and below a zero line. Unlike oscillators used for short-term timing, the Coppock Curve is specifically intended for long-term investors seeking a signal to enter the market after a prolonged decline.

## Details
The Coppock Curve is a "momentum of momentum" indicator. It does not track price action directly but rather the rate of change in price over two different time horizons. By summing these rates of change and applying a weighted moving average, the indicator smooths out short-term volatility to highlight the broader trend.

### Interpretation
Traders primarily use the Coppock Curve to identify buying opportunities. The core signal is a **bullish reversal**: when the indicator is below zero and begins to turn upward, it suggests that the downward momentum has exhausted and a new long-term uptrend is beginning.

*   **Buy Signal:** A trough formed below the zero line followed by a positive slope.
*   **Sell Signal:** While the indicator is primarily a buying tool, some traders view a peak and subsequent decline as a signal to reduce exposure, though it is significantly less reliable for timing exits than for timing entries.

### Limitations
The Coppock Curve is not a versatile tool for all market conditions. Because it uses long-term timeframes, it is prone to significant lag; by the time a signal is generated, a meaningful portion of the recovery may have already occurred. 

Furthermore, the indicator is ineffective in sideways or range-bound markets. In these environments, the curve may oscillate around the zero line, producing "whipsaws" or false signals. It is most effective when applied to monthly charts of broad indices (like the S&P 500) rather than individual volatile stocks.

## Text Formula
The Coppock Curve is calculated using the following steps:

1.  **Rate of Change (ROC) 1:** `((Current Close - Close 14 periods ago) / Close 14 periods ago) * 100`
2.  **Rate of Change (ROC) 2:** `((Current Close - Close 11 periods ago) / Close 11 periods ago) * 100`
3.  **Sum of ROCs:** `ROC 1 + ROC 2`
4.  **Coppock Curve:** A 10-month Weighted Moving Average (WMA) of the Sum of ROCs.

The WMA is calculated by multiplying the most recent `Sum of ROCs` by 10, the previous by 9, and so on, then dividing the total by the sum of the weights (which for a 10-period WMA is 55).

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df):
    """
    Calculates the Coppock Curve for a DataFrame.
    
    Input DataFrame columns: 'symbol', 'date', 'open', 'high', 'low', 'close'
    Returns: DataFrame with 'coppock_curve' column added.
    """
    # Ensure data is sorted by date to maintain time-series integrity
    df = df.sort_values(['symbol', 'date'])
    
    # Calculate 14-period Rate of Change
    # ROC = ((Price_t - Price_{t-n}) / Price_{t-n}) * 100
    roc14 = df.groupby('symbol')['close'].pct_change(periods=14) * 100
    
    # Calculate 11-period Rate of Change
    roc11 = df.groupby('symbol')['close'].pct_change(periods=11) * 100
    
    # Sum of the two ROCs
    roc_sum = roc14 + roc11
    
    # Calculate the 10-period Weighted Moving Average (WMA)
    # WMA = (Sum of (Value_i * Weight_i)) / (Sum of Weights)
    weights = range(1, 11) # 1 to 10
    sum_weights = sum(weights)
    
    def apply_wma(series):
        # Use a rolling window to apply weights to the last 10 periods
        return series.rolling(window=10).apply(
            lambda x: (x * weights).sum() / sum_weights, 
            raw=True
        )

    # Apply the WMA calculation per symbol
    df['coppock_curve'] = roc_sum.groupby(df['symbol']).apply(apply_wma).reset_index(level=0, drop=True)
    
    return df
```
```json
{ "model_code": "d4vh9pq2xtw6", "topic": "Coppock Curve", "timer_secs": 91.07, "tokens_in": 578, "tokens_out": 1060, "cost_tokens_in": 0.00006936, "cost_tokens_out": 0.00039220, "cost_tokens_tot": 0.00046156 }
```