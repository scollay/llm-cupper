# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum oscillator that highlights major buying opportunities in broad stock market indices. It appears on a chart as a single line that oscillates around a zero line, typically generated from monthly price data. Edwin Sedgwick Coppock introduced the indicator in 1965 at the request of the Episcopal Church, which sought a reliable method for timing long-term equity purchases.

## Details
The Coppock Curve combines two rate-of-change calculations to measure the speed of price movement over intermediate time frames, then smooths the result with a weighted moving average. Because it is constructed from monthly closes, it is intended for identifying secular market bottoms rather than short-term swings. Traders watch for the line to cross above zero from below; this upward zero-line crossover is treated as a buy signal. Downward crossings are generally ignored, as the indicator was designed only to flag the end of major bear markets.

The signal tends to work best on capitalization-weighted indices such as the S&P 500 or Dow Jones Industrial Average. On individual stocks or narrow sectors the curve produces frequent whipsaws. Its heavy smoothing creates noticeable lag, so the buy signal often arrives well after the actual low. In prolonged sideways markets the indicator can drift near zero and generate false or ambiguous crosses. Because the original parameters were chosen for monthly data, applying the same settings to daily or weekly bars distorts the intended cycle lengths and reduces reliability.

## Text Formula
ROC(14) = ((Close - Close[14 periods ago]) / Close[14 periods ago]) × 100  
ROC(11) = ((Close - Close[11 periods ago]) / Close[11 periods ago]) × 100  
ROC Sum = ROC(14) + ROC(11)  
Coppock Curve = 10-period weighted moving average of ROC Sum  
where the WMA places linearly increasing weights 1 through 10 on the most recent 10 values of the ROC Sum.

## Python Code
```python
import pandas as pd
import numpy as np

def coppock_curve(df, roc_long=14, roc_short=11, wma_period=10):
    df = df.sort_values(['symbol', 'date']).copy()
    
    def _calc_coppock(group):
        close = group['close']
        roc_long_val = ((close - close.shift(roc_long)) / close.shift(roc_long)) * 100
        roc_short_val = ((close - close.shift(roc_short)) / close.shift(roc_short)) * 100
        roc_sum = roc_long_val + roc_short_val
        
        def _wma(x):
            weights = np.arange(1, len(x) + 1)
            return np.average(x, weights=weights)
        
        copp = roc_sum.rolling(window=wma_period).apply(_wma, raw=True)
        return copp
    
    df['coppock'] = df.groupby('symbol', group_keys=False).apply(_calc_coppock)
    return df
```
```json
{ "model_code": "w5jp2zk6vqr9", "topic": "Coppock Curve", "timer_secs": 9.84, "tokens_in": 677, "tokens_out": 1473, "cost_tokens_in": 0.00084625, "cost_tokens_out": 0.00368250, "cost_tokens_tot": 0.00452875 }
```