# Simple Moving Average (SMA)

## Overview
The Simple Moving Average (SMA) is the most basic and widely used trend-following indicator in technical analysis. It calculates the arithmetic mean of a security’s price over a chosen number of periods, creating a continuously updated average line that smooths out short-term fluctuations. On a chart, the SMA appears as a single curved line overlaying price bars or candlesticks. While no single individual invented the moving average—its origins lie in early 20th‑century statistical smoothing methods, notably the work of R.H. Hooker on time series in 1901—it was popularized in trading by technicians like J.M. Hurst and later by the growth of computer-based analysis in the 1970s.

## Details
The SMA is a lagging indicator: its value at any moment is simply the sum of the last *n* closing prices divided by *n*. As each new period completes, the oldest price drops out of the window and the new one enters, keeping the lookback constant. This constant window is what makes it a “simple” moving average.

### Calculation Intuition
- For a 10-day SMA of daily closing prices, add the last 10 closing prices and divide by 10.
- The average “moves” each day because the set of 10 numbers changes.
- The longer the period, the smoother the line and the greater the lag.

### Common Settings
Traders often choose lookback periods that correspond to natural cycles. Typical day‑trader and investor settings include:

- **20‑period** (or 21): approximates one trading month, used for short‑term trend.
- **50‑period**: a medium‑term trend gauge, often watched by active traders and institutions.
- **200‑period**: a key long‑term trend indicator, heavily monitored in equity markets for the line between bull and bear regimes.

While closing prices are the default, some traders apply SMAs to high, low, or volume data to generate separate insights.

### Typical Interpretations

1. **Trend direction**  
   When price is above a rising SMA, the trend is considered bullish; when below a falling SMA, bearish. A flat SMA suggests a trendless, ranging market.

2. **Dynamic support and resistance**  
   In an uptrend, traders often see pullbacks to an SMA as potential support; in a downtrend, bounces toward it may act as resistance. This works best with periods that many participants watch (e.g., the 50‑day SMA in equities).

3. **Price crossovers**  
   A close above the SMA can be taken as a bullish signal, while a close below it is bearish. However, these signals are prone to whipsaws in choppy markets.

4. **Dual‑SMA crossovers (ribbon analysis)**  
   Combining a shorter SMA with a longer one produces crossover signals. A classic example is the *golden cross* (50‑day SMA crossing above the 200‑day SMA, bullish) and the *death cross* (the opposite, bearish). Multiple SMAs of sequential lengths—often called an “SMA ribbon”—show trend strength and potential reversals when the lines fan out or converge.

### Where Interpretation Breaks Down

- **Lagging nature**  
  Because the SMA is a backward‑looking average, it confirms a trend only after price has moved. In fast‑moving reversals, an SMA‑based entry may give back much of the move.
  
- **Whipsaws in sideways markets**  
  When price oscillates around a moving average without establishing a trend, repeated crossovers generate false signals that quickly produce small losses.
  
- **Equal weighting**  
  The SMA treats every price in the lookback the same. This can make recent changes feel understated compared to older ones, leading traders to switch to exponential or weighted moving averages.
  
- **Sensitivity to lookback length**  
  A short SMA reacts faster but generates more noise; a long SMA filters noise but misses turning points. No single length works for all market conditions, and optimizing retrospectively often leads to curve‑fitting.

Despite these limitations, the SMA remains a foundational building block—not only as a standalone tool but as the basis for advanced indicators like Bollinger Bands, moving average envelopes, and the MACD.

## Text Formula
For a Simple Moving Average of length *n*, the value at closing period *t* is calculated as:

SMA(*n*)*_t* = (C*_t* + C*_t-1* + C*_t-2* + … + C*_t-n+1*) / *n*

where C*_t* is the closing price at period *t*, and *n* is the number of periods in the lookback window. When applied to other price fields (e.g., high, low), replace C with the chosen data series.

## Python Code
```python
def add_sma(df, period, price_col='close'):
    """
    Add a Simple Moving Average column to a DataFrame containing OHLCV data.

    Parameters
    ----------
    df : pandas.DataFrame
        Must contain at least these columns:
        ['symbol', 'date', 'open', 'high', 'low', 'close']
        Can include data for one or more symbols. The rows should be sorted
        by date within each symbol before calling this function.

    period : int
        The lookback window length (e.g., 20, 50, 200).

    price_col : str, optional
        The column name on which to compute the SMA. Defaults to 'close'.
        Can be changed to 'open', 'high', or 'low'.

    Returns
    -------
    pandas.DataFrame
        The input DataFrame with an additional column named 'sma_<period>'
        (e.g., 'sma_20') containing the rolling simple average. Values for
        the first (period-1) rows of each symbol will be NaN.
    """
    col_name = f'sma_{period}'
    
    # Compute SMA per symbol to avoid data leakage across symbols
    df = df.copy()
    df[col_name] = (
        df.groupby('symbol', group_keys=False)[price_col]
          .rolling(window=period, min_periods=period)
          .mean()
          .reset_index(level=0, drop=True)
    )
    return df

# Example usage (assuming a properly sorted DataFrame named 'prices'):
# prices = add_sma(prices, period=20)
# prices = add_sma(prices, period=50, price_col='high')  # apply to high prices
```
```json
{ "model_code": "m4n8jp5xq7vh", "topic": "Simple Moving Average", "timer_secs": 48.64, "tokens_in": 560, "tokens_out": 2251, "cost_tokens_in": 0.00024080, "cost_tokens_out": 0.00195837, "cost_tokens_tot": 0.00219917 }
```