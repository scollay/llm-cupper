# Bollinger Bands

## Overview
Bollinger Bands® are a volatility-based technical indicator that plots two trading bands around a simple moving average (SMA) of price. The upper band is set `k` standard deviations *above* the SMA, while the lower band sits `k` standard deviations *below* it. By default, `k = 2`, and the SMA period is 20. On a chart, the bands expand during periods of high volatility and contract during low volatility. Developed by John Bollinger in the 1980s, the tool helps traders identify overbought/oversold conditions, potential breakouts, and trend strength.

---

## Details

### **Components**
1. **Middle Band (SMA)**: A simple moving average of closing prices (typically 20 periods).
2. **Upper Band**: `SMA + (k × standard deviation)`.
3. **Lower Band**: `SMA − (k × standard deviation)`.

The standard deviation measures price volatility over the same lookback period as the SMA. Bollinger’s default settings (`period=20`, `k=2`) are widely used, but traders may adjust these (e.g., `period=10`, `k=1.5`) for shorter-term strategies.

---

### **Interpretation**
1. **Volatility Context**:
   - Bands widen when volatility increases (e.g., during news events or breakouts).
   - Bands narrow during consolidation ("squeeze"), often preceding a sharp move.

2. **Overbought/Oversold Signals**:
   - Prices touching the *upper band* may suggest overbought conditions (potential reversal).
   - Prices touching the *lower band* may suggest oversold conditions (potential bounce).
   - *Caution*: In strong trends, price can ride a band for extended periods ("walking the band"). These are not automatic reversal signals.

3. **Breakouts**:
   - A close *outside* the bands can signal continuation (e.g., upper-band breakout in an uptrend).
   - False breakouts are common; confirmation (e.g., volume, momentum) is critical.

4. **Squeeze Patterns**:
   - Narrowing bands indicate declining volatility, often followed by a volatility expansion.
   - Traders watch for a breakout direction post-squeeze, but direction is not predicted by the bands alone.

---

### **Limitations**
- **Lagging Indicator**: Based on moving averages, Bollinger Bands react to price rather than predict it.
- **Subjective Parameters**: Changing `period` or `k` alters sensitivity. Shorter periods increase noise; longer periods smooth but delay signals.
- **No Directional Bias**: Bands expand/contract symmetrically and do not favor bullish or bearish outcomes.
- **Whipsaws**: In ranging markets, price may oscillate between bands without clear trends.

---

### **Common Strategies**
- **Mean Reversion**: Fade moves to the upper/lower band in ranging markets (requires confirmation, e.g., RSI divergence).
- **Trend Following**: Enter pullbacks to the middle band in strong trends (e.g., price bounces off SMA in an uptrend).
- **Volatility Breakout**: Trade the direction of the first close outside the bands after a squeeze.

---

## Text Formula

1. **Middle Band (SMA)**:
   ```
   SMA = (Sum of closing prices over `n` periods) / n
   ```

2. **Standard Deviation (σ)**:
   ```
   σ = sqrt( (Sum over `n` periods of (close − SMA)²) / n )
   ```

3. **Upper Band**:
   ```
   Upper Band = SMA + (k × σ)
   ```

4. **Lower Band**:
   ```
   Lower Band = SMA − (k × σ)
   ```

Where:
- `n` = lookback period (default: 20)
- `k` = number of standard deviations (default: 2)

---

## Python Code

```python
import pandas as pd

def bollinger_bands(df, period=20, k=2):
    """
    Calculate Bollinger Bands for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pandas.DataFrame
        Required columns: ['symbol', 'date', 'close'].
        Must be sorted by ['symbol', 'date'] ascending.
    period : int
        Lookback period for SMA and standard deviation (default: 20).
    k : float
        Number of standard deviations for bands (default: 2).

    Returns:
    --------
    pandas.DataFrame
        Original DataFrame with added columns:
        - `sma`: Middle band (SMA of close).
        - `upper_band`: Upper Bollinger Band.
        - `lower_band`: Lower Bollinger Band.
        - `band_width`: (Upper Band − Lower Band) / Middle Band (normalized width).
    """
    # Validate input
    required_cols = {'symbol', 'date', 'close'}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"DataFrame must contain columns: {required_cols}")

    # Calculate SMA and standard deviation per symbol
    df['sma'] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=period, min_periods=period).mean()
    )
    df['std'] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=period, min_periods=period).std(ddof=0)
    )

    # Calculate bands
    df['upper_band'] = df['sma'] + (k * df['std'])
    df['lower_band'] = df['sma'] - (k * df['std'])
    df['band_width'] = (df['upper_band'] - df['lower_band']) / df['sma']

    return df
```

### **Usage Notes**
- **Input**: The function expects a DataFrame sorted by `['symbol', 'date']` with at least columns `symbol`, `date`, and `close`.
- **Output**: Returns the original DataFrame with 4 new columns:
  - `sma`: Middle band (20-period SMA by default).
  - `upper_band`/`lower_band`: Volatility-adjusted bands.
  - `band_width`: Normalized width (useful for identifying squeezes; values near 0 indicate low volatility).
- **Edge Cases**:
  - The first `period-1` rows for each symbol will have `NaN` values (insufficient data).
  - `ddof=0` in `std()` ensures the formula matches the text description (population standard deviation). Use `ddof=1` for sample standard deviation.
```json
{ "model_code": "r4cm8gd3qjt7", "topic": "Bollinger Bands", "timer_secs": 23.78, "tokens_in": 569, "tokens_out": 1438, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00287600, "cost_tokens_tot": 0.00310360 }
```