# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is one of the oldest and most widely used technical indicators. It smooths price data by calculating the arithmetic mean of a security’s closing price over a specified number of periods. On a price chart the SMA appears as a single line that trails the price action, shifting forward one bar for each new data point. The concept was popularized in the 1970s by technical analysts such as John J. Mackinlay and later cemented by the rise of computer‑driven charting platforms. Because it treats every price in the look‑back window equally, the SMA is often called a “flat‑weighted” moving average.

## Details
### How the SMA works
To compute an SMA you first choose a **look‑back period** `N` (e.g., 20, 50, 200 days). For each bar `t` you sum the closing prices of the most recent `N` bars—including the current bar—and divide by `N`:

\[
\text{SMA}_t = \frac{1}{N}\sum_{i=0}^{N-1} \text{Close}_{t-i}
\]

The result is plotted as a continuous line. When the price is above the SMA, the market is generally considered to be in an **uptrend**; when price is below, a **downtrend** is implied. Traders often watch for **crossovers**—the price crossing the SMA or two SMAs of different lengths crossing each other—as entry or exit signals.

### Common uses
| Use | Typical Settings | Interpretation |
|-----|------------------|----------------|
| Trend direction | 20‑day, 50‑day, 200‑day | Price > SMA → bullish, Price < SMA → bearish |
| Support / resistance | 20‑day, 50‑day | SMA can act as dynamic support (price above) or resistance (price below) |
| Crossover signals | 50‑day vs. 200‑day (the “golden cross”/“death cross”) | Short‑term SMA crossing above long‑term SMA → bullish; opposite → bearish |
| Filter for other indicators | Any period | SMA smooths price, reducing noise for oscillators like RSI |

### Where interpretation breaks down
1. **Lag** – Because the SMA averages past data, it reacts slowly to rapid price changes. In fast‑moving markets the SMA may give delayed signals, causing traders to miss the optimal entry point.
2. **Equal weighting** – Treating all observations equally can be a disadvantage when recent price action is more relevant. Alternatives such as the Exponential Moving Average (EMA) address this by weighting recent bars more heavily.
3. **Whipsaws** – In ranging or choppy markets, price frequently crosses the SMA, generating false signals. A single crossover may not be reliable without additional confirmation (e.g., volume, higher‑timeframe trend).
4. **Window selection** – The choice of `N` is arbitrary. A 20‑day SMA works well for short‑term traders but may be too noisy for long‑term investors; a 200‑day SMA smooths out noise but may be too sluggish for day traders.
5. **Multiple symbols** – When applying the SMA across a basket of stocks, each security’s volatility and price scale differ. A one‑size‑fits‑all window can misrepresent trends for low‑volatility stocks versus high‑volatility ones.

### Best‑practice tips
- **Combine with a second SMA** of a different length to create a crossover system. The classic “golden cross” (50‑day crossing above 200‑day) is a long‑term bullish signal.
- **Confirm with price action**: Look for higher highs/lows when price is above the SMA, and lower highs/lows when below.
- **Adjust the window** to the trading horizon: day traders may use 5‑ or 10‑period SMAs; swing traders often prefer 20‑ or 50‑period; position traders lean toward 100‑ or 200‑period.
- **Use volume**: A crossover accompanied by a surge in volume carries more weight than one on low volume.
- **Avoid over‑reliance**: Treat the SMA as a component of a broader system that includes momentum, volatility, and market‑structure analysis.

## Text Formula
For a given symbol and a look‑back period `N`:

```
SMA_t(N) = (Close_t + Close_{t-1} + … + Close_{t-(N-1)}) / N
```

If you compute multiple SMAs with periods `N1, N2, …, Nk`, the set of values for bar `t` is:

```
{SMA_t(N1), SMA_t(N2), …, SMA_t(Nk)}
```

When the close price crosses a particular SMA, the crossover condition can be expressed as:

```
CrossUp_t(N) = (Close_{t-1} < SMA_{t-1}(N)) and (Close_t >= SMA_t(N))
CrossDown_t(N) = (Close_{t-1} > SMA_{t-1}(N)) and (Close_t <= SMA_t(N))
```

A dual‑SMA crossover (e.g., short `Ns` and long `Nl`) is:

```
GoldenCross_t = (SMA_{t-1}(Ns) < SMA_{t-1}(Nl)) and (SMA_t(Ns) >= SMA_t(Nl))
DeathCross_t  = (SMA_{t-1}(Ns) > SMA_{t-1}(Nl)) and (SMA_t(Ns) <= SMA_t(Nl))
```

## Python Code
```python
import pandas as pd

def calculate_sma(df: pd.DataFrame, periods: list[int]) -> pd.DataFrame:
    """
    Compute Simple Moving Averages (SMAs) for one or more look‑back periods.

    Parameters
    ----------
    df : pd.DataFrame
        Input data containing at least the columns:
        - 'symbol' : identifier for each security (string or categorical)
        - 'date'   : trading date (datetime‑like)
        - 'close'  : closing price (float)

        The DataFrame may hold multiple symbols; rows do not need to be pre‑sorted.

    periods : list[int]
        List of integer look‑back windows for which to calculate SMAs,
        e.g., [20, 50, 200].

    Returns
    -------
    pd.DataFrame
        A copy of ``df`` with additional columns named ``SMA_{N}`` for each
        period ``N`` in ``periods``.  The SMA values are NaN for the first
        ``N-1`` rows of each symbol because insufficient data exist.

    Notes
    -----
    * The function groups by ``symbol`` to ensure each security is processed
      independently.
    * Rows are sorted by ``date`` within each group before applying the rolling
      window, guaranteeing chronological order.
    * The SMA is calculated on the ``close`` column using a flat (equal‑weight)
      arithmetic mean.
    """
    # Validate required columns
    required = {"symbol", "date", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Input DataFrame missing required columns: {missing}")

    # Work on a copy to avoid mutating the caller's data
    result = df.copy()

    # Ensure date column is datetime for proper sorting
    if not pd.api.types.is_datetime64_any_dtype(result["date"]):
        result["date"] = pd.to_datetime(result["date"], errors="coerce")

    # Sort once globally; groupby will preserve this order within each symbol
    result.sort_values(["symbol", "date"], inplace=True)

    # Compute SMAs per symbol
    for n in periods:
        col_name = f"SMA_{n}"
        # Rolling with min_periods=n ensures NaN until enough points are present
        result[col_name] = (
            result.groupby("symbol")["close"]
            .apply(lambda x: x.rolling(window=n, min_periods=n).mean())
            .reset_index(level=0, drop=True)
        )

    return result
```
```json
{ "model_code": "gcwq4ebg96qi", "topic": "Simple Moving Average", "timer_secs": 26.10, "tokens_in": 561, "tokens_out": 1759, "cost_tokens_in": 0.00002188, "cost_tokens_out": 0.00031662, "cost_tokens_tot": 0.00033850 }
```