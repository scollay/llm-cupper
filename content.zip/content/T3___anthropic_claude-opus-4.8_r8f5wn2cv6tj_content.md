# T3 Moving Average

## Overview
The **T3 Moving Average** is a smoothing indicator designed to track price closely while filtering out noise, producing far less lag than traditional moving averages. Developed by Tim Tillson and introduced in his 1998 *Technical Analysis of Stocks & Commodities* article "Smoothing Techniques for More Accurate Signals," the T3 builds on the work of others—particularly the Generalized DEMA (GD) concept—to create a curve that hugs price action with minimal whipsaw.

On a chart, the T3 appears as a single smooth line overlaid directly on price, similar to an exponential moving average (EMA). Compared with a same-period EMA or simple moving average (SMA), the T3 reacts faster to turns yet remains visually smoother, making it popular for trend identification and as a dynamic support/resistance reference.

## Details
The T3 is essentially a *chain of six exponential moving averages* combined through a weighting scheme controlled by a **volume factor** (commonly denoted `v`, default `0.7`). The construction proceeds in two conceptual stages.

### Generalized DEMA
Tillson's building block is the Generalized DEMA (GD), which extends the standard double EMA:

`GD = EMA1 * (1 + v) - EMA2 * v`

where `EMA1` is an EMA of price and `EMA2` is an EMA of `EMA1`. When `v = 0`, the GD collapses to a plain EMA; when `v = 1`, it becomes the standard DEMA. Intermediate values balance responsiveness against smoothness.

### Three nested GDs
The T3 applies the GD operation **three times in succession**: it computes a GD of price, then a GD of that result, then a GD of *that*. Expanding the three nested GDs into the six underlying EMAs (`e1` through `e6`) yields a closed-form weighted combination using coefficients derived from `v`:

- `c1 = -v^3`
- `c2 = 3v^2 + 3v^3`
- `c3 = -6v^2 - 3v - 3v^3`
- `c4 = 1 + 3v + v^3 + 3v^2`

The final T3 is `c1*e6 + c2*e5 + c3*e4 + c4*e3`.

### Interpretation
Traders use the T3 much like any moving average, but with the expectation of earlier, cleaner signals:

- **Trend direction:** A rising T3 suggests an uptrend; a falling T3 suggests a downtrend. The slope itself is often used as a filter.
- **Price crossovers:** Price closing above the T3 can signal bullish momentum, below it bearish.
- **Multiple T3s:** Some traders plot two T3 lines of different periods and trade their crossovers, as with classic dual-MA systems.

### Where it breaks down
The T3's responsiveness comes at a cost. Because the volume factor can make the line *overshoot* turning points, in choppy or sideways markets the T3 can still produce false crossovers despite its smoothness. A higher `v` increases responsiveness but reintroduces noise; a lower `v` smooths more but adds lag—reintroducing the very problem the indicator was built to solve.

Like all moving averages, the T3 is a **lagging, trend-following** tool: it adds no predictive value in genuinely directionless markets and will whipsaw. The nested-EMA construction also requires a meaningful warm-up period before values stabilize, so early readings on a short data series are unreliable.

## Text Formula
Let `price` be the input series (typically `close`) and `v` the volume factor (default `0.7`). Define `EMA(series, period)` as the standard exponential moving average with smoothing factor `alpha = 2 / (period + 1)`.

```
e1 = EMA(price, period)
e2 = EMA(e1, period)
e3 = EMA(e2, period)
e4 = EMA(e3, period)
e5 = EMA(e4, period)
e6 = EMA(e5, period)

c1 = -v^3
c2 = 3*v^2 + 3*v^3
c3 = -6*v^2 - 3*v - 3*v^3
c4 = 1 + 3*v + v^3 + 3*v^2

T3 = c1*e6 + c2*e5 + c3*e4 + c4*e3
```

Equivalently, in GD form with `GD(x) = EMA(x, period)*(1+v) - EMA(EMA(x, period), period)*v`:

```
T3 = GD(GD(GD(price)))
```

Both expressions produce identical results.

## Python Code
```python
import pandas as pd


def t3_moving_average(df, period=5, volume_factor=0.7, price_col="close"):
    """
    Compute the T3 Moving Average (Tim Tillson, 1998) for one or more symbols.

    Expected input DataFrame columns:
        symbol : str    - instrument identifier
        date   : any    - date/datetime (used for ordering)
        open   : float
        high   : float
        low    : float
        close  : float

    Parameters
    ----------
    df            : pandas.DataFrame with the columns described above.
    period        : int   - EMA length used for each of the six nested EMAs.
    volume_factor : float - the 'v' factor (0..1), default 0.7.
    price_col     : str   - which price column to smooth (default 'close').

    Returns
    -------
    A copy of the input DataFrame with added columns:
        e1..e6 : the six nested EMAs
        t3     : the final T3 Moving Average value
    Each symbol is processed independently.
    """
    v = volume_factor

    # Coefficients derived from the volume factor.
    c1 = -(v ** 3)
    c2 = 3 * v ** 2 + 3 * v ** 3
    c3 = -6 * v ** 2 - 3 * v - 3 * v ** 3
    c4 = 1 + 3 * v + v ** 3 + 3 * v ** 2

    def _compute(group):
        # Ensure chronological order within each symbol.
        group = group.sort_values("date").copy()
        price = group[price_col]

        # Six successively chained EMAs.
        e1 = price.ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()

        group["e1"] = e1
        group["e2"] = e2
        group["e3"] = e3
        group["e4"] = e4
        group["e5"] = e5
        group["e6"] = e6

        # Weighted combination producing the T3.
        group["t3"] = c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3
        return group

    # group_keys=False keeps the original row structure without an extra index level.
    result = df.groupby("symbol", group_keys=False).apply(_compute)

    return result.reset_index(drop=True)
```
```json
{ "model_code": "r8f5wn2cv6tj", "topic": "T3", "timer_secs": 29.59, "tokens_in": 840, "tokens_out": 2436, "cost_tokens_in": 0.00420000, "cost_tokens_out": 0.06090000, "cost_tokens_tot": 0.06510000 }
```