# Simple Moving Average

## Overview
The simple moving average (SMA) is a foundational lagging technical indicator that smooths raw price action to highlight underlying trend direction. It appears on price charts as a single continuous line overlaid on price bars, calculated as the average of a fixed number of historical price periods. While no single individual is credited with its invention, the SMA was formalized as a core technical analysis tool in the early 20th century as charting became widespread among market participants. It is used by traders of all timeframes, from day traders to long-term investors, to identify trends, spot dynamic support and resistance, and generate trade signals.

## Details
The SMA is calculated as the unweighted arithmetic mean of a fixed set of historical price data, almost always closing prices, over a user-selected lookback period. Common lookback periods are 20-day (roughly one trading month), 50-day (roughly two trading months), and 200-day (roughly one trading year), though traders may use any period aligned to their strategy timeframe. Unlike exponential moving averages (EMAs), which assign greater weight to more recent price data, the SMA gives equal weight to every data point in the lookback window.

Traders use the SMA for three core purposes:
1. **Trend identification**: The slope of the SMA and its position relative to price are the most common signals. When price trades above the SMA and the SMA is sloping upward, the trend is considered bullish; price below a downward-sloping SMA signals a bearish trend.
2. **Dynamic support and resistance**: In strong uptrends, price often pulls back to the SMA and bounces off it, acting as dynamic support; in downtrends, the SMA acts as dynamic resistance as price rallies to it before reversing lower.
3. **Crossover signals**: Traders often pair two SMAs of different lookback periods to generate trade signals. A "golden cross" occurs when a shorter-term SMA (e.g., 50-day) crosses above a longer-term SMA (e.g., 200-day), interpreted as a long-term bullish signal. A "death cross" is the opposite: shorter-term SMA crosses below longer-term, signaling a bearish trend shift.

The interpretation of SMA signals has well-documented breakdowns, however:
- **Lag**: Because the SMA uses historical data and gives equal weight to old and new prices, it is a lagging indicator. It confirms a trend shift only after price has already moved significantly, leading to late entry and exit signals that erode profitability.
- **Poor performance in sideways markets**: In range-bound, choppy markets with no clear trend, price will frequently cross above and below the SMA, generating a high volume of false signals that can lead to whipsaw losses.
- **Arbitrary lookback selection**: There is no universally optimal lookback period; a 20-day SMA works well for a low-volatility large-cap stock but will generate constant false signals for a high-volatility crypto asset or a low-liquidity penny stock. Traders often backtest lookback periods for the specific asset they are trading to find a suitable fit.
- **Irrelevance in parabolic trends**: During extremely strong, fast-moving trends, price can move far above or below the SMA for extended periods, making the indicator useless as a support/resistance level or signal generator.

## Text Formula
The simple moving average for a user-defined lookback period *n* at time period *t* is calculated as the arithmetic mean of the *n* most recent closing prices ending at *t*:
**SMAₙ,ₜ = (Cₜ + Cₜ₋₁ + Cₜ₋₂ + ... + Cₜ₋ₙ₊₁) / n**
Where:
- *Cₓ* = closing price at period *x*
- *n* = lookback period (number of historical periods included in the calculation)
- *t* = current time period
For the first *n-1* periods in a dataset, there is insufficient historical data to calculate a full SMA, so these values are typically represented as `NaN` (not a number).

## Python Code
```python
import pandas as pd

def calculate_sma(
    price_data: pd.DataFrame,
    lookback_period: int = 20,
    price_column: str = "close"
) -> pd.DataFrame:
    """
    Calculate simple moving average (SMA) for one or more symbols in a price DataFrame.
    
    Parameters:
    -----------
    price_data : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close
    lookback_period : int
        Number of periods to use for SMA calculation (e.g., 20 for 20-day SMA)
    price_column : str
        Name of the column to use for price calculation (default: 'close')
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with an added 'sma' column containing SMA values for each symbol
    """
    # Validate required columns exist in input data
    required_cols = ["symbol", "date", price_column]
    if not all(col in price_data.columns for col in required_cols):
        raise ValueError(f"Input DataFrame missing required columns: {required_cols}")
    
    # Sort data by symbol and date to ensure chronological order for rolling calculation
    price_data = price_data.sort_values(by=["symbol", "date"]).reset_index(drop=True)
    
    # Calculate SMA per symbol using a rolling window, with min_periods set to lookback to return NaN for incomplete windows
    price_data["sma"] = price_data.groupby("symbol")[price_column].transform(
        lambda x: x.rolling(window=lookback_period, min_periods=lookback_period).mean()
    )
    
    return price_data
```
```json
{ "model_code": "rps2b8a4fpay", "topic": "Simple Moving Average", "timer_secs": 35.40, "tokens_in": 567, "tokens_out": 6879, "cost_tokens_in": 0.00011340, "cost_tokens_out": 0.00791085, "cost_tokens_tot": 0.00802425 }
```