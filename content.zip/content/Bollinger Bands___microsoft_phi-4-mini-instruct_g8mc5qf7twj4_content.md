# Bollinger Bands

## Overview
Bollinger Bands are a volatility indicator developed by John Bollinger in the 1980s. They consist of a middle band being an N-period simple moving average (SMA) and two outer bands at a specified number of standard deviations away from the middle band. Traders use Bollinger Bands to identify overbought or oversold conditions in a market. The bands expand and contract based on volatility, with wider bands indicating higher volatility and vice versa. This indicator is commonly used in conjunction with price action and other technical analysis tools.

## Details
Bollinger Bands are calculated using a simple moving average of a security's closing price over a specified period, typically 20 days. The upper and lower bands are then set at a certain number of standard deviations away from the middle band, usually two. When the price touches or crosses a band, it may signal a potential buying or selling opportunity. For example, if the price touches the lower band, it may indicate that the security is oversold, and a buying opportunity may arise. Conversely, if the price touches the upper band, it may indicate that the security is overbought, and a selling opportunity may arise. Traders often look for confluence with other indicators or price patterns to confirm these signals. However, it is important to note that Bollinger Bands are not foolproof and can produce false signals, especially during periods of low volatility.

## Text Formula
The formula for calculating Bollinger Bands is as follows:

1. Calculate the N-period simple moving average (SMA) of the closing prices: `SMA = (sum of closing prices over N periods) / N`
2. Calculate the standard deviation (SD) of the closing prices over N periods: `SD = sqrt((sum of (closing price - SMA)^2) / N)`
3. Calculate the upper band: `Upper Band = SMA + (2 * SD)`
4. Calculate the lower band: `Lower Band = SMA - (2 * SD)`

## Python Code
```python
import pandas as pd
import numpy as np

def bollinger_bands(df, period=20, num_std=2):
    """
    Calculate Bollinger Bands for a given DataFrame.
    
    Parameters:
    df (pd.DataFrame): DataFrame containing 'close' column with closing prices.
    period (int): Number of periods for the SMA (default is 20).
    num_std (int): Number of standard deviations for the bands (default is 2).
    
    Returns:
    pd.DataFrame: DataFrame with Bollinger Bands added as 'upper_band', 'middle_band', and 'lower_band'.
    """
    # Calculate the middle band (N-period SMA)
    df['middle_band'] = df['close'].rolling(window=period).mean()
    
    # Calculate the standard deviation
    df['std_dev'] = df['close'].rolling(window=period).std()
    
    # Calculate the upper and lower bands
    df['upper_band'] = df['middle_band'] + (num_std * df['std_dev'])
    df['lower_band'] = df['middle_band'] - (num_std * df['std_dev'])
    
    return df[['upper_band', 'middle_band', 'lower_band']]

# Example usage:
# df = pd.DataFrame({'symbol': ['AAPL'], 'date': ['2021-01-01'], 'open': [150], 'high': [155], 'low': [148], 'close': [152]})
# bollinger_bands(df, period=20, num_std=2)
```

This Python function takes a DataFrame with a 'close' column and calculates the Bollinger Bands using the specified period and number of standard deviations. The resulting DataFrame will include the upper band, middle band, and lower band for each date. The function can handle data for one or more symbols independently.
```json
{ "model_code": "g8mc5qf7twj4", "topic": "Bollinger Bands", "timer_secs": 3.53, "tokens_in": 555, "tokens_out": 805, "cost_tokens_in": 0.00004440, "cost_tokens_out": 0.00028175, "cost_tokens_tot": 0.00032615 }
```