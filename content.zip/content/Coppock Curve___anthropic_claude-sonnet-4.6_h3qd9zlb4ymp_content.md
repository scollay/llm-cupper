# Coppock Curve

## Overview

The Coppock Curve is a long-term momentum oscillator designed to identify major buying opportunities in broad market indexes. It appears on a chart as a single smoothed line that oscillates above and below a zero line, typically plotted beneath a price chart. Edwin "Sedge" Coppock developed the indicator in 1962, originally publishing it in *Barron's*. He reportedly based the recovery periods on the average length of human grief following a bereavement — an unusual but enduring piece of market lore.

---

## Details

### What It Measures

The Coppock Curve combines two rate-of-change (ROC) readings with a weighted moving average to produce a smoothed momentum signal. The goal is to filter out short-term noise and capture the slow, grinding recoveries that follow major bear markets. Because of this design, the indicator is most commonly applied to monthly data on broad indexes such as the S&P 500 or Dow Jones Industrial Average, though traders do apply it to weekly and daily data as well.

### Standard Parameters

The classic settings, as Coppock specified them, are:

- **ROC period 1:** 14 periods (months in the original design)
- **ROC period 2:** 11 periods
- **WMA period:** 10 periods

These parameters are widely used as defaults, though some traders experiment with shorter periods when applying the indicator to weekly or daily charts.

### How It Is Calculated

1. Compute the 14-period rate of change of price.
2. Compute the 11-period rate of change of price.
3. Add the two ROC values together to form a combined momentum reading.
4. Apply a 10-period weighted moving average (WMA) to that sum. The result is the Coppock Curve value for that bar.

The WMA gives more weight to recent data than a simple moving average, which helps the curve respond to emerging momentum shifts without becoming overly reactive.

### Interpreting the Signal

The classic interpretation is straightforward:

- **Buy signal:** The Coppock Curve crosses *above* zero from below, or turns upward while below zero. This is the primary signal Coppock himself emphasized.
- **Sell signal:** The curve crosses *below* zero from above, or turns downward while above zero. Coppock originally designed the indicator only for buy signals, but many modern traders use the downward cross as a caution or exit signal.

The zero-line crossover is the most widely cited trigger. A turn upward while the curve is still negative is considered an *early* buy signal — it anticipates the zero cross and carries slightly more risk but offers an earlier entry.

### Practical Use

Because the indicator was designed for monthly charts, a single signal can take months to develop. Traders who apply it to monthly data typically use it for strategic, long-horizon positioning rather than active trading. On weekly or daily charts, signals are more frequent but also noisier and more prone to whipsaws.

The Coppock Curve works best as a *confirmation* tool alongside trend analysis. A buy signal that coincides with price reclaiming a major moving average or breaking a long-term downtrend line carries more weight than the oscillator signal alone.

### Where Interpretation Breaks Down

- **Sideways markets:** In prolonged range-bound conditions, the curve can oscillate near zero and produce repeated false crossovers.
- **Short timeframes:** On daily data, the smoothing that makes the indicator reliable on monthly charts becomes insufficient, and signals lose their historical reliability.
- **Sell-side weakness:** Because the indicator was not originally designed to generate sell signals, downward crosses are less historically validated than upward crosses.
- **Lag:** The WMA smoothing introduces meaningful lag. By the time a zero-line crossover occurs on a monthly chart, a significant portion of the recovery move may already be priced in.

---

## Text Formula

```
ROC(n, price) = ((price / price[n periods ago]) - 1) × 100

Combined ROC = ROC(14, close) + ROC(11, close)

WMA(values, period):
    weight(i) = i + 1  for i = 0 (oldest) to period-1 (newest)
    WMA = sum(values[i] × weight(i)) / sum(weights)

Coppock Curve = WMA(Combined ROC, 10)
```

---

## Python Code

The function below calculates the Coppock Curve for each symbol independently and returns the original DataFrame with three new columns appended: `roc_14`, `roc_11`, and `coppock`.

```python
import pandas as pd

def weighted_moving_average(series: pd.Series, period: int) -> pd.Series:
    """
    Compute a weighted moving average (WMA) over a rolling window.
    Weights are linear: oldest bar in window gets weight 1,
    newest bar gets weight `period`.
    """
    weights = list(range(1, period + 1))          # [1, 2, ..., period]
    weight_sum = sum(weights)

    def wma_window(window):
        return sum(v * w for v, w in zip(window, weights)) / weight_sum

    return series.rolling(window=period).apply(wma_window, raw=True)


def coppock_curve(
    df: pd.DataFrame,
    roc_period_long: int = 14,
    roc_period_short: int = 11,
    wma_period: int = 10,
) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        May contain data for one or more symbols; each is processed independently.
    roc_period_long : int
        Lookback for the longer rate-of-change calculation (default 14).
    roc_period_short : int
        Lookback for the shorter rate-of-change calculation (default 11).
    wma_period : int
        Period for the weighted moving average applied to the combined ROC (default 10).

    Returns
    -------
    pd.DataFrame
        Original DataFrame with three new columns appended:
          roc_14     - long-period rate of change (%)
          roc_11     - short-period rate of change (%)
          coppock    - the Coppock Curve value
        Column names for roc_14 and roc_11 reflect the actual period arguments.
    """
    df = df.copy()
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)

    roc_long_col = f"roc_{roc_period_long}"
    roc_short_col = f"roc_{roc_period_short}"

    results = []

    for symbol, group in df.groupby("symbol", sort=False):
        group = group.copy()

        # Rate of change: ((close / close[n periods ago]) - 1) * 100
        group[roc_long_col] = (
            (group["close"] / group["close"].shift(roc_period_long)) - 1
        ) * 100

        group[roc_short_col] = (
            (group["close"] / group["close"].shift(roc_period_short)) - 1
        ) * 100

        # Combined ROC is the sum of both readings
        combined_roc = group[roc_long_col] + group[roc_short_col]

        # Coppock Curve = WMA of the combined ROC
        group["coppock"] = weighted_moving_average(combined_roc, wma_period)

        results.append(group)

    result_df = pd.concat(results).sort_values(["symbol", "date"]).reset_index(drop=True)
    return result_df
```
```json
{ "model_code": "h3qd9zlb4ymp", "topic": "Coppock Curve", "timer_secs": 36.07, "tokens_in": 611, "tokens_out": 1893, "cost_tokens_in": 0.00183300, "cost_tokens_out": 0.02839500, "cost_tokens_tot": 0.03022800 }
```