# Simple Moving Average

## Overview

The Simple Moving Average, or SMA, is one of the most widely used trend-following indicators in technical analysis. It plots the average closing price of a security over a fixed number of periods, producing a smooth line that updates with each new bar. On a chart, the SMA typically appears as an overlay on price rather than in a separate indicator pane.

The SMA has no single credited creator. Moving averages have been used in statistics and market analysis for more than a century, and they became common in technical trading as charting methods developed through the 20th century. Traders use SMAs to identify trend direction, potential support and resistance, momentum shifts, and crossovers between shorter- and longer-term averages.

## Details

A Simple Moving Average is calculated by adding the prices over a chosen lookback period and dividing by the number of periods. A 20-day SMA, for example, is the average of the last 20 closing prices. When a new trading day is added, the oldest price drops out of the calculation and the newest price is included. This creates a rolling average.

The key feature of the SMA is that every observation in the lookback window receives equal weight. In a 50-day SMA, today’s close and the close from 49 sessions ago have the same influence on the average. This makes the SMA easy to understand, but also slower to respond than indicators that weight recent prices more heavily, such as the Exponential Moving Average.

### Common SMA Periods

Traders often choose SMA lengths based on their time horizon:

- **10- or 20-period SMA:** often used by short-term traders to gauge near-term trend and pullbacks.
- **50-period SMA:** commonly used as an intermediate trend measure.
- **100- or 200-period SMA:** widely followed by position traders and institutions as longer-term trend filters.

The period does not have to be daily. A 20-period SMA on a 5-minute chart averages the last 20 five-minute bars. A 50-week SMA averages the last 50 weekly closes. The interpretation depends on both the lookback length and the chart timeframe.

### Trend Identification

The most basic SMA interpretation is directional:

- If price is above a rising SMA, the market is generally considered to be in an uptrend.
- If price is below a falling SMA, the market is generally considered to be in a downtrend.
- If the SMA is flat and price repeatedly crosses it, the market may be range-bound or directionless.

The slope of the SMA matters. A price trading above a flat 200-day SMA is not the same as a price trading above a strongly rising 200-day SMA. The first may show only mild strength; the second suggests a more established uptrend.

Many traders use the SMA as a trend filter. For example, a swing trader might take long setups only when the close is above the 50-day SMA, or a longer-term investor might prefer to own securities trading above the 200-day SMA.

### Support and Resistance

SMAs can act as dynamic support or resistance because many market participants watch the same levels. In an uptrend, pullbacks to a rising 20-day or 50-day SMA may attract buyers. In a downtrend, rallies into a declining SMA may meet selling pressure.

This support or resistance is not mechanical. Price often overshoots, undershoots, or temporarily pierces a moving average before resuming the trend. Traders usually combine SMA levels with other evidence, such as price structure, volume, volatility, or momentum.

### Moving Average Crossovers

A common SMA technique compares a shorter moving average with a longer one. When the shorter SMA crosses above the longer SMA, it indicates that recent prices are improving relative to the longer-term average. This is often interpreted as a bullish signal. When the shorter SMA crosses below the longer SMA, it is interpreted as bearish.

The best-known crossover pair is the 50-day SMA and the 200-day SMA:

- A **golden cross** occurs when the 50-day SMA crosses above the 200-day SMA.
- A **death cross** occurs when the 50-day SMA crosses below the 200-day SMA.

Crossovers can be useful in sustained trends, but they are lagging signals. By the time a crossover occurs, a significant portion of the move may already have happened. In sideways markets, crossovers can produce repeated whipsaws.

### Distance From the SMA

Traders may also measure how far price is from an SMA. A large positive distance can indicate strong momentum, but it may also suggest that price is extended. A large negative distance may show downside momentum or oversold conditions, depending on context.

This distance is often expressed as a percentage:

- A close 5% above the 50-day SMA means price is trading at a moderate premium to that average.
- A close 20% above the 200-day SMA may show a strong trend, but also a potentially stretched condition.

The interpretation depends heavily on the asset. A 10% move from a long-term average may be extreme for a low-volatility utility stock but ordinary for a high-growth technology stock, small-cap equity, or cryptocurrency.

### Where SMA Interpretation Breaks Down

The SMA works best when markets trend. It is less reliable in choppy, mean-reverting, or news-driven environments. Because it uses historical prices, it always lags current price action. A long SMA may confirm a major trend but react too slowly for entries and exits. A short SMA reacts faster but creates more false signals.

The SMA is also sensitive to the selected period. A 20-day SMA can tell a very different story from a 200-day SMA. There is no universally correct length. Traders should match the period to their strategy, timeframe, and the behavior of the instrument being traded.

Finally, the SMA should not be treated as a standalone trading system. It can help define trend, structure, and risk areas, but entries, exits, position sizing, and trade management require additional rules.

## Text Formula

For a price series using closing prices:

`SMA_t(n) = (Close_t + Close_{t-1} + Close_{t-2} + ... + Close_{t-n+1}) / n`

Where:

- `SMA_t(n)` = simple moving average at time `t` over `n` periods
- `Close_t` = closing price at time `t`
- `n` = lookback period

Equivalent summation form:

`SMA_t(n) = (1 / n) * sum(Close_{t-i}) for i = 0 to n - 1`

Distance from SMA in price terms:

`Distance_t(n) = Close_t - SMA_t(n)`

Distance from SMA in percentage terms:

`DistancePct_t(n) = ((Close_t / SMA_t(n)) - 1) * 100`

SMA slope over one period:

`Slope_t(n) = SMA_t(n) - SMA_{t-1}(n)`

Spread between a fast SMA and a slow SMA:

`Spread_t(fast, slow) = SMA_t(fast) - SMA_t(slow)`

Percentage spread between a fast SMA and a slow SMA:

`SpreadPct_t(fast, slow) = ((SMA_t(fast) / SMA_t(slow)) - 1) * 100`

Bullish crossover condition:

`SMA_t(fast) > SMA_t(slow) and SMA_{t-1}(fast) <= SMA_{t-1}(slow)`

Bearish crossover condition:

`SMA_t(fast) < SMA_t(slow) and SMA_{t-1}(fast) >= SMA_{t-1}(slow)`

## Python Code

```python
import pandas as pd


def calculate_simple_moving_average(
    df: pd.DataFrame,
    windows=(20, 50, 200),
    price_col="close",
    crossover_pairs=((50, 200),),
) -> pd.DataFrame:
    # Required input columns:
    # symbol, date, open, high, low, close
    #
    # The dataframe may contain one or more symbols.
    # Calculations are performed independently for each symbol.
    #
    # Parameters:
    # df: pandas DataFrame containing market data
    # windows: iterable of SMA lookback periods to calculate
    # price_col: price column used for the SMA, normally "close"
    # crossover_pairs: iterable of (fast_window, slow_window) pairs for crossover values

    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing_cols = required_cols.difference(df.columns)
    if missing_cols:
        raise ValueError(f"Missing required columns: {sorted(missing_cols)}")

    if price_col not in df.columns:
        raise ValueError(f"price_col '{price_col}' not found in dataframe")

    windows = tuple(int(w) for w in windows)
    if any(w <= 0 for w in windows):
        raise ValueError("All SMA windows must be positive integers")

    crossover_pairs = tuple((int(fast), int(slow)) for fast, slow in crossover_pairs)
    for fast, slow in crossover_pairs:
        if fast <= 0 or slow <= 0:
            raise ValueError("Crossover windows must be positive integers")
        if fast == slow:
            raise ValueError("Fast and slow crossover windows must be different")

    all_windows = sorted(set(windows).union({w for pair in crossover_pairs for w in pair}))

    out = df.copy()
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    grouped = out.groupby("symbol", group_keys=False)

    for window in all_windows:
        sma_col = f"sma_{window}"
        distance_col = f"sma_{window}_distance"
        distance_pct_col = f"sma_{window}_distance_pct"
        slope_col = f"sma_{window}_slope"

        out[sma_col] = grouped[price_col].transform(
            lambda s: s.rolling(window=window, min_periods=window).mean()
        )

        out[distance_col] = out[price_col] - out[sma_col]
        out[distance_pct_col] = ((out[price_col] / out[sma_col]) - 1.0) * 100.0

        out[slope_col] = out.groupby("symbol")[sma_col].diff()

    for fast, slow in crossover_pairs:
        fast_col = f"sma_{fast}"
        slow_col = f"sma_{slow}"

        spread_col = f"sma_{fast}_{slow}_spread"
        spread_pct_col = f"sma_{fast}_{slow}_spread_pct"
        bullish_col = f"sma_{fast}_{slow}_bullish_cross"
        bearish_col = f"sma_{fast}_{slow}_bearish_cross"

        out[spread_col] = out[fast_col] - out[slow_col]
        out[spread_pct_col] = ((out[fast_col] / out[slow_col]) - 1.0) * 100.0

        prev_fast = out.groupby("symbol")[fast_col].shift(1)
        prev_slow = out.groupby("symbol")[slow_col].shift(1)

        out[bullish_col] = (out[fast_col] > out[slow_col]) & (prev_fast <= prev_slow)
        out[bearish_col] = (out[fast_col] < out[slow_col]) & (prev_fast >= prev_slow)

        out.loc[out[[fast_col, slow_col]].isna().any(axis=1), bullish_col] = False
        out.loc[out[[fast_col, slow_col]].isna().any(axis=1), bearish_col] = False

    return out
```
```json
{ "model_code": "t9bn4kx2lrf6", "topic": "Simple Moving Average", "timer_secs": 43.08, "tokens_in": 559, "tokens_out": 2975, "cost_tokens_in": 0.00279500, "cost_tokens_out": 0.08925000, "cost_tokens_tot": 0.09204500 }
```