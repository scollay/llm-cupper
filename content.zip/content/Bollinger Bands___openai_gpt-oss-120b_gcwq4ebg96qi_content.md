# Bollinger Bands

## Overview
Bollinger Bands are a volatility‑based technical indicator that consists of three lines plotted directly on a price chart: a **middle band** (typically a 20‑period simple moving average), an **upper band**, and a **lower band**. The outer bands are positioned a fixed number of standard deviations—most commonly two—above and below the middle band. John Bollinger introduced the concept in the early 1980s, and it has since become a staple for traders seeking to gauge price extremes, trend strength, and potential breakout conditions.

## Details
Bollinger Bands translate raw price data into a visual envelope that expands when volatility rises and contracts when volatility falls. The core components are:

1. **Middle Band (MB)** – a simple moving average (SMA) of the closing price over a chosen look‑back period *n* (default = 20).  
2. **Upper Band (UB)** – MB + *k* × σ, where σ is the standard deviation of the same *n* closes and *k* is the width multiplier (default = 2).  
3. **Lower Band (LB)** – MB − *k* × σ.

Because the bands are anchored to a moving average, they move with the price, but the distance between UB and LB reflects recent volatility. When the market is calm, the bands tighten; during turbulent periods they widen.

### Common Interpretations
- **Overbought / Oversold** – Prices touching or briefly breaching the UB are often viewed as overbought, while contact with the LB suggests oversold conditions. Traders may look for reversal candlesticks at these extremes.
- **The Squeeze** – A prolonged contraction of the band width signals low volatility. Bollinger theorized that a squeeze precedes a significant price move; the direction is usually confirmed by a breakout above UB or below LB.
- **Trend Confirmation** – In a strong uptrend, price tends to ride the UB, and in a downtrend it hugs the LB. Persistent price action staying near one band can reinforce the prevailing trend.
- **%B and Bandwidth** – Two derived metrics help quantify band behavior:
  - **%B** = (Close − LB) / (UB − LB). Values near 0 indicate proximity to the LB, near 1 to the UB, and values outside the 0‑1 range signal a breakout.
  - **Bandwidth** = (UB − LB) / MB. Rising bandwidth confirms expanding volatility; falling bandwidth flags a squeeze.

### Where Interpretation Breaks Down
- **Trendless Markets** – In sideways ranges, price may oscillate between bands without meaningful signals, leading to false overbought/oversold alerts.
- **Non‑Normal Distributions** – Standard deviation assumes a roughly normal price distribution. During extreme events (e.g., flash crashes), the bands may lag or misrepresent risk.
- **Parameter Sensitivity** – The default 20‑period SMA and 2‑σ width work well for many equities but can be suboptimal for assets with different trading cycles (e.g., crypto, commodities). Adjusting *n* or *k* without testing can produce misleading envelopes.
- **Lag** – Because the middle band is a moving average, it inherently lags price. Early breakouts may be missed, and the bands can be “late” in reacting to rapid volatility spikes.

Traders typically combine Bollinger Bands with complementary tools—such as volume, momentum oscillators, or trendlines—to filter out noise and confirm signals.

## Text Formula
Let  

- `C_t` be the closing price at time *t*  
- `n` be the look‑back period (default = 20)  
- `k` be the standard‑deviation multiplier (default = 2)  

Then  

1. **Middle Band (MB)**  
   \[
   MB_t = \frac{1}{n}\sum_{i=0}^{n-1} C_{t-i}
   \]

2. **Standard Deviation (σ)**  
   \[
   \sigma_t = \sqrt{\frac{1}{n}\sum_{i=0}^{n-1} (C_{t-i} - MB_t)^2}
   \]

3. **Upper Band (UB)**  
   \[
   UB_t = MB_t + k \times \sigma_t
   \]

4. **Lower Band (LB)**  
   \[
   LB_t = MB_t - k \times \sigma_t
   \]

5. **%B**  
   \[
   \%B_t = \frac{C_t - LB_t}{UB_t - LB_t}
   \]

6. **Bandwidth**  
   \[
   BW_t = \frac{UB_t - LB_t}{MB_t}
   \]

All calculations are performed independently for each symbol in the dataset.

## Python Code
```python
import pandas as pd

def bollinger_bands(df: pd.DataFrame,
                    price_col: str = "close",
                    window: int = 20,
                    std_factor: float = 2.0) -> pd.DataFrame:
    """
    Calculate Bollinger Bands, %B, and Bandwidth for each symbol in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input data containing at least the columns:
        ['symbol', 'date', 'open', 'high', 'low', 'close'].
        The DataFrame may hold multiple symbols; calculations are done per symbol.
    price_col : str, default "close"
        Column name to use for price (typically closing price).
    window : int, default 20
        Look‑back period for the simple moving average and standard deviation.
    std_factor : float, default 2.0
        Multiplier applied to the standard deviation to form the outer bands.

    Returns
    -------
    pd.DataFrame
        Original DataFrame enriched with the following columns:
        - `bb_middle`   : Middle Band (SMA)
        - `bb_upper`    : Upper Band (SMA + k*σ)
        - `bb_lower`    : Lower Band (SMA - k*σ)
        - `bb_percent_b`: %B value
        - `bb_bandwidth`: Bandwidth value
        The new columns align with the original rows; rows lacking enough
        history (i.e., the first `window-1` rows per symbol) contain NaN.
    """

    # Helper function to compute bands for a single symbol series
    def _calc_symbol(group: pd.DataFrame) -> pd.DataFrame:
        # Ensure chronological order
        group = group.sort_values("date")

        # Simple moving average of the chosen price column
        sma = group[price_col].rolling(window=window, min_periods=window).mean()

        # Rolling standard deviation
        std = group[price_col].rolling(window=window, min_periods=window).std()

        # Upper and lower bands
        upper = sma + std_factor * std
        lower = sma - std_factor * std

        # %B: (price - lower) / (upper - lower)
        percent_b = (group[price_col] - lower) / (upper - lower)

        # Bandwidth: (upper - lower) / sma
        bandwidth = (upper - lower) / sma

        # Assign results back to the group
        group = group.assign(
            bb_middle=sma,
            bb_upper=upper,
            bb_lower=lower,
            bb_percent_b=percent_b,
            bb_bandwidth=bandwidth,
        )
        return group

    # Apply the calculation per symbol while preserving original index
    result = df.groupby("symbol", group_keys=False).apply(_calc_symbol)

    # Return the DataFrame with new Bollinger columns
    return result
```
```json
{ "model_code": "gcwq4ebg96qi", "topic": "Bollinger Bands", "timer_secs": 24.25, "tokens_in": 620, "tokens_out": 2001, "cost_tokens_in": 0.00002418, "cost_tokens_out": 0.00036018, "cost_tokens_tot": 0.00038436 }
```