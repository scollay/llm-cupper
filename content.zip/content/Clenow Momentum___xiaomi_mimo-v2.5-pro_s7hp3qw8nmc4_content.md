Let me review the article one more time to make sure everything is correct and well-written.

 The article covers:
 five key elements: title, overview, Details, text Formula, Python code. Let me verify each section:

1. **Title**: "# Clenow Momentum" ✓

2. **Overview**: Brief description of what it is, how it appears, who created it ✓

3. **Details**: How it works, interpretation, limitations ✓

4. **Text Formula**: Step-by-step calculation ✓

5. **Python Code**: Complete implementation ✓

The code:
- Handles multiple symbols via groupby ✓
- Computes all values mentioned in the article ✓
- Uses correct ddof=2 for regression residuals ✓
- Proper annualization ✓
- Trend filter included ✓
- Handles NaN values ✓
- Would run without errors on a properly formatted DataFrame ✓

The formula and code agree ✓
The prose and formula agree ✓

I'm satisfied with the article. Let me output it now.# Clenow Momentum

## Overview

Clenow Momentum is a volatility-adjusted trend-following indicator designed to rank stocks by the strength and consistency of their recent uptrend. It measures the slope of a linear regression fitted to the natural log of price over a rolling window, annualizes that slope, and normalizes it by the standard deviation of the regression residuals. The result is a single score that favors stocks rising steadily over those rising erratically.

The indicator was developed by **Andreas Clenow**, a Swedish systematic portfolio manager and author of *Stocks on the Move: Beating the Market with Hedge Fund Momentum Strategies* (2015). It is typically plotted as a ranked list or screener output rather than as a line on a price chart.

## Details

### How It Works

The calculation proceeds in three steps:

1. **Fit a regression to log prices.** Over a lookback window of *N* trading days (commonly 90), a straight line is fitted to `ln(close)` versus time. The slope of this line represents the stock's continuously compounded daily return rate.

2. **Annualize the slope.** The daily slope is converted into an annualized simple return: `(e^(slope × 252) − 1)`. This tells you what the stock would return in a year if it continued trending at the same rate.

3. **Normalize by volatility.** The standard deviation of the regression residuals measures how much the stock's actual path deviates from the fitted trend line. Dividing the annualized return by the annualized residual volatility produces the final Clenow Momentum score.

A stock that climbs in a smooth, steady line will have a high slope and low residual deviation — yielding a high score. A stock that swings wildly while trending upward will have a similar slope but a much larger residual deviation — yielding a lower score.

### Typical Interpretation

- **Ranking universe.** Traders compute the score for every stock in their universe and rank from highest to lowest. The top-ranked stocks exhibit the strongest risk-adjusted uptrend.
- **Trend filter.** Clenow pairs the momentum score with a simple trend filter: the stock's price must be above its long-term moving average (commonly the 200-day SMA). This eliminates stocks whose high score is an artifact of a sharp bounce within a larger downtrend.
- **Portfolio construction.** A typical approach is to hold the top 20–30 ranked stocks that pass the trend filter, rebalancing monthly or quarterly.

### Where It Breaks Down

- **Choppy, mean-reverting markets.** The indicator assumes trending behavior. When markets oscillate without direction, the slopes cluster near zero and the ranking loses discriminating power.
- **Regime transitions.** A stock can score highly right before a trend reversal, since the lookback window still contains the prior uptrend. Shorter lookback periods react faster but introduce more noise.
- **Survivorship and liquidity bias.** Like any cross-sectional momentum strategy, results depend heavily on the composition of the stock universe and whether thinly traded names are included.
- **Short lookback sensitivity.** The 90-day default is a compromise. Much shorter windows amplify noise; much longer windows dilute recent information.

## Text Formula

Given a lookback of *N* trading days (default 90) and *T* = 252 trading days per year:

1. For each day *t* in the window, compute the log price:
   `y_t = ln(close_t)`

2. Fit a simple linear regression over the index *x* = 0, 1, …, N−1:
   `y = a + b × x`
   where *b* is the slope and *a* is the intercept.

3. Compute the fitted values and residuals:
   `ŷ_t = a + b × x_t`
   `ε_t = y_t − ŷ_t`

4. Standard deviation of residuals (using *N − 2* degrees of freedom):
   `σ_ε = √[ Σ(ε_t²) / (N − 2) ]`

5. Annualized return from the slope:
   `R_annual = e^(b × T) − 1`

6. Annualized residual volatility:
   `σ_annual = σ_ε × √T`

7. **Clenow Momentum score:**
   `Score = R_annual / σ_annual`

8. **Trend filter** (optional but standard):
   `Pass if close > SMA(close, 200)`

## Python Code

```python
import numpy as np
import pandas as pd


def clenow_momentum(
    df,
    lookback=90,
    sma_period=200,
    trading_days=252,
):
    """
    Compute Clenow Momentum for each row in a DataFrame of price data.

    Parameters
    ----------
    df : pd.DataFrame
        Columns required: symbol, date, open, high, low, close.
        The DataFrame may contain one or more symbols.
        Rows should be sorted by symbol and date (the function
        enforces this internally).
    lookback : int
        Rolling window length in trading days for the regression
        (default 90).
    sma_period : int
        Period for the long-term SMA used in the trend filter
        (default 200).
    trading_days : int
        Trading days per year for annualization (default 252).

    Returns
    -------
    pd.DataFrame
        Copy of the input with these columns appended:
        sma_long, log_close, regression_slope, residual_std,
        annualized_return, clenow_momentum, trend_filter.
    """
    df = df.sort_values(["symbol", "date"]).copy()

    out_frames = []

    for symbol, grp in df.groupby("symbol"):
        grp = grp.copy()
        n = len(grp)

        # --- long-term SMA (trend filter) ---
        grp["sma_long"] = (
            grp["close"]
            .rolling(window=sma_period, min_periods=sma_period)
            .mean()
        )

        # --- log prices ---
        grp["log_close"] = np.log(grp["close"])

        # --- allocate result columns ---
        grp["regression_slope"] = np.nan
        grp["residual_std"] = np.nan
        grp["annualized_return"] = np.nan
        grp["clenow_momentum"] = np.nan
        grp["trend_filter"] = False

        log_prices = grp["log_close"].to_numpy()
        closes = grp["close"].to_numpy()
        sma_vals = grp["sma_long"].to_numpy()

        # --- rolling regression ---
        for i in range(lookback - 1, n):
            window = log_prices[i - lookback + 1 : i + 1]

            # skip if any NaN in the window
            if np.isnan(window).any():
                continue

            x = np.arange(lookback, dtype=float)
            # np.polyfit returns [slope, intercept] for degree 1
            slope, intercept = np.polyfit(x, window, 1)

            fitted = intercept + slope * x
            residuals = window - fitted
            # ddof=2: two estimated parameters (slope, intercept)
            res_std = np.std(residuals, ddof=2)

            ann_ret = np.exp(slope * trading_days) - 1.0
            ann_vol = res_std * np.sqrt(trading_days)

            score = ann_ret / ann_vol if ann_vol > 0 else np.nan

            idx = grp.index[i]
            grp.loc[idx, "regression_slope"] = slope
            grp.loc[idx, "residual_std"] = res_std
            grp.loc[idx, "annualized_return"] = ann_ret
            grp.loc[idx, "clenow_momentum"] = score
            grp.loc[idx, "trend_filter"] = (
                closes[i] > sma_vals[i]
                if not np.isnan(sma_vals[i])
                else False
            )

        out_frames.append(grp)

    return pd.concat(out_frames)
```
```json
{ "model_code": "s7hp3qw8nmc4", "topic": "Clenow Momentum", "timer_secs": 217.72, "tokens_in": 807, "tokens_out": 9192, "cost_tokens_in": 0.00080700, "cost_tokens_out": 0.02757600, "cost_tokens_tot": 0.02838300 }
```