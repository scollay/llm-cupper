# Coppock Curve

## Overview

The Coppock Curve is a long-term momentum indicator used primarily to identify major buying opportunities in the stock market. Plotted as an oscillator beneath the price chart, it fluctuates above and below a zero line. The indicator was created by Edwin Coppock in 1962—originally named the "Trendex Model"—and was designed specifically for monthly data on the S&P 500 to signal the end of bear markets and the beginning of secular bull trends.

## Details

### Construction and Mechanics
Edwin Coppock based his indicator on the psychological premise that market bottoms are formed through a prolonged grieving process. When investors experience a severe market decline, it takes time for confidence to return. To capture this delayed recovery, the Coppock Curve combines long-term rate of change (ROC) calculations with a smoothing moving average. 

By default, the indicator uses monthly data. It calculates the 14-month and 11-month rates of change, sums them together, and then applies a 10-month weighted moving average (WMA) to the result. The WMA assigns greater weight to recent data points, allowing the curve to respond to new momentum slightly faster than a simple moving average would, while still filtering out short-term noise.

### Trading Interpretation
Active traders and long-term investors typically use the Coppock Curve for a single, specific purpose: generating long-term buy signals. 

* **Zero-Line Crossover:** The classic buy signal occurs when the Coppock Curve crosses above the zero line from below. This indicates that long-term momentum has shifted from negative to positive, suggesting a new bull market is underway.
* **Bullish Divergence:** Traders also look for bullish divergence during a downtrend. If the broader market index makes a lower low, but the Coppock Curve makes a higher low, it suggests that downward momentum is exhausting and a reversal may be imminent.
* **Lack of Sell Signals:** Edwin Coppock did not believe in shorting the market, and consequently, the indicator was not designed to generate sell signals. While some modern traders interpret a cross below the zero line as a sell or short signal, it is generally considered unreliable for this purpose due to extreme lag.

### Limitations and Breakdowns
The primary drawback of the Coppock Curve is its inherent lag. Because it relies on long lookback periods (11 and 14 months) and a 10-period moving average, a significant portion of a new bull rally will have already occurred by the time the curve crosses above zero. Traders who wait for this signal may miss the most lucrative, high-velocity phase of the initial recovery.

Furthermore, the indicator breaks down in choppy, sideways, or secular bear markets. During prolonged periods of market consolidation, the Coppock Curve will frequently whipsaw across the zero line, generating false buy signals that lead to immediate drawdowns. 

Finally, while modern charting platforms allow traders to apply the Coppock Curve to daily or weekly timeframes, doing so without adjusting the parameters fundamentally alters the indicator. Applying the default 14, 11, and 10 settings to daily data measures momentum over a matter of weeks rather than years, stripping away the macroeconomic context that makes the indicator effective.

## Text Formula

The Coppock Curve is calculated in three steps: determining the two Rates of Change (ROC), summing them, and applying a Weighted Moving Average (WMA).

**1. Rate of Change (ROC)**
Calculate the 14-period and 11-period ROC for the closing price:
`ROC(n) = ((Close - Close_n) / Close_n) * 100`
*Where `Close` is the current period's closing price, and `Close_n` is the closing price `n` periods ago.*

**2. Sum of ROCs**
Add the two ROC values together for the current period:
`ROC_Sum = ROC(14) + ROC(11)`

**3. Weighted Moving Average (WMA)**
Apply a 10-period WMA to the `ROC_Sum`:
`WMA(n) = (P_1 * 1 + P_2 * 2 + ... + P_n * n) / (n * (n + 1) / 2)`
*Where `n` is the WMA period (10), `P_1` is the oldest `ROC_Sum` value in the window, and `P_n` is the most recent `ROC_Sum` value.*

**Final Calculation**
`Coppock Curve = WMA(10, ROC_Sum)`

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_coppock_curve(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates the Coppock Curve for a Pandas DataFrame containing price data.
    
    Parameters:
    df (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 
                       'high', 'low', 'close'. Can contain one or more symbols.
                       
    Returns:
    pd.DataFrame: Original DataFrame with added columns for ROC 14, ROC 11, 
                  ROC Sum, and the final Coppock Curve.
    """
    # Ensure data is sorted by symbol and date for correct time-series calculations
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Calculate 14-period and 11-period Rate of Change (ROC) per symbol
    # pct_change(periods=n) calculates (Current - Previous_n) / Previous_n
    df['roc_14'] = df.groupby('symbol')['close'].pct_change(periods=14) * 100
    df['roc_11'] = df.groupby('symbol')['close'].pct_change(periods=11) * 100
    
    # Sum the two ROC values
    df['roc_sum'] = df['roc_14'] + df['roc_11']
    
    # Define a helper function to calculate the Weighted Moving Average (WMA)
    def calculate_wma(series: pd.Series, window: int) -> pd.Series:
        # Weights increase linearly from 1 (oldest) to window (newest)
        weights = np.arange(1, window + 1)
        weight_sum = weights.sum()
        
        # Apply rolling window and compute dot product for WMA
        return series.rolling(window=window).apply(
            lambda x: np.dot(x, weights) / weight_sum, 
            raw=True
        )
    
    # Calculate the 10-period WMA of the ROC Sum per symbol
    # Using transform to maintain the original DataFrame shape and index
    df['coppock_curve'] = df.groupby('symbol')['roc_sum'].transform(
        lambda x: calculate_wma(x, window=10)
    )
    
    return df

# Expected Input DataFrame Format:
# df = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL', ..., 'MSFT', 'MSFT', ...],
#     'date': ['2020-01-31', '2020-02-29', ...],
#     'open': [74.0, 71.5, ...],
#     'high': [79.0, 73.5, ...],
#     'low': [73.0, 68.0, ...],
#     'close': [78.5, 68.5, ...]
# })
# 
# result_df = calculate_coppock_curve(df)
```
```json
{ "model_code": "l8nf5cm3wph7", "topic": "Coppock Curve", "timer_secs": 65.82, "tokens_in": 580, "tokens_out": 4101, "cost_tokens_in": 0.00072500, "cost_tokens_out": 0.01537875, "cost_tokens_tot": 0.01610375 }
```