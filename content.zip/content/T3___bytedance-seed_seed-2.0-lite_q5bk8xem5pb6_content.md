# T3 Indicator

## Overview
The T3 Moving Average (or Tillson T3) is a low-lag smoothed moving average designed to solve the core tradeoff of traditional moving averages: lag that delays signal generation vs. excessive noise that produces false signals. Charted as a continuous line overlayed on price action, T3 outperforms common moving averages including the Simple Moving Average (SMA), Exponentialential Moving Average (EMA), Double EMA (DEMA), and even Triple EMA (TEMA) in its ability to track price trends while filtering short-term volatility. It was developed by engineer and trader Tim Tillson, who first published the indicator in a 1998 issue of *Technical Analysis of Stocks & Commodities* magazine.

## Details
T3 is built on the insight that repeated applications of EMA smoothing can reduce lag, but unmodified triple-smoothing (the core of TEMA) introduces overshoot, where the moving average temporarily moves past actual price during reversals, distorting signals. Tillson solved this by introducing a "volume factor" (a weighting constant) to blend successive EMA outputs, creating a smoother, less erratic line that retains its low-lag advantage. Unlike TEMA, which simply combines three EMAs to cancel lag, T3 weights intermediate smoothed series to avoid overshoot, resulting in a moving average that stays closely aligned with price without unnecessary noise.

Traders most commonly use T3 to identify trend direction and generate entry/exit signals, similar to other moving averages. Standard interpretation follows two core frameworks:
1. **Price-T3 crossovers**: If price closes above a rising T3 line, it is interpreted as a bullish signal to enter long positions. If price closes below a falling T3 line, it is a bearish signal to enter short or exit long positions. T3’s low lag means these crossover signals occur far earlier than crossovers involving a 50-day SMA or EMA, making it popular with day and swing traders.
2. **Dual T3 crossovers**: Traders often plot two T3 lines with different lookback periods (e.g., a 6-period T3 and a 20-period T3). A bullish signal triggers when the shorter-period T3 crosses above the longer-period T3, while a bearish signal triggers when the short-term T3 crosses below the long-term line. This framework filters some of the noise of single crossovers, as it requires confirmation from two trend measures.

Despite its advantages, T3 interpretation breaks down in three key scenarios. First, in sideways, range-bound markets, T3’s responsiveness leads to frequent, repeated crossovers that generate false signals, as the indicator flips direction quickly with small price swings, resulting in multiple losing trades from whipsaws. Second, over-optimization of T3’s default parameters (a 6-period lookback and 0.7 volume factor) is a common pitfall: traders often tweak these values to fit historical price data perfectly, leading to overfitted models that fail to perform in live market conditions. Third, while T3 has less lag than traditional moving averages, it remains a lagging indicator: during sharp, volatility-driven market reversals (e.g., interest rate shocks, earnings surprises), T3 can still lag price by multiple bars, leading to late exits or entries if used as the sole signal source. It also does not incorporate volume or implied volatility into its calculation, so it cannot distinguish between price moves driven by high conviction vs. low liquidity, which can lead to misinterpretation of trend strength.

## Text Formula
All T3 calculations rely on three core inputs: an asset’s periodic closing price, a lookback period `n` (default 6), and a volume factor `v` (default 0.7). The step-by-step formula to compute T3 is as follows:
1. Calculate the base EMA smoothing factor alpha: `alpha = 2 / (n + 1)`, the same constant used for standard EMA calculations.
2. Compute six successive EMAs, each using the same lookback period `n` applied to the output of the previous EMA:
   - EMA1 = EMA(close, n): first EMA of the raw closing price
   - EMA2 = EMA(EMA1, n): EMA of the first smoothed series
   - EMA3 = EMA(EMA2, n)
   - EMA4 = EMA(EMA3, n)
   - EMA5 = EMA(EMA4, n)
   - EMA6 = EMA(EMA5, n)
3. Calculate three intermediate blended moving averages to reduce lag and avoid overshoot:
   - e1 = (EMA1 * (1 + v)) - (EMA2 * v)
   - e2 = (EMA3 * (1 + v)) - (EMA4 * v)
   - e3 = (EMA5 * (1 + v)) - (EMA6 * v)
4. Calculate the final T3 value by applying the same EMA smoothing to the third intermediate series: `T3 = EMA(e3, n)`

## Python Code
```python
import pandas as pd

def calculate_t3(df, period=6, volume_factor=0.7):
    """
    Calculate Tillson T3 Moving Average for a pandas DataFrame of OHLC data.
    Input DataFrame requirements:
    - Columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    - Contains time series data for one or more symbols, processed independently per symbol
    - Sorted internally by date to ensure correct chronological EMA calculations
    """
    # Sort data to avoid EMA calculation errors from misordered timestamps
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    alpha = 2 / (period + 1)

    def compute_t3_group(group):
        # Process each symbol's time series independently
        close = group['close']
        # Calculate six successive EMAs, using recursive EMA logic (adjust=False)
        ema1 = close.ewm(alpha=alpha, adjust=False).mean()
        ema2 = ema1.ewm(alpha=alpha, adjust=False).mean()
        ema3 = ema2.ewm(alpha=alpha, adjust=False).mean()
        ema4 = ema3.ewm(alpha=alpha, adjust=False).mean()
        ema5 = ema4.ewm(alpha=alpha, adjust=False).mean()
        ema6 = ema5.ewm(alpha=alpha, adjust=False).mean()
        # Calculate intermediate blended series
        e1 = ema1 * (1 + volume_factor) - ema2 * volume_factor
        e2 = ema3 * (1 + volume_factor) - ema4 * volume_factor
        e3 = ema5 * (1 + volume_factor) - ema6 * volume_factor
        # Final T3 calculation
        t3 = e3.ewm(alpha=alpha, adjust=False).mean()
        return pd.Series(t3, name='t3')

    # Assign calculated T3 values to the main DataFrame
    df['t3'] = df.groupby('symbol', group_keys=False).apply(compute_t3_group)
    return df
```
```json
{ "model_code": "q5bk8xem5pb6", "topic": "T3", "timer_secs": 258.91, "tokens_in": 626, "tokens_out": 5419, "cost_tokens_in": 0.00015650, "cost_tokens_out": 0.01083800, "cost_tokens_tot": 0.01099450 }
```