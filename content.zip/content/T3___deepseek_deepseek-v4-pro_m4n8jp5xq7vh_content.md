# T3 Moving Average

## Overview
The T3 moving average is a responsive yet exceptionally smooth trend-following indicator designed to reduce the lag inherent in traditional exponential moving averages. Developed by Tim Tillson and first published in *Technical Analysis of Stocks & Commodities* magazine in 1998, the T3 applies repeated exponential smoothing and a “volume factor” to create a line that hugs price without excessive noise. On a chart, the T3 appears as a single curving line that shifts colour in some platforms when its slope changes, but its core value is a single numeric series plotted on the same pane as price. It can replace a conventional EMA or SMA in crossover strategies, trailing stops, and trend-confirmation filters.

## Details
### How the T3 Is Built
Tillson’s innovation is to take an exponential moving average, feed it back into the EMA formula multiple times, and then combine the intermediate averages with coefficients derived from a user‑chosen volume factor *v* (typically between 0 and 1). The procedure creates a family of averages that grow progressively smoother, and the final T3 is a weighted blend of those averages that cancels much of the remaining lag.

The calculation begins with a standard **period** (denoted *n*). Starting from the price series, six successive EMAs are computed:

- E1 = EMA(price, n)
- E2 = EMA(E1, n)
- E3 = EMA(E2, n)
- E4 = EMA(E3, n)
- E5 = EMA(E4, n)
- E6 = EMA(E5, n)

The T3 value is then:

`T3 = c1·E6 + c2·E5 + c3·E4 + c4·E3`

where the coefficients depend solely on the volume factor *v*:

- c1 = –*v*³
- c2 = 3*v*² + 3*v*³
- c3 = –6*v*² – 3*v* – 3*v*³
- c4 = 1 + 3*v* + *v*³ + 3*v*²

The four coefficients always sum to exactly 1. When *v* = 0, c4 = 1 and the other coefficients vanish, so T3 collapses to E3 — a triple‑exponential moving average. As *v* increases toward 1, the weights shift toward the smoother E6 and E5 components, producing a much silkier line.

Typical settings are a period between 5 and 20 and a volume factor around 0.7. The period controls how reactive the T3 is to recent price changes, while *v* governs the balance between smoothness and lag. Traders may fine‑tune both for different timeframes or instruments.

### Interpretation and Common Uses
Because the T3 is a smoothed directional indicator, it is employed in many of the same ways as a traditional moving average, but with fewer whipsaws.

- **Trend identification:** When the T3 is rising, the short‑term trend is considered up; a falling T3 signals a downtrend. Its slope can be more informative than its absolute level because the line responds quickly to changes in momentum.
- **Crossovers:** A trader may buy when price closes above the T3 and sell when it closes below. Alternatively, a faster T3 (shorter period, low *v*) can be paired with a slower T3 to generate signals on crossover.
- **Dynamic support and resistance:** In trending markets, the T3 often acts as a trailing support or resistance. Pullbacks that hold the T3 line offer low‑risk entry opportunities.
- **Colour‑changing versions:** Some charting platforms colour the line green when it is rising and red when it is falling, giving a quick visual assessment of trend direction.

The volume factor *v* can be thought of as a “damping” control. High *v* (near 1) yields a very flat, stable line ideal for identifying the main trend on daily or weekly charts but will miss smaller swings. Lower *v* (0.3–0.5) produces a more sensitive line suitable for intraday trading, albeit with more false signals.

### Where the Indicator Breaks Down
No moving average escapes the fundamental trade‑off between smoothness and lag. The T3 reduces lag remarkably well, but it is not immune.

- **Latency still exists:** In fast, strong trends the T3 will trail price by a few bars. A crossover signal can therefore trigger late, giving back a meaningful portion of the move.
- **Choppy, sideways markets:** When price oscillates within a narrow range, the T3 flattens and can generate repeated, tiny crossovers that whipsaw a trader.
- **Parameter sensitivity:** The optimal period and volume factor depend heavily on the market’s volatility regime. A setting that performed brilliantly during a sustained trend may fail catastrophically during a range‑bound period. Many traders succumb to over‑optimization, curve‑fitting *v* and *n* to historical data.
- **It is still a smoothing device:** Applying the T3 to non‑trending indicators does not create an oscillator. For example, a T3 of the RSI still yields a smoothed RSI line, not an overbought/oversold trigger on its own. The T3 is best used as a trend filter, not as a standalone trading system.
- **Outliers and gaps:** Because the T3 is built from exponential averages, it is vulnerable to sudden price shocks. A large gap can pull the line sharply, but the subsequent recovery can be slow, misleading traders about the trend’s health.

Experienced traders often combine the T3 with volume confirmation, market structure analysis, or a second indicator (such as ADX to gauge trend strength) to filter out low‑probability signals.

## Text Formula
Given a price series (typically closing prices) and a chosen period *n* and volume factor *v*:

1. Compute six exponential moving averages recursively:
   - E1<sub>t</sub> = EMA<sub>n</sub>(Price<sub>t</sub>)
   - E2<sub>t</sub> = EMA<sub>n</sub>(E1<sub>t</sub>)
   - E3<sub>t</sub> = EMA<sub>n</sub>(E2<sub>t</sub>)
   - E4<sub>t</sub> = EMA<sub>n</sub>(E3<sub>t</sub>)
   - E5<sub>t</sub> = EMA<sub>n</sub>(E4<sub>t</sub>)
   - E6<sub>t</sub> = EMA<sub>n</sub>(E5<sub>t</sub>)

2. Calculate the four coefficients from *v*:
   - c1 = –*v*³
   - c2 = 3*v*² + 3*v*³
   - c3 = –6*v*² – 3*v* – 3*v*³
   - c4 = 1 + 3*v* + *v*³ + 3*v*²

3. Form the T3 value for each bar *t*:
   - T3<sub>t</sub> = c1 · E6<sub>t</sub> + c2 · E5<sub>t</sub> + c3 · E4<sub>t</sub> + c4 · E3<sub>t</sub>

The formula yields one T3 value per bar. For *v* = 0, T3<sub>t</sub> = E3<sub>t</sub>, a triple EMA.

## Python Code
```python
import pandas as pd

def add_t3(df: pd.DataFrame, period: int = 10, v: float = 0.7) -> pd.DataFrame:
    """
    Add a T3 moving average column to a DataFrame containing OHLC data.
    
    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
        Data may cover one or multiple symbols.
    period : int
        Lookback period for the underlying EMA calculations.
    v : float
        Volume factor (0 ≤ v ≤ 1). Typical values are 0.5–0.8.
    
    Returns
    -------
    pd.DataFrame
        The input DataFrame with an additional 'T3' column.
    """
    # Coefficients derived from volume factor v
    c1 = -v**3
    c2 = 3 * v**2 + 3 * v**3
    c3 = -6 * v**2 - 3 * v - 3 * v**3
    c4 = 1 + 3 * v + v**3 + 3 * v**2

    def t3_series(price: pd.Series) -> pd.Series:
        """
        Compute the T3 line for a single price series.
        Returns a Series aligned with the input index.
        """
        # Use pandas' exponential weighted function with adjust=False
        # to match the typical TA library behavior (alpha = 2/(span+1)).
        e1 = price.ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()
        t3 = c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3
        return t3

    # Apply per symbol to keep calculations independent
    df = df.copy()
    df['T3'] = df.groupby('symbol')['close'].transform(
        lambda grp: t3_series(grp)
    )
    return df
```
```json
{ "model_code": "m4n8jp5xq7vh", "topic": "T3", "timer_secs": 72.92, "tokens_in": 559, "tokens_out": 3850, "cost_tokens_in": 0.00024037, "cost_tokens_out": 0.00334950, "cost_tokens_tot": 0.00358987 }
```