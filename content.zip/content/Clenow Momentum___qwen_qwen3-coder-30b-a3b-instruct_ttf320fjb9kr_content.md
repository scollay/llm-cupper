# Clenow Momentum

## Overview
Clenow Momentum is a technical momentum indicator developed by trader and analyst David Clenow in the early 2000s. It measures the rate of change of price over a specified period, adjusted for volatility, and is displayed as a line on a chart that oscillates above and below a zero line. Unlike traditional momentum indicators, Clenow Momentum incorporates a volatility-adjusted component to reduce false signals in choppy markets. It is particularly useful for identifying momentum shifts and potential trend reversals.

## Details
Clenow Momentum is calculated by taking the difference between the current price and the price `n` periods ago, then normalizing this difference by the average true range (ATR) over the same period. This normalization helps to filter out noise and provides a more reliable signal in volatile environments.

Traders typically interpret Clenow Momentum as follows:
- Values above zero indicate bullish momentum.
- Values below zero indicate bearish momentum.
- Divergences between the indicator and price may signal potential reversals.
- Crossovers of the zero line can be used as trade entries.

However, the indicator's effectiveness can be limited in ranging markets, where volatility is low and the normalized values may not provide clear directional signals. Additionally, like all momentum indicators, it is subject to lag and may generate false signals during strong trends or sudden price spikes.

## Text Formula
The formula for Clenow Momentum is:

```
Clenow Momentum = (Close - Close[n]) / ATR[n]
```

Where:
- `Close` is the current closing price.
- `Close[n]` is the closing price `n` periods ago.
- `ATR[n]` is the Average True Range over `n` periods.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_atr(df, period=14):
    """Calculate Average True Range (ATR) for a given period."""
    df = df.copy()
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = abs(df['high'] - df['close'].shift(1))
    df['low_close'] = abs(df['low'] - df['close'].shift(1))
    df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    df['atr'] = df['tr'].rolling(window=period).mean()
    return df['atr']

def calculate_clenow_momentum(df, period=14):
    """
    Calculate Clenow Momentum indicator.
    
    Parameters:
    df: DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    period: Lookback period for momentum and ATR calculation
    
    Returns:
    DataFrame with Clenow Momentum values added as a new column 'clenow_momentum'
    """
    df = df.copy()
    df = df.sort_values(['symbol', 'date'])
    
    # Group by symbol to handle multiple symbols independently
    df['clenow_momentum'] = np.nan
    
    for symbol in df['symbol'].unique():
        symbol_data = df[df['symbol'] == symbol].copy()
        symbol_data = symbol_data.sort_values('date')
        
        # Calculate ATR
        symbol_data['atr'] = calculate_atr(symbol_data, period)
        
        # Calculate momentum
        symbol_data['momentum'] = symbol_data['close'] - symbol_data['close'].shift(period)
        
        # Calculate Clenow Momentum
        symbol_data['clenow_momentum'] = symbol_data['momentum'] / symbol_data['atr']
        
        # Update the main dataframe
        df.loc[symbol_data.index, 'clenow_momentum'] = symbol_data['clenow_momentum']
    
    return df
```
```json
{ "model_code": "ttf320fjb9kr", "topic": "Clenow Momentum", "timer_secs": 8.85, "tokens_in": 564, "tokens_out": 807, "cost_tokens_in": 0.00003948, "cost_tokens_out": 0.00021789, "cost_tokens_tot": 0.00025737 }
```