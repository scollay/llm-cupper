# Clenow Momentum

## Overview

Clenow Momentum is a trend-following indicator designed to measure the underlying strength and smoothness of an asset's price trend. Unlike traditional momentum metrics that simply calculate the percentage change between two points in time, Clenow Momentum evaluates the entire price path over a specified lookback period. It is typically plotted as a continuous line oscillating around a zero axis on a sub-chart below the primary price action. 

The indicator was created and popularized by quantitative trader Andreas Clenow in his 2015 book, *Stocks on the Move: Beating the Market with Hedge Fund Momentum Strategies*. Clenow developed it to address the inherent noise and path-dependency flaws found in standard Rate of Change (ROC) calculations.

## Details

### How It Works
Traditional momentum indicators, such as a 12-month ROC, only look at the starting and ending prices. This approach ignores the path the price took to get there. A stock that experienced a massive drawdown before recovering to post a 20% gain will receive the exact same momentum score as a stock that climbed smoothly and steadily by 20%. 

Clenow Momentum solves this by applying ordinary least squares (OLS) linear regression to the natural logarithm of the asset's closing prices. Taking the natural log linearizes exponential price growth, allowing the regression slope to represent the continuous compounding rate of return. 

To filter out choppy, unreliable trends, Clenow adjusts this annualized slope by multiplying it by the coefficient of determination ($R^2$) of the regression. The $R^2$ value measures the "goodness of fit," or how closely the actual prices adhere to the calculated trendline. A steep slope with a low $R^2$ indicates high volatility and a lack of directional conviction, which the indicator heavily penalizes.

### Interpretation
Traders and quantitative funds primarily use Clenow Momentum for cross-sectional ranking rather than generating isolated buy/sell signals on a single chart. 
* **High Positive Values:** Indicate a strong, smooth, and reliable uptrend. In a long-only equity strategy, traders will rank a universe of stocks and buy the top decile or quintile of assets with the highest positive Clenow Momentum.
* **High Negative Values:** Indicate a strong, smooth downtrend. In long/short strategies, these assets are prime candidates for short selling.
* **Values Near Zero:** Indicate sideways, mean-reverting, or highly erratic price action. These assets are typically avoided.

### Limitations and Breakdowns
While highly effective in trending regimes, Clenow Momentum has distinct vulnerabilities. Because it relies on a long lookback period (typically 90 trading days), it suffers from structural lag. During sudden market crashes or sharp V-shaped reversals, the regression line takes time to adjust, often keeping the momentum score artificially high just as the trend collapses. 

Furthermore, the indicator breaks down in heavily mean-reverting or sideways markets. The $R^2$ penalty helps mitigate choppy trends, but it cannot entirely prevent whipsaws when an asset oscillates tightly around a flat regression line. Finally, the model assumes log-normal returns, which can understate the impact of extreme, fat-tail volatility events.

## Text Formula

To calculate Clenow Momentum for a given lookback period $N$ (typically 90 days), follow these steps:

1. **Transform the Prices:** Calculate the natural logarithm of the closing price ($P_t$) for each day $t$ in the lookback window.
   $y_t = \ln(P_t)$ for $t = 1, 2, \dots, N$

2. **Define the Time Index:** Assign a sequential time index $x_t$ for the window.
   $x_t = t$

3. **Calculate the Linear Regression Slope ($\beta$):**
   $\beta = \frac{N \sum (x_t y_t) - \sum x_t \sum y_t}{N \sum (x_t^2) - (\sum x_t)^2}$

4. **Calculate the Coefficient of Determination ($R^2$):**
   $R^2 = \frac{[N \sum (x_t y_t) - \sum x_t \sum y_t]^2}{[N \sum (x_t^2) - (\sum x_t)^2][N \sum (y_t^2) - (\sum y_t)^2]}$

5. **Annualize the Return:** Multiply the daily slope by the number of trading days in a year (typically 252) and convert it to an annualized percentage return.
   $\text{Annualized Return} = e^{(\beta \times 252)} - 1$

6. **Calculate Clenow Momentum:** Adjust the annualized return by the trend quality.
   $\text{Clenow Momentum} = \text{Annualized Return} \times R^2$

*(Note: The slope $\beta$ remains mathematically identical whether the time index $x_t$ starts at 0 or 1.)*

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df, lookback=90, trading_days=252):
    """
    Calculates Clenow Momentum for a Pandas DataFrame containing price data.
    
    Parameters:
    df (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.
    lookback (int): Number of trading days for the regression window (default 90).
    trading_days (int): Number of trading days in a year for annualization (default 252).
    
    Returns:
    pd.DataFrame: Original DataFrame with added Clenow Momentum columns.
    """
    # Ensure data is sorted by symbol and date
    df = df.copy()
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Calculate the natural log of the closing prices
    df['log_close'] = np.log(df['close'])
    
    # Helper function to calculate the OLS slope for a rolling window
    def calc_slope(y):
        n = len(y)
        x = np.arange(n)
        x_mean = np.mean(x)
        y_mean = np.mean(y)
        
        ss_xx = np.sum((x - x_mean) ** 2)
        ss_xy = np.sum((x - x_mean) * (y - y_mean))
        
        return ss_xy / ss_xx if ss_xx != 0 else 0.0

    # Helper function to calculate the R-squared for a rolling window
    def calc_r2(y):
        n = len(y)
        x = np.arange(n)
        x_mean = np.mean(x)
        y_mean = np.mean(y)
        
        ss_xx = np.sum((x - x_mean) ** 2)
        ss_yy = np.sum((y - y_mean) ** 2)
        ss_xy = np.sum((x - x_mean) * (y - y_mean))
        
        if ss_xx == 0 or ss_yy == 0:
            return 0.0
            
        return (ss_xy ** 2) / (ss_xx * ss_yy)

    # Apply rolling regressions independently for each symbol
    # raw=True passes numpy arrays to the functions for faster execution
    rolling_slope = df.groupby('symbol')['log_close'].rolling(lookback).apply(calc_slope, raw=True)
    rolling_r2 = df.groupby('symbol')['log_close'].rolling(lookback).apply(calc_r2, raw=True)
    
    # Reset the multi-index created by groupby to align with the original dataframe
    df['regression_slope'] = rolling_slope.reset_index(level=0, drop=True)
    df['r_squared'] = rolling_r2.reset_index(level=0, drop=True)
    
    # Calculate the annualized return based on the continuous compounding slope
    df['annualized_return'] = np.exp(df['regression_slope'] * trading_days) - 1
    
    # Calculate the final Clenow Momentum value
    df['clenow_momentum'] = df['annualized_return'] * df['r_squared']
    
    # Clean up intermediate calculation columns
    df = df.drop(columns=['log_close'])
    
    return df
```
```json
{ "model_code": "l8nf5cm3wph7", "topic": "Clenow Momentum", "timer_secs": 121.52, "tokens_in": 581, "tokens_out": 7300, "cost_tokens_in": 0.00072625, "cost_tokens_out": 0.02737500, "cost_tokens_tot": 0.02810125 }
```