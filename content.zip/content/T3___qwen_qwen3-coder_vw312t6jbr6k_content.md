# T3 Moving Average

## Overview
The T3 Moving Average is a technical indicator designed to reduce lag and eliminate overshoot commonly found in traditional moving averages. It was developed by Tim Tillson and introduced in the late 1990s. On a price chart, the T3 appears as a smooth, responsive line that closely follows price action, making it popular among traders seeking timely signals without excessive noise.

## Details
The T3 Moving Average is derived from a modified version of the traditional Exponential Moving Average (EMA), with additional smoothing applied through multiple iterations. Its main advantage lies in maintaining a closer proximity to price while reducing the tendency to overshoot during sharp reversals. This makes it particularly useful in both trending and sideways markets.

Traders typically use the T3 to:

- Identify trend direction: When price is above the T3, the trend is considered bullish; below, bearish.
- Spot potential entry or exit points: Crossovers between price and the T3 can signal shifts in momentum.
- Smooth price data: The indicator filters out minor fluctuations, helping to highlight significant moves.

However, like all moving averages, the T3 has limitations:

- **Lag still exists**: Although reduced compared to traditional moving averages, there is still some delay in signal generation.
- **Whipsaw risk**: In choppy or consolidating markets, the indicator may generate false signals.
- **Overfitting concern**: The multiple smoothing steps can sometimes overreact to sudden price spikes, especially in illiquid or thinly traded assets.

The T3 is calculated using a volume factor (often denoted as `v`) that controls the degree of smoothing. A commonly used value is `v = 0.7`, which balances responsiveness and smoothness.

## Text Formula
The T3 Moving Average is computed through a multi-step process involving several iterations of a modified EMA. Let `v` be the volume factor (typically 0.7), and `close` be the closing price.

1. Compute the first EMA:
   ```
   EMA1 = EMA(close, period)
   ```

2. Compute subsequent EMAs:
   ```
   EMA2 = EMA(EMA1, period)
   EMA3 = EMA(EMA2, period)
   EMA4 = EMA(EMA3, period)
   EMA5 = EMA(EMA4, period)
   EMA6 = EMA(EMA5, period)
   ```

3. Apply the T3 formula:
   ```
   c1 = -v * v * v
   c2 = 3 * v * v + 3 * v * v * v
   c3 = -6 * v * v - 3 * v - 3 * v * v * v
   c4 = 1 + 3 * v + v * v * v + 3 * v * v

   T3 = c1 * EMA6 + c2 * EMA5 + c3 * EMA4 + c4 * EMA3
   ```

This final value is the T3 Moving Average.

## Python Code
```python
import pandas as pd

def ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def t3(dataframe, period=5, v=0.7):
    df = dataframe.copy()
    
    # Step 1: Calculate initial EMA
    df['ema1'] = ema(df['close'], period)
    
    # Step 2: Calculate subsequent EMAs
    df['ema2'] = ema(df['ema1'], period)
    df['ema3'] = ema(df['ema2'], period)
    df['ema4'] = ema(df['ema3'], period)
    df['ema5'] = ema(df['ema4'], period)
    df['ema6'] = ema(df['ema5'], period)
    
    # Step 3: T3 coefficients
    c1 = -v * v * v
    c2 = 3 * v * v + 3 * v * v * v
    c3 = -6 * v * v - 3 * v - 3 * v * v * v
    c4 = 1 + 3 * v + v * v * v + 3 * v * v
    
    # Step 4: Compute T3
    df['t3'] = (
        c1 * df['ema6'] +
        c2 * df['ema5'] +
        c3 * df['ema4'] +
        c4 * df['ema3']
    )
    
    # Return only relevant columns grouped by symbol
    result = df[['symbol', 'date', 't3']].copy()
    return result
```
```json
{ "model_code": "vw312t6jbr6k", "topic": "T3", "timer_secs": 5.09, "tokens_in": 562, "tokens_out": 1003, "cost_tokens_in": 0.00012364, "cost_tokens_out": 0.00180540, "cost_tokens_tot": 0.00192904 }
```