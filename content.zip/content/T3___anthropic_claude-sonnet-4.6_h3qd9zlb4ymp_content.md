# T3 Moving Average

## Overview

The T3 Moving Average is a smooth, low-lag trend-following indicator developed by Tim Tillson and introduced in his 1998 article *"Better Moving Averages"* in *Technical Analysis of Stocks & Commodities*. It appears on a price chart as a single flowing line that tracks price more closely than a simple or exponential moving average of the same period, while producing fewer false signals than faster alternatives. Its signature characteristic is an unusually smooth curve that still responds relatively quickly to genuine trend changes.

---

## Details

### Construction

T3 is built by layering six exponential moving averages (EMAs) on top of one another and then combining them with a set of coefficients derived from a single tuning parameter called the *volume factor* (commonly written as `vFactor` or `v`). The process starts with a standard EMA of price, then takes an EMA of that EMA, and so on — six levels deep. These six EMAs are labeled `e1` through `e6`. The final T3 value is a weighted linear combination of `e1` through `e6`, where the weights are determined by `v`.

The volume factor controls the trade-off between smoothness and responsiveness:

- A value of **0.7** is Tillson's original default and the most widely used setting.
- Lower values (e.g., 0.618) produce a smoother line with more lag.
- Higher values (approaching 1.0) increase responsiveness but reduce smoothness; at `v = 1` the indicator becomes noticeably noisier.

The period parameter (commonly 5 or 8 for short-term work, 14–21 for swing trading) sets the length of each underlying EMA.

### Interpretation

Traders use T3 in much the same way they use any trend-following moving average:

- **Trend direction:** When price is above T3 and T3 is rising, the trend is considered bullish. When price is below a falling T3, the trend is bearish.
- **Crossovers:** A price cross above T3 is a potential long entry signal; a cross below is a potential short or exit signal. Two T3 lines of different periods can also be crossed against each other (fast/slow crossover system).
- **Dynamic support and resistance:** In a trending market, T3 often acts as a support level on pullbacks in an uptrend and resistance on rallies in a downtrend.
- **Slope changes:** A flattening or reversal of the T3 slope can signal a weakening trend before price itself confirms it.

Because T3 is smoother than a comparable EMA, crossover signals tend to be cleaner and whipsaws less frequent — a meaningful practical advantage in choppy intraday data.

### Limitations

No moving average eliminates lag entirely, and T3 is no exception:

- **Overshoot:** The multi-layer construction can cause T3 to overshoot price at sharp reversals, temporarily moving *away* from price just as a new trend begins.
- **Ranging markets:** Like all trend-following tools, T3 generates repeated false crossover signals when price oscillates without a clear direction.
- **Parameter sensitivity:** Results vary noticeably with different combinations of period and `v`. Optimizing both on historical data risks overfitting.
- **Complexity:** The six-EMA chain means the indicator needs a meaningful warm-up period before its values are reliable — roughly six times the chosen EMA period.

---

## Text Formula

**Step 1 — EMA smoothing constant**

```
alpha = 2 / (period + 1)
```

**Step 2 — Six cascaded EMAs**

```
e1 = EMA(close, period)
e2 = EMA(e1, period)
e3 = EMA(e2, period)
e4 = EMA(e3, period)
e5 = EMA(e4, period)
e6 = EMA(e5, period)
```

Each EMA uses the same `alpha`.

**Step 3 — Tillson coefficients**

```
c1 = -(v^3)
c2 =  3*v^2 + 3*v^3
c3 = -6*v^2 - 3*v - 3*v^3
c4 =  1 + 3*v + v^3 + 3*v^2
```

**Step 4 — T3 value**

```
T3 = c1*e6 + c2*e5 + c3*e4 + c4*e3
```

Where `v` is the volume factor (default 0.7) and `period` is the chosen EMA length.

---

## Python Code

```python
import pandas as pd

# ---------------------------------------------------------------------------
# Input DataFrame format
# ---------------------------------------------------------------------------
# df must be a pandas DataFrame with at least these columns:
#   symbol  : str   — ticker or instrument identifier
#   date    : date/datetime — bar timestamp
#   open    : float
#   high    : float
#   low     : float
#   close   : float
#
# The DataFrame may contain data for one or more symbols; each symbol is
# processed independently so that EMA chains do not bleed across symbols.
# ---------------------------------------------------------------------------


def calculate_t3(df: pd.DataFrame, period: int = 5, v: float = 0.7) -> pd.DataFrame:
    """
    Calculate the T3 Moving Average for each symbol in df.

    Parameters
    ----------
    df : pd.DataFrame
        Input price data with columns: symbol, date, open, high, low, close.
    period : int
        EMA period used for each of the six cascaded EMAs. Default is 5.
    v : float
        Volume factor controlling smoothness vs. responsiveness. Default is 0.7.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with the following columns appended:
          t3_e1 … t3_e6  — the six intermediate EMAs
          t3              — the final T3 value
    """

    # Tillson coefficients derived from the volume factor
    c1 = -(v ** 3)
    c2 = 3 * v**2 + 3 * v**3
    c3 = -6 * v**2 - 3 * v - 3 * v**3
    c4 = 1 + 3 * v + v**3 + 3 * v**2

    alpha = 2.0 / (period + 1)

    result_frames = []

    for symbol, group in df.groupby("symbol", sort=False):
        g = group.copy().sort_values("date").reset_index(drop=True)

        # Six cascaded EMAs; each takes the previous level as its input
        g["t3_e1"] = g["close"].ewm(alpha=alpha, adjust=False).mean()
        g["t3_e2"] = g["t3_e1"].ewm(alpha=alpha, adjust=False).mean()
        g["t3_e3"] = g["t3_e2"].ewm(alpha=alpha, adjust=False).mean()
        g["t3_e4"] = g["t3_e3"].ewm(alpha=alpha, adjust=False).mean()
        g["t3_e5"] = g["t3_e4"].ewm(alpha=alpha, adjust=False).mean()
        g["t3_e6"] = g["t3_e5"].ewm(alpha=alpha, adjust=False).mean()

        # Final T3 combination
        g["t3"] = (
            c1 * g["t3_e6"]
            + c2 * g["t3_e5"]
            + c3 * g["t3_e4"]
            + c4 * g["t3_e3"]
        )

        result_frames.append(g)

    result = pd.concat(result_frames).sort_values(["symbol", "date"]).reset_index(drop=True)
    return result
```
```json
{ "model_code": "h3qd9zlb4ymp", "topic": "T3", "timer_secs": 35.27, "tokens_in": 607, "tokens_out": 1939, "cost_tokens_in": 0.00182100, "cost_tokens_out": 0.02908500, "cost_tokens_tot": 0.03090600 }
```