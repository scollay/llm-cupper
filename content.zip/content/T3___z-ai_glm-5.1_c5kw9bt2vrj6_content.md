# T3 Moving Average

## Overview
The T3 Moving Average is a technical indicator designed to smooth price data while minimizing the lag traditionally associated with moving averages. It appears on a chart as a single, fluid line overlaid on price action. Because of its unique mathematical structure, the T3 line is noticeably smoother than a standard Exponential Moving Average (EMA) and hugs price trends more tightly than a Simple Moving Average (SMA) of the same period. The indicator was introduced by Tim Tillson in 1998 in his article "Smoothed Technical Indicators," originally published in *Technical Analysis of Stocks & Commodities* magazine.

## Details
The T3 is an evolution of the Double Exponential Moving Average (DEMA) and Triple Exponential Moving Average (TEMA). Tillson recognized that while DEMA and TEMA reduced lag, they lacked a mechanism for the trader to control the balance between smoothness and responsiveness. To solve this, he introduced a "volume factor" (commonly denoted as `vfactor` or `b`), which scales the degree of lag reduction.

At its core, the T3 is a triple-smoothed generalized DEMA. It calculates six successive EMAs—`e1` through `e6`—and combines them using a specific set of coefficients derived from the `vfactor`. The `vfactor` typically ranges between 0 and 1. A `vfactor` of 1 applies maximum lag reduction, resulting in the T3 behaving like a TEMA. A `vfactor` of 0 applies no lag reduction, causing the T3 to degrade into a standard EMA. The most common default setting is a period of 5 with a `vfactor` of 0.7, which provides an optimal visual balance for many markets.

**How Traders Interpret It**

Traders generally use the T3 in three ways:

*   **Trend Identification:** The slope of the T3 line indicates the prevailing trend. An upward slope suggests bullish conditions, while a downward slope suggests bearish conditions. Because the T3 is highly smooth, changes in its slope are considered more significant and less prone to false signals than standard moving averages.
*   **Dynamic Support and Resistance:** In strongly trending markets, the T3 line frequently acts as a dynamic floor or ceiling. Traders look for price pullbacks to the T3 line to enter positions in the direction of the trend.
*   **Crossover Signals:** Traders use price crossing the T3 as a basic entry or exit signal. Alternatively, traders run two T3 lines (e.g., a 5-period and a 20-period) and trade the crossovers of the two lines, similar to a dual moving average crossover system.

**Where Interpretation Breaks Down**

The T3's primary weakness is shared by all trend-following indicators: it lags price. While the `vfactor` reduces this lag, it cannot eliminate it. In sideways, choppy markets, price will repeatedly cross the T3, generating whipsaw losses. 

Furthermore, the T3 exhibits a mathematical quirk known as "overshoot." When the `vfactor` is set high (approaching 1) and the market experiences a sharp, sudden reversal, the T3 line can actually overshoot the current price action. While this overshoot is a mathematical artifact of the heavy weighting on recent price differences, it can confuse traders who interpret it as a loss of correlation between the indicator and the asset. Finally, the T3's responsiveness is highly sensitive to its two input parameters; traders must carefully tune the period and `vfactor` for specific assets, which risks overfitting the indicator to historical data.

## Text Formula
To calculate the T3 Moving Average, define `n` as the lookback period and `v` as the volume factor (`vfactor`).

First, calculate six successive EMAs, all using the same period `n`:

`e1 = EMA(close, n)`
`e2 = EMA(e1, n)`
`e3 = EMA(e2, n)`
`e4 = EMA(e3, n)`
`e5 = EMA(e4, n)`
`e6 = EMA(e5, n)`

Next, calculate the four coefficients using the volume factor `v`:

`c1 = -v^3`
`c2 = 3v^2 + 3v^3`
`c3 = -3v - 6v^2 - 3v^3`
`c4 = 1 + 3v + 3v^2 + v^3`

Finally, combine the EMAs using the coefficients:

`T3 = (c1 * e6) + (c2 * e5) + (c3 * e4) + (c4 * e3)`

## Python Code
```python
import pandas as pd

def calculate_t3(df, period=5, vfactor=0.7):
    """
    Calculates the T3 Moving Average for one or more symbols.

    Parameters:
    df (pd.DataFrame): DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    period (int): Lookback period for the EMAs.
    vfactor (float): Volume factor (between 0 and 1) controlling smoothing and lag.

    Returns:
    pd.DataFrame: Original DataFrame with an added 't3' column.
    """
    # Ensure data is sorted chronologically per symbol
    df = df.sort_values(by=['symbol', 'date']).copy()

    def compute_t3_group(group):
        # Calculate the six successive EMAs
        # adjust=False matches standard technical analysis EMA calculations
        e1 = group['close'].ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()

        # Calculate the coefficients based on the volume factor
        v = vfactor
        c1 = -(v ** 3)
        c2 = 3.0 * (v ** 2) + 3.0 * (v ** 3)
        c3 = -3.0 * v - 6.0 * (v ** 2) - 3.0 * (v ** 3)
        c4 = 1.0 + 3.0 * v + 3.0 * (v ** 2) + v ** 3

        # Calculate T3
        group['t3'] = (c1 * e6) + (c2 * e5) + (c3 * e4) + (c4 * e3)
        return group

    # Apply the calculation independently to each symbol
    df = df.groupby('symbol', group_keys=False).apply(compute_t3_group)

    return df
```
```json
{ "model_code": "c5kw9bt2vrj6", "topic": "T3", "timer_secs": 125.44, "tokens_in": 558, "tokens_out": 6446, "cost_tokens_in": 0.00054684, "cost_tokens_out": 0.01985368, "cost_tokens_tot": 0.02040052 }
```