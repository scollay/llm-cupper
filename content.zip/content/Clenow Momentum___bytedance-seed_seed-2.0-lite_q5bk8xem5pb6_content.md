# Clenow Momentum

## Overview
Clenow Momentum is a risk-adjusted momentum indicator designed to rank assets by the strength of their price trends, normalized for volatility to enable fair cross-sectional comparison across different securities. Developed by systematic trader and hedge fund manager Andreas Clenow, it was first introduced to a broad audience in his 2015 book *Stocks on the Move*, which outlined a rules-based trend-following strategy for global equities. Unlike single-asset oscillators like the Relative Strength Index (RSI), Clenow Momentum is an unbounded numerical score calculated for every asset in a universe at each time step. On a chart, it is typically plotted as a time series of the asset’s score over time, or used to generate a ranked list of all assets in a universe, with top-ranked assets flagged for long positions and bottom-ranked for sells or short positions.

## Details
### Core Mechanics
Clenow Momentum solves a key flaw of raw price momentum, which only measures total percentage return over a set lookback period. Raw momentum disproportionately favors volatile assets: a stock with a 20% 12-month return and 40% annualized volatility has a lower risk-adjusted trend strength than a stock with a 15% 12-month return and 10% annualized volatility, but raw momentum would rank the first stock higher. Clenow’s indicator normalizes returns by historical volatility to eliminate this bias, effectively measuring the trend’s consistency rather than just its size. It retains the standard "skip-month" convention from academic momentum research, which excludes the most recent 1 month of returns to avoid short-term mean reversion that can distort long-term trend signals.

### Common Interpretation
Traders use Clenow Momentum almost exclusively for cross-sectional ranking, though it can also be used to track an individual asset’s trend strength over time. In its original use case, Clenow recommended ranking a universe of large-cap, liquid equities monthly, going long the top 20% of assets by score and exiting (or shorting) the bottom 20%. Scores are unbounded, but most healthy long-term trends fall between 0.5 and 3; a score above 1 indicates a trend that delivered positive returns greater than its annualized volatility, while a negative score indicates a downtrend. Many traders add a hard threshold, only entering long positions for assets with a score above 0.75 to filter out weak, choppy trends.

### Limitations
Interpretation of Clenow Momentum breaks down in several common market scenarios. First, it is a backward-looking indicator, so it fails during sharp market rotations or regime changes, when recent trends reverse abruptly. For example, during the 2022 U.S. rate hike cycle, high-flying growth stocks that had topped Clenow rankings for years saw their scores collapse as markets rotated into value, leading to large losses for traders who entered positions based on pre-rotation scores. Second, the default 12-month lookback is too slow for short-term trading strategies, and will miss fast emerging trends that could generate profits over 3-6 month windows. Third, extreme low volatility can inflate scores: an asset with a tiny 1% cumulative return and 1% annualized volatility will post a 1.0 score, which incorrectly signals a strong trend when the price is actually range-bound. Finally, the indicator does not account for cross-asset correlation, so a portfolio of top-ranked assets may be heavily concentrated in a single sector or macro risk factor unless paired with separate position-sizing rules.

## Text Formula
Clenow Momentum is calculated in three sequential steps for each asset on every date `t`, using the original standard parameters of a 252-trading-day (1 calendar year) lookback window and a 21-trading-day (1 calendar month) skip period to avoid lookahead bias and short-term reversal:
1. Calculate the cumulative total return `R` of the asset’s closing prices over the window spanning from `t-273` (252 + 21 trading days prior to the current date) to `t-21` (the end of the skip period, 21 days prior to the current date):
   `R = (close[t-21] / close[t-273]) - 1`
2. Calculate the annualized volatility `σ_annual` of the asset’s daily log returns over that same window. First compute the standard deviation of daily log returns `σ_daily`, then scale to annual terms:
   `σ_annual = σ_daily * sqrt(252)`
3. Compute the final Clenow Momentum Score as the ratio of cumulative return to annualized volatility:
   `Clenow Score = R / σ_annual`

Variations of the formula use shorter lookback windows (e.g., 126 trading days for 6-month momentum) for shorter trading horizons, but the core ratio of cumulative return to annualized volatility remains consistent.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df, lookback_days: int = 252, skip_days: int = 21):
    """
    Calculate Clenow Momentum scores for a DataFrame of asset prices.
    Input DataFrame must contain columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    Handles multiple assets (symbols) by processing each independently.
    
    Parameters:
        df (pd.DataFrame): Input price DataFrame sorted by symbol and date
        lookback_days (int): Number of trading days to use for trend calculation (default 252 = 1 year)
        skip_days (int): Number of most recent trading days to exclude to avoid short-term reversal (default 21 = 1 month)
    
    Returns:
        pd.DataFrame: Original DataFrame with added 'clenow_momentum' column
    """
    # Validate input columns
    required_cols = {'symbol', 'date', 'open', 'high', 'low', 'close'}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"Input DataFrame missing required columns: {required_cols - set(df.columns)}")
    
    # Sort data to ensure chronological order per symbol
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate core metrics grouped by symbol to avoid cross-asset contamination
    def compute_clenow(group):
        # Calculate daily log returns
        group['daily_log_return'] = np.log(group['close'] / group['close'].shift(1))
        # Calculate cumulative return over rolling window, shifted by skip_days to avoid lookahead
        group['cumulative_return'] = (group['close'] / group['close'].shift(lookback_days)) - 1
        group['cumulative_return'] = group['cumulative_return'].shift(skip_days)
        # Calculate rolling daily volatility, annualize, shift to avoid lookahead
        group['rolling_daily_vol'] = group['daily_log_return'].rolling(window=lookback_days).std()
        group['annualized_vol'] = group['rolling_daily_vol'] * np.sqrt(252)
        group['annualized_vol'] = group['annualized_vol'].shift(skip_days)
        # Calculate final Clenow Momentum score
        group['clenow_momentum'] = group['cumulative_return'] / group['annualized_vol']
        # Drop intermediate calculation columns
        group = group.drop(columns=['daily_log_return', 'cumulative_return', 'rolling_daily_vol', 'annualized_vol'])
        return group
    
    # Apply calculation to each symbol group
    df = df.groupby('symbol', group_keys=False).apply(compute_clenow)
    return df
```
```json
{ "model_code": "q5bk8xem5pb6", "topic": "Clenow Momentum", "timer_secs": 406.15, "tokens_in": 629, "tokens_out": 5936, "cost_tokens_in": 0.00015725, "cost_tokens_out": 0.01187200, "cost_tokens_tot": 0.01202925 }
```