# Coppock Curve

## Overview

The Coppock Curve is a long-term momentum oscillator created in 1962 by economist Edwin Coppock, who published the method in *Barron's*. It was originally designed for monthly price data on broad market indices — specifically to identify **major buying opportunities** at significant market bottoms. On a chart, it appears as a single smooth line oscillating around a zero centerline. Uniquely among technical indicators, the Coppock Curve was built with only buy signals in mind; its creator never intended it to generate sell signals.

## Details

### How It Works

The Coppock Curve blends two concepts: **momentum** and **smoothing**. First, it measures the percentage change in price over two different periods — typically 11 months and 14 months — using the Rate of Change (ROC) formula. These two ROC values are then summed together to capture momentum across multiple lookback windows. Finally, the sum is smoothed with a 10-period Weighted Moving Average (WMA), which gives more weight to recent values than a simple moving average would.

The result is a curve that responds slowly and deliberately to price shifts, filtering out short-term noise.

### Standard Parameters

The classic setup uses:
- **11-period ROC** and **14-period ROC** (summed)
- **10-period WMA** (smoothing)

These were chosen empirically by Coppock. The 11- and 14-period values roughly correspond to the typical duration of intermediate market cycles, while the 10-period WMA moderates the combined signal.

### Interpreting the Signal

The interpretation is straightforward:

- **Buy signal**: The Coppock Curve turns *upward* from below the zero line. This cross-from-below suggests that downside momentum has exhausted and a new uptrend may be forming.
- **Confirmed uptrend**: While the curve remains above zero and continues rising, bullish momentum is intact.
- **Neutral/distribution zone**: The curve flattening or turning down above zero does not trigger a sell signal by design, but some practitioners treat it as a warning.

The original application was strictly on **monthly charts of broad indices** like the S&P 500. The indicator was never meant for individual stocks or short timeframes.

### Where It Breaks Down

- **Lag**: The WMA smoothing makes this a lagging indicator. By the time the curve crosses zero, a meaningful portion of the move may already be underway. Entries can be late.
- **No sell signal**: Coppock deliberately omitted a sell-side rule. Traders who use the curve crossing downward as a sell signal are extending the indicator beyond its design. That extension has mixed results.
- **False signals on shorter timeframes**: Applying the standard parameters to daily or weekly data — without re-tuning — produces unreliable whipsaws. The indicator was calibrated for monthly cycles.
- **Bear markets and sideways action**: In prolonged bear markets or range-bound conditions, the curve can cross zero multiple times, generating a series of losing entries.
- **Parameter sensitivity**: The choice of 11, 14, and 10 is not universal. Different markets or asset classes may require different settings, and there is no rigorous theoretical basis for the originals.

### Common Extensions

Some traders adapt the concept by:
- Using the curve on weekly data with re-tuned parameters (e.g., shorter ROC periods and a shorter WMA).
- Adding a simple confirmation rule, such as requiring the curve to stay above zero for a minimum number of periods before acting.
- Applying it to sectors or individual stocks, though this moves further from Coppock's intent.

## Text Formula

Given price data indexed by period *t*:

1. **Rate of Change (11-period):**
   `ROC₁₁(t) = ((Close(t) − Close(t − 11)) / Close(t − 11)) × 100`

2. **Rate of Change (14-period):**
   `ROC₁₄(t) = ((Close(t) − Close(t − 14)) / Close(t − 14)) × 100`

3. **Raw Coppock Sum:**
   `Sum(t) = ROC₁₁(t) + ROC₁₄(t)`

4. **Coppock Curve (10-period WMA):**
   `Coppock(t) = WMA(Sum(t), 10)`

   Where the *n*-period WMA at position *t* is:
   `WMA(t) = Σ(i = 1 to n) [wᵢ × Sum(t − n + i)] / Σ(i = 1 to n) wᵢ`
   with weights `wᵢ = i` (most recent value gets the highest weight).

5. **Buy signal:**
   `Coppock(t) > 0 AND Coppock(t − 1) ≤ 0`
   (curve crosses zero from below)

## Python Code

```python
import pandas as pd


def calculate_coppock_curve(
    df: pd.DataFrame,
    roc_short: int = 11,
    roc_long: int = 14,
    wma_period: int = 10,
) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
        May contain rows for multiple symbols; each is processed independently.
        Data should be sorted by symbol and date.
    roc_short : int
        The shorter ROC lookback period (default 11).
    roc_long : int
        The longer ROC lookback period (default 14).
    wma_period : int
        The Weighted Moving Average period (default 10).

    Returns
    -------
    pd.DataFrame
        Original columns plus:
        - 'roc_short': Rate of Change over roc_short periods (percentage).
        - 'roc_long': Rate of Change over roc_long periods (percentage).
        - 'coppock_raw': Sum of the two ROC values.
        - 'coppock_curve': WMA-smoothed Coppock Curve value.
        - 'coppock_buy_signal': Boolean, True on the bar where the curve
          crosses zero from below (buy signal).
    """
    df = df.sort_values(["symbol", "date"]).copy()

    def _compute_group(group: pd.DataFrame) -> pd.DataFrame:
        close = group["close"]

        # Step 1 & 2: Rate of Change for both periods
        group["roc_short"] = (
            (close - close.shift(roc_short)) / close.shift(roc_short)
        ) * 100
        group["roc_long"] = (
            (close - close.shift(roc_long)) / close.shift(roc_long)
        ) * 100

        # Step 3: Raw sum of the two ROC values
        group["coppock_raw"] = group["roc_short"] + group["roc_long"]

        # Step 4: Weighted Moving Average of the raw sum
        # WMA weights: 1 (oldest in window) to wma_period (most recent)
        weights = pd.Series(range(1, wma_period + 1), dtype=float)

        def wma(series):
            return (series.values * weights.values).sum() / weights.sum()

        group["coppock_curve"] = (
            group["coppock_raw"]
            .rolling(window=wma_period, min_periods=wma_period)
            .apply(wma, raw=False)
        )

        # Step 5: Buy signal — curve crosses zero from below
        prev_curve = group["coppock_curve"].shift(1)
        group["coppock_buy_signal"] = (group["coppock_curve"] > 0) & (
            prev_curve <= 0
        )

        return group

    result = df.groupby("symbol", group_keys=False).apply(_compute_group)
    return result
```
```json
{ "model_code": "s7hp3qw8nmc4", "topic": "Coppock Curve", "timer_secs": 62.92, "tokens_in": 806, "tokens_out": 2143, "cost_tokens_in": 0.00080600, "cost_tokens_out": 0.00642900, "cost_tokens_tot": 0.00723500 }
```