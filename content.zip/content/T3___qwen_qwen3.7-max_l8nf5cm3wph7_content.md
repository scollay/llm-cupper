# T3 Moving Average

## Overview

The T3 Moving Average is a trend-following technical indicator designed to smooth price data while significantly reducing the lag inherent in traditional moving averages. It appears on a price chart as a single, continuous line overlaid on the candlesticks or bars, visually resembling a standard Exponential Moving Average (EMA) but with noticeably fewer minor fluctuations. The indicator was created by Tim Tillson and introduced to the trading community in 1998 through an article in *Technical Analysis of Stocks & Commodities* magazine.

## Details

### Mechanics and Calculation
To understand the T3, it is helpful to first understand the Triple Exponential Moving Average (TEMA). A standard TEMA applies an EMA three times and uses a simple linear combination to reduce lag. Tillson sought to create an even smoother curve without sacrificing responsiveness. 

The T3 achieves this by applying a six-pass EMA process. Rather than a simple linear combination, it uses a generalized binomial expansion to weight the outputs of these six sequential EMAs. This weighting is controlled by a "volume factor" (typically denoted as *v*), which defaults to 0.7. This factor dictates the degree of smoothing: a higher *v* yields a smoother line with more lag, while a lower *v* makes the line more responsive to recent price changes but rougher in appearance. By mathematically combining the third, fourth, fifth, and sixth EMAs with specific coefficients derived from the volume factor, the T3 effectively filters out market noise while tracking the underlying trend.

### Trading Interpretation
Active traders utilize the T3 Moving Average in much the same way they use traditional moving averages, but with a higher degree of confidence in the signals due to the reduction in noise.

*   **Trend Identification:** The slope of the T3 indicates the prevailing trend. An upward slope signifies a bullish trend, while a downward slope indicates a bearish trend. Because the T3 filters out minor pullbacks, it helps traders stay in trending positions without being stopped out by normal market volatility.
*   **Crossovers:** Traders watch for the price to cross the T3 line as a signal of trend initiation or reversal. Additionally, crossing a fast T3 (shorter period) over a slow T3 (longer period) generates systemic buy and sell signals.
*   **Dynamic Support and Resistance:** In strong trends, the T3 often acts as a dynamic support or resistance level. Traders may look to enter pullbacks when the price retraces to the T3 line and shows signs of bouncing.

### Limitations and Breakdowns
While the T3 is a superior smoothing tool, it is not a standalone trading system and has distinct limitations.

*   **Lag During Parabolic Moves:** The very mechanism that makes the T3 smooth—six passes of exponential smoothing—heavily anchors the indicator to historical data. During sudden, violent price spikes or flash crashes, the T3 will lag significantly behind the actual price, potentially delaying exit signals.
*   **Whipsaws in Ranging Markets:** Although it filters noise better than a standard EMA, the T3 will still generate false crossover signals in choppy, sideways, or mean-reverting markets. Traders must pair it with oscillators or volume indicators to confirm breakouts.
*   **Parameter Sensitivity:** The default volume factor of 0.7 works well for many assets, but it is not universally optimal. Highly volatile assets (like certain cryptocurrencies) may require a higher *v* to prevent whipsaws, while slower-moving assets might need a lower *v* to maintain responsiveness. Over-optimizing these parameters to fit historical data can lead to severe curve-fitting and poor out-of-sample performance.

## Text Formula

The T3 Moving Average is calculated using a six-pass Exponential Moving Average (EMA) process and a set of binomial coefficients based on a volume factor (*v*).

First, calculate the six sequential EMAs using the chosen lookback period (*n*):
EMA1 = EMA(Price, n)
EMA2 = EMA(EMA1, n)
EMA3 = EMA(EMA2, n)
EMA4 = EMA(EMA3, n)
EMA5 = EMA(EMA4, n)
EMA6 = EMA(EMA5, n)

Next, calculate the four coefficients using the volume factor (*v*):
c1 = -v^3
c2 = (3 * v^2) + (3 * v^3)
c3 = (-6 * v^2) - (3 * v) - (3 * v^3)
c4 = 1 + (3 * v) + (3 * v^2) + v^3

Finally, calculate the T3 value by applying the coefficients to the corresponding EMAs:
T3 = (c1 * EMA6) + (c2 * EMA5) + (c3 * EMA4) + (c4 * EMA3)

## Python Code

```python
import pandas as pd

def calculate_t3(df: pd.DataFrame, period: int = 5, v_factor: float = 0.7) -> pd.DataFrame:
    """
    Calculates the T3 Moving Average for a DataFrame containing one or more symbols.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close'].
    period (int): The lookback period for the sequential EMA calculations.
    v_factor (float): The volume factor (v) used to weight the EMA components.
    
    Returns:
    pd.DataFrame: Original DataFrame with an added 't3' column.
    """
    # Ensure data is sorted by symbol and date to maintain chronological integrity
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Pre-calculate the binomial coefficients based on the volume factor
    c1 = -(v_factor ** 3)
    c2 = (3 * v_factor ** 2) + (3 * v_factor ** 3)
    c3 = (-6 * v_factor ** 2) - (3 * v_factor) - (3 * v_factor ** 3)
    c4 = 1 + (3 * v_factor) + (3 * v_factor ** 2) + (v_factor ** 3)
    
    def _calc_t3_group(group: pd.DataFrame) -> pd.Series:
        """
        Calculates the 6-pass EMA and applies T3 coefficients for a single symbol group.
        """
        # Calculate the six sequential EMAs
        # adjust=False is used to match the standard EMA calculation on most trading platforms
        e1 = group['close'].ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()
        
        # Apply the coefficients to the 3rd through 6th EMAs
        t3 = (c1 * e6) + (c2 * e5) + (c3 * e4) + (c4 * e3)
        
        return t3

    # Apply the calculation to each symbol independently to prevent data leakage
    df['t3'] = df.groupby('symbol', group_keys=False).apply(_calc_t3_group)
    
    return df
```
```json
{ "model_code": "l8nf5cm3wph7", "topic": "T3", "timer_secs": 100.18, "tokens_in": 579, "tokens_out": 6265, "cost_tokens_in": 0.00072375, "cost_tokens_out": 0.02349375, "cost_tokens_tot": 0.02421750 }
```