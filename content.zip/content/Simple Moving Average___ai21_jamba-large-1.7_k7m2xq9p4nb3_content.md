# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that smooths price data by calculating the average of a specified number of past prices. It appears as a line on a chart and helps traders identify trends and potential support or resistance levels. The SMA was not attributed to a single creator but has been a foundational concept in technical analysis for over a century.

## Details
The SMA is calculated by taking the sum of a set of closing prices over a specified period and dividing it by the number of periods. For example, a 10-day SMA uses the last 10 closing prices and averages them. Traders use the SMA to identify the direction of a trend: if prices are above the SMA, it may indicate an uptrend, while prices below the SMA suggest a downtrend. The SMA can also act as dynamic support or resistance, where price bounces or reverses near the SMA line.

However, the SMA has limitations. It treats all data points in the period equally, which can make it less responsive to recent price changes compared to other moving averages like the Exponential Moving Average (EMA). This lag can result in delayed signals during rapid market moves. Additionally, the SMA can produce false signals in choppy or sideways markets, where prices frequently cross the SMA without a clear trend.

## Text Formula
The formula for the SMA is:

$$\text{SMA} = \frac{\text{Sum of closing prices over } n \text{ periods}}{n}$$

Where:

- $n$ is the number of periods used in the calculation.

For a series of closing prices $C_1, C_2, ..., C_n$, the SMA for the $n$th period is:

$$\text{SMA}_n = \frac{C_1 + C_2 + ... + C_n}{n}$$

## Python Code
```python
import pandas as pd

def simple_moving_average(data, period):
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the input DataFrame.
    
    Parameters:
    data (pd.DataFrame): A DataFrame with columns: symbol, date, open, high, low, close.
    period (int): The number of periods to use for the SMA calculation.
    
    Returns:
    pd.DataFrame: A DataFrame with an additional column `sma` for each symbol.
    """
    # Ensure data is sorted by date for each symbol
    data = data.sort_values(by=['symbol', 'date'])
    
    # Group by symbol and calculate SMA for the 'close' column
    data['sma'] = (
        data.groupby('symbol')['close']
        .rolling(window=period, min_periods=period)
        .mean()
        .reset_index(drop=True)
    )
    return data

# Example usage:
# Assume `df` is a DataFrame with the required columns
# df = simple_moving_average(df, period=10)
# The resulting DataFrame will include a new column `sma` for the 10-period SMA of 'close'.
```

This code calculates the SMA for the `close` column grouped by `symbol`. It uses the `rolling` method with a `window` equal to the specified `period`. The `min_periods=period` ensures that the SMA is only calculated when enough data is available. The output includes the original DataFrame with a new `sma` column for each symbol.
```json
{ "model_code": "k7m2xq9p4nb3", "topic": "Simple Moving Average", "timer_secs": 12.59, "tokens_in": 602, "tokens_out": 807, "cost_tokens_in": 0.00120400, "cost_tokens_out": 0.00645600, "cost_tokens_tot": 0.00766000 }
```