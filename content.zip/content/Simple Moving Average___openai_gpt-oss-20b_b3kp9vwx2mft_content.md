# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is one of the most basic and widely used technical indicators. It smooths price data by calculating the arithmetic mean of a selected range of prices, usually closing prices, over a fixed number of periods. The SMA line appears on a chart as a smooth curve that lags behind the price action, reflecting the average price over the chosen window. The concept dates back to the early 20th century, with roots in the work of Charles Dow and later formalized by traders in the 1970s and 1980s. Today, the SMA is a staple in both retail and institutional trading systems.

## Details
### How the SMA Works
The SMA is calculated by summing the closing prices of the last *n* periods and dividing by *n*. For example, a 20‑period SMA on daily data uses the last 20 closing prices. Because it uses a simple arithmetic mean, each price in the window contributes equally to the result. The SMA is updated every new period, shifting the window forward by one bar.

### Typical Interpretations
- **Trend Identification**: A rising SMA indicates an uptrend, while a falling SMA signals a downtrend. Traders often look at the slope of the SMA or compare it to the price to gauge momentum.
- **Support and Resistance**: In an uptrend, the SMA can act as dynamic support; in a downtrend, it can serve as dynamic resistance. Prices often bounce off the SMA line.
- **Crossover Signals**: The most common strategy involves a short‑term SMA crossing a long‑term SMA (e.g., 50‑period crossing 200‑period). A bullish crossover (golden cross) suggests a buy, while a bearish crossover (death cross) signals a sell.
- **Entry and Exit Timing**: Some traders use the SMA as a trigger for entering or exiting positions, especially when combined with other indicators like RSI or MACD.

### Where the Interpretation Breaks Down
- **Lagging Nature**: Because the SMA averages past prices, it reacts slowly to sharp price moves. In volatile markets, the SMA can lag behind the trend, causing missed opportunities or late exits.
- **Sensitivity to Period Length**: Short‑term SMAs (e.g., 5‑period) are noisy and prone to whipsaws, while long‑term SMAs (e.g., 200‑period) are sluggish. Selecting an inappropriate period can distort signals.
- **False Crossovers**: In ranging markets, short‑term and long‑term SMAs may cross frequently without a genuine trend shift, generating false trade signals.
- **Non‑Stationary Data**: The SMA assumes a stationary mean. In markets with structural breaks or regime changes, the SMA may fail to capture new dynamics.
- **Price Gaps and Missing Data**: Gaps or missing bars can distort the SMA calculation if not handled properly, leading to misleading signals.

### Practical Tips for Traders
- **Combine with Confirmation**: Use the SMA in conjunction with momentum indicators (RSI, Stochastics) or volume analysis to filter out weak signals.
- **Adjust Periods to Asset Volatility**: More volatile assets may benefit from shorter SMAs to capture rapid moves, whereas stable assets can use longer SMAs.
- **Backtest Thoroughly**: Historical performance can be misleading; ensure that the SMA strategy is robust across different market regimes.
- **Watch for Divergence**: When price makes a new high but the SMA does not, it may signal a weakening trend.

## Text Formula
For a given symbol and period *n*, the Simple Moving Average at time *t* is:

```
SMA_t = (1/n) * Σ_{i=0}^{n-1} P_{t-i}
```

where `P_{t-i}` is the closing price at time `t-i`.  
In practice, for a daily chart with a 20‑period SMA:

```
SMA_20(t) = (Close_t + Close_{t-1} + … + Close_{t-19}) / 20
```

The SMA is undefined for the first `n-1` periods because there are not enough data points to fill the window.

## Python Code
```python
import pandas as pd

def compute_sma(df: pd.DataFrame, period: int = 20) -> pd.DataFrame:
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input data must contain the following columns:
            - 'symbol' : ticker identifier
            - 'date'   : trading date (datetime-like)
            - 'open'   : opening price
            - 'high'   : highest price of the period
            - 'low'    : lowest price of the period
            - 'close'  : closing price
    period : int, optional
        Number of periods over which to compute the SMA. Default is 20.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with an additional column 'sma_{period}' containing
        the SMA values. Rows where the SMA cannot be computed (first period-1
        rows per symbol) will contain NaN.
    """
    # Ensure the date column is a datetime type for proper sorting
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])

    # Sort by symbol and date to maintain chronological order
    df.sort_values(['symbol', 'date'], inplace=True)

    # Group by symbol to compute SMA independently for each ticker
    sma_col = f'sma_{period}'
    df[sma_col] = (
        df.groupby('symbol')['close']
          .rolling(window=period, min_periods=period)
          .mean()
          .reset_index(level=0, drop=True)
    )

    return df
```
```json
{ "model_code": "b3kp9vwx2mft", "topic": "Simple Moving Average", "timer_secs": 12.84, "tokens_in": 620, "tokens_out": 1542, "cost_tokens_in": 0.00001798, "cost_tokens_out": 0.00021588, "cost_tokens_tot": 0.00023386 }
```