# Bollinger Bands

## Overview

Bollinger Bands are a volatility-based overlay consisting of a middle line and two outer bands that envelop price action. The middle line is typically a 20-period simple moving average (SMA), while the upper and lower bands are plotted a set number of standard deviations away from it. The bands automatically expand when volatility increases and contract when it subsides, giving traders a dynamic view of relative price extremes. Because they adapt to market conditions rather than using fixed percentages, they remain relevant across asset classes and timeframes. The tool was created by John Bollinger in the early 1980s and formally introduced to the public through his 2001 book, *Bollinger on Bollinger Bands*.

## Details

The indicator’s core premise is that prices tend to remain within a statistically normal range around a mean. The middle band serves as that mean, conventionally a 20-period simple moving average of the close. The upper and lower bands are derived by adding and subtracting two standard deviations of the same closing prices to the SMA. Because standard deviation measures dispersion, the bands widen when price swings grow and narrow during consolidation. This self-adjusting property distinguishes Bollinger Bands from fixed-width envelopes such as percentage-price oscillators, allowing the indicator to adapt to both high-volatility breakouts and quiet basing periods without manual rescaling. While 20 and 2 are the defaults, short-term traders may use 10-period settings with 1.5 standard deviations, and longer-term investors may prefer 50-period settings with 2.5 standard deviations to smooth out noise.

Traders monitor two derived metrics. **Bandwidth** normalizes the distance between the bands by dividing their spread by the middle band, producing a pure volatility reading that can be compared across instruments and timeframes. A reading near historic lows—a “squeeze”—signals that volatility is compressed and a directional expansion may be imminent, though it does not predict whether the breakout will be up or down. **%B** quantifies where the most recent close sits relative to the bands. A %B of 0.50 means price is exactly at the SMA; values above 1.0 occur when price closes above the upper band, while negative readings print below the lower band. %B is especially useful for spotting divergences: if price records a higher high but %B forms a lower high, upside momentum may be fading even while the trend appears intact.

The most common trading heuristic treats band touches as overbought or oversold signals in ranging markets. When price pushes to the upper band in a sideways regime, mean-reversion traders look for a return toward the SMA; a tag of the lower band may prompt a long entry with a target at the middle. In practice, this logic collapses during strong trends. Price can “walk the band” for extended periods, repeatedly kissing the upper band in a bullish run or the lower band in a bearish decline. Treating every touch as a reversal signal in those environments leads to repeated stop-outs. The bands are therefore better viewed as relative-value gauges than as deterministic reversal levels.

Breakouts outside the bands also require context. A close beyond two standard deviations is statistically unusual, and many traders interpret it as a continuation signal—momentum strong enough to violate the normal range. Yet false breakouts are common during low-volatility regimes or news-driven spikes that lack follow-through. A band walk accompanied by expanding volume and clean market structure behaves very differently from a single spike on low participation. Conversely, a rapid band expansion after a squeeze often marks the start of a new volatility regime rather than a directional trend, and prices may remain inside the newly widened channels without a clean follow-through.

Like all moving-average-based tools, Bollinger Bands carry inherent lag. The 20-period SMA reflects past prices, and the standard deviation is equally backward-looking. When volatility shifts abruptly, the bands need several bars to recalibrate. Moreover, the classic calculation uses closing prices only, meaning intraday wicks that pierce the bands are ignored unless the session settles beyond them. Some practitioners shorten the lookback or switch to a volume-weighted average, but those modifications alter the statistical foundation and should be tested independently.

The indicator’s greatest weakness is directional ambiguity. A squeeze can resolve with a violent move in either direction, and a band touch can mark either exhaustion or acceleration. Successful application therefore pairs the bands with trend filters—such as a longer-term moving average or the Average Directional Index—and with volume analysis to confirm whether a breakout or reversal has institutional backing. Used in isolation, Bollinger Bands describe the market’s current volatility regime and relative price position with precision, but they do not tell you what happens next.

## Text Formula

Let `n` be the lookback period (typically 20) and `k` be the number of standard deviations (typically 2). The formulas below use the population standard deviation (divisor `n`), consistent with the original specification and most trading platforms.

**Middle Band:**
`Middle_t = (Close_t + Close_{t-1} + ... + Close_{t-n+1}) / n`

**Population Standard Deviation:**
`σ_t = sqrt( sum((Close_i - Middle_t)^2) / n )` for `i` from `t-n+1` to `t`

**Upper Band:**
`Upper_t = Middle_t + (k * σ_t)`

**Lower Band:**
`Lower_t = Middle_t - (k * σ_t)`

**Bandwidth:**
`Bandwidth_t = (Upper_t - Lower_t) / Middle_t`

**%B:**
`%B_t = (Close_t - Lower_t) / (Upper_t - Lower_t)`

## Python Code

```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculate Bollinger Bands for one or more symbols.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Input data containing columns:
        - symbol: ticker or identifier
        - date: datetime or sortable date
        - open, high, low, close: OHLC prices as float
        
    Returns
    -------
    pandas.DataFrame
        Original data with added columns:
        - middle: rolling simple moving average of `close`
        - upper: middle + (num_std * rolling std dev)
        - lower: middle - (num_std * rolling std dev)
        - bandwidth: (upper - lower) / middle
        - pct_b: (close - lower) / (upper - lower)
    """
    # Work on a copy to avoid mutating the input
    result = df.copy()
    
    # Ensure proper chronological order within each symbol
    result = result.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Group by symbol so calculations are ticker-specific
    grouped = result.groupby('symbol', sort=False)
    
    # Middle band: simple moving average
    result['middle'] = grouped['close'].transform(
        lambda x: x.rolling(window=window, min_periods=window).mean()
    )
    
    # Rolling standard deviation (population std dev, ddof=0)
    result['_stddev'] = grouped['close'].transform(
        lambda x: x.rolling(window=window, min_periods=window).std(ddof=0)
    )
    
    # Upper and lower bands
    result['upper'] = result['middle'] + (num_std * result['_stddev'])
    result['lower'] = result['middle'] - (num_std * result['_stddev'])
    
    # Bandwidth: relative width of the bands
    result['bandwidth'] = (result['upper'] - result['lower']) / result['middle']
    
    # %B: position of close within the bands (0 = lower, 1 = upper)
    result['pct_b'] = (result['close'] - result['lower']) / (result['upper'] - result['lower'])
    
    # Drop intermediate helper column
    result = result.drop(columns=['_stddev'])
    
    return result
```
```json
{ "model_code": "h7dt4jq8mlc5", "topic": "Bollinger Bands", "timer_secs": 221.87, "tokens_in": 560, "tokens_out": 7872, "cost_tokens_in": 0.00040880, "cost_tokens_out": 0.02747328, "cost_tokens_tot": 0.02788208 }
```