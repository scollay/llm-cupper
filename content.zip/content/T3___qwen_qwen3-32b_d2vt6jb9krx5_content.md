# T3 Indicator

## Overview  
The T3 indicator is a technical oscillator designed to smooth price data and identify potential overbought and oversold conditions. Created by Tim Tillman in the early 2000s, it builds on the Triple Exponential Moving Average (TEMA) by introducing a time lag adjustment to reduce noise. The indicator typically appears as a line oscillating around zero on a chart, with overbought and oversold thresholds often set at +1 and -1. Traders use it to spot trend reversals or confirm momentum in conjunction with price action.

## Details  
The T3 indicator combines smoothing and lag adjustment to filter market noise. It calculates a modified version of the TEMA, which itself is a smoothed average of three EMAs (Exponential Moving Averages). The time lag parameter (usually 0.7) adjusts how aggressively the indicator reacts to recent price changes.  

Traders interpret T3 by watching for:  
- **Crossovers**: The line crossing above +1 (overbought) or below -1 (oversold) may signal potential reversals.  
- **Divergences**: When price makes a new high but T3 does not, suggesting weakening momentum.  
- **Trend confirmation**: In uptrends, T3 staying above zero may validate bullish momentum; the inverse applies in downtrends.  

However, limitations include:  
- **False signals**: In trending markets, T3 may stay in overbought/oversold zones for extended periods.  
- **Lag sensitivity**: The time lag parameter requires tuning for different markets or timeframes.  
- **Choppy markets**: High volatility can generate frequent false crossovers.  

## Text Formula  
The T3 indicator is calculated in six steps:  

1. **EMA1** = EMA(close)  
2. **EMA2** = EMA(EMA1)  
3. **EMA3** = EMA(EMA2)  
4. **TEMA** = 3 × EMA1 − 3 × EMA2 + EMA3  
5. **TEMA_lagged** = TEMA shifted by one period  
6. **T3** = `(TEMA − TEMA_lagged) × (1 − time_lag) + TEMA × time_lag`  

Where:  
- `EMA` is an Exponential Moving Average with a specified period (commonly 7).  
- `time_lag` is a user-defined parameter (default: 0.7).  

## Python Code  
```python
import pandas as pd

def calculate_t3(df, period=7, time_lag=0.7):
    """
    Calculate the T3 indicator for each symbol in the DataFrame.
    
    Parameters:
        df (pd.DataFrame): Input DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.
        period (int): EMA period (default: 7).
        time_lag (float): Time lag parameter (default: 0.7).
    
    Returns:
        pd.DataFrame: Original DataFrame with added 'T3' column.
    """
    # Group by symbol to process each independently
    def _t3(group):
        close = group['close']
        # Step 1: Calculate EMAs
        ema1 = close.ewm(span=period, adjust=False).mean()
        ema2 = ema1.ewm(span=period, adjust=False).mean()
        ema3 = ema2.ewm(span=period, adjust=False).mean()
        # Step 2: Calculate TEMA
        tema = 3 * ema1 - 3 * ema2 + ema3
        # Step 3: Apply time lag adjustment
        tema_lagged = tema.shift(1)
        t3 = (tema - tema_lagged) * (1 - time_lag) + tema * time_lag
        group['T3'] = t3
        return group
    
    df = df.groupby('symbol', group_keys=False).apply(_t3)
    return df
```

This code:  
- Groups data by `symbol` to ensure calculations are isolated per asset.  
- Computes three nested EMAs to derive TEMA.  
- Applies the time lag formula to generate the final T3 values.  
- Returns the original DataFrame with a new `T3` column.  

To use, pass a DataFrame with the required columns and optional parameters (`period`, `time_lag`). The output includes T3 values for each row, ready for visualization or further analysis.
```json
{ "model_code": "d2vt6jb9krx5", "topic": "T3", "timer_secs": 31.96, "tokens_in": 563, "tokens_out": 3136, "cost_tokens_in": 0.00004504, "cost_tokens_out": 0.00075264, "cost_tokens_tot": 0.00079768 }
```