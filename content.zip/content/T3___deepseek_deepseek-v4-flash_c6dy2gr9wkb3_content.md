# T3

## Overview

The T3 is a smoothed, lag-reduced moving average developed by Tim Tillson in 1998. It appears on a chart as a single line that follows price action more closely than a simple moving average (SMA) or exponential moving average (EMA) of the same period, while remaining smoother than a double or triple EMA. The T3 achieves this by applying a triple‑stage smoothing process that incorporates a user‑defined volume factor (often denoted *v*), which controls the trade‑off between smoothness and responsiveness. The indicator is popular among traders who want a trend‑following line that reacts quickly to price changes without excessive whipsaws.

## Details

The T3 is built from a series of exponential moving averages. First, a single EMA of the price is computed. That EMA is then smoothed again with another EMA, and the result is smoothed a third time. These three layers are combined using the volume factor *v* (typically set between 0 and 1, with 0.7 being common). The core operation is a “generalized DEMA” (GD) step:  
`GD(x, v) = (1 - v) * x + v * EMA(x, period)`.

Applying GD three times in succession – first to the raw price, then to the result of the first GD, then to the result of the second GD – yields the T3. The effect is that the final line retains the low‑lag characteristics of a DEMA but with additional smoothing from the triple pass.

**How traders interpret it:**

- **Trend direction:** When price is above the T3, the trend is considered up; below, down.
- **Support/resistance:** The T3 can act as dynamic support or resistance during pullbacks.
- **Crossovers:** A crossover of price above or below the T3 is a common entry signal. Some traders also use two T3 lines with different periods (e.g., 5 and 13) and trade their crossovers.
- **Slope:** The slope of the T3 line itself can indicate trend strength – a steep slope suggests a strong trend.

**Where interpretation breaks down:**

- **Choppy markets:** In sideways or ranging conditions, the T3 can produce many false crossovers, leading to whipsaws.
- **Parameter sensitivity:** The volume factor *v* dramatically changes the indicator’s behavior. A high *v* (close to 1) makes it very smooth but slow; a low *v* (close to 0) makes it fast but noisy. There is no universally optimal setting.
- **Lag still exists:** While the T3 reduces lag compared to a simple triple EMA, it is not a leading indicator. It will always lag price to some degree, especially during sharp reversals.
- **Not a standalone system:** Like all moving averages, the T3 works best when combined with other forms of analysis (volume, momentum oscillators, price patterns).

## Text Formula

Let `price` be the closing price series, `period` be the number of bars for the EMA, and `v` be the volume factor (0 < v < 1).

Define the generalized DEMA function:

```
GD(x, v) = (1 - v) * x + v * EMA(x, period)
```

Then the T3 is computed by applying GD three times:

```
e1 = EMA(price, period)
gd1 = GD(price, v) = (1 - v) * price + v * e1

e2 = EMA(gd1, period)
gd2 = GD(gd1, v) = (1 - v) * gd1 + v * e2

e3 = EMA(gd2, period)
T3 = GD(gd2, v) = (1 - v) * gd2 + v * e3
```

Equivalently, the T3 can be expressed as a weighted combination of six EMAs (e1 through e6), but the iterative GD approach is simpler to implement and understand.

## Python Code

```python
import pandas as pd
import numpy as np

def compute_t3(df: pd.DataFrame, period: int = 5, v: float = 0.7) -> pd.DataFrame:
    """
    Compute the T3 indicator for each symbol in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data should be sorted by date within each symbol.
    period : int
        Lookback period for the EMA (default 5).
    v : float
        Volume factor (default 0.7). Must be between 0 and 1.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with an added 'T3' column.
        The T3 values are NaN for the first (3*period - 2) rows of each symbol
        because the triple EMA requires sufficient history.
    """
    def _t3_for_symbol(group: pd.DataFrame) -> pd.Series:
        price = group['close']
        # First EMA
        e1 = price.ewm(span=period, adjust=False).mean()
        # First GD
        gd1 = (1 - v) * price + v * e1
        # Second EMA (of gd1)
        e2 = gd1.ewm(span=period, adjust=False).mean()
        # Second GD
        gd2 = (1 - v) * gd1 + v * e2
        # Third EMA (of gd2)
        e3 = gd2.ewm(span=period, adjust=False).mean()
        # Third GD = T3
        t3 = (1 - v) * gd2 + v * e3
        return t3

    df = df.copy()
    df['T3'] = df.groupby('symbol', group_keys=False).apply(_t3_for_symbol)
    return df
```
```json
{ "model_code": "c6dy2gr9wkb3", "topic": "T3", "timer_secs": 38.55, "tokens_in": 559, "tokens_out": 1911, "cost_tokens_in": 0.00007826, "cost_tokens_out": 0.00053508, "cost_tokens_tot": 0.00061334 }
```