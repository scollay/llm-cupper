# Coppock Curve

## Overview
The Coppock Curve is a momentum indicator used in technical analysis to identify long-term buying opportunities in the stock market. It appears on a chart as a line that oscillates around zero, signaling bullish or bearish trends. The Coppock Curve was developed by Edwin Coppock, an economist, in 1965.

## Details
The Coppock Curve is calculated using a combination of short-term and long-term price changes. It is designed to capture the overall momentum of the market by smoothing out short-term fluctuations. The indicator is typically used on a monthly chart to identify long-term trends. A buy signal is generated when the Coppock Curve crosses above zero, indicating a potential long-term uptrend. Conversely, a sell signal is generated when the curve crosses below zero, suggesting a potential downtrend.

Traders typically interpret the Coppock Curve as a confirmation tool, using it in conjunction with other indicators to validate their investment decisions. The Coppock Curve is considered a contrarian indicator, as it is based on the idea that periods of extreme pessimism are often followed by strong market rallies.

However, the interpretation of the Coppock Curve can break down during periods of high market volatility or when the market is experiencing a significant structural change. In such cases, the indicator may produce false signals or fail to capture the underlying trend.

## Text Formula
To calculate the Coppock Curve, the following steps are required:
1. Calculate the 14-month rate of change (`ROC_14`) as `(close - close 14 months ago) / close 14 months ago`.
2. Calculate the 11-month rate of change (`ROC_11`) as `(close - close 11 months ago) / close 11 months ago`.
3. Calculate the sum of `ROC_14` and `ROC_11`.
4. Calculate the 10-month weighted moving average (`WMA_10`) of the sum from step 3.

The Coppock Curve is the `WMA_10` calculated in step 4.

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df):
    # Ensure the dataframe is sorted by symbol and date
    df = df.sort_values(by=['symbol', 'date'])
    
    # Calculate the 14-month and 11-month rate of change
    df['ROC_14'] = df.groupby('symbol')['close'].pct_change(14)
    df['ROC_11'] = df.groupby('symbol')['close'].pct_change(11)
    
    # Calculate the sum of ROC_14 and ROC_11
    df['ROC_sum'] = df['ROC_14'] + df['ROC_11']
    
    # Calculate the 10-month weighted moving average of ROC_sum
    df['WMA_10'] = df.groupby('symbol')['ROC_sum'].transform(lambda x: x.ewm(span=10, adjust=False).mean())
    
    # The Coppock Curve is the WMA_10
    df['Coppock_Curve'] = df['WMA_10']
    
    return df
```
```json
{ "model_code": "n7gx4mc8btf3", "topic": "Coppock Curve", "timer_secs": 18.07, "tokens_in": 561, "tokens_out": 635, "cost_tokens_in": 0.00008415, "cost_tokens_out": 0.00038100, "cost_tokens_tot": 0.00046515 }
```