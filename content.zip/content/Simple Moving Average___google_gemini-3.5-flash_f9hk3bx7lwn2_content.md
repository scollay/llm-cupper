# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is one of the foundational technical indicators used by traders to identify market trends, smooth out price volatility, and establish potential support and resistance levels. On a financial chart, the SMA appears as a smoothed, continuous line plotted directly over the price bars, lagging behind the current price action because it is calculated from historical data. 

While the mathematical concept of a moving average dates back to the late 19th and early 20th centuries, its systematic application to financial markets was popularized in the mid-20th century by technical analysis pioneers such as Richard Donchian, who utilized moving average crossover systems to pioneer trend-following trading strategies.

## Details
The SMA is an arithmetic moving average calculated by adding the closing prices of a security over a specified number of periods and then dividing that sum by the number of periods. Because it treats every data point within the lookback window with equal weight, it provides a clear, unweighted representation of a security's average price over time.

### How Traders Interpret the SMA
Traders utilize the SMA in three primary ways: trend identification, dynamic support and resistance, and crossover systems.

#### Trend Identification
The most straightforward application of the SMA is determining the direction of the prevailing trend. 
* **Uptrend:** When the price is trading above a rising SMA, the market is considered to be in an uptrend.
* **Downtrend:** When the price is trading below a falling SMA, the market is considered to be in a downtrend.

The length of the lookback period determines the trend horizon. Short-term traders often monitor the 20-period SMA, medium-term traders look to the 50-period SMA, and long-term institutional investors rely heavily on the 200-period SMA to define macro bull and bear regimes.

#### Dynamic Support and Resistance
Unlike static horizontal support and resistance lines, the SMA acts as a dynamic boundary. In a strong uptrend, pullbacks often find buying interest near the 50-day or 200-day SMA, as institutional market participants use these key averages to accumulate positions at average value. Conversely, in a downtrend, the SMA can act as a ceiling, capping relief rallies.

#### Crossover Strategies
Crossovers generate actionable entry and exit signals. There are two primary types of crossovers:
* **Price Crossover:** A bullish signal is generated when the price crosses above the SMA from below. A bearish signal is generated when the price crosses below the SMA from above.
* **Moving Average Crossover:** This involves using two SMAs of different lengths—a faster (shorter-term) SMA and a slower (longer-term) SMA. 
    * **Golden Cross:** A highly watched bullish signal that occurs when a fast SMA (typically the 50-day) crosses above a slow SMA (typically the 200-day).
    * **Death Cross:** A bearish signal that occurs when the fast SMA crosses below the slow SMA.

### Where the SMA Breaks Down
While highly effective in trending markets, the SMA has distinct structural limitations that traders must manage.

#### Lag and Delayed Execution
Because the SMA is a lagging indicator based entirely on past price action, it will always react after a market turning point. In a rapid market reversal, a trader relying solely on the SMA may enter a trade late or give back a significant portion of accumulated profits before an exit signal is triggered.

#### The "Drop-Off" Effect
The equal-weighting methodology of the SMA introduces a mathematical anomaly known as the drop-off effect. When a new price is added to the calculation, the oldest price in the lookback window is dropped. If the price being dropped was an extreme outlier (such as a single-day earnings spike or flash crash), the SMA line will shift significantly today, even if today's actual price action is completely flat. This can lead to false signals unrelated to current market dynamics.

#### Whipsaws in Range-Bound Markets
In sideways, consolidating, or choppy markets, the SMA flattens out. During these periods, price will frequently oscillate back and forth across the SMA line. This generates rapid, consecutive false signals (whipsaws) that can quickly erode a trader's capital through transaction costs and small, consecutive losses.

## Text Formula

The Simple Moving Average for a given period $N$ at time $t$ is calculated as:

$$SMA_t = \frac{P_t + P_{t-1} + P_{t-2} + \dots + P_{t-N+1}}{N}$$

Where:
* $N$ = The lookback period (number of bars/days).
* $P_t$ = The closing price of the security at period $t$.

To calculate the SMA sequentially without summing the entire window each time, the formula can be updated using the rolling step:

$$SMA_t = SMA_{t-1} + \frac{P_t - P_{t-N}}{N}$$

### Crossover Logic

* **Golden Cross (Bullish Crossover):**
  $$\text{Golden Cross}_t = (SMA_{50, t} > SMA_{200, t}) \land (SMA_{50, t-1} \le SMA_{200, t-1})$$

* **Death Cross (Bearish Crossover):**
  $$\text{Death Cross}_t = (SMA_{50, t} < SMA_{200, t}) \land (SMA_{50, t-1} \ge SMA_{200, t-1})$$

## Python Code

```python
import pandas as pd

def calculate_sma_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates Simple Moving Averages (20, 50, and 200 periods) along with
    Golden Cross and Death Cross signals for a multi-symbol DataFrame.
    
    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame containing historical price data.
        Required columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
        
    Returns:
    --------
    pd.DataFrame
        The original DataFrame sorted chronologically per symbol, with the 
        following columns appended:
        - 'sma_20': 20-period Simple Moving Average
        - 'sma_50': 50-period Simple Moving Average
        - 'sma_200': 200-period Simple Moving Average
        - 'golden_cross': Boolean flag indicating a 50/200 bullish crossover
        - 'death_cross': Boolean flag indicating a 50/200 bearish crossover
    """
    # Ensure the data is sorted chronologically within each symbol
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Group by symbol to calculate rolling averages independently for each asset
    grouped = df.groupby('symbol')
    
    # Calculate the SMAs mentioned in the article
    df['sma_20'] = grouped['close'].transform(lambda x: x.rolling(window=20).mean())
    df['sma_50'] = grouped['close'].transform(lambda x: x.rolling(window=50).mean())
    df['sma_200'] = grouped['close'].transform(lambda x: x.rolling(window=200).mean())
    
    # Shift the SMAs by 1 period within each group to detect crossovers
    df['sma_50_prev'] = grouped['sma_50'].shift(1)
    df['sma_200_prev'] = grouped['sma_200'].shift(1)
    
    # Golden Cross: 50 SMA crosses above 200 SMA
    df['golden_cross'] = (
        (df['sma_50'] > df['sma_200']) & 
        (df['sma_50_prev'] <= df['sma_200_prev'])
    )
    
    # Death Cross: 50 SMA crosses below 200 SMA
    df['death_cross'] = (
        (df['sma_50'] < df['sma_200']) & 
        (df['sma_50_prev'] >= df['sma_200_prev'])
    )
    
    # Drop temporary shift columns used for crossover logic
    df = df.drop(columns=['sma_50_prev', 'sma_200_prev'])
    
    return df
```
```json
{ "model_code": "f9hk3bx7lwn2", "topic": "Simple Moving Average", "timer_secs": 20.99, "tokens_in": 565, "tokens_out": 4300, "cost_tokens_in": 0.00084750, "cost_tokens_out": 0.03870000, "cost_tokens_tot": 0.03954750 }
```