# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum oscillator designed to identify major, secular buying opportunities in equity markets. Visually, it appears as a single continuous line fluctuating above and below a zero-level center line, typically plotted beneath a monthly price chart. 

The indicator was developed by economist and investment adviser Edwin Coppock and published in *Barron's* in 1969. Coppock originally designed the curve for long-term investors, specifically targeting major index bottoms rather than short-term trading swings.

## Details
The Coppock Curve is built on the premise that market bottoms are characterized by a distinct, measurable shift in momentum. To capture this shift, the indicator combines a short-term and a long-term measure of momentum and smooths the result to filter out market noise. 

### How It Works
The indicator relies on three primary parameters, traditionally set to 14, 11, and 10:
1. **Long-Term Momentum:** A 14-period Rate of Change (ROC).
2. **Short-Term Momentum:** An 11-period Rate of Change (ROC).
3. **Smoothing Filter:** A 10-period Weighted Moving Average (WMA).

Coppock arrived at the 11- and 14-period intervals through an unusual methodology. Commissioned by the Episcopal Church to find reliable long-term investment opportunities, he asked the church priests how long it took the average person to grieve and recover from a major loss. The priests responded that the typical mourning period was 11 to 14 months. Equating a severe market downturn to emotional grief, Coppock adopted these periods for his momentum calculations.

The two ROC values are summed to combine short- and long-term momentum trends. This sum is then smoothed using a 10-period WMA, which assigns greater weight to the most recent data points. This weighting helps the indicator react more quickly to genuine trend reversals than a simple moving average would.

### Trader Interpretation and Signals
Active traders and analysts use the Coppock Curve primarily to identify major market bottoms and trend reversals:

* **The Classic Buy Signal:** A buy signal is generated when the Coppock Curve is below the zero line and begins to turn upward (i.e., it prints a local trough and starts rising). Crucially, the signal occurs *below* the zero line; traders do not need to wait for the curve to cross above zero to initiate a position.
* **Zero-Line Crossovers:** Some modern traders adapt the indicator by using a cross above the zero line as a confirmation of a new bull market, or a cross below the zero line as a macro-level exit signal.
* **Timeframe Adaptation:** While designed for monthly charts, active traders sometimes apply the Coppock Curve to weekly or daily charts to capture intermediate-term trend shifts.

### Where the Interpretation Breaks Down
While highly regarded for its historical accuracy in identifying major market bottoms, the Coppock Curve has distinct limitations:

* **Inherent Lag:** Because the indicator relies on a 10-period WMA of two lagging ROC calculations, it is structurally late. By the time the curve bottoms out and turns upward, the absolute price bottom has already passed—often by several weeks on a weekly chart, or months on a monthly chart.
* **The "Sell" Signal Problem:** The Coppock Curve was not designed to generate sell signals, and using it as such is notoriously unreliable. In a strong, multi-year bull market, the curve will often peak and drift downward while prices continue to climb. Selling or shorting based on a downward turn from overbought territory frequently results in premature exits and missed gains.
* **Whipsaws on Lower Timeframes:** When applied to daily or intraday charts, the indicator loses its secular smoothing utility. In range-bound or choppy markets, it produces frequent false signals (whipsaws) as the curve oscillates rapidly around the zero line.

## Text Formula
To calculate the Coppock Curve, use the following step-by-step formulas:

1. **Calculate the Long-Term Rate of Change ($ROC_{long}$):**
   $$ROC_{long} = \left( \frac{Close_t - Close_{t-14}}{Close_{t-14}} \right) \times 100$$

2. **Calculate the Short-Term Rate of Change ($ROC_{short}$):**
   $$ROC_{short} = \left( \frac{Close_t - Close_{t-11}}{Close_{t-11}} \right) \times 100$$

3. **Sum the Rates of Change ($ROC_{sum}$):**
   $$ROC_{sum} = ROC_{long} + ROC_{short}$$

4. **Calculate the Coppock Curve ($CC$):**
   $$CC = WMA_{10}(ROC_{sum})$$

Where the Weighted Moving Average ($WMA$) of period $n$ for a series $X$ at time $t$ is calculated as:
$$WMA_n(X) = \frac{\sum_{i=1}^{n} (i \cdot X_{t - n + i})}{\sum_{i=1}^{n} i}$$

## Python Code

```python
import numpy as np
import pandas as pd


def calculate_coppock_curve(
    df: pd.DataFrame,
    roc_long_period: int = 14,
    roc_short_period: int = 11,
    wma_period: int = 10,
) -> pd.DataFrame:
    """Calculates the Coppock Curve for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame containing columns: 'symbol', 'date', 'open', 'high',
        'low', 'close'.
    roc_long_period : int, default 14
        The lookback period for the long-term Rate of Change.
    roc_short_period : int, default 11
        The lookback period for the short-term Rate of Change.
    wma_period : int, default 10
        The smoothing period for the Weighted Moving Average.

    Returns:
    --------
    pd.DataFrame
        The original DataFrame with the calculated 'coppock_curve' column
        and intermediate calculation columns.
    """
    # Ensure the DataFrame is sorted chronologically per symbol
    df = df.sort_values(by=["symbol", "date"]).reset_index(drop=True)

    # Group by symbol to perform independent calculations
    grouped = df.groupby("symbol")

    # Calculate the long-term and short-term ROC
    df["roc_long"] = (
        grouped["close"].pct_change(periods=roc_long_period) * 100
    )
    df["roc_short"] = (
        grouped["close"].pct_change(periods=roc_short_period) * 100
    )

    # Sum the two ROC values
    df["roc_sum"] = df["roc_long"] + df["roc_short"]

    # Define WMA weights and denominator
    weights = np.arange(1, wma_period + 1)
    sum_weights = weights.sum()

    def apply_wma(series: pd.Series) -> pd.Series:
        """Applies a Weighted Moving Average to a pandas Series."""
        return series.rolling(window=wma_period).apply(
            lambda window: np.dot(window, weights) / sum_weights, raw=True
        )

    # Apply the WMA to the sum of the ROCs independently for each symbol
    df["coppock_curve"] = df.groupby("symbol")["roc_sum"].transform(apply_wma)

    return df
```
```json
{ "model_code": "f9hk3bx7lwn2", "topic": "Coppock Curve", "timer_secs": 23.36, "tokens_in": 565, "tokens_out": 4736, "cost_tokens_in": 0.00084750, "cost_tokens_out": 0.04262400, "cost_tokens_tot": 0.04347150 }
```