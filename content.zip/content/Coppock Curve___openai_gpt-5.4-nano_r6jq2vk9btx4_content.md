# Coppock Curve

## Overview
The **Coppock Curve** is a long-term momentum indicator designed to identify market turns, especially for broad equity indexes and similar benchmarks. It’s typically plotted as a single line that rises and falls slowly, making it most useful for identifying **major bear-market bottoms** and subsequent recoveries rather than short-term trading swings.

The indicator was created by **Elliott J. Coppock** and introduced in his writing in the late **1960s** (commonly dated to 1969). Coppock popularized it as a smoother alternative to faster oscillators, emphasizing *trend-change detection* over frequent overbought/oversold signals.

## Details
### What the Coppock Curve measures
At its core, the Coppock Curve blends two **rates of change** components and smooths them. Conceptually, it asks:

- Is momentum (as measured by long-term price changes) improving?
- And is it improving *consistently enough* to suggest a new macro uptrend?

It does this by combining a **long and a slightly shorter ROC** and then applying a **weighted moving average**.

### Standard construction (typical parameters)
Most traders use a parameter set similar to:

- `ROC1 = 14` (days/months depending on your data frequency)
- `ROC2 = 11`
- `WMA length = 10`

But the indicator is not universally standardized—some practitioners tune these lengths to the asset’s cycle and the timeframe they trade.

### How traders interpret it
Because the curve is slow-moving, traders generally use these interpretations:

1. **Turning points around zero**
   - A common rule of thumb is: **buy when the curve crosses above zero** (or turns up after being below zero).
   - The zero line is not “overbought/oversold”; it’s more like a regime filter for long-term momentum.

2. **Positive momentum confirmation**
   - Sustained time above zero suggests a more persistent positive momentum regime.
   - Traders often wait for the curve to **turn upward**, not merely touch the line, to reduce whipsaw risk.

3. **Bear market bottom signaling**
   - The indicator is frequently described as bottom-finding: it tends to improve after the worst part of a downtrend, then confirms recovery as its smoothed momentum rises.

4. **Divergence and failure modes**
   - If price begins trending up but the Coppock Curve stays flat or declines, it may indicate that the rally lacks long-term momentum strength.

### Where interpretation tends to break down
Like any momentum-based tool, the Coppock Curve has limitations—especially for traders expecting fast, reliable signals.

- **Timeframe mismatch**
  - The Coppock Curve is designed for **long-term** turns. If you run it on short intraday bars, the behavior may not match its intended smoothing and lag characteristics.
- **Lag is inherent**
  - The curve’s smoothing (and its use of ROCs) introduces delay. In fast reversals, you may get late confirmation—more “trend change” than “trend prediction.”
- **Parameter sensitivity**
  - Different markets can respond differently to `ROC1`, `ROC2`, and WMA length. A parameter set that fits one index’s cycle can underperform elsewhere.
- **Range-bound regimes**
  - In sideways markets, the curve may chop around zero, producing multiple false “turn” signals. Because it’s slow, it can also “stick” on one side of zero longer than traders prefer.
- **Single-rule automation risk**
  - Using only a naive zero-cross rule without a second filter (trend context, volatility regime, or a confirmation such as price structure) can lead to noisy outcomes.

### Practical ways traders use it
Common implementation patterns include:

- Use the Coppock Curve as a **bias filter** (only take longs when it’s rising / above zero).
- Combine with a **trend filter** (e.g., moving averages of price) to avoid countertrend entries.
- Treat it as a **signal to reduce risk**, not to force entries (e.g., fade long exposure when it rolls over).

## Text Formula
Let `t` be a bar index (daily bars, weekly bars, etc.) and `Close[t]` be the closing price at time `t`.

1. **Rate of Change (ROC)**
   - `ROC(n, t) = 100 * (Close[t] / Close[t-n] - 1)`

2. **Raw Coppock computation (sum of two ROCs)**
   - `RawCoppock[t] = ROC(ROC1, t) + ROC(ROC2, t)`
   - Using typical defaults: `ROC1 = 14`, `ROC2 = 11`

3. **Weighted Moving Average (WMA) smoothing**
   - For a window length `L` (typical default `L = 10`):
   - `Coppock[t] = WMA(RawCoppock, L, t)`
   - `WMA` with linearly increasing weights `1..L`:
     - `WMA[t] = ( Σ_{i=0..L-1} ( (L - i) * RawCoppock[t - i] ) ) / ( Σ_{i=0..L-1} (L - i) )`
     - Denominator is `L*(L+1)/2`

4. **Signal interpretations commonly used**
   - **Zero-line cross (or turn):** check whether `Coppock[t]` crosses above 0 from below, or turns upward after being below 0.

## Python Code
```python
import pandas as pd
import numpy as np

def coppock_curve(
    df: pd.DataFrame,
    roc1: int = 14,
    roc2: int = 11,
    wma_length: int = 10,
    price_col: str = "close"
) -> pd.DataFrame:
    """
    Expected input DataFrame columns:
        - 'symbol', 'date', 'open', 'high', 'low', 'close'
    Output DataFrame includes (per symbol, per date):
        - 'coppock_raw'   : ROC(roc1) + ROC(roc2)
        - 'coppock'        : WMA(smoothed coppock_raw, wma_length)
        - 'coppock_turn_up': 1 if Coppock makes an upward turn after a decline (local monotonic turn), else 0/NaN
        - 'coppock_cross_above_0': 1 if crosses from <=0 to >0, else 0
        - 'coppock_cross_below_0': 1 if crosses from >=0 to <0, else 0
    """

    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Compute ROC(n): 100 * (Close / Close.shift(n) - 1)
    def roc(series: pd.Series, n: int) -> pd.Series:
        prev = series.shift(n)
        return 100.0 * (series / prev - 1.0)

    # WMA with linearly increasing weights (1..L) for the most recent value having weight L.
    # Implemented via rolling.apply for correctness and clarity.
    def wma(series: pd.Series, L: int) -> pd.Series:
        weights = np.arange(L, 0, -1, dtype=float)  # [L, L-1, ..., 1]
        denom = weights.sum()

        def _calc(x: np.ndarray) -> float:
            # x has length L
            return float(np.dot(x, weights) / denom)

        return series.rolling(L, min_periods=L).apply(_calc, raw=True)

    # Compute per symbol independently
    grouped = out.groupby("symbol", group_keys=False)

    close = out[price_col]

    # ROC components per symbol
    roc1_series = grouped[price_col].transform(lambda s: roc(s, roc1))
    roc2_series = grouped[price_col].transform(lambda s: roc(s, roc2))

    coppock_raw = roc1_series + roc2_series

    # Smooth with WMA
    coppock_smoothed = grouped.apply(
        lambda g: wma((roc(g[price_col], roc1) + roc(g[price_col], roc2)), wma_length)
    ).reset_index(level=0, drop=True)

    out["coppock_raw"] = coppock_raw
    out["coppock"] = coppock_smoothed

    # Zero-line crosses per symbol
    coppock = out["coppock"]
    coppock_prev = grouped["coppock"].shift(1)

    out["coppock_cross_above_0"] = (
        (coppock_prev <= 0) & (coppock > 0)
    ).astype(int).where(~coppock.isna(), other=np.nan)

    out["coppock_cross_below_0"] = (
        (coppock_prev >= 0) & (coppock < 0)
    ).astype(int).where(~coppock.isna(), other=np.nan)

    # "Turn up" definition (local turn): Coppock[t] > Coppock[t-1] AND Coppock[t-1] <= Coppock[t-2]
    # This captures "turning upward" rather than merely being above/below zero.
    prev1 = grouped["coppock"].shift(1)
    prev2 = grouped["coppock"].shift(2)

    out["coppock_turn_up"] = (
        (coppock > prev1) &
        (prev1 <= prev2)
    ).astype(int).where(~coppock.isna(), other=np.nan)

    return out
```
```json
{ "model_code": "r6jq2vk9btx4", "topic": "Coppock Curve", "timer_secs": 13.12, "tokens_in": 559, "tokens_out": 2125, "cost_tokens_in": 0.00011180, "cost_tokens_out": 0.00265625, "cost_tokens_tot": 0.00276805 }
```