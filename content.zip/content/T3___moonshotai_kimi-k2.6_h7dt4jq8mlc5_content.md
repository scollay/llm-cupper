# T3

## Overview
T3 is a smoothing moving average developed by technical analyst Tim Tillson and introduced in the January 1998 issue of *Technical Analysis of Stocks and Commodities*. It is constructed by nesting six exponential moving averages (EMAs) of the same period and blending them with a volume factor to reduce lag and noise simultaneously. On a chart, T3 appears as a single, highly responsive line that hugs price more tightly than a conventional EMA or simple moving average, filtering out minor whipsaws while maintaining a fluid curve. Traders often overlay it directly on price action to judge trend health, using it as a dynamic support and resistance tool or as a trailing-stop anchor.

## Details
T3 is a higher-order moving average designed to cut the lag of conventional trend filters without sacrificing smoothness. Tillson built it by extending the Generalized Double Exponential Moving Average (GD), a structure that adds a user-defined volume factor `v` to the standard DEMA formula. Applying GD three times in succession creates a six-pole EMA filter. The volume factor acts as a responsiveness dial: at `v = 0` the indicator collapses to a plain EMA, while at `v = 1` it becomes a triple DEMA. The widely adopted default of `0.7` offers a middle ground that preserves the curve’s fluidity during trends yet dampens noise in congested markets.

**Construction.** The calculation begins with a standard EMA of the closing price over a selected lookback period, commonly between 5 and 15 bars for short-term work and 20 to 50 for swing analysis. That result, labeled `e1`, is fed into a second EMA of the same period to create `e2`. The smoothing continues through `e6`. T3 discards the earliest two layers and weights `e3` through `e6` using coefficients expanded from `(1 + v)³`. In signal-processing terms, this produces a filter with a steeper frequency cutoff than a single EMA, meaning it reacts faster to legitimate trend changes while ignoring minor ripples.

**Trading interpretation.** Traders deploy T3 as a dynamic trend proxy. When price closes above the line, the prevailing read is bullish; a sustained close below indicates bearish control. Because the line is noticeably smoother than a simple or exponential moving average of the same period, it is popular for trailing stops and for defining the directional bias in multi-timeframe strategies. Some practitioners look for pullbacks to T3 in an established trend, treating penetrations that fail to close on the wrong side as continuation entries.

**Limitations and failure modes.** Despite its sophistication, T3 is not a lag-free oracle. In a strong directional move, the line still trails price, and crossover signals inherently arrive after the initial thrust. The negative weights embedded in the formula create an overshoot characteristic common to higher-order filters: during sharp reversals, T3 can briefly print beyond the actual price extreme before snapping back, which may trigger premature exits if a trader uses absolute touch levels as hard stops.

In rangebound, choppy environments, T3 will still crisscross price and generate whipsaws. The smoothness reduces their frequency compared with a raw EMA, but it does not eliminate them. Because six nested EMAs are involved, the indicator is data-hungry; the first several dozen bars of a series are effectively a warm-up phase, and backtests that do not discard this initialization period are unreliable.

The volume factor itself is a double-edged sword. Raising `v` above `0.8` pushes the filter toward over-responsiveness, causing it to hug short-term noise and produce head-fake reversals. Many traders optimize the factor and period against historical equity curves without out-of-sample testing, which invites curve fitting. Finally, T3 is price-only; it incorporates no volume, volatility, or intermarket context. A trader relying on T3 crossovers during a volatility expansion—such as around earnings or macro releases—will often find that the indicator’s overshoot amplifies rather than reduces risk.

**Comparison with TEMA.** Traders often confuse T3 with the Triple Exponential Moving Average (TEMA). TEMA, developed by Patrick Mulloy, combines three EMA layers—`3 × EMA − 3 × EMA(EMA) + EMA(EMA(EMA))`—and is essentially a three-pole filter. T3 uses six poles and a variable volume factor, giving it a softer, rounder profile. Where TEMA can feel angular and prone to stair-stepping, T3 flows; however, that fluidity comes at the cost of greater computational complexity and a longer initialization tail.

**Implementation notes.** Because T3 depends on recursive EMAs, the choice of `adjust=False` in most libraries mimics the real-time streaming calculation and matches what Tillson intended. Using an adjusted initialization that backfills with a weighted average alters the first several bars and can skew backtests. Traders building the indicator from scratch should also ensure they do not inadvertently mix lookback periods across the six layers; every EMA in the stack must use the same `n`.

## Text Formula
Let `n` be the EMA lookback period and `v` be the volume factor (typically `0.7`).

EMA smoothing constant:
- `α = 2 / (n + 1)`

Recursive EMA of the close:
- `EMA_t = α × close_t + (1 − α) × EMA_{t−1}`

Six nested EMAs, each using the same period `n`:
- `e1 = EMA(close, n)`
- `e2 = EMA(e1, n)`
- `e3 = EMA(e2, n)`
- `e4 = EMA(e3, n)`
- `e5 = EMA(e4, n)`
- `e6 = EMA(e5, n)`

T3 coefficients, expanded from the triple GD operator:
- `c1 = −v³`
- `c2 = 3v² + 3v³`
- `c3 = −6v² − 3v − 3v³`
- `c4 = 1 + 3v + 3v² + v³`

Note that `c4 = (1 + v)³`, `c3 = −3v(1 + v)²`, `c2 = 3v²(1 + v)`, and `c1 = −v³`, which reveals the polynomial structure of the six-pole filter.

Final indicator value:
- `T3 = (c1 × e6) + (c2 × e5) + (c3 × e4) + (c4 × e3)`

## Python Code
```python
import pandas as pd

def calculate_t3(df, period=10, volume_factor=0.7):
    """
    Calculate T3 and its nested EMA components.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Input data with columns: symbol, date, open, high, low, close.
        May contain multiple symbols.
    period : int
        Lookback period for each EMA layer.
    volume_factor : float
        Volume factor v (default 0.7).
    
    Returns
    -------
    pandas.DataFrame
        Copy of `df` with columns e1, e2, e3, e4, e5, e6, and t3.
    """
    df = df.copy()
    v = volume_factor
    
    # Helper to compute EMA within each symbol group
    def ema(series):
        return series.ewm(span=period, adjust=False).mean()
    
    # Sequentially calculate six nested EMAs per symbol
    df['e1'] = df.groupby('symbol')['close'].transform(ema)
    df['e2'] = df.groupby('symbol')['e1'].transform(ema)
    df['e3'] = df.groupby('symbol')['e2'].transform(ema)
    df['e4'] = df.groupby('symbol')['e3'].transform(ema)
    df['e5'] = df.groupby('symbol')['e4'].transform(ema)
    df['e6'] = df.groupby('symbol')['e5'].transform(ema)
    
    # Coefficients derived from the volume factor
    c1 = -(v ** 3)
    c2 = 3 * (v ** 2) + 3 * (v ** 3)
    c3 = -6 * (v ** 2) - 3 * v - 3 * (v ** 3)
    c4 = 1 + 3 * v + 3 * (v ** 2) + (v ** 3)
    
    # Final T3 value
    df['t3'] = c1 * df['e6'] + c2 * df['e5'] + c3 * df['e4'] + c4 * df['e3']
    
    return df
```
```json
{ "model_code": "h7dt4jq8mlc5", "topic": "T3", "timer_secs": 875.72, "tokens_in": 557, "tokens_out": 15115, "cost_tokens_in": 0.00040661, "cost_tokens_out": 0.05275135, "cost_tokens_tot": 0.05315796 }
```