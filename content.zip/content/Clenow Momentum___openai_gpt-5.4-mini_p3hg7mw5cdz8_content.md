# Clenow Momentum

## Overview
Clenow Momentum is a **trend-following stock-selection indicator** popularized by trader and author Andreas Clenow in *Stocks on the Move* (2015). It is not typically plotted as a classic oscillator on the price chart; instead, it is computed as a ranking score used to compare securities against one another. The idea is to identify stocks with persistent upside momentum while filtering out names that are too volatile or too recently listed.

In practice, Clenow Momentum combines a long-term trend measure with a volatility adjustment. The result is a cross-sectional ranking tool: traders use it to sort a universe of stocks and focus on the strongest candidates.

## Details
Clenow Momentum is designed to answer a simple question: **which stocks are trending most strongly, after adjusting for risk?** The indicator is built from three core ideas:

1. **Use a long lookback window**  
   The indicator measures the slope of a stock’s price trend over a substantial period, typically around 90 trading days or more. This helps reduce noise and emphasize durable trends.

2. **Express trend on a log scale**  
   Clenow’s framework uses logarithmic prices so that trend growth is measured in percentage terms rather than raw price points. That makes the slope comparable across low-priced and high-priced stocks.

3. **Penalize excessive volatility**  
   A strong trend is less attractive if it is accompanied by large swings. So the slope is divided by a volatility estimate, usually the standard deviation of daily log returns over the same lookback period.

The indicator is often used as a **ranking filter** rather than a standalone entry signal. A typical workflow is:

- Build a universe of liquid stocks.
- Compute Clenow Momentum for each symbol.
- Rank from highest to lowest.
- Buy the top-ranked names, often with additional liquidity, sector, or risk controls.

### How traders interpret it
A higher Clenow Momentum value means:

- the stock has a stronger upward drift over the lookback period,
- the trend is more stable relative to its volatility,
- the stock is more likely to be part of an established momentum regime.

A low or negative value suggests:

- weak trend strength,
- sideways or declining price behavior,
- poor suitability for momentum-style long exposure.

Because it is a ranking measure, the absolute number matters less than the **relative score across the universe**. A stock with a modest positive reading may still be attractive if the rest of the universe is weaker.

### Why it works
The indicator aligns with a well-documented market tendency: **winners often keep winning for a while**. Clenow Momentum attempts to capture that persistence while avoiding names whose apparent trend is mostly volatility.

The use of log prices and volatility normalization makes it more robust than a plain moving-average slope. A stock that rises steadily with low dispersion can outrank a faster-moving but erratic stock.

### Where it breaks down
Like all momentum measures, Clenow Momentum is vulnerable to regime change.

Common failure modes include:

- **Trend reversals**: Momentum can stay high well into the late stages of a move, so it is not a timing tool for tops.
- **Mean-reverting markets**: In choppy or range-bound conditions, trend scores may be weak and rankings unstable.
- **Event-driven gaps**: Earnings or news shocks can distort recent returns and volatility, making the score jump or collapse.
- **Short sample bias**: New listings or sparse data can make the volatility estimate unreliable.
- **Universe dependence**: A score only has meaning relative to the set of assets being ranked.

A practical limitation is that the indicator can lag. It is intended to identify existing trends, not predict them early. Traders often combine it with liquidity filters, broader market trend checks, and risk management rules such as trailing stops or position sizing based on volatility.

## Text Formula
Let:

- `P_t` = closing price at time `t`
- `L` = lookback period in trading days
- `r_i = ln(P_i / P_{i-1})` = daily log return
- `x_i` = day index, with `i = 1, 2, ..., L`

Then:

1. **Log-price series**
   - `y_i = ln(P_i)`

2. **Linear regression slope of log price on time**
   - `b = Cov(x, y) / Var(x)`

3. **Annualized trend component**
   - `Trend = (1 + b)^{252} - 1`
   - or, in many implementations, `Trend = exp(252 * b) - 1`

4. **Volatility**
   - `Vol = StdDev(r_1, r_2, ..., r_L)`

5. **Clenow Momentum**
   - `CM = Trend / Vol`

A common simplified implementation uses the annualized regression slope directly in log-return terms:

- `CM = (252 * b) / Vol`

Equivalent formulations vary slightly by implementation, but the core concept is always:

**momentum = long-term trend strength ÷ volatility**

## Python Code
```python
import numpy as np
import pandas as pd


def clenow_momentum(
    df: pd.DataFrame,
    lookback: int = 90,
    min_periods: int | None = None,
    annualization_factor: int = 252,
) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    Returns a copy of the input DataFrame with these added columns:
        log_close
        log_return
        cm_slope
        cm_volatility
        clenow_momentum

    Notes:
    - The calculation is performed independently for each symbol.
    - Clenow Momentum is computed as:
          annualized_slope / volatility
      where the slope is the regression slope of log(price) versus time,
      measured over the rolling lookback window.
    - The first values within each symbol will be NaN until enough data exists.
    """
    if min_periods is None:
        min_periods = lookback

    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    def _calc_group(g: pd.DataFrame) -> pd.DataFrame:
        g = g.sort_values("date").copy()

        g["log_close"] = np.log(g["close"].astype(float))
        g["log_return"] = g["log_close"].diff()

        x = np.arange(lookback, dtype=float)
        x_mean = x.mean()
        x_centered = x - x_mean
        denom = np.sum(x_centered ** 2)

        def rolling_slope(values: np.ndarray) -> float:
            if np.any(np.isnan(values)):
                return np.nan
            y = values.astype(float)
            y_mean = y.mean()
            num = np.sum((x - x_mean) * (y - y_mean))
            return num / denom

        g["cm_slope"] = (
            g["log_close"]
            .rolling(window=lookback, min_periods=min_periods)
            .apply(rolling_slope, raw=True)
        )

        g["cm_volatility"] = (
            g["log_return"]
            .rolling(window=lookback, min_periods=min_periods)
            .std(ddof=1)
        )

        g["clenow_momentum"] = (annualization_factor * g["cm_slope"]) / g["cm_volatility"]

        return g

    out = out.groupby("symbol", group_keys=False).apply(_calc_group)

    return out
```
```json
{ "model_code": "p3hg7mw5cdz8", "topic": "Clenow Momentum", "timer_secs": 11.75, "tokens_in": 560, "tokens_out": 1677, "cost_tokens_in": 0.00042000, "cost_tokens_out": 0.00754650, "cost_tokens_tot": 0.00796650 }
```