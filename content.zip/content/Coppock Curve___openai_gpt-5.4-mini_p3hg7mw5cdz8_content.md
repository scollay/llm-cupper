# Coppock Curve

## Overview

The **Coppock Curve** is a long-term momentum indicator originally designed for identifying major market bottoms. It is typically plotted as a single line beneath the price chart, oscillating around zero and turning from negative to positive as downward momentum fades and longer-term strength begins to reassert itself.

The indicator was created by **Edwin Sedgwick Coppock** in **1962** for *Barron’s*. Coppock was asked to develop a tool to help investors recognize favorable entry points after extended declines in stock indices, especially on a monthly chart.

## Details

The Coppock Curve is built from **rate-of-change momentum**, then smoothed with a moving average. In its classic form, it uses monthly data and combines two momentum horizons:

- a **10-period rate of change**
- a **14-period rate of change**
- a **10-period weighted moving average** of their sum

The logic is straightforward: when an asset has fallen for a while, both medium-term and longer-term momentum tend to be negative. As the decline matures, those negative readings begin to improve. The Coppock Curve captures that improvement and smooths it into a slower-turning line.

### How traders interpret it

The most common interpretation is:

- **Bullish signal:** the Coppock Curve turns up from a low level, especially after being negative
- **Stronger confirmation:** the curve crosses above zero
- **Bearish signal:** less emphasized in the original concept, since Coppock was mainly meant as a *buy-the-dip after a bear market* tool

In practice, traders usually look for:

1. A prolonged decline or correction in price
2. The Coppock Curve remaining below zero during the decline
3. The curve bottoming and turning upward
4. Optional confirmation from trend or price structure before entry

Because the indicator is slow, it is often used for **position trading** or **swing trading on higher time frames**, not for short-term timing.

### Why it works

The indicator blends two ideas:

- **Momentum persistence:** recent and intermediate price changes reveal whether selling pressure is weakening
- **Smoothing:** the weighted moving average filters noise so the line changes direction less often than raw momentum

The result is a lagging but relatively stable tool for spotting major inflection points.

### Where it breaks down

Like most momentum indicators, the Coppock Curve has limitations:

- **Lag:** by design, it turns late. It often confirms a recovery after a meaningful portion of the move has already occurred.
- **Whipsaws in choppy markets:** if price trends sideways, the curve can flatten, hook, and re-hook without a durable trend developing.
- **Not ideal for timing exits:** the original use case is mainly for identifying long-term buying opportunities, not precise sell signals.
- **Different behavior across assets:** it tends to work best on broad indices or liquid instruments with cleaner trend structure. On highly volatile individual names, signals may be less reliable.

### Practical usage

Many traders combine the Coppock Curve with other tools:

- **trend filters** such as moving averages
- **breadth measures** for index-based timing
- **support/resistance** or price structure
- **relative strength** to compare candidate assets

A useful way to think about it is: the Coppock Curve does not tell you *where* to buy precisely; it tells you when downside momentum is likely exhausting and a new long-term advance may be beginning.

## Text Formula

Let:

- `ROC_n(t) = ((Close_t - Close_(t-n)) / Close_(t-n)) * 100`
- `WMA_m(X_t) = sum(i * X_(t-m+i)) for i=1..m / sum(i=1..m)`

For the classic Coppock Curve:

- `Coppock_t = WMA_10( ROC_10(t) + ROC_14(t) )`

Expanded:

- `ROC_10(t) = ((Close_t - Close_(t-10)) / Close_(t-10)) * 100`
- `ROC_14(t) = ((Close_t - Close_(t-14)) / Close_(t-14)) * 100`
- `Raw_t = ROC_10(t) + ROC_14(t)`
- `Coppock_t = (1*Raw_(t-9) + 2*Raw_(t-8) + ... + 10*Raw_t) / 55`

Where `55 = 1 + 2 + ... + 10`.

## Python Code

```python
import pandas as pd
import numpy as np

def coppock_curve(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate the classic Coppock Curve for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    Notes:
        - The function handles each symbol independently.
        - Dates are sorted within each symbol.
        - Output includes the intermediate ROC values and the final Coppock Curve.
        - The classic implementation uses:
            ROC(10), ROC(14), and a 10-period weighted moving average
            of their sum.
    """
    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    def _calc(group: pd.DataFrame) -> pd.DataFrame:
        g = group.sort_values("date").copy()

        # Rate of change calculations
        g["roc_10"] = g["close"].pct_change(10) * 100.0
        g["roc_14"] = g["close"].pct_change(14) * 100.0

        # Raw Coppock input
        g["coppock_raw"] = g["roc_10"] + g["roc_14"]

        # 10-period weighted moving average of the raw input
        weights = np.arange(1, 11, dtype=float)
        weight_sum = weights.sum()

        def _wma(values: np.ndarray) -> float:
            return float(np.dot(values, weights) / weight_sum)

        g["coppock_curve"] = (
            g["coppock_raw"]
            .rolling(window=10, min_periods=10)
            .apply(_wma, raw=True)
        )

        return g

    result = out.groupby("symbol", group_keys=False).apply(_calc)
    return result
```
```json
{ "model_code": "p3hg7mw5cdz8", "topic": "Coppock Curve", "timer_secs": 11.76, "tokens_in": 559, "tokens_out": 1400, "cost_tokens_in": 0.00041925, "cost_tokens_out": 0.00630000, "cost_tokens_tot": 0.00671925 }
```