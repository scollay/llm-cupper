# Coppock Curve

## Overview
The Coppock Curve is a momentum oscillator designed to identify buying opportunities in the stock market by measuring the rate of change in price over a long-term period. It appears as a single line on a price chart, oscillating above and below a zero line. The indicator was developed by economist Edwin Coppock in 1962 and is sometimes called the Coppock Indicator.

## Details
The Coppock Curve is a long-term momentum indicator that helps traders identify potential buying points in a market that has been in a sustained downtrend. Unlike short-term oscillators, it uses monthly price data to smooth out volatility and reduce false signals.

The indicator works by calculating the weighted sum of two rate-of-change (ROC) calculations over different periods. Typically, Coppock used a 14-month ROC and a 11-month ROC, then applied a weighted moving average (WMA) to the sum of these two values. The result is plotted as a line that oscillates around a zero line. When the Coppock Curve crosses above the zero line from below, it is interpreted as a bullish signal, suggesting that the market may be transitioning from a downtrend to an uptrend. Conversely, a cross below the zero line is seen as a bearish signal.

Traders often use the Coppock Curve in conjunction with other indicators or trend-following tools to confirm signals. Because it is based on monthly data, the Coppock Curve is not suitable for short-term trading but is valuable for identifying major trend reversals. One limitation is that it can produce lagging signals, as it relies on long-term data. Additionally, in strongly trending markets, the Coppock Curve may remain above or below the zero line for extended periods, reducing its effectiveness as a timing tool.

## Text Formula
The Coppock Curve is calculated as follows:

1. Calculate the Rate of Change (ROC) for two periods:
   - ROC1 = (Close price at time `t` / Close price `14` periods ago - 1) * 100
   - ROC2 = (Close price at time `t` / Close price `11` periods ago - 1) * 100

2. Sum the two ROC values:
   - Sum = ROC1 + ROC2

3. Apply a weighted moving average (WMA) to the Sum over a specified period (typically 10 periods):
   - Coppock Curve = WMA(Sum, 10)

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Assumes date is sorted in ascending order for each symbol.

    Returns:
    --------
    pd.DataFrame
        DataFrame with an additional column `coppock_curve` containing the Coppock Curve values.
    """
    # Ensure the DataFrame is sorted by date for each symbol
    df = df.sort_values(by=['symbol', 'date'])

    # Initialize the Coppock Curve column
    df['coppock_curve'] = 0.0

    # Group by symbol to process each independently
    for symbol, group in df.groupby('symbol'):
        closes = group['close'].values
        n = len(closes)

        # Skip if not enough data points
        if n < 25:  # Minimum required for 14 + 11 + 10 periods
            continue

        # Calculate ROC1 (14-period) and ROC2 (11-period)
        roc1 = (closes / closes[14:] - 1) * 100
        roc2 = (closes / closes[11:] - 1) * 100

        # Sum the two ROC values
        roc_sum = roc1 + roc2

        # Apply 10-period WMA to the sum
        # WMA weights: [10, 9, 8, ..., 1] for the last 10 values
        weights = list(range(10, 0, -1))
        wma_values = []
        for i in range(10, len(roc_sum) + 1):
            window = roc_sum[i-10:i]
            wma = (window * weights).sum() / weights.sum()
            wma_values.append(wma)

        # Align WMA values with the original DataFrame index
        # The first 9 values will be NaN due to insufficient data
        wma_series = pd.Series(wma_values, index=group.index[9:])

        # Assign the WMA values to the Coppock Curve column
        df.loc[group.index[9:], 'coppock_curve'] = wma_series

    return df
```
```json
{ "model_code": "k9nw5bp6vzx2", "topic": "Coppock Curve", "timer_secs": 7.83, "tokens_in": 581, "tokens_out": 1056, "cost_tokens_in": 0.00008715, "cost_tokens_out": 0.00063360, "cost_tokens_tot": 0.00072075 }
```