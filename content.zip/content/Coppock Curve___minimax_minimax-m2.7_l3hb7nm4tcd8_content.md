# Coppock Curve

## Overview
The Coppock Curve is a long‑term momentum indicator that helps traders identify major trend reversals in equity markets. It appears as a single line plotted beneath a price chart, oscillating above and below a zero line. The indicator was introduced in 1962 by economist Edwin “Ed” Coppock and was originally designed to signal buying opportunities in the S&P 500 on a monthly time frame. The curve is constructed from two rate‑of‑change (ROC) components smoothed by a weighted moving average, giving it a slow, “smoothed” response to price movements.

## Details
### How it is calculated
The calculation proceeds in three steps:

1. **Rate‑of‑change** – Compute the percentage change of the closing price over two look‑back periods. The classic periods are 11 bars and 14 bars (often months, but the same logic applies to weekly or daily data).  
   `ROC(period) = (Close – Close_{t‑period}) / Close_{t‑period} × 100`

2. **Sum** – Add the two ROC values for each observation:  
   `Sum = ROC(11) + ROC(14)`

3. **Weighted moving average (WMA)** – Smooth the sum with a 10‑period linear‑weighted moving average. Linear weighting gives recent observations more influence.  
   `Coppock Curve = Σ(i·Sum_{t‑i}) / Σ(i)  for i = 1 … 10`

The result is a line that moves slowly, making it suitable for long‑term analysis.

### Typical interpretation
Traders watch for three basic signals:

* **Zero‑line crossover** – When the curve crosses from negative to positive, it is considered a bullish cue; the opposite crossover is bearish.  
* **Divergence** – If price makes a new high while the curve lags behind, the upward move lacks momentum and a reversal may be near.  
* **Extended extremes** – Values that remain far above or below zero for long periods can warn that the market is overbought or oversold, though the indicator is not bounded.

The indicator is inherently lagging because it uses long ROC periods and a smoothing window. It is best used as a confirmation tool rather than a timing tool.

### Where interpretation tends to break down
* **Choppy markets** – In sideways or range‑bound environments the curve can oscillate around zero without generating clear signals.  
* **Late signals** – The long look‑back periods mean the curve reacts slowly, so traders may miss the early part of a move.  
* **False crossovers** – In strong trending markets the curve can cross the zero line repeatedly, producing whipsaws.  
* **Inappropriate time frame** – Applying the curve on a short time frame (e.g., intraday) amplifies noise and reduces the original long‑term intent.

Because the curve is unbounded, it does not have fixed overbought/oversold levels; traders must rely on context and complementary indicators.

## Text Formula
Let:

* `C_t` = closing price at time `t`
* `p₁` = 11 (first ROC period)
* `p₂` = 14 (second ROC period)
* `w_i = i` for `i = 1 … 10` (linear weights)

Then:

```
ROC(p₁) = (C_t – C_{t‑p₁}) / C_{t‑p₁} × 100
ROC(p₂) = (C_t – C_{t‑p₂}) / C_{t‑p₂} × 100
Sum_t   = ROC(p₁) + ROC(p₂)
Coppock_t = ( Σ_{i=0}^{9} w_{i+1} · Sum_{t‑i} ) / Σ_{i=0}^{9} w_{i+1}
```

The denominator `Σ w_i = 55` (the sum of integers 1‑10). The formula produces the smoothed momentum line.

## Python Code
```python
import numpy as np
import pandas as pd

def calc_coppock(df):
    """
    Calculate the Coppock Curve and its components for a single symbol.

    Parameters
    ----------
    df : pandas.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
        The DataFrame may contain multiple symbols; the function will be applied
        per symbol via groupby.

    Returns
    -------
    pandas.DataFrame
        DataFrame with the original columns plus:
        - 'roc_11'      : 11‑period rate of change (percent)
        - 'roc_14'      : 14‑period rate of change (percent)
        - 'coppock_sum' : ROC(11) + ROC(14)
        - 'coppock'     : 10‑period linear weighted moving average of coppock_sum
    """
    # Linear weights for the 10‑period WMA (1 … 10)
    weights = np.arange(1, 11, dtype=float)
    weight_sum = weights.sum()  # = 55.0

    # Compute rate‑of‑change for the two periods
    df['roc_11'] = df['close'].pct_change(periods=11) * 100
    df['roc_14'] = df['close'].pct_change(periods=14) * 100

    # Sum of the two ROC series
    df['coppock_sum'] = df['roc_11'] + df['roc_14']

    # Weighted moving average smoothing
    df['coppock'] = (
        df['coppock_sum']
        .rolling(window=10)
        .apply(lambda x: np.dot(x, weights) / weight_sum, raw=True)
    )

    return df

def coppock_curve(df: pd.DataFrame) -> pd.DataFrame:
    """
    Wrapper that applies calc_coppock to each symbol independently.
    Expects a DataFrame with a 'symbol' column.
    """
    return df.groupby('symbol', group_keys=False).apply(calc_coppock)
```
```json
{ "model_code": "l3hb7nm4tcd8", "topic": "Coppock Curve", "timer_secs": 33.07, "tokens_in": 561, "tokens_out": 1310, "cost_tokens_in": 0.00016830, "cost_tokens_out": 0.00157200, "cost_tokens_tot": 0.00174030 }
```