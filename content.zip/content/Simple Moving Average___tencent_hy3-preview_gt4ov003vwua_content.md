# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a lagging, trend-following technical indicator that plots as a smooth line overlayed on a security’s price chart. It calculates the arithmetic mean of a security’s closing prices over a user-defined lookback period, smoothing short-term price noise to highlight underlying trend direction. While moving average concepts date to early 20th century market analysis, the standardized SMA gained widespread adoption as computerized charting platforms democratized technical indicator access in the 1970s and 1980s.

## Details
### Calculation Basics
The SMA is the simplest type of moving average, differing from weighted (WMA) or exponential (EMA) variants that assign higher weight to recent prices. Standard calculation uses the `close` column, as the close is the most widely accepted "settlement" price for a period, but traders may substitute `open`, `high`, `low`, or typical price ( (high + low + close)/3 ) for specialized use cases. The lookback period is set by the trader: common equity periods are 20-day (short-term), 50-day (medium-term), 200-day (long-term). Crypto and forex traders often use shorter periods (e.g., 10, 20, 50) due to higher volatility and 24/7 trading.

### Common Interpretation
Traders use SMAs to inform three core decisions: trend identification, entry/exit timing, and risk management. Key interpretation rules include:

1. **Trend Identification**: The slope of the SMA indicates trend direction. An upward-sloping SMA signals a bullish uptrend; a downward-sloping SMA signals a bearish downtrend; a flat SMA indicates a rangebound, sideways market. Traders often use a 200-day SMA to define long-term primary trends: price above 200-day SMA = secular bull market, below = secular bear.
2. **Support and Resistance**: SMAs act as dynamic, trend-aligned support and resistance levels. In a confirmed uptrend, price will often pull back to the SMA and bounce, as buyers step in at the "fair value" average. In a downtrend, rallies will often fail at the SMA, as sellers offload positions at the average price. The 50-day and 200-day SMAs are the most widely watched levels for institutional and retail traders, making them self-fulfilling to an extent.
3. **Crossover Signals**: Two types of crossovers are used:
   - *Price-SMA Crossover*: When price crosses above the SMA, it is a bullish signal (trend may be turning up); crossing below is bearish.
   - *SMA-SMA Crossover*: When a shorter-term SMA crosses above a longer-term SMA, it is a bullish "golden cross" (e.g., 50-day crossing above 200-day). When the shorter SMA crosses below the longer SMA, it is a bearish "death cross". These are widely followed by media and institutional investors.
4. **Trend Confirmation**: Traders often wait for price to close above/below the SMA for multiple consecutive periods to confirm a signal, reducing false positives from intraday price spikes.

### Limitations and Failure Points
SMA interpretation is not universally reliable, and signals often break down in specific market conditions:

- **Inherent Lag**: Because the SMA is calculated entirely from past prices, it always lags current market action. A 200-day SMA, for example, only reflects the average of the past 200 days of closes: by the time it turns downward to confirm a bear market, the market may have already fallen 20% from its peak. This lag leads to late entries and exits, reducing profit potential and increasing loss size.
- **Whipsaw Risk in Sideways Markets**: When a security trades in a tight range with no clear trend, the SMA flattens, and price will cross above and below the SMA repeatedly. These false signals (whipsaws) generate frequent small losses that can erode trading capital quickly. Short-term SMAs (e.g., 10-day) are especially prone to whipsaws in rangebound markets.
- **Arbitrary Period Selection**: There is no objectively "correct" SMA lookback period. A 20-day SMA may align with a trader’s short-term strategy, but a 15-day or 25-day SMA may produce better results for the same security in the same period. Many traders overfit SMA periods to historical data, selecting a period that worked in the past but fails in live markets.
- **No Predictive Value**: The SMA is a descriptive, not predictive, tool. It summarizes past price action but cannot forecast future moves. Relying solely on SMA signals ignores critical context like trading volume, volatility, macroeconomic catalysts, and fundamental security value. For example, a stock may cross above its 50-day SMA while trading at an extreme valuation, making the bullish signal unreliable.
- **Cross-Symbol Distortion**: SMAs are not comparable across securities with different volatility profiles. A 10-day SMA crossover may be meaningful for a low-volatility large-cap stock, but irrelevant for a high-volatility small-cap crypto asset. Traders must adjust period lengths to match the volatility and trading hours of the security being analyzed.

## Text Formula
The Simple Moving Average for a user-defined lookback period n is calculated as the arithmetic mean of closing prices over the n most recent periods. For a given period t, the formula is:

SMAₙ(t) = (Pₜ₋ₙ₊₁ + Pₜ₋ₙ₊₂ + ... + Pₜ₋₁ + Pₜ) / n

Where:
- SMAₙ(t) = Simple Moving Average over n periods at current period t
- Pᵢ = Closing price of the security at period i
- n = Lookback period length (integer ≥ 1, ≤ total number of available price observations)
- t = Current period index (chronologically ordered)

For incremental calculation (to avoid re-summing all n prices for each new period), the rolling update formula is used:

SMAₙ(t) = SMAₙ(t-1) + (Pₜ - Pₜ₋ₙ) / n

Where:
- SMAₙ(t-1) = SMA value for the prior period t-1
- Pₜ = Closing price at current period t
- Pₜ₋ₙ = Closing price at period t-n (the oldest price being removed from the lookback window)

This formula is valid only when t ≥ n, as insufficient data exists to calculate the SMA before n periods have elapsed.

## Python Code
```python
import pandas as pd

def calculate_sma(df, sma_periods=None):
    """
    Calculate Simple Moving Average (SMA) for one or more symbols in a DataFrame.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with columns: symbol, date, open, high, low, close.
                       May contain data for multiple symbols; order of rows is not guaranteed.
    sma_periods (list): List of integer lookback periods to calculate SMAs for.
                        Defaults to [10, 20, 50, 100, 200] as referenced in the article.
    
    Returns:
    pd.DataFrame: Original DataFrame with additional columns for each SMA period:
                  `sma_{period}` (e.g., sma_10, sma_20) containing calculated SMA values.
                  Rows with insufficient data for a given period will have NaN values.
    """
    # Document expected input format (no simulated data)
    # Required columns: symbol, date, open, high, low, close
    # symbol: string identifier for the security (e.g., 'AAPL', 'BTC-USD')
    # date: datetime or sortable date string (e.g., '2024-01-01')
    # open/high/low/close: float price values for the period
    
    # Set default SMA periods if not provided
    if sma_periods is None:
        sma_periods = [10, 20, 50, 100, 200]
    
    # Validate required columns exist
    required_cols = ['symbol', 'date', 'close']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Input DataFrame missing required columns: {missing_cols}")
    
    # Process each symbol independently to avoid cross-symbol calculation errors
    def process_symbol_group(group):
        # Sort group by date ascending (critical for correct rolling window calculation)
        group = group.sort_values('date').copy()
        # Calculate SMA for each requested period
        for period in sma_periods:
            # Use rolling window of size `period`, calculate mean of `close` column
            # min_periods=period ensures SMA is only calculated once full window is available
            group[f'sma_{period}'] = group['close'].rolling(window=period, min_periods=period).mean()
        return group
    
    # Group by symbol, apply processing, reset index to match original format
    result_df = df.groupby('symbol', group_keys=False).apply(process_symbol_group)
    
    return result_df
```
```json
{ "model_code": "gt4ov003vwua", "topic": "Simple Moving Average", "timer_secs": 115.47, "tokens_in": 564, "tokens_out": 9252, "cost_tokens_in": 0.00003553, "cost_tokens_out": 0.00194292, "cost_tokens_tot": 0.00197845 }
```