# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a foundational technical indicator that smooths out price data by calculating a constantly updated average price over a specific number of periods. On a price chart, it appears as a single, continuous line overlaid directly on the price action. Because it relies on basic arithmetic, the SMA is one of the oldest technical tools in finance. It was utilized by early 20th-century market pioneers like Charles Dow and Richard Schabacker to filter out daily volatility and identify broader market trends long before the advent of computerized charting.

## Details
The Simple Moving Average is calculated by taking the arithmetic mean of a given set of prices over a specific number of past periods. As each new period closes, the oldest data point is dropped from the calculation and the newest is added, causing the average to "move" along the time axis. 

### Trend Identification
The most fundamental application of the SMA is determining the broader market trend. Traders look at two primary factors: the slope of the SMA line and the position of the price relative to the SMA.

*   **Uptrend:** If the SMA is sloping upward and the current price is trading above the line, the asset is generally considered to be in an uptrend.
*   **Downtrend:** Conversely, a downward sloping SMA with the price trading below it indicates a downtrend.

The choice of the lookback period drastically alters the indicator's responsiveness. Short-term traders and swing traders often rely on a 10-period or 20-period SMA to capture immediate momentum shifts. These shorter moving averages hug the price action closely and react quickly to new information. Conversely, macro traders and long-term investors look to the 100-period or 200-period SMA to gauge the overarching secular trend. The 200-day SMA, in particular, is widely considered the ultimate barometer of an asset's long-term health; an asset trading consistently above its 200-day SMA is generally viewed as being in a bull market, while one trading below is in a bear market.

### Moving Average Crossovers
Active traders frequently use multiple SMAs of varying lengths simultaneously to generate crossover signals. This technique helps filter out the daily noise of price action and provides objective rules for trend-following strategies.

*   **Golden Cross:** This occurs when a shorter-term SMA crosses above a longer-term SMA. The most famous example is the 50-period SMA crossing above the 200-period SMA, which is widely interpreted as a strong, long-term bullish signal indicating that recent momentum is accelerating past historical averages.
*   **Death Cross:** The inverse of the Golden Cross, this happens when the shorter-term SMA crosses below the longer-term SMA, signaling a potential long-term bearish shift.

### Dynamic Support and Resistance
In trending markets, SMAs often act as dynamic zones of support or resistance. For instance, during a prolonged uptrend, an asset's price may repeatedly pull back to its 50-period or 200-period SMA, find buying interest, and bounce higher. Because these specific intervals are watched by millions of market participants and programmed into algorithmic trading models, their efficacy as support or resistance is often a self-fulfilling prophecy.

### Limitations and Breakdowns
Despite its ubiquity, the SMA has distinct mechanical limitations that traders must manage.

**The Lag Factor**
Because the SMA is an average of historical data, it is inherently a lagging indicator. It confirms trends after they have established themselves rather than predicting them. By the time a 50-period and 200-period SMA trigger a Golden Cross, a significant portion of the upward price move has already occurred. In fast-moving markets, relying strictly on SMA signals can result in late entries and delayed exits.

**Whipsaws in Ranging Markets**
The SMA breaks down severely in choppy, sideways, or trendless markets. When price oscillates within a horizontal range, it will repeatedly cross back and forth over the SMA. Traders relying on price crossovers for entry and exit signals will experience "whipsaws"—a series of false signals resulting in small, rapid losses.

**The Drop-Off Effect and Equal Weighting**
The SMA assigns equal mathematical weight to every period in its lookback window. In a 50-period SMA, the closing price from 50 days ago impacts the current average just as much as today's closing price. This creates the "drop-off effect." 

To understand this vulnerability, imagine a stock that has traded exactly at $100 for 49 days, but 50 days ago, it spiked to $150 due to an anomaly. A 50-day SMA will remain elevated due to that single $150 print. On day 51, when that $150 print falls out of the 50-day rolling window and is replaced by another $100 print, the SMA will suddenly drop. A trader looking only at the indicator might interpret this sudden downward slope as bearish momentum, even though the actual price of the asset hasn't moved from $100 in nearly two months. Many traders prefer the Exponential Moving Average (EMA) specifically to counteract this, as the EMA heavily weights recent data and minimizes the drop-off effect.

## Text Formula
The Simple Moving Average is calculated using a straightforward arithmetic mean of the asset's price over a specified number of periods.

SMA = (P1 + P2 + P3 + ... + Pn) / n

Where:
*   **P** = The price of the asset (most commonly the closing price) for a specific period.
*   **n** = The total number of periods in the lookback window.

For example, a 5-period SMA of closing prices would be calculated as:
SMA = (Close1 + Close2 + Close3 + Close4 + Close5) / 5

## Python Code
```python
import pandas as pd

def add_simple_moving_averages(df, windows=[50, 200]):
    """
    Calculates Simple Moving Averages (SMA) for given lookback windows.
    
    Parameters:
    df (pd.DataFrame): Input dataframe containing 'symbol', 'date', 'open', 
                       'high', 'low', 'close' columns.
    windows (list): A list of integers representing the SMA periods to calculate.
                    Defaults to 50 and 200 to capture the Golden/Death Cross 
                    metrics discussed in the article.
                    
    Returns:
    pd.DataFrame: The original dataframe with new SMA columns added.
    """
    # Create a copy to avoid SettingWithCopyWarning on the original dataframe
    data = df.copy()
    
    # Ensure the data is sorted chronologically per symbol for accurate rolling calculations
    data = data.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate the SMA for each specified window
    for window in windows:
        column_name = f'sma_{window}'
        
        # Group by 'symbol' to prevent rolling calculations from bleeding across different assets.
        # The transform function applies the rolling mean to each group independently.
        data[column_name] = data.groupby('symbol')['close'].transform(
            lambda x: x.rolling(window=window).mean()
        )
        
    return data
```
```json
{ "model_code": "t5pz4nm8vqj7", "topic": "Simple Moving Average", "timer_secs": 43.64, "tokens_in": 565, "tokens_out": 4948, "cost_tokens_in": 0.00113000, "cost_tokens_out": 0.05937600, "cost_tokens_tot": 0.06050600 }
```