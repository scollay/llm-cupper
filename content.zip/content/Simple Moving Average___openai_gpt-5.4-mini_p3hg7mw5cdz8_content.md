# Simple Moving Average

## Overview
The **Simple Moving Average (SMA)** is one of the most basic and widely used trend indicators in technical analysis. It plots a smoothed line on a price chart by averaging closing prices over a fixed lookback period, such as 20, 50, or 200 bars. The line is typically overlaid directly on price rather than shown in a separate pane.

The SMA is not credited to a single inventor in the way some newer indicators are. It emerged from classical price-averaging methods long before modern technical analysis was formalized. In practice, traders use it as a baseline for trend direction, dynamic support and resistance, and crossover signals.

## Details
A simple moving average is exactly what the name implies: the arithmetic mean of the last *N* closing prices, recalculated each bar as new data comes in and the oldest observation drops out. Because each price in the lookback window gets equal weight, the SMA is easy to understand and stable, but it reacts more slowly than weighted or exponential averages.

### How traders use it
Common interpretations include:

- **Trend filter**:  
  - Price above a rising SMA often suggests an uptrend.
  - Price below a falling SMA often suggests a downtrend.
- **Dynamic support/resistance**:  
  Traders often watch the SMA as a level where price may pause, bounce, or reject.
- **Crossovers**:  
  - A shorter SMA crossing above a longer SMA is often called a bullish crossover.
  - A shorter SMA crossing below a longer SMA is often called a bearish crossover.
- **Mean reversion context**:  
  In sideways markets, price frequently oscillates around the SMA, making it a reference for stretch and reversion.

### Period choice matters
The lookback length changes the character of the signal:

- **Short SMAs** such as 5, 10, or 20 periods respond quickly and are useful for short-term momentum.
- **Medium SMAs** such as 50 periods are often used to gauge intermediate trend.
- **Long SMAs** such as 100 or 200 periods are used to frame major trend structure.

There is no universally “correct” period. The choice depends on the trader’s horizon, instrument volatility, and execution style.

### Where the interpretation breaks down
The SMA is useful, but it has clear limitations:

- **Lag**:  
  Because it averages past data, the SMA always trails price. It confirms trends rather than predicts them.
- **Whipsaws in ranges**:  
  In choppy, non-trending markets, price may cross the SMA repeatedly, producing poor signals.
- **Equal weighting can dull responsiveness**:  
  A 20-day SMA treats a price from 20 days ago the same as yesterday’s price, which can make it slower to adapt than an EMA.
- **Single-line bias**:  
  Reading too much into one moving average can lead to overfitting. Many traders combine it with volume, momentum, or volatility filters.

### Practical notes
A few implementation details matter:

- The first valid SMA value appears only after enough bars exist to fill the lookback window.
- On charts, the SMA is most often calculated from `close` prices, though some traders apply it to `open`, `high`, `low`, or typical price.
- For multiple symbols, each symbol’s SMA must be computed independently to avoid contamination from another ticker’s data.

The SMA is best thought of as a simple reference line, not a trading system by itself. It is strongest when used to define context: trend, location, and relative price behavior.

## Text Formula
For a lookback period of `N`, the Simple Moving Average at time `t` is:

`SMA_t = (P_t + P_(t-1) + P_(t-2) + ... + P_(t-N+1)) / N`

Where:

- `P_t` = the selected price at time `t` (usually close)
- `N` = the number of periods in the moving average

Equivalent rolling-window form:

`SMA_t = (1 / N) * sum_{i=0 to N-1} P_(t-i)`

For the first `N-1` observations, the SMA is undefined because there are not enough data points to compute a full window.

## Python Code
```python
import pandas as pd

def calculate_sma(df: pd.DataFrame, period: int = 20, price_col: str = "close") -> pd.DataFrame:
    """
    Calculate the Simple Moving Average (SMA) for one or more symbols.

    Required input columns:
        - symbol
        - date
        - open
        - high
        - low
        - close

    Parameters
    ----------
    df : pd.DataFrame
        Input market data for one or more symbols.
    period : int, default 20
        Lookback window length for the SMA.
    price_col : str, default "close"
        Column to use as the price input for the SMA.

    Returns
    -------
    pd.DataFrame
        A copy of the input DataFrame sorted by symbol and date, with:
        - sma: the simple moving average
        - sma_valid: True where SMA is available, False otherwise
    """
    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    if period <= 0:
        raise ValueError("period must be a positive integer")

    if price_col not in df.columns:
        raise ValueError(f"price_col '{price_col}' not found in DataFrame")

    out = df.copy()

    # Ensure dates are sortable as datetimes when possible
    out["date"] = pd.to_datetime(out["date"], errors="coerce")

    # Sort within each symbol so rolling calculations are correct
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Compute SMA independently for each symbol
    out["sma"] = (
        out.groupby("symbol", group_keys=False)[price_col]
           .transform(lambda s: s.rolling(window=period, min_periods=period).mean())
    )

    # Flag rows where the SMA is available
    out["sma_valid"] = out["sma"].notna()

    return out
```
```json
{ "model_code": "p3hg7mw5cdz8", "topic": "Simple Moving Average", "timer_secs": 9.43, "tokens_in": 559, "tokens_out": 1350, "cost_tokens_in": 0.00041925, "cost_tokens_out": 0.00607500, "cost_tokens_tot": 0.00649425 }
```