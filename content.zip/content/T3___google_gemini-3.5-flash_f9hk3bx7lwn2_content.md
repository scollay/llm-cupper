# T3 Moving Average

## Overview

The T3 Moving Average is a highly sophisticated, smooth, and low-lag trend-following indicator developed by technical analyst Tim Tillson in 1998. First introduced in the journal *Technical Analysis of Stocks & Commodities*, the T3 was designed to address a fundamental flaw inherent in traditional moving averages: the trade-off between lag and smoothness. 

On a price chart, the T3 appears as a single, continuous line overlaying price action, much like a Simple Moving Average (SMA) or an Exponential Moving Average (EMA). However, because of its unique mathematical design, the T3 tracks price trends far more closely than an EMA of the same period, while simultaneously filtering out market noise and reducing the "overshoot" common in other low-lag moving averages.

## Details

To understand how the T3 Moving Average works, one must first understand the evolution of lag-reduction techniques in technical analysis. Traditional moving averages, such as the SMA, lag behind price action because they assign equal weight to past data. The EMA improves on this by weighting recent data more heavily, but still suffers from noticeable lag during sharp trend reversals.

To combat this lag, Patrick Mulloy developed the Double Exponential Moving Average (DEMA) and the Triple Exponential Moving Average (TEMA). While DEMA and TEMA successfully reduce lag, they often suffer from "overshoot"—a phenomenon where the moving average line projects past the actual price peak or trough during volatile swings, leading to false breakout signals.

Tim Tillson solved this problem by introducing a damping factor, which he called the "volume factor" (`vfactor`, denoted as $a$). He created a generalized version of DEMA (GD) that allows traders to control the blend between a standard EMA and a DEMA. The formula for Generalized DEMA is:

$$GD(x, t, a) = EMA(x, t) \times (1 + a) - EMA(EMA(x, t), t) \times a$$

Where $x$ is the price series, $t$ is the period, and $a$ is the volume factor between 0 and 1. 
* If $a = 0$, the formula simplifies to a standard EMA.
* If $a = 1$, the formula becomes a standard DEMA.

The T3 Moving Average is a "triple" application of this Generalized DEMA process. Instead of calculating GD once, Tillson nested the calculation three times:

$$T3 = GD(GD(GD(Close, t, a), t, a), t, a)$$

By expanding this recursive relationship mathematically, Tillson derived a computationally efficient formula that uses six nested EMAs. This allows traders to calculate the T3 without having to run three separate nested functions.

### How Traders Interpret T3

Traders utilize the T3 Moving Average in several primary ways:

1. **Trend Direction and Slope**: The most basic application is observing the slope of the T3 line. A rising T3 indicates an uptrend, while a falling T3 indicates a downtrend. Because of its superior smoothing, the T3 changes direction far less frequently than standard EMAs, reducing false trend-change signals.
2. **Support and Resistance**: During strong trends, the T3 line acts as a dynamic support level in an uptrend and a dynamic resistance level in a downtrend. Traders often look for bullish or bearish price action patterns to form as the price tests the T3 line.
3. **Price Crossovers**: A classic trading signal is generated when the price crosses the T3. A close above the T3 is considered a buy signal, while a close below is a sell signal.
4. **Moving Average Crossovers**: Traders often pair a fast-period T3 (e.g., 8 periods) with a slow-period T3 (e.g., 21 periods). A bullish crossover occurs when the fast T3 crosses above the slow T3, while a bearish crossover occurs when the fast T3 crosses below.

### Where T3 Breaks Down

Despite its mathematical elegance, the T3 is not a holy grail and has specific failure modes:

* **Sideways and Range-Bound Markets**: Like all trend-following indicators, the T3 performs poorly when the market lacks a clear direction. In a consolidation phase, the price will repeatedly whip back and forth across the T3 line, generating numerous false crossover signals.
* **Parameter Sensitivity**: The performance of the T3 is highly sensitive to the volume factor ($a$). If the volume factor is set too high (close to 1.0), the indicator becomes highly responsive but starts to overshoot and mimic the noise of a DEMA. If it is set too low (close to 0.0), the indicator introduces significant lag, defeating the purpose of using T3 over a standard EMA. The industry standard default is 0.7, but this must be optimized for different assets and timeframes.
* **Delayed Reaction to Black Swan Events**: Because the T3 relies on six nested EMAs, an abrupt, extreme price shock (such as an unexpected earnings miss or geopolitical event) can take several bars to fully register in the T3, potentially delaying a trader's exit compared to a faster, noisier indicator.

## Text Formula

To calculate the T3 Moving Average for a given period $n$ and volume factor $a$ (typically $0.7$):

1. Calculate the smoothing constant $\alpha$:
   $$\alpha = \frac{2}{n + 1}$$

2. Calculate six nested Exponential Moving Averages ($e1$ through $e6$) recursively:
   $$e1_t = \alpha \times Close_t + (1 - \alpha) \times e1_{t-1}$$
   $$e2_t = \alpha \times e1_t + (1 - \alpha) \times e2_{t-1}$$
   $$e3_t = \alpha \times e2_t + (1 - \alpha) \times e3_{t-1}$$
   $$e4_t = \alpha \times e3_t + (1 - \alpha) \times e4_{t-1}$$
   $$e5_t = \alpha \times e4_t + (1 - \alpha) \times e5_{t-1}$$
   $$e6_t = \alpha \times e5_t + (1 - \alpha) \times e6_{t-1}$$

3. Calculate the polynomial coefficients ($c1$, $c2$, $c3$, $c4$) using the volume factor $a$:
   $$c1 = -a^3$$
   $$c2 = 3a^2 + 3a^3$$
   $$c3 = -6a^2 - 3a - 3a^3$$
   $$c4 = 1 + 3a + 3a^2 + a^3$$

4. Calculate the final T3 value:
   $$T3_t = c1 \times e6_t + c2 \times e5_t + c3 \times e4_t + c4 \times e3_t$$

## Python Code

```python
import pandas as pd


def calculate_t3(df: pd.DataFrame, period: int = 5, vfactor: float = 0.7) -> pd.DataFrame:
    """
    Calculates the T3 Moving Average for a multi-symbol pandas DataFrame.
    
    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame containing columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
    period : int, default 5
        The lookback period for the underlying EMAs.
    vfactor : float, default 0.7
        The volume factor (damping factor) 'a', typically between 0.0 and 1.0.
        
    Returns:
    --------
    pd.DataFrame
        The input DataFrame sorted by symbol and date with an additional 't3' column.
    """
    # Ensure the DataFrame is sorted correctly to maintain time-series integrity
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Calculate polynomial coefficients based on the volume factor (a)
    a = vfactor
    c1 = -a**3
    c2 = 3 * (a**2) + 3 * (a**3)
    c3 = -6 * (a**2) - 3 * a - 3 * (a**3)
    c4 = 1 + 3 * a + 3 * (a**2) + (a**3)
    
    def compute_group_t3(group: pd.DataFrame) -> pd.Series:
        # Calculate the 6 nested EMAs using pandas ewm (Exponential Weighted Moving)
        # adjust=False matches the standard recursive EMA formula
        e1 = group['close'].ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()
        
        # Combine the nested EMAs using the calculated coefficients
        t3_series = c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3
        return t3_series

    # Apply the calculation independently to each symbol group
    df['t3'] = df.groupby('symbol', group_keys=False).apply(compute_group_t3)
    
    return df
```
```json
{ "model_code": "f9hk3bx7lwn2", "topic": "T3", "timer_secs": 26.43, "tokens_in": 564, "tokens_out": 5486, "cost_tokens_in": 0.00084600, "cost_tokens_out": 0.04937400, "cost_tokens_tot": 0.05022000 }
```