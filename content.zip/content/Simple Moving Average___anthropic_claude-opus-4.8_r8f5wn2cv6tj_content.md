# Simple Moving Average

## Overview
The **Simple Moving Average (SMA)** is one of the oldest and most widely used technical indicators. It smooths price data by averaging a security's closing prices over a fixed number of periods, producing a single line that lags behind price action and filters out short-term noise. On a chart, the SMA appears as a continuous curve overlaid directly on the price plot, rising and falling more slowly than the underlying candles or bars.

The concept of the moving average predates modern markets and has roots in statistical smoothing techniques from the early 20th century. It became a staple of technical analysis as charting grew popular among traders in the mid-1900s, and it remains a foundational building block for countless other indicators, including Bollinger Bands and the MACD.

## Details

### How it works
An SMA of length `n` is calculated by summing the most recent `n` closing prices and dividing by `n`. As each new period closes, the oldest price drops out of the calculation and the newest price enters — hence the average "moves" forward through time. A 50-day SMA, for example, always reflects the average closing price of the last 50 trading days.

Because every observation in the window receives equal weight, the SMA reacts slowly to recent price changes. This is its defining trade-off: it produces a smooth, stable line at the cost of **lag**.

### How traders interpret it
- **Trend direction:** A rising SMA suggests an uptrend; a falling SMA suggests a downtrend. A flat SMA implies consolidation.
- **Dynamic support and resistance:** Price often pauses or reverses near a widely watched SMA, such as the 50-day or 200-day.
- **Price crossovers:** When price closes above its SMA, some traders read it as bullish; a close below is read as bearish.
- **Moving average crossovers:** Combining two SMAs of different lengths produces classic signals. A shorter SMA crossing above a longer one is a **golden cross** (bullish); the reverse is a **death cross** (bearish).

Shorter lookbacks (e.g., 10 or 20 periods) hug price closely and respond quickly, while longer lookbacks (e.g., 100 or 200 periods) define the broader trend.

### Where interpretation breaks down
The SMA's greatest weakness is **lag**. By weighting all periods equally, it responds late to turning points, so crossover signals frequently arrive after a large portion of a move has already occurred. In **sideways, choppy markets**, the SMA generates repeated false signals as price oscillates back and forth across the line — a phenomenon traders call *whipsaw*.

The SMA is also purely backward-looking and assigns no extra importance to the most recent data, which is why some traders prefer the Exponential Moving Average (EMA) when responsiveness matters. Finally, the "best" lookback length is not universal; a setting that works in one regime or on one instrument may fail in another, and over-optimizing the length to past data invites curve-fitting.

A practical companion metric is the **SMA slope**, the period-over-period change in the average, which quantifies whether the trend is strengthening or flattening.

## Text Formula

For a chosen lookback length `n`:

```
SMA(n)_t = (Close_t + Close_(t-1) + ... + Close_(t-n+1)) / n
```

Equivalently:

```
SMA(n)_t = ( sum of the last n closing prices ending at period t ) / n
```

The slope of the SMA (period-over-period change):

```
SMA_Slope_t = SMA(n)_t - SMA(n)_(t-1)
```

Price-to-SMA relationship (used for crossover interpretation):

```
Price_vs_SMA_t = Close_t - SMA(n)_t
    > 0  ->  price above SMA (bullish bias)
    < 0  ->  price below SMA (bearish bias)
```

Dual-SMA crossover, using a fast length `f` and a slow length `s` (with f < s):

```
Crossover_t = SMA(f)_t - SMA(s)_t

Golden Cross : Crossover_(t-1) <= 0 AND Crossover_t > 0
Death Cross  : Crossover_(t-1) >= 0 AND Crossover_t < 0
```

## Python Code

```python
import pandas as pd
import numpy as np


def simple_moving_average(df, fast=50, slow=200):
    """
    Calculate the Simple Moving Average (SMA) and related values.

    Expected input: a pandas DataFrame with the following columns:
        symbol : ticker/identifier (string)
        date   : date or datetime of the bar
        open   : opening price (float)
        high   : high price (float)
        low    : low price (float)
        close  : closing price (float)

    The DataFrame may contain one or more symbols. Each symbol is
    processed independently, in chronological order.

    Parameters
    ----------
    fast : int
        Lookback length for the fast SMA (used for crossover logic).
    slow : int
        Lookback length for the slow SMA (used for crossover logic).

    Returns a copy of the input DataFrame with added columns:
        sma_fast       : SMA over `fast` periods of close
        sma_slow       : SMA over `slow` periods of close
        sma_slope      : period-over-period change in sma_fast
        price_vs_sma   : close minus sma_fast (>0 bullish, <0 bearish)
        crossover      : sma_fast minus sma_slow
        golden_cross   : True where fast crosses above slow
        death_cross    : True where fast crosses below slow
    """
    out = df.copy()

    # Ensure correct ordering within each symbol.
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Group by symbol so calculations never bleed across instruments.
    grp = out.groupby("symbol", group_keys=False)

    # Core SMAs: equal-weighted mean of the trailing window of closes.
    out["sma_fast"] = grp["close"].transform(
        lambda s: s.rolling(window=fast, min_periods=fast).mean()
    )
    out["sma_slow"] = grp["close"].transform(
        lambda s: s.rolling(window=slow, min_periods=slow).mean()
    )

    # Slope of the fast SMA: how much it changed vs. the prior period.
    out["sma_slope"] = grp["sma_fast"].transform(lambda s: s.diff())

    # Price relative to the fast SMA: positive = above, negative = below.
    out["price_vs_sma"] = out["close"] - out["sma_fast"]

    # Difference between fast and slow SMA drives crossover signals.
    out["crossover"] = out["sma_fast"] - out["sma_slow"]

    # Previous crossover value, computed per symbol for cross detection.
    prev_cross = grp["crossover"].transform(lambda s: s.shift(1))

    # Golden cross: fast moves from at/below slow to above slow.
    out["golden_cross"] = (prev_cross <= 0) & (out["crossover"] > 0)

    # Death cross: fast moves from at/above slow to below slow.
    out["death_cross"] = (prev_cross >= 0) & (out["crossover"] < 0)

    # Rows lacking enough history (NaN crossover) cannot be signals.
    out.loc[out["crossover"].isna(), ["golden_cross", "death_cross"]] = False

    return out
```
```json
{ "model_code": "r8f5wn2cv6tj", "topic": "Simple Moving Average", "timer_secs": 30.99, "tokens_in": 846, "tokens_out": 2512, "cost_tokens_in": 0.00423000, "cost_tokens_out": 0.06280000, "cost_tokens_tot": 0.06703000 }
```