# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a foundational technical analysis tool used to smooth out price data by creating a constantly updated average price. It appears on a chart as a single line that follows the price action, lagging behind current market movements to filter out short-term noise and highlight the underlying trend. While the concept of averaging prices has been used by traders for centuries, the SMA became a staple of modern technical analysis in the mid-20th century as a primary component of trend-following strategies.

## Details
The SMA is calculated by taking the arithmetic mean of a given set of prices over a specific number of days in the past. Because it assigns equal weight to every data point in the lookback period, it is considered a "lagging" indicator. The primary utility of the SMA is to identify the direction of a trend: if the SMA is sloping upward, the trend is generally considered bullish; if it is sloping downward, the trend is bearish.

### Interpretation and Strategy
Traders typically use the SMA in three primary ways:
* **Trend Identification:** When the price is consistently above the SMA, the asset is in an uptrend. Conversely, when the price is below the SMA, it is in a downtrend.
* **Support and Resistance:** In strong trends, the SMA often acts as a dynamic level of support (in uptrends) or resistance (in downtrends), where price pullbacks find equilibrium before resuming the primary trend.
* **Crossovers:** Traders often use two SMAs of different lengths—a "fast" SMA (short period) and a "slow" SMA (long period). A "Golden Cross" occurs when the fast SMA crosses above the slow SMA, signaling a potential long-term bullish reversal. A "Death Cross" occurs when the fast SMA crosses below the slow SMA, signaling a potential long-term bearish reversal.

### Limitations
The SMA’s greatest strength—its simplicity—is also its primary weakness. Because it treats the oldest data point in the lookback period with the same importance as the most recent price, it can be slow to react to sudden market shocks or trend reversals. This lag can lead to "whipsaws," where a trader enters a position based on a crossover signal only for the price to immediately reverse, resulting in a loss. Furthermore, the SMA is a trend-following indicator; it performs poorly in sideways or range-bound markets, where it may generate frequent, unreliable signals.

## Text Formula
The Simple Moving Average for a period `n` is calculated as the sum of the closing prices over the last `n` periods, divided by `n`.

`SMA = (Sum of closing prices over n periods) / n`

Where:
* `n` = The number of periods (e.g., 50, 200).
* `Sum of closing prices` = The aggregate of the `close` values for the current period and the preceding `n-1` periods.

## Python Code
```python
import pandas as pd

def calculate_sma(df, period):
    """
    Calculates the Simple Moving Average for a DataFrame.
    
    Parameters:
    df (pd.DataFrame): Must contain 'symbol' and 'close' columns.
    period (int): The lookback window for the SMA.
    
    Returns:
    pd.Series: The calculated SMA values.
    """
    # Ensure the data is sorted by date to maintain chronological order
    df = df.sort_values(['symbol', 'date'])
    
    # Group by symbol to ensure calculations are independent for each asset
    # The rolling().mean() function computes the arithmetic mean over the window
    sma = df.groupby('symbol')['close'].transform(lambda x: x.rolling(window=period).mean())
    
    return sma

# Example usage:
# df = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL', 'MSFT', 'MSFT'],
#     'date': ['2023-01-01', '2023-01-02', '2023-01-01', '2023-01-02'],
#     'open': [150, 151, 250, 251],
#     'high': [152, 153, 252, 253],
#     'low': [149, 150, 249, 250],
#     'close': [151, 152, 251, 252]
# })
# df['SMA_50'] = calculate_sma(df, 50)
```
```json
{ "model_code": "p2qm6vw4rzc8", "topic": "Simple Moving Average", "timer_secs": 4.42, "tokens_in": 567, "tokens_out": 1004, "cost_tokens_in": 0.00014175, "cost_tokens_out": 0.00150600, "cost_tokens_tot": 0.00164775 }
```