# Coppock Curve

## Overview
The Coppock Curve is a long-term price momentum indicator designed primarily to identify major bottoms in broad equity market indices. On a chart, it appears as a single oscillating line that fluctuates above and below a zero line, similar to the MACD but generally much smoother. The indicator was created by economist Edwin Sedgwick Coppock, who first introduced it in *Barron's* magazine in October 1962. Originally developed for monthly charts to signal long-term buying opportunities, it remains a popular tool among macro-focused traders and investors looking to capture cyclical market upturns.

## Details

### The Psychological Foundation
The standard parameters of the Coppock Curve are highly specific and rooted in behavioral finance. According to market lore, Coppock asked an Episcopal priest how long it typically took people to mourn the loss of a loved one. The priest answered that the grieving process usually lasted between 11 and 14 months. Coppock hypothesized that financial losses in the stock market triggered a similar psychological mourning period among investors. Consequently, he built his indicator around 11-period and 14-period lookbacks to measure the point at which market grief subsides and buying appetite returns.

### Mechanics of the Indicator
The Coppock Curve is constructed by combining two different Rates of Change (ROC) and then smoothing the result. 

First, the indicator calculates the 14-period ROC and the 11-period ROC of the closing price. The Rate of Change is simply the percentage difference between the current close and the close a set number of periods ago. These two ROC values are then added together. Summing a shorter and longer momentum measure captures both the immediate shift in trend and the broader cyclical baseline.

Because raw momentum data can be erratic, the sum of the two ROCs is smoothed using a 10-period Weighted Moving Average (WMA). Unlike a Simple Moving Average, a WMA assigns heavier mathematical weight to the most recent data points and progressively less weight to older data. This smoothing technique helps filter out short-term noise while keeping the indicator relatively responsive to new price action.

### Interpretation and Trading Signals
Traders typically use the Coppock Curve to identify long-term buying opportunities. Because it was designed for broad market indices like the S&P 500 or the Dow Jones Industrial Average, its signals are most respected when applied to these macro instruments.

**The Classic Buy Signal:** The most conservative and widely used signal occurs when the Coppock Curve crosses above the zero line from negative territory. This indicates that long-term momentum has shifted from bearish to bullish. 

**The Aggressive Buy Signal:** Some active traders prefer to anticipate the zero-line crossover. In this approach, a buy signal is generated when the Coppock Curve forms a trough below the zero line and begins to turn upward. This allows traders to enter the market earlier, though it carries a higher risk of a false signal if the downward trend resumes.

**Sell Signals:** Notably, Coppock did not design his curve to generate sell signals. Because equity markets have a historical upward bias, momentum can remain positive for years. While some modern traders interpret a cross below the zero line or a downturn from a high peak as a sell or shorting signal, these are generally considered unreliable and are prone to whipsawing the trader out of secular bull markets.

### Where the Interpretation Breaks Down
The most significant limitation of the Coppock Curve is its inherent lag. Because it relies on 11-period and 14-period lookbacks, and then smooths that data with a 10-period WMA, the indicator is deeply historical. By the time the curve crosses the zero line, the actual market bottom may have occurred months prior, and a substantial portion of the initial price recovery may have already been missed. 

Furthermore, the indicator breaks down when applied outside its intended scope. While modern charting platforms allow traders to apply the Coppock Curve to daily or weekly timeframes, doing so often generates excessive noise and false signals. The 11-to-14 period "mourning" concept does not translate cleanly to 11 or 14 days. 

Finally, the Coppock Curve struggles when applied to individual stocks. Individual equities are subject to idiosyncratic risks—such as earnings misses, management changes, or sector-specific headwinds—that can cause erratic momentum swings. The indicator is much more reliable when applied to the smoothed, aggregate psychology of a broad market index.

## Text Formula

The calculation of the Coppock Curve requires three distinct steps:

**1. Calculate the Rates of Change (ROC):**
*   **ROC14** = ((Current Close - Close 14 periods ago) / Close 14 periods ago) * 100
*   **ROC11** = ((Current Close - Close 11 periods ago) / Close 11 periods ago) * 100

**2. Calculate the ROC Sum:**
*   **ROC Sum** = ROC14 + ROC11

**3. Calculate the 10-period Weighted Moving Average (WMA) of the ROC Sum:**
To calculate a 10-period WMA, multiply the most recent ROC Sum by 10, the previous period's ROC Sum by 9, the one before that by 8, and so on, down to 1. Finally, divide the total by the sum of the weights (10 + 9 + 8 + 7 + 6 + 5 + 4 + 3 + 2 + 1 = 55).

*   **Coppock Curve** = [(ROC Sum * 10) + (ROC Sum 1 period ago * 9) + (ROC Sum 2 periods ago * 8) + ... + (ROC Sum 9 periods ago * 1)] / 55

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_coppock_curve(df):
    """
    Calculates the Coppock Curve and its components for a given DataFrame.
    
    Assumes the input DataFrame has the following columns:
    'symbol', 'date', 'open', 'high', 'low', 'close'
    
    The function handles multiple symbols independently and returns the 
    DataFrame with new columns for the indicator's components.
    """
    # Create a copy to avoid modifying the original dataframe
    df = df.copy()
    
    # Ensure the data is sorted chronologically per symbol for accurate rolling calculations
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Helper function to calculate the Weighted Moving Average (WMA)
    def wma(series, period):
        # Create an array of weights: [1, 2, 3, ..., period]
        weights = np.arange(1, period + 1)
        # Apply the weights to the rolling window using a dot product
        return series.rolling(period).apply(lambda x: np.dot(x, weights) / weights.sum(), raw=True)

    # Calculate the 14-period and 11-period Rate of Change (ROC)
    # pct_change(n) calculates (current - previous_n) / previous_n
    # Multiplying by 100 converts it to a percentage format
    df['roc_14'] = df.groupby('symbol')['close'].pct_change(periods=14) * 100
    df['roc_11'] = df.groupby('symbol')['close'].pct_change(periods=11) * 100
    
    # Calculate the sum of the two ROCs
    df['roc_sum'] = df['roc_14'] + df['roc_11']
    
    # Calculate the 10-period WMA of the ROC sum to generate the final Coppock Curve
    df['coppock_curve'] = df.groupby('symbol')['roc_sum'].transform(lambda x: wma(x, 10))
    
    return df
```
```json
{ "model_code": "t5pz4nm8vqj7", "topic": "Coppock Curve", "timer_secs": 33.58, "tokens_in": 565, "tokens_out": 3978, "cost_tokens_in": 0.00113000, "cost_tokens_out": 0.04773600, "cost_tokens_tot": 0.04886600 }
```