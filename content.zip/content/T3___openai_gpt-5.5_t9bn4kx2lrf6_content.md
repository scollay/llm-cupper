# T3 Moving Average

## Overview

The T3 Moving Average, often called the Tillson T3, is a smooth, low-lag moving average used to identify trend direction, filter noise, and generate crossover or slope-based trading signals. On a chart, it appears as a single curved line plotted over price, similar to an EMA but typically smoother and less jagged.

The indicator was developed by Tim Tillson and introduced in the late 1990s. Its key innovation is a multi-stage exponential smoothing process controlled by a “volume factor,” which is not trading volume but a coefficient that adjusts the balance between smoothness and responsiveness.

## Details

The T3 is designed to solve a familiar moving-average problem: simple and exponential moving averages smooth price, but they often lag turning points. Faster averages reduce lag but become noisy. Slower averages are cleaner but react late. The T3 attempts to sit between those trade-offs by applying multiple exponential moving averages and then combining them with coefficients derived from a user-defined factor.

The standard T3 uses six sequential EMAs of the chosen price series, usually the close. The final T3 line is not simply the sixth EMA. Instead, it blends the third, fourth, fifth, and sixth EMAs using coefficients based on the volume factor, commonly set to `0.7`.

### Key inputs

The T3 has two main parameters:

- **Length**: The EMA lookback period used at each smoothing step. Common values include 5, 8, 10, 14, and 20.
- **Volume factor**: A smoothing coefficient, often written as `v` or `a`. The common default is `0.7`.

Despite the name, the volume factor does not use exchange volume. A higher factor generally makes the T3 more responsive but can increase overshoot. A lower factor makes it smoother but more lagging.

### How traders interpret the T3

The T3 is usually read like a refined trend-following average.

When price is above a rising T3, traders often view the market as being in an uptrend. When price is below a falling T3, the market is often treated as being in a downtrend. The slope of the T3 is important because it helps distinguish a trend filter from a simple price-location tool.

Common interpretations include:

1. **Trend direction**
   - Rising T3: bullish trend bias.
   - Falling T3: bearish trend bias.
   - Flat T3: neutral or range-bound conditions.

2. **Price crossovers**
   - A close above the T3 may be interpreted as a bullish signal.
   - A close below the T3 may be interpreted as a bearish signal.

3. **Slope turns**
   - A T3 turning upward can indicate improving momentum.
   - A T3 turning downward can indicate weakening momentum.

4. **Dynamic support and resistance**
   - In trending markets, pullbacks toward the T3 may act as potential support in uptrends or resistance in downtrends.

Some traders also use two T3 lines with different lengths, treating the faster T3 crossing above the slower T3 as bullish and the reverse as bearish. That is an extension of the indicator rather than the core calculation.

### Strengths

The T3’s main advantage is that it can appear smoother than a traditional EMA while still reacting relatively quickly to price changes. This makes it useful for traders who want a trend line that does not flip direction on every minor bar.

It is often attractive in liquid markets with persistent directional movement, such as index futures, major currency pairs, and highly traded equities. Swing traders may use it as a trend filter, while intraday traders may use it to define directional bias before looking for entries with price action or momentum indicators.

### Where it breaks down

The T3 is still a moving average, so it does not eliminate lag. In fast reversals, price can move sharply before the T3 turns. In sideways markets, crossovers can produce repeated whipsaws, especially with short lengths or high volume-factor settings.

The indicator also provides no direct information about volatility, volume participation, market structure, or the probability that a breakout will continue. A rising T3 tells the trader that smoothed price is rising; it does not confirm that a trend is strong enough to trade without additional context.

Another limitation is parameter sensitivity. A T3 length and volume factor that work well on one market or timeframe may perform poorly elsewhere. Over-optimizing these inputs can create a curve-fitted signal that fails in live trading.

For these reasons, traders commonly pair the T3 with tools such as support and resistance, volatility measures, volume analysis, or higher-timeframe trend filters.

## Text Formula

Let:

- `P_t` = price at time `t`, usually the close
- `n` = T3 length
- `v` = volume factor, commonly `0.7`
- `alpha = 2 / (n + 1)`

The exponential moving average is:

`EMA_t(X, n) = alpha * X_t + (1 - alpha) * EMA_{t-1}(X, n)`

Calculate six sequential EMAs:

`e1_t = EMA_t(P, n)`

`e2_t = EMA_t(e1, n)`

`e3_t = EMA_t(e2, n)`

`e4_t = EMA_t(e3, n)`

`e5_t = EMA_t(e4, n)`

`e6_t = EMA_t(e5, n)`

Calculate the T3 coefficients:

`c1 = -v^3`

`c2 = 3v^2 + 3v^3`

`c3 = -6v^2 - 3v - 3v^3`

`c4 = 1 + 3v + 3v^2 + v^3`

Then the T3 Moving Average is:

`T3_t = c1 * e6_t + c2 * e5_t + c3 * e4_t + c4 * e3_t`

Common derived values are:

`T3_Slope_t = T3_t - T3_{t-1}`

`T3_Direction_t = sign(T3_Slope_t)`

`Close_Above_T3_t = Close_t > T3_t`

`Close_Cross_Above_T3_t = Close_t > T3_t and Close_{t-1} <= T3_{t-1}`

`Close_Cross_Below_T3_t = Close_t < T3_t and Close_{t-1} >= T3_{t-1}`

`T3_Turn_Up_t = T3_Slope_t > 0 and T3_Slope_{t-1} <= 0`

`T3_Turn_Down_t = T3_Slope_t < 0 and T3_Slope_{t-1} >= 0`

EMA initialization can vary by charting platform. Some seed the first EMA with the first available price, while others require a minimum number of observations before returning values.

## Python Code

```python
import numpy as np
import pandas as pd


def calculate_t3(
    data,
    length=5,
    vfactor=0.7,
    price_col="close",
    min_periods=None,
    adjust=False,
):
    # Required input format:
    # A pandas DataFrame with columns:
    # symbol, date, open, high, low, close
    #
    # The DataFrame may contain one symbol or multiple symbols.
    # Calculations are performed independently for each symbol.
    #
    # Parameters:
    # length: EMA period used in the T3 calculation.
    # vfactor: Tillson volume factor; common default is 0.7.
    # price_col: price column to smooth; default is "close".
    # min_periods: minimum observations required for each EMA stage.
    #              If None, defaults to length.
    # adjust: passed to pandas ewm(); False is typical for trading indicators.

    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols.difference(data.columns)
    if missing:
        raise ValueError(f"Input DataFrame is missing required columns: {sorted(missing)}")

    if price_col not in data.columns:
        raise ValueError(f"price_col '{price_col}' is not in the DataFrame.")

    if length < 1:
        raise ValueError("length must be at least 1.")

    if min_periods is None:
        min_periods = length

    if min_periods < 1:
        raise ValueError("min_periods must be at least 1.")

    df = data.copy()
    df["_original_order"] = np.arange(len(df))
    df = df.sort_values(["symbol", "date", "_original_order"])

    alpha = 2.0 / (length + 1.0)

    def ema_by_symbol(series):
        return series.ewm(
            alpha=alpha,
            adjust=adjust,
            min_periods=min_periods,
        ).mean()

    df["t3_e1"] = df.groupby("symbol", group_keys=False)[price_col].transform(ema_by_symbol)
    df["t3_e2"] = df.groupby("symbol", group_keys=False)["t3_e1"].transform(ema_by_symbol)
    df["t3_e3"] = df.groupby("symbol", group_keys=False)["t3_e2"].transform(ema_by_symbol)
    df["t3_e4"] = df.groupby("symbol", group_keys=False)["t3_e3"].transform(ema_by_symbol)
    df["t3_e5"] = df.groupby("symbol", group_keys=False)["t3_e4"].transform(ema_by_symbol)
    df["t3_e6"] = df.groupby("symbol", group_keys=False)["t3_e5"].transform(ema_by_symbol)

    c1 = -(vfactor ** 3)
    c2 = 3 * (vfactor ** 2) + 3 * (vfactor ** 3)
    c3 = -6 * (vfactor ** 2) - 3 * vfactor - 3 * (vfactor ** 3)
    c4 = 1 + 3 * vfactor + 3 * (vfactor ** 2) + (vfactor ** 3)

    df["t3_c1"] = c1
    df["t3_c2"] = c2
    df["t3_c3"] = c3
    df["t3_c4"] = c4

    df["t3"] = (
        c1 * df["t3_e6"]
        + c2 * df["t3_e5"]
        + c3 * df["t3_e4"]
        + c4 * df["t3_e3"]
    )

    grouped = df.groupby("symbol", group_keys=False)

    df["t3_slope"] = grouped["t3"].diff()
    df["t3_direction"] = np.sign(df["t3_slope"])

    prev_close = grouped[price_col].shift(1)
    prev_t3 = grouped["t3"].shift(1)
    prev_slope = grouped["t3_slope"].shift(1)

    df["close_above_t3"] = df[price_col] > df["t3"]

    df["close_cross_above_t3"] = (
        (df[price_col] > df["t3"])
        & (prev_close <= prev_t3)
    )

    df["close_cross_below_t3"] = (
        (df[price_col] < df["t3"])
        & (prev_close >= prev_t3)
    )

    df["t3_turn_up"] = (
        (df["t3_slope"] > 0)
        & (prev_slope <= 0)
    )

    df["t3_turn_down"] = (
        (df["t3_slope"] < 0)
        & (prev_slope >= 0)
    )

    df = df.sort_values("_original_order").drop(columns=["_original_order"])

    return df
```
```json
{ "model_code": "t9bn4kx2lrf6", "topic": "T3", "timer_secs": 70.69, "tokens_in": 558, "tokens_out": 4761, "cost_tokens_in": 0.00279000, "cost_tokens_out": 0.14283000, "cost_tokens_tot": 0.14562000 }
```