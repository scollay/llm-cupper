# Bollinger Bands

## Overview
Bollinger Bands are a volatility‑based technical indicator developed by John Bollinger in the early 1980s. They consist of a central moving average line flanked by two bands that expand and contract with market volatility. On a price chart, the bands appear as a shaded envelope around the price action, giving traders a visual cue of relative price levels and potential breakouts. Bollinger Bands are widely used by day traders, swing traders, and institutional investors to gauge overbought or oversold conditions, identify trend strength, and spot “squeeze” patterns that often precede large moves.

## Details
### How the Indicator Works
Bollinger Bands are built on three components:

1. **Middle Band** – a simple moving average (SMA) of the closing price over a chosen period (commonly 20 days).  
2. **Upper Band** – the middle band plus *k* times the rolling standard deviation of the closing price.  
3. **Lower Band** – the middle band minus *k* times the rolling standard deviation.

The default multiplier *k* is 2, which captures roughly 95 % of price action if the underlying distribution is normal. The bands widen when volatility rises and contract when volatility falls, creating a dynamic range that adapts to market conditions.

### Typical Interpretation
- **Price Touching the Upper Band** – often signals an overbought market; traders may look for a pullback or reversal.  
- **Price Touching the Lower Band** – often signals an oversold market; traders may look for a bounce or reversal.  
- **Band Squeeze** – when the distance between the upper and lower bands narrows significantly, it indicates low volatility and a potential upcoming breakout.  
- **Band Breakout** – a sustained move beyond the upper or lower band can confirm a strong trend and is sometimes used to trigger entries.  
- **Band Width** – the absolute difference between the upper and lower bands; a widening width suggests increasing volatility and potential trend continuation.

### Where the Interpretation Breaks Down
1. **False Signals in Trending Markets** – In a strong trend, price can ride the upper band for extended periods without reversal, leading to whipsaws if traders exit on every touch.  
2. **Non‑Normal Volatility** – The assumption that price changes follow a normal distribution is often violated; extreme events can push price beyond the bands without a clear reversal.  
3. **Lagging Nature** – Since the bands rely on historical data, they lag behind real‑time volatility changes, sometimes missing rapid shifts.  
4. **Overreliance on Default Settings** – The 20‑period SMA and *k* = 2 are not universal; applying them to all instruments can produce misleading signals.  
5. **Squeeze Misinterpretation** – A squeeze can precede a move in either direction; without additional confirmation (e.g., volume, momentum), traders may misread the breakout.

Because of these pitfalls, Bollinger Bands are most effective when combined with other tools—such as trendlines, oscillators, or volume analysis—to filter out noise and confirm signals.

## Text Formula
Let `C_t` be the closing price at time `t`, `N` the chosen period (default 20), and `k` the multiplier (default 2).

1. **Middle Band (SMA)**  
   `SMA_t = (1/N) * Σ_{i=0}^{N-1} C_{t-i}`

2. **Rolling Standard Deviation**  
   `σ_t = sqrt( (1/(N-1)) * Σ_{i=0}^{N-1} (C_{t-i} - SMA_t)^2 )`

3. **Upper Band**  
   `Upper_t = SMA_t + k * σ_t`

4. **Lower Band**  
   `Lower_t = SMA_t - k * σ_t`

5. **Band Width**  
   `Width_t = Upper_t - Lower_t`

6. **Percent B (%B)** – a normalized measure of price position within the bands  
   `PctB_t = (C_t - Lower_t) / Width_t`  
   (PctB ranges from 0 to 1; values near 0 indicate price near the lower band, values near 1 near the upper band.)

These formulas apply independently to each symbol in a multi‑symbol dataset.

## Python Code
```python
import pandas as pd

def bollinger_bands(df: pd.DataFrame,
                    period: int = 20,
                    multiplier: float = 2.0,
                    price_col: str = 'close') -> pd.DataFrame:
    """
    Calculate Bollinger Bands for one or more symbols in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', and a price column (default 'close').
    period : int, optional
        Rolling window for SMA and standard deviation. Default is 20.
    multiplier : float, optional
        Number of standard deviations for upper/lower bands. Default is 2.0.
    price_col : str, optional
        Column name for the price to use. Default is 'close'.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with added columns:
        - 'sma'      : simple moving average
        - 'upper'    : upper Bollinger Band
        - 'lower'    : lower Bollinger Band
        - 'width'    : band width (upper - lower)
        - 'pctb'     : percent B (price position within bands)
    """
    # Ensure required columns exist
    required = {'symbol', 'date', price_col}
    if not required.issubset(df.columns):
        missing = required - set(df.columns)
        raise ValueError(f"Missing columns: {missing}")

    # Sort by symbol and date to maintain correct rolling order
    df_sorted = df.sort_values(['symbol', 'date'])

    # Group by symbol to compute rolling statistics independently
    def _calc(group: pd.DataFrame) -> pd.DataFrame:
        # Rolling SMA
        sma = group[price_col].rolling(window=period, min_periods=period).mean()
        # Rolling standard deviation (sample, ddof=1)
        std = group[price_col].rolling(window=period, min_periods=period).std(ddof=1)
        # Upper and lower bands
        upper = sma + multiplier * std
        lower = sma - multiplier * std
        # Band width
        width = upper - lower
        # Percent B
        pctb = (group[price_col] - lower) / width
        # Assign new columns
        group = group.assign(
            sma=sma,
            upper=upper,
            lower=lower,
            width=width,
            pctb=pctb
        )
        return group

    # Apply calculation to each symbol group
    result = df_sorted.groupby('symbol', group_keys=False).apply(_calc)

    # Return in original order
    return result.sort_index()
```
This function accepts a DataFrame with potentially multiple symbols, computes the Bollinger Bands for each symbol independently, and returns the enriched DataFrame with all indicator values. The code uses pandas’ rolling functions with `min_periods=period` to avoid NaNs until enough data points are available. The standard deviation uses `ddof=1` to match the common sample‑based calculation. The percent‑B column normalizes price position between 0 and 1, facilitating quick visual assessment of relative band proximity.
```json
{ "model_code": "b3kp9vwx2mft", "topic": "Bollinger Bands", "timer_secs": 16.31, "tokens_in": 620, "tokens_out": 2021, "cost_tokens_in": 0.00001798, "cost_tokens_out": 0.00028294, "cost_tokens_tot": 0.00030092 }
```