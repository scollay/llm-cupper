# Clenow Momentum

## Overview
Clenow Momentum is a quantitative measure of a security's price trend, developed by analyst and author Andreas Clenow. Unlike simple price-change percentages, it combines the absolute return of an asset with the stability of that return (volatility). It typically appears as a numerical value assigned to a security, allowing traders to rank a universe of stocks from highest to lowest momentum to build a trend-following portfolio.

## Details
The core philosophy behind Clenow Momentum is that a strong trend is not just one that moves the price significantly in one direction, but one that does so with low volatility. A stock that rises 20% in a straight line is considered to have higher quality momentum than a stock that rises 20% via wild swings.

### How it Works
The indicator calculates the annualized return of an asset over a specific lookback period (typically 12 months). To account for the "quality" of the trend, this return is divided by the annualized standard deviation of the asset's daily returns. This effectively creates a risk-adjusted momentum score, similar in spirit to the Sharpe Ratio, but focused on price momentum rather than excess return over a risk-free rate.

### Interpretation
Traders use Clenow Momentum primarily for **cross-sectional ranking**. Instead of looking for a specific "overbought" or "oversold" level, the trader calculates the score for a large group of assets and selects the top decile or top $N$ assets.

*   **High Positive Score:** Indicates a strong, smooth uptrend.
*   **Low or Negative Score:** Indicates a downtrend or a highly volatile, unstable price action.

### Limitations
The primary weakness of Clenow Momentum is its lag. Because it relies on historical lookback periods, it may keep a trader in a position long after the trend has peaked. Additionally, in "mean-reverting" or "choppy" markets, the indicator can produce false positives, as a sudden spike in price can temporarily inflate the momentum score before the asset reverts to the mean.

## Text Formula
The calculation involves three primary steps:

1.  **Annualized Return**:
    `Annualized Return = (Current Price / Price at start of lookback) ^ (252 / Trading Days in lookback) - 1`

2.  **Annualized Volatility**:
    `Annualized Volatility = Standard Deviation of Daily Log Returns * Square Root of 252`

3.  **Clenow Momentum Score**:
    `Momentum Score = Annualized Return / Annualized Volatility`

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df, lookback_days=252):
    """
    Calculates Clenow Momentum for a DataFrame of assets.
    
    Input DataFrame columns: 
    `symbol`, `date`, `open`, `high`, `low`, `close`
    """
    # Ensure data is sorted by date to maintain time-series integrity
    df = df.sort_values(['symbol', 'date'])
    
    results = []
    
    # Process each symbol independently
    for symbol, group in df.groupby('symbol'):
        group = group.copy()
        
        # 1. Calculate Daily Log Returns for volatility
        group['log_ret'] = np.log(group['close'] / group['close'].shift(1))
        
        # 2. Calculate Annualized Return
        # We look at the price change over the lookback period
        # Formula: (Price_now / Price_then) ^ (252 / actual_days) - 1
        current_price = group['close'].iloc[-1]
        start_price = group['close'].iloc[-lookback_days] if len(group) >= lookback_days else group['close'].iloc[0]
        actual_days = len(group) - (group.index.get_loc(group.index[-1]) - group.index.get_loc(group.index[0])) # Simplified as window size
        
        # Using the actual number of observations in the window for the exponent
        window_size = min(len(group), lookback_days)
        annualized_return = (current_price / group['close'].iloc[-window_size]) ** (252 / window_size) - 1
        
        # 3. Calculate Annualized Volatility
        # Standard deviation of log returns over the lookback window * sqrt(252)
        volatility = group['log_ret'].tail(window_size).std() * np.sqrt(252)
        
        # 4. Calculate Clenow Momentum Score
        # Handle division by zero if volatility is 0
        momentum_score = annualized_return / volatility if volatility != 0 else 0
        
        results.append({
            'symbol': symbol,
            'annualized_return': annualized_return,
            'annualized_volatility': volatility,
            'clenow_momentum': momentum_score
        })
        
    return pd.DataFrame(results)
```
```json
{ "model_code": "d4vh9pq2xtw6", "topic": "Clenow Momentum", "timer_secs": 70.75, "tokens_in": 579, "tokens_out": 1133, "cost_tokens_in": 0.00006948, "cost_tokens_out": 0.00041921, "cost_tokens_tot": 0.00048869 }
```