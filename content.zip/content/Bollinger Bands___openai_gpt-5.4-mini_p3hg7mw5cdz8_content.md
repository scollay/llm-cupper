# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based overlay developed by **John Bollinger** in the 1980s. They typically appear as three lines plotted around price: a **middle band** (usually a simple moving average) and an **upper** and **lower band** placed a set number of standard deviations away from that average.

Traders use Bollinger Bands to gauge whether price is relatively stretched or compressed versus its recent history. The bands expand when volatility rises and contract when volatility falls, making the indicator useful for spotting breakouts, trend strength, and potential mean-reversion setups.

## Details
Bollinger Bands are built from two ingredients:

- a moving average of price, usually the 20-period simple moving average
- a volatility measure, usually the standard deviation of price over the same lookback

The most common configuration is:

- **Middle Band** = 20-period SMA
- **Upper Band** = Middle Band + 2 standard deviations
- **Lower Band** = Middle Band - 2 standard deviations

The idea is simple: in a normal distribution, roughly 95% of observations fall within two standard deviations of the mean. Financial prices are not normally distributed in a clean statistical sense, but the framework still gives traders a dynamic envelope around price.

### How traders interpret Bollinger Bands

Common readings include:

- **Band expansion**: volatility is increasing. This often happens after a quiet consolidation and can precede a directional move.
- **Band contraction**: volatility is falling. Traders often call this a “squeeze,” which can signal an impending breakout, though not the direction.
- **Touches of the upper band**: can suggest strength in an uptrend, not necessarily overbought conditions.
- **Touches of the lower band**: can suggest weakness in a downtrend, not necessarily oversold conditions.
- **Price riding a band**: in strong trends, price may persistently “walk” the upper band in uptrends or the lower band in downtrends.

A key mistake is treating band touches as automatic reversal signals. In a strong trend, price can stay near or outside the bands for extended periods. What looks “overbought” on a Bollinger Band chart may simply reflect strong momentum.

### Where the interpretation breaks down

Bollinger Bands work best when you understand the market regime:

- **Mean-reverting markets**: band fades can work better when price oscillates around a stable average.
- **Trending markets**: breakouts and band rides matter more than contrarian fades.
- **News shocks**: gaps and discontinuous moves can make the bands lag badly because the moving average and standard deviation are backward-looking.
- **Low-liquidity assets**: erratic prints can distort standard deviation and produce misleading bands.

Another limitation is that the bands are relative, not predictive. They describe where price sits versus recent volatility, but they do not forecast whether a move will continue or reverse. For that reason, traders often pair Bollinger Bands with:

- volume
- trend filters such as moving averages
- momentum indicators like RSI
- price action patterns such as breakouts or failed breakouts

### Practical use
A common workflow is:

1. Identify whether the market is trending or ranging.
2. Watch for a squeeze or expansion in band width.
3. Wait for confirmation from price structure or volume.
4. Use the bands as a guide for volatility context, not as a standalone signal.

In short, Bollinger Bands are best viewed as a **volatility envelope** that helps frame price behavior, not as a self-contained buy/sell system.

## Text Formula
Let `P_t` be the closing price at time `t`, and let `n` be the lookback period, usually 20. Let:

- `SMA_t = (P_t + P_{t-1} + ... + P_{t-n+1}) / n`
- `σ_t = sqrt( (1/n) * Σ_{i=0 to n-1} (P_{t-i} - SMA_t)^2 )`

With multiplier `k` (usually 2):

- `Middle Band_t = SMA_t`
- `Upper Band_t = SMA_t + k * σ_t`
- `Lower Band_t = SMA_t - k * σ_t`
- `Band Width_t = Upper Band_t - Lower Band_t = 2 * k * σ_t`
- `Percent B_t = (P_t - Lower Band_t) / (Upper Band_t - Lower Band_t)`

## Python Code
```python
import pandas as pd
import numpy as np

def bollinger_bands(df: pd.DataFrame, period: int = 20, num_std: float = 2.0) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    Returns the input data sorted by symbol and date, with these added columns:
        bb_middle: middle band (rolling SMA of close)
        bb_std: rolling standard deviation of close
        bb_upper: upper band
        bb_lower: lower band
        bb_width: upper - lower
        bb_percent_b: (close - lower) / (upper - lower)
    """
    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    def _calc(group: pd.DataFrame) -> pd.DataFrame:
        g = group.copy()
        close = g["close"].astype(float)

        g["bb_middle"] = close.rolling(window=period, min_periods=period).mean()
        g["bb_std"] = close.rolling(window=period, min_periods=period).std(ddof=0)
        g["bb_upper"] = g["bb_middle"] + num_std * g["bb_std"]
        g["bb_lower"] = g["bb_middle"] - num_std * g["bb_std"]
        g["bb_width"] = g["bb_upper"] - g["bb_lower"]

        denom = g["bb_width"].replace(0, np.nan)
        g["bb_percent_b"] = (close - g["bb_lower"]) / denom

        return g

    out = out.groupby("symbol", group_keys=False, sort=False).apply(_calc)

    return out
```
```json
{ "model_code": "p3hg7mw5cdz8", "topic": "Bollinger Bands", "timer_secs": 9.58, "tokens_in": 559, "tokens_out": 1387, "cost_tokens_in": 0.00041925, "cost_tokens_out": 0.00624150, "cost_tokens_tot": 0.00666075 }
```