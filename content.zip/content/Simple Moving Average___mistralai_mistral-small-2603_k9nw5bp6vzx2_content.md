# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that smooths price data by averaging a fixed number of past prices over a specified period. It appears as a single line on a price chart, lagging behind the most recent price action. The SMA was developed as one of the earliest trend-following tools in technical analysis, with its origins tracing back to early 20th-century market analysts. It remains a foundational indicator for identifying trends, support, and resistance levels.

## Details
The SMA calculates the arithmetic mean of a set of prices over a defined lookback period, typically using closing prices. By averaging past prices, it filters out short-term noise and highlights the underlying trend direction. Traders commonly use SMAs to:

- Identify trend direction: When price is above the SMA, the trend is considered bullish; when below, bearish.
- Generate signals: A crossover between price and SMA (or between two SMAs of different periods) can signal entry or exit points.
- Act as dynamic support/resistance: In uptrends, the SMA often acts as a floor; in downtrends, as a ceiling.

However, the SMA has limitations. Its lagging nature means it reacts slowly to sudden price changes, potentially delaying signals. It also struggles in choppy or sideways markets, where it may produce false signals by whipsawing around the price. Additionally, the SMA weights all prices equally, which can distort its relevance during periods of extreme volatility.

## Text Formula
The Simple Moving Average is calculated as:

```
SMA = (P₁ + P₂ + ... + Pₙ) / n
```

Where:
- `P₁, P₂, ..., Pₙ` are the closing prices over the last `n` periods.
- `n` is the lookback period (e.g., 20 days).

For example, a 20-day SMA on Day 21 is the sum of closing prices from Day 1 to Day 20, divided by 20.

## Python Code
```python
import pandas as pd

def simple_moving_average(df: pd.DataFrame, period: int = 20, column: str = 'close') -> pd.DataFrame:
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Must be sorted by 'symbol' and 'date' in ascending order.
    period : int, optional
        Lookback period for the SMA (default: 20).
    column : str, optional
        Price column to use for calculation (default: 'close').

    Returns:
    --------
    pd.DataFrame
        Original DataFrame with an additional 'sma' column containing SMA values.
    """
    # Group by symbol and compute SMA
    df['sma'] = df.groupby('symbol')[column].transform(
        lambda x: x.rolling(window=period, min_periods=period).mean()
    )
    return df
```
```json
{ "model_code": "k9nw5bp6vzx2", "topic": "Simple Moving Average", "timer_secs": 4.16, "tokens_in": 581, "tokens_out": 663, "cost_tokens_in": 0.00008715, "cost_tokens_out": 0.00039780, "cost_tokens_tot": 0.00048495 }
```