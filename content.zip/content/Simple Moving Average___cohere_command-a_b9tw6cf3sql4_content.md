# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that calculates the average of a security's price over a specified number of periods. It appears as a smooth line overlaid on a price chart, helping traders identify trends and potential reversal points. The SMA was not invented by a single individual but has been a fundamental tool in technical analysis for decades, with its origins tracing back to the early 20th century.

## Details
The Simple Moving Average is calculated by summing up the closing prices of a security over a defined number of periods and then dividing that sum by the number of periods. For example, a 10-day SMA would sum the closing prices of the last 10 days and divide by 10. This process "moves" forward one period at a time, dropping the oldest price and adding the newest one as time progresses.

Traders use the SMA to:
- **Identify Trends**: A rising SMA indicates an uptrend, while a falling SMA suggests a downtrend.
- **Generate Signals**: Crossovers between short-term and long-term SMAs (e.g., 50-day and 200-day) are often used as buy or sell signals.
- **Support and Resistance**: SMAs can act as dynamic support or resistance levels, where prices may bounce off or reverse at these levels.

However, the SMA has limitations:
- **Lagging Indicator**: Because it is based on past prices, the SMA can lag behind current market conditions, leading to delayed signals.
- **Equal Weighting**: Each price point in the SMA is given equal weight, which may not reflect the importance of more recent prices.
- **Whipsaws**: In choppy or sideways markets, the SMA can generate false signals, leading to whipsaws.

## Text Formula
The formula for the Simple Moving Average (SMA) is:

\[
\text{SMA} = \frac{\sum_{i=1}^{n} \text{Close}_i}{n}
\]

Where:
- \(\text{Close}_i\) = Closing price of the security at period \(i\)
- \(n\) = Number of periods in the moving average

## Python Code
```python
import pandas as pd

def calculate_sma(data, window):
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the DataFrame.

    Parameters:
    data (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.
    window (int): Number of periods for the SMA.

    Returns:
    pd.DataFrame: Original DataFrame with an additional column 'SMA' containing the calculated SMA values.
    """
    # Group by symbol to handle multiple symbols independently
    result = data.copy()
    for symbol, group in data.groupby('symbol'):
        result.loc[result['symbol'] == symbol, 'SMA'] = group['close'].rolling(window=window, min_periods=1).mean()
    return result

# Example usage:
# Assuming `df` is a DataFrame with the required columns
# df = pd.DataFrame({...})
# df_with_sma = calculate_sma(df, window=10)
```
```json
{ "model_code": "b9tw6cf3sql4", "topic": "Simple Moving Average", "timer_secs": 10.27, "tokens_in": 574, "tokens_out": 705, "cost_tokens_in": 0.00143500, "cost_tokens_out": 0.00705000, "cost_tokens_tot": 0.00848500 }
```