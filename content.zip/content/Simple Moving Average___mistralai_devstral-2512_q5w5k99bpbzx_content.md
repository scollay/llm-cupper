# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a fundamental technical indicator that smooths price data by calculating the average price over a specified number of periods. It appears on a chart as a single line that lags behind the price action, providing a clear visual representation of the underlying trend. The SMA is widely used by traders to identify trend direction, potential support and resistance levels, and entry or exit points. While its origins are unclear, moving averages have been a staple of technical analysis since the early 20th century, with variations like the Exponential Moving Average (EMA) introduced later to address some of its limitations.

## Details
The SMA is calculated by summing the closing prices (or another chosen price point) over a defined lookback period and dividing by the number of periods. The result is plotted as a continuous line that moves in tandem with price but with a delay equal to half the lookback period. Traders use the SMA in several ways:

- **Trend Identification**: A rising SMA suggests an uptrend, while a falling SMA indicates a downtrend. The slope of the SMA can also signal trend strength.
- **Support and Resistance**: Prices often react to the SMA as a dynamic support or resistance level. In uptrends, the SMA may act as support; in downtrends, it may act as resistance.
- **Crossover Strategies**: Traders frequently use crossovers between two SMAs (e.g., a 50-period and 200-period SMA) or between price and the SMA to generate buy or sell signals. A price crossing above the SMA may signal a buy, while a cross below may signal a sell.

### Limitations
The SMA is inherently lagging and does not predict future prices. Its effectiveness diminishes in choppy or sideways markets, where frequent crossovers can generate false signals. Additionally, the SMA gives equal weight to all prices in the lookback period, which can make it slower to react to recent price changes compared to weighted or exponential moving averages.

## Text Formula
The Simple Moving Average is calculated as follows:

```
SMA = (Sum of closing prices over N periods) / N
```

Where:
- `N` = the number of periods in the lookback window (e.g., 20 for a 20-period SMA).
- The calculation is repeated for each new period, dropping the oldest price and adding the newest.

For example, a 5-period SMA for days 6–10 would be:
```
SMA = (Close_6 + Close_7 + Close_8 + Close_9 + Close_10) / 5
```

## Python Code
```python
import pandas as pd

def calculate_sma(data, periods):
    """
    Calculate the Simple Moving Average (SMA) for one or more symbols.

    Parameters:
    - data: Pandas DataFrame with columns: symbol, date, open, high, low, close.
            Must be sorted by symbol and date in ascending order.
    - periods: int or list of ints, the lookback period(s) for the SMA (e.g., 20, 50).

    Returns:
    - DataFrame with original columns plus new columns for each SMA period:
      sma_<period> (e.g., sma_20, sma_50).
    """
    if isinstance(periods, int):
        periods = [periods]

    # Ensure data is sorted by symbol and date
    data = data.sort_values(['symbol', 'date']).copy()

    # Calculate SMA for each period
    for period in periods:
        col_name = f'sma_{period}'
        data[col_name] = data.groupby('symbol')['close'].transform(
            lambda x: x.rolling(window=period, min_periods=1).mean()
        )

    return data
```

### Notes on the Code:
- The function handles multiple symbols by grouping calculations by `symbol`.
- `min_periods=1` ensures the SMA is calculated even when fewer than `period` observations are available (e.g., at the start of the series).
- The output includes the original columns plus new columns for each SMA period (e.g., `sma_20`).
- The input DataFrame must be sorted by `symbol` and `date` for correct rolling calculations.
```json
{ "model_code": "q5w5k99bpbzx", "topic": "Simple Moving Average", "timer_secs": 13.72, "tokens_in": 569, "tokens_out": 907, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00181400, "cost_tokens_tot": 0.00204160 }
```