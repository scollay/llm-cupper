# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a widely used technical indicator that smooths price data by creating a constantly updated average price over a specified number of periods. It appears on charts as a line that tracks the average price of an asset over time. The SMA was developed in the 19th century and is one of the most fundamental tools in technical analysis, often used to identify trends and potential support or resistance levels.

## Details
The SMA is calculated by summing up the closing prices of an asset over a specific number of periods and dividing that sum by the number of periods. For example, a 10-day SMA is calculated by adding the closing prices for the last 10 days and dividing by 10. As new data becomes available, the oldest price is dropped from the calculation and the newest price is added, creating a moving average that shifts with time.

Traders use the SMA to identify the direction of a trend. When the price is above the SMA, it suggests an uptrend, and when below, a downtrend. Crossovers of the SMA with price or between different SMAs (e.g., a 50-day crossing above a 200-day) are often interpreted as buy or sell signals. However, the SMA has limitations: it is lagging, meaning it follows price rather than anticipating it, and it can produce false signals in choppy or sideways markets. Additionally, because it treats all periods equally, it may not respond quickly to sudden price changes.

## Text Formula
The formula for the Simple Moving Average is:

`SMA = (P1 + P2 + P3 + ... + Pn) / n`

Where:
- `P1` to `Pn` are the closing prices over `n` periods
- `n` is the number of periods used in the calculation

For a rolling window of `n` periods, the SMA at time `t` is:

`SMA_t = (close_t + close_{t-1} + ... + close_{t-n+1}) / n`

## Python Code
```python
import pandas as pd

def calculate_sma(df, period=20):
    """
    Calculate Simple Moving Average for each symbol in the DataFrame.
    
    Parameters:
    df (DataFrame): Input DataFrame with columns 'symbol', 'date', 'close'
    period (int): Number of periods to use in the SMA calculation
    
    Returns:
    DataFrame: Original DataFrame with added 'sma' column
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Group by symbol and calculate SMA for each group
    df['sma'] = df.groupby('symbol')['close'].rolling(window=period, min_periods=period).mean().reset_index(0, drop=True)
    
    return df
```
```json
{ "model_code": "ttf320fjb9kr", "topic": "Simple Moving Average", "timer_secs": 6.25, "tokens_in": 563, "tokens_out": 604, "cost_tokens_in": 0.00003941, "cost_tokens_out": 0.00016308, "cost_tokens_tot": 0.00020249 }
```