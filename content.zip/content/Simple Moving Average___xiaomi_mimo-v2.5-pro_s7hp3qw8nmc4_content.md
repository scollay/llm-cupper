# Simple Moving Average

## Overview

The **Simple Moving Average (SMA)** is a trend-following technical indicator that calculates the arithmetic mean of a security's closing prices over a specified number of periods. On a chart, it appears as a smooth, continuous line overlaid on the price data. The SMA is one of the oldest and most widely used indicators in technical analysis, with roots in early 20th-century charting practices. Its exact origin is difficult to pin down to a single creator, though it became a cornerstone of the methodical approach to technical analysis popularized by practitioners in the 1950s and 1960s.

## Details

### How It Works

The SMA takes an equal-weighted average of closing prices across a chosen lookback window. Common periods include **10, 20, 50, 100, and 200** days, each serving a different analytical purpose:

- **Short-term SMAs (10–20 days):** React quickly to price changes and are used by swing traders to identify near-term momentum and trend shifts.
- **Medium-term SMAs (50 days):** Represent the intermediate trend and are widely watched by institutional and retail traders alike.
- **Long-term SMAs (100–200 days):** Smooth out noise to reveal the dominant trend. The **200-day SMA** is arguably the most referenced long-term average in all of financial markets.

Because every price in the window receives the same weight, the SMA can be slow to respond when a recent price move deviates sharply from the rest of the data set.

### Interpretation

Traders use the SMA in several ways:

1. **Trend direction.** When price trades *above* an SMA, the trend is generally considered bullish; when *below*, bearish. The longer the SMA period, the more significant the signal.
2. **Support and resistance.** Rising SMAs often act as dynamic support in uptrends, while declining SMAs can serve as resistance in downtrends. Price frequently "bounces" off a major SMA before continuing in the trend direction.
3. **Crossovers.** When a shorter-period SMA crosses above a longer-period SMA, it generates a bullish signal known as a **golden cross**. The reverse—a shorter SMA crossing below a longer one—is called a **death cross**. The most common pairing is the 50-day and 200-day SMAs.
4. **Multiple SMA confirmation.** Some traders layer several SMAs (e.g., 10, 50, and 200) on a single chart. When the short SMA is above the medium SMA, which is above the long SMA—a condition sometimes called "fan alignment"—it signals a strong, well-established trend.

### Where It Breaks Down

- **Lag.** The SMA is inherently backward-looking. By the time a crossover or trend-change signal fires, the new trend may already be well underway, reducing potential profit.
- **Choppy or range-bound markets.** In sideways conditions, price criss-crosses the SMA frequently, generating a series of small losing trades known as **whipsaws**.
- **Equal weighting.** Because the SMA treats a price from 20 periods ago the same as yesterday's close, it can be slow to incorporate new information. Exponential and other weighted moving averages address this by assigning greater weight to recent data.
- **Period selection.** There is no universally "correct" SMA length. A 50-day SMA may work well for one security or timeframe but poorly for another. Period selection often involves a degree of curve-fitting.

Despite these limitations, the SMA remains a foundational tool. Its simplicity makes it easy to combine with other indicators—such as the Relative Strength Index, MACD, or Bollinger Bands—and its widespread use means that major SMAs can function as self-fulfilling levels of support and resistance.

## Text Formula

Given a lookback window of **N** periods:

```
SMA(N) = (1 / N) × (C₁ + C₂ + C₃ + … + Cₙ)
```

Where:

- **C₁** is the most recent closing price
- **C₂** is the closing price one period prior
- **Cₙ** is the closing price N−1 periods prior

Using summation notation, the SMA at time *t* is:

```
SMA_t(N) = (1 / N) × Σ (i = 0 to N−1) Close_(t−i)
```

The result is a single value per time period *t*. Plotting these values across all periods produces the SMA line.

## Python Code

```python
import pandas as pd


def calculate_sma(
    df: pd.DataFrame,
    periods: list[int] = [10, 20, 50, 100, 200],
) -> pd.DataFrame:
    """
    Calculate Simple Moving Average(s) for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data for each symbol should already be sorted by date in
        ascending order (oldest first).
    periods : list of int
        SMA lookback windows to compute, e.g. [10, 20, 50, 100, 200].

    Returns
    -------
    pd.DataFrame
        Original DataFrame with one additional column per period:
        sma_<period>  (e.g. sma_10, sma_50, sma_200).
        Rows where fewer than `period` observations are available for a
        symbol will contain NaN.
    """
    result = df.copy()

    # Ensure rows are sorted correctly within each symbol
    result = result.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Calculate each requested SMA independently per symbol
    for period in periods:
        col_name = f"sma_{period}"
        result[col_name] = (
            result.groupby("symbol")["close"]
            .transform(
                lambda x: x.rolling(window=period, min_periods=period).mean()
            )
        )

    return result
```
```json
{ "model_code": "s7hp3qw8nmc4", "topic": "Simple Moving Average", "timer_secs": 88.52, "tokens_in": 806, "tokens_out": 3343, "cost_tokens_in": 0.00080600, "cost_tokens_out": 0.01002900, "cost_tokens_tot": 0.01083500 }
```