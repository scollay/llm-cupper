# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is one of the most fundamental technical indicators in financial markets. It calculates the arithmetic mean of a security's price over a specified number of periods, smoothing out short-term price fluctuations to reveal underlying trends. On a chart, the SMA appears as a single line that trails the price action, typically overlaid directly on the candlestick or bar chart. The concept is straightforward and has been used by traders for decades; while no single inventor is credited, the moving average became a standard tool in technical analysis during the mid-20th century as charting became more accessible to retail traders.

## Details

The Simple Moving Average works by summing the closing prices (or sometimes other price points) over a fixed lookback period and dividing by the number of periods. A 20-period SMA, for example, adds the last 20 closing prices and divides by 20. As new data arrives, the oldest price in the window drops out and the newest enters, creating a continuously updated average that "moves" through time.

**How traders interpret it**

Traders use SMAs in several ways:

- **Trend identification**: A price trading above its SMA suggests an uptrend; below suggests a downtrend. Longer SMAs (50, 100, 200 periods) are often used to identify the primary trend, while shorter SMAs (10, 20 periods) capture shorter-term momentum.

- **Support and resistance**: An SMA can act as dynamic support during uptrends or dynamic resistance during downtrends. Traders watch for price bounces off the moving average as confirmation of trend strength.

- **Crossover signals**: When a faster SMA (e.g., 10-period) crosses above a slower SMA (e.g., 50-period), it may signal a bullish shift; a cross below signals bearish momentum. These "golden cross" and "death cross" events are popular entry and exit triggers.

- **Mean reversion**: Some traders use SMAs to identify overbought or oversold conditions, betting that price will revert toward the average.

**Where interpretation breaks down**

The SMA has important limitations:

- **Lag**: Because it averages historical prices, the SMA always lags current price action. During sharp reversals, the SMA may not respond quickly enough to warn traders of a trend change.

- **Whipsaws in choppy markets**: In sideways or range-bound markets, price may cross the SMA repeatedly without establishing a clear trend, generating false signals.

- **Period selection is arbitrary**: There is no universally "correct" period length. A 20-period SMA works well in some markets and timeframes but poorly in others. Traders often must test multiple periods or rely on convention.

- **No predictive power**: The SMA is a lagging indicator. It describes what has already happened, not what will happen next. Relying solely on SMA crossovers without additional confirmation often leads to late entries and exits.

- **Equal weighting**: Every price in the window receives the same weight, even though recent prices are arguably more relevant. This can make the SMA less responsive than alternatives like the Exponential Moving Average (EMA).

Despite these drawbacks, the SMA remains popular because it is simple, transparent, and works reasonably well as part of a broader trading system. Many traders combine it with other indicators—such as momentum oscillators, volume analysis, or support/resistance levels—to filter out false signals and improve decision-making.

## Text Formula

**Simple Moving Average (SMA)**

SMA = (P₁ + P₂ + P₃ + ... + Pₙ) / n

Where:
- P₁, P₂, ..., Pₙ = closing prices (or other price data) for the last n periods
- n = the number of periods in the lookback window

**Example calculation for a 5-period SMA:**

If closing prices for the last 5 days are: 100, 102, 101, 103, 104

SMA = (100 + 102 + 101 + 103 + 104) / 5 = 510 / 5 = 102

## Python Code

```python
import pandas as pd

def calculate_sma(df, periods):
    """
    Calculate Simple Moving Average for one or more symbols.
    
    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame with columns: symbol, date, open, high, low, close
        Data should be sorted by symbol and date in ascending order.
    
    periods : int or list of int
        Period(s) for the SMA calculation. If a list, multiple SMAs are calculated.
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with new columns: SMA_{period} for each period requested.
    """
    
    # Ensure periods is a list
    if isinstance(periods, int):
        periods = [periods]
    
    # Create a copy to avoid modifying the original
    result = df.copy()
    
    # Calculate SMA for each symbol independently
    for symbol in result['symbol'].unique():
        symbol_mask = result['symbol'] == symbol
        
        for period in periods:
            # Calculate the SMA using rolling window
            result.loc[symbol_mask, f'SMA_{period}'] = (
                result.loc[symbol_mask, 'close']
                .rolling(window=period, min_periods=1)
                .mean()
            )
    
    return result


# Example usage (not executed, for documentation):
# 
# Assume df is a DataFrame with columns: symbol, date, open, high, low, close
# 
# df = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL', 'AAPL', 'AAPL', 'AAPL'],
#     'date': pd.date_range('2024-01-01', periods=5),
#     'open': [150, 151, 152, 151, 153],
#     'high': [152, 153, 154, 153, 155],
#     'low': [149, 150, 151, 150, 152],
#     'close': [151, 152, 153, 152, 154]
# })
#
# result = calculate_sma(df, periods=[5, 20, 50])
# print(result[['symbol', 'date', 'close', 'SMA_5', 'SMA_20', 'SMA_50']])
```
```json
{ "model_code": "x2vp7k8nm4rj", "topic": "Simple Moving Average", "timer_secs": 12.00, "tokens_in": 608, "tokens_out": 1532, "cost_tokens_in": 0.00060800, "cost_tokens_out": 0.00766000, "cost_tokens_tot": 0.00826800 }
```