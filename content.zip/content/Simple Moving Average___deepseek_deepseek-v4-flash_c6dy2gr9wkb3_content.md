# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is a lagging, trend-following indicator that calculates the average price of a security over a specified number of periods. On a price chart, the SMA appears as a smooth line that follows the price action, rising as prices rise and falling as prices fall. The SMA is one of the oldest and most widely used technical indicators; its origins trace back to early 20th-century commodity trading, and it was popularized in modern technical analysis by pioneers such as Charles Dow and later by John J. Murphy in his seminal works on technical analysis. It is the foundational building block for many more complex moving average variants, including the Exponential Moving Average (EMA) and the Weighted Moving Average (WMA).

## Details

The SMA is calculated by taking the arithmetic mean of a given set of price values over a specific number of periods. As each new period ends, the oldest price in the average is dropped and the newest price is added, causing the line to "move" forward. The most commonly used price is the *closing price*, but traders may apply the SMA to the high, low, open, or any derived value (e.g., the typical price = (high + low + close) / 3).

Traders interpret the SMA in several key ways:

- **Trend Direction**: When price is above the SMA, the trend is considered bullish; when price is below, the trend is considered bearish. The slope of the SMA itself indicates trend strength — rising slope reinforces an uptrend, falling slope reinforces a downtrend.
- **Support and Resistance**: In an uptrend, the SMA often acts as a dynamic support level where price bounces higher. In a downtrend, it acts as resistance where price rallies are rejected.
- **Crossover Signals**: Two SMAs of different periods (e.g., a 50-period and a 200-period) are used together. A "golden cross" occurs when a shorter-term SMA crosses above a longer-term SMA, signaling a potential uptrend. A "death cross" occurs when the shorter-term crosses below, signaling a potential downtrend.
- **Entry/Exit Triggers**: Some traders buy when price closes above a key SMA and sell when it closes below it, often in combination with other confirmations like volume or momentum oscillators.

**Where interpretation breaks down**: The SMA's major weakness is its inherent lag. Because it weights all periods equally, it reacts slowly to sudden price changes. A sharp reversal may be well underway before the SMA line bends, causing late entry or exit signals. In choppy, sideways markets, price whipsaws above and below the SMA frequently, generating false signals and leading to poor trading performance. The SMA is also sensitive to the choice of lookback period: shorter periods (e.g., 10 or 20) are more responsive but noisier, while longer periods (e.g., 200) are smoother but slower to react. Furthermore, past data does not guarantee future support/resistance levels; a level that held previously may fail without notice.

## Text Formula

The Simple Moving Average (SMA) for period `n` at time `t` is calculated as:

```
SMA(t) = (Price(t - n + 1) + Price(t - n + 2) + ... + Price(t - 1) + Price(t)) / n
```

Where:
- `t` = current time period
- `n` = number of periods in the moving average (the lookback window)
- `Price` = the chosen price value (typically the closing price, `Close`)

The SMA is undefined for the first `n - 1` periods of the dataset, as there are not enough historical observations to form a complete window. After that, the value updates each period by removing the oldest observation and adding the newest.

## Python Code

```python
import pandas as pd
import numpy as np

def simple_moving_average(
    df: pd.DataFrame,
    column: str = "close",
    windows: list[int] = [10, 20, 50, 200]
) -> pd.DataFrame:
    """
    Compute Simple Moving Averages (SMA) for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data should be sorted by symbol and then date ascending.
    column : str, optional
        Price column to use for SMA calculation (default 'close').
    windows : list of int, optional
        Lookback periods for which to compute SMAs (default [10,20,50,200]).

    Returns
    -------
    pd.DataFrame
        Original dataframe with additional columns named 'sma_<window>'
        for each window in the input list. Rows that do not have enough
        prior data for a given window will have NaN for that SMA column.

    Notes
    -----
    - The DataFrame is assumed to be sorted by symbol and date.
    - Calculation is performed independently per symbol using groupby.
    - The function does not modify the original DataFrame; it returns a copy.
    """
    # Ensure we work on a sorted copy
    df_sorted = df.sort_values(["symbol", "date"]).copy()

    # Create SMA columns initialized to NaN
    for w in windows:
        col_name = f"sma_{w}"
        df_sorted[col_name] = np.nan

    # Compute SMA per symbol using groupby rolling
    for w in windows:
        col_name = f"sma_{w}"
        # Rolling mean on the price column within each symbol group
        # rolling() defaults to using the current and previous w-1 rows
        # min_periods=w ensures NaN for insufficient data
        grouped = df_sorted.groupby("symbol")[column].transform(
            lambda x: x.rolling(window=w, min_periods=w).mean()
        )
        df_sorted[col_name] = grouped

    return df_sorted

# Example usage (assuming 'data' is a DataFrame with required columns):
# result = simple_moving_average(data, column='close', windows=[20, 50, 200])
# print(result[[ 'symbol', 'date', 'close', 'sma_20', 'sma_50', 'sma_200' ]].head())
```
```json
{ "model_code": "c6dy2gr9wkb3", "topic": "Simple Moving Average", "timer_secs": 17.33, "tokens_in": 560, "tokens_out": 1344, "cost_tokens_in": 0.00007840, "cost_tokens_out": 0.00037632, "cost_tokens_tot": 0.00045472 }
```