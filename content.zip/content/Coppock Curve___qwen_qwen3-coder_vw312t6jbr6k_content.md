# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum indicator used primarily to identify potential buy signals in stock markets, particularly for long-term investing. It appears on price charts as a single oscillating line, typically colored to distinguish it from price action. The indicator was developed by Edwin Coppock in 1962 and originally published in *Barron's*. Coppock designed it to help investors spot significant bottoms in major stock indices after prolonged bear markets.

## Details
The Coppock Curve is calculated using a combination of two rates of change (ROC) and a weighted moving average. Specifically, it uses a 10-month weighted moving average of the sum of a 14-month ROC and an 11-month ROC. This construction makes it sensitive to long-term momentum shifts while filtering out short-term noise.

Traders and investors typically interpret the Coppock Curve as a **buy signal generator**. A buy signal is triggered when the indicator turns upward from negative territory, suggesting that long-term momentum is beginning to improve. Some traders also look for **centerline crossovers** (when the curve crosses above or below zero) or **divergences** between price and the indicator to confirm reversals.

Despite its utility, the Coppock Curve has limitations:
- It is a lagging indicator due to its long calculation periods.
- It is most effective on major indices rather than individual stocks.
- It may generate false signals during prolonged sideways markets.
- It is not designed for short-term trading and should not be used in isolation.

Because of its design, the Coppock Curve is best suited for long-term investors looking to identify accumulation phases in bear markets.

## Text Formula
The Coppock Curve is calculated using the following steps:

1. Calculate the 14-period Rate of Change (ROC):
   `ROC_14 = (close - close[14]) / close[14]`

2. Calculate the 11-period Rate of Change (ROC):
   `ROC_11 = (close - close[11]) / close[11]`

3. Sum the two ROCs:
   `ROC_Sum = ROC_14 + ROC_11`

4. Apply a 10-period Weighted Moving Average (WMA) to the ROC_Sum:
   `Coppock_Curve = WMA(ROC_Sum, 10)`

## Python Code
```python
import pandas as pd

def coppock_curve(df):
    """
    Calculate the Coppock Curve for one or more symbols.
    
    Assumes input DataFrame has columns: symbol, date, open, high, low, close
    Returns DataFrame with additional column: coppock_curve
    """
    def calc_coppock(group):
        # Calculate ROC 14 and ROC 11
        group['roc_14'] = group['close'].pct_change(14)
        group['roc_11'] = group['close'].pct_change(11)
        
        # Sum of ROCs
        group['roc_sum'] = group['roc_14'] + group['roc_11']
        
        # 10-period Weighted Moving Average
        def wma(series, period=10):
            weights = list(range(1, period + 1))
            def inner(x):
                return (weights * x).mean() if len(x) == period else None
            return series.rolling(window=period).apply(inner, raw=True)
        
        group['coppock_curve'] = wma(group['roc_sum'], 10)
        return group[['symbol', 'date', 'close', 'coppock_curve']]
    
    result = df.groupby('symbol').apply(calc_coppock).reset_index(drop=True)
    return result
```
```json
{ "model_code": "vw312t6jbr6k", "topic": "Coppock Curve", "timer_secs": 8.39, "tokens_in": 563, "tokens_out": 790, "cost_tokens_in": 0.00012386, "cost_tokens_out": 0.00142200, "cost_tokens_tot": 0.00154586 }
```