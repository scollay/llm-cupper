# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is a foundational, lagging technical indicator used to smooth out price data and identify underlying market trends. On a price chart, it appears as a single, continuous line that trails the price action, filtering out short-term noise to reveal the broader directional bias. While its exact origins in financial trading are diffuse, the mathematical concept of the moving average was developed by statisticians like R.H. Hooker and G.U. Yule in the early 20th century. It was later adapted and popularized for commodity and equity trading by technical analysis pioneers such as Richard Donchian in the 1950s.

## Details

### Mechanics and Calculation
The SMA calculates the arithmetic mean of a security's price over a specified number of periods. As new price data is generated, the oldest data point in the sequence is dropped, causing the average to "move" forward in time. While the calculation can be applied to the `open`, `high`, or `low` columns, it is almost universally calculated using the `close` price. The closing price is generally considered the most critical valuation point of the trading session, representing the final consensus of market participants for that day.

### Trend Identification and Dynamic Levels
Traders use the slope and relative position of the SMA to gauge trend direction and momentum. 
* **Trend Direction:** When the price is trading above a rising SMA, the asset is considered to be in an uptrend. Conversely, price action below a falling SMA indicates a downtrend. A flat SMA suggests a ranging or consolidating market.
* **Support and Resistance:** In strong, established trends, the SMA often acts as a dynamic support level in an uptrend or a dynamic resistance level in a downtrend. Traders frequently look for pullbacks to the moving average as potential entry points to join the prevailing trend.

### Moving Average Crossovers
A ubiquitous trading strategy involves plotting two SMAs of different lengths on the same chart: a short-term SMA and a long-term SMA. 
* **Golden Cross:** Occurs when a short-term SMA (e.g., 50-period) crosses above a long-term SMA (e.g., 200-period), generating a bullish signal that suggests a long-term uptrend is beginning.
* **Death Cross:** Occurs when the short-term SMA crosses below the long-term SMA, generating a bearish signal that indicates a potential long-term downtrend.

### Choosing the Right Timeframe
The utility of an SMA depends heavily on the trader's time horizon. Day traders might use a 9-period or 20-period SMA to capture intraday momentum. Swing traders often rely on the 50-period SMA to manage positions held for days or weeks. Long-term investors and institutional algorithms heavily monitor the 200-period SMA to define the macroeconomic trend of an asset. Shorter SMAs hug the price closer, resulting in less lag but more noise. Longer SMAs are much smoother, reducing noise but significantly increasing lag.

### Limitations and Breakdowns
The primary flaw of the SMA is its inherent lag. Because it is entirely backward-looking, it will not predict trend reversals; it will only confirm them after a significant price move has already occurred. 

Furthermore, the SMA assigns equal weight to every data point in the window. A price from 200 days ago has the exact same mathematical impact on a 200-period SMA as yesterday's price. This equal weighting often fails to reflect current market psychology, which is why many active traders prefer the Exponential Moving Average (EMA) that applies heavier weighting to recent prices. 

Finally, in sideways or choppy markets, the price will repeatedly cross the SMA. Because the indicator lacks directional conviction in a range, it will generate a high volume of false signals known as whipsaws, leading to consecutive losing trades for crossover-based strategies.

## Text Formula

SMA = (P1 + P2 + P3 + ... + Pn) / n

Where:
* **SMA** = Simple Moving Average
* **P** = Price (typically the closing price) for a given period
* **n** = Total number of periods in the moving average window

## Python Code

```python
import pandas as pd

def calculate_sma(df: pd.DataFrame, short_window: int = 20, long_window: int = 50) -> pd.DataFrame:
    """
    Calculates Simple Moving Averages for one or more symbols independently.
    
    Expected DataFrame format (do not run this simulation, just use as a schema reference):
    df = pd.DataFrame({
        'symbol': ['AAPL', 'AAPL', 'MSFT', 'MSFT'],
        'date': ['2023-01-01', '2023-01-02', '2023-01-01', '2023-01-02'],
        'open': [150.0, 151.0, 240.0, 241.0],
        'high': [152.0, 153.0, 242.0, 243.0],
        'low': [149.0, 150.0, 239.0, 240.0],
        'close': [151.5, 152.5, 241.5, 242.5]
    })
    
    Parameters:
    df (pd.DataFrame): DataFrame containing 'symbol', 'date', 'open', 'high', 'low', 'close'.
    short_window (int): Number of periods for the short-term SMA.
    long_window (int): Number of periods for the long-term SMA.
    
    Returns:
    pd.DataFrame: Original DataFrame with added SMA columns.
    """
    
    # Ensure data is sorted chronologically within each symbol to prevent look-ahead bias
    df = df.sort_values(['symbol', 'date']).copy()
    
    # Define column names for the new indicators
    short_col = f'sma_{short_window}'
    long_col = f'sma_{long_window}'
    
    # Calculate the short-term SMA independently for each symbol
    # min_periods ensures NaN is returned until the full window is available
    df[short_col] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=short_window, min_periods=short_window).mean()
    )
    
    # Calculate the long-term SMA independently for each symbol
    df[long_col] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=long_window, min_periods=long_window).mean()
    )
    
    return df
```
```json
{ "model_code": "l8nf5cm3wph7", "topic": "Simple Moving Average", "timer_secs": 81.10, "tokens_in": 580, "tokens_out": 5138, "cost_tokens_in": 0.00072500, "cost_tokens_out": 0.01926750, "cost_tokens_tot": 0.01999250 }
```