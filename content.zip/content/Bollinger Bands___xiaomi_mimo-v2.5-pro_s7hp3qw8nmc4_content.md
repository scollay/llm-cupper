# Bollinger Bands

## Overview

Bollinger Bands are a volatility overlay developed by **John Bollinger** in the early 1980s. On a price chart they appear as three lines: a middle band (a simple moving average) flanked by an upper and lower band that expand and contract with recent price volatility. The indicator helps traders assess whether prices are relatively high or low, and to anticipate periods of consolidation followed by breakout.

## Details

**Construction**

The standard setup uses a **20-period simple moving average** (SMA) as the middle band. The upper band is placed two standard deviations above that SMA; the lower band sits two standard deviations below it. Because the standard deviation is recalculated over the same window, the bands dynamically adapt—widening during volatile moves and narrowing during quiet ones.

**How traders interpret the bands**

- **Mean-reversion signals.** Many traders treat the bands as a dynamic support-and-resistance envelope. Price reaching the upper band may prompt short setups; price touching the lower band may prompt longs—assuming price will revert toward the middle SMA. This works best in range-bound conditions.

- **The Bollinger Squeeze.** When the bands contract sharply, volatility is compressed. A squeeze often precedes a significant directional move, though the bands alone do not signal *direction*. Traders watch for a decisive close outside the bands after a squeeze as breakout confirmation.

- **Walking the bands.** In a strong trend, price can "walk" along the upper band (uptrend) or lower band (downtrend) for many bars. Each touch of a band is **not** an automatic reversal signal—fading a strong trend just because price is at the upper or lower band is a common mistake.

- **Pattern recognition.** Bollinger described two patterns: the **W-bottom** (a double bottom where the second low holds near the lower band while a momentum indicator improves) and the **M-top** (a double top where the second high fails to reach the upper band while momentum fades).

**Derived measures**

Two secondary values extend the basic bands:

- **%B** quantifies where the latest close sits *within* the bands. A value of 1.0 means price is exactly at the upper band; 0.0 means it is at the lower band. Values above 1.0 or below 0.0 indicate price has moved outside the bands—useful for screening and building systematic rules.

- **Bandwidth** normalizes the distance between the bands by dividing it by the middle band. It gives a single number for comparing volatility across securities or over time, and is the most common way to quantify a squeeze programmatically.

**Where interpretation breaks down**

- **Trending markets.** Mean-reversion logic assumes price oscillates within the envelope. In a sustained trend, price can close outside the bands repeatedly; fading those moves can produce steep losses.
- **Lag.** The bands are built on a moving average and a rolling standard deviation, making them inherently backward-looking. By the time a squeeze resolves, the optimal entry may have already passed.
- **Parameter sensitivity.** The default 20 / 2 setting works reasonably well on many daily charts, but shorter timeframes, less liquid instruments, or different asset classes may require tuning. There is no universally "correct" setting.
- **False breakouts.** A close outside the bands does not guarantee continuation. Price can briefly pierce a band and snap back, especially in choppy, range-bound markets.

## Text Formula

**Inputs:** closing price series `C`, lookback period `N` (default 20), multiplier `K` (default 2).

1. **Middle Band (MB):**
   `MB = SMA(C, N)` — the simple moving average of the last *N* closes.

2. **Standard Deviation (σ):**
   `σ = StdDev(C, N)` — the population standard deviation of the last *N* closes.

3. **Upper Band (UB):**
   `UB = MB + K × σ`

4. **Lower Band (LB):**
   `LB = MB − K × σ`

5. **%B:**
   `%B = (C − LB) / (UB − LB)`

6. **Bandwidth (BW):**
   `BW = (UB − LB) / MB`

## Python Code

```python
import pandas as pd


def bollinger_bands(
    df: pd.DataFrame,
    period: int = 20,
    num_std: float = 2.0,
) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data for multiple symbols is supported; each symbol is processed
        independently via groupby.
    period : int
        Lookback window for the SMA and standard deviation (default 20).
    num_std : float
        Number of standard deviations for the bands (default 2.0).

    Returns
    -------
    pd.DataFrame
        Original columns plus: bb_mid, bb_upper, bb_lower, bb_pct_b,
        bb_bandwidth. Rows where a full window is not yet available
        contain NaN.
    """
    df = df.sort_values(["symbol", "date"]).copy()

    close_grouped = df.groupby("symbol")["close"]

    # Middle band: simple moving average
    df["bb_mid"] = close_grouped.transform(
        lambda s: s.rolling(window=period, min_periods=period).mean()
    )

    # Rolling population standard deviation (ddof=0)
    df["bb_std"] = close_grouped.transform(
        lambda s: s.rolling(window=period, min_periods=period).std(ddof=0)
    )

    # Upper and lower bands
    df["bb_upper"] = df["bb_mid"] + num_std * df["bb_std"]
    df["bb_lower"] = df["bb_mid"] - num_std * df["bb_std"]

    # %B: position of close relative to the bands
    band_range = df["bb_upper"] - df["bb_lower"]
    df["bb_pct_b"] = (df["close"] - df["bb_lower"]) / band_range

    # Bandwidth: normalized distance between the bands
    df["bb_bandwidth"] = band_range / df["bb_mid"]

    # Drop the intermediate standard-deviation column
    df.drop(columns=["bb_std"], inplace=True)

    return df
```
```json
{ "model_code": "s7hp3qw8nmc4", "topic": "Bollinger Bands", "timer_secs": 82.29, "tokens_in": 807, "tokens_out": 3387, "cost_tokens_in": 0.00080700, "cost_tokens_out": 0.01016100, "cost_tokens_tot": 0.01096800 }
```