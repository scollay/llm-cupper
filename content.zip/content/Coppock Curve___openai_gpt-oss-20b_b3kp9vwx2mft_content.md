# Coppock Curve

## Overview
The Coppock Curve is a long‑term momentum indicator developed by Edmund R. Coppock in 1962. It is plotted as a single line on a price chart and is designed to identify the beginning of a bullish trend. The curve is typically drawn on a daily chart and is most useful for swing and position traders rather than day traders. Coppock’s original publication was in the *Journal of the American Stock Exchange* and the indicator has since become a staple in many technical analysis toolkits.

## Details
### How It Works
The Coppock Curve is built from three core components:

1. **Rate‑of‑Change (ROC)**  
   Two ROC values are calculated: a 14‑period ROC and an 11‑period ROC.  
   ROC measures the percentage change between the current close and the close `n` periods ago.

2. **Sum of ROCs**  
   The two ROC values are added together to produce a single “sum‑ROC” series.  
   This step amplifies the momentum signal by combining two different time horizons.

3. **Weighted Moving Average (WMA)**  
   The sum‑ROC is smoothed with a 10‑period WMA.  
   The WMA gives more weight to recent data, which helps the curve react to changes in momentum while still filtering out noise.

The resulting line is plotted against a zero baseline. A bullish signal is typically generated when the Coppock Curve rises above zero after a prolonged trough, indicating that momentum is turning positive. Some traders also look for a “turn‑up” from a trough regardless of the zero line, interpreting the upward bend as a potential entry point.

### Typical Interpretation
- **Bullish Turn‑Up**: The curve moves from a low point upward, often crossing above zero. This is considered a long‑term buying signal.  
- **Crossing Zero**: When the curve crosses above zero after a period of negative values, it is interpreted as a confirmation of a bullish trend.  
- **Crossing Below Zero**: A downward turn or crossing below zero can signal a potential reversal or a weakening trend.

Traders often combine the Coppock Curve with other tools, such as moving averages or trendlines, to filter out false signals. Because the indicator is lagging (due to the 10‑period WMA), it is best suited for identifying the *start* of a trend rather than timing precise entries or exits.

### Where the Interpretation Breaks Down
1. **Lagging Nature**  
   The 10‑period WMA introduces a significant lag. In fast‑moving markets, the signal may arrive too late, causing missed opportunities or premature exits.

2. **False Signals in Sideways Markets**  
   In a range‑bound market, the Coppock Curve can oscillate around zero, producing multiple false crossovers. Traders may interpret these as trend changes when the market is actually flat.

3. **Sensitivity to ROC Periods**  
   The choice of 14‑ and 11‑period ROCs is somewhat arbitrary. Different asset classes or timeframes may require adjustment. Using the default periods on a highly volatile asset can produce noisy signals.

4. **Over‑Smoothing**  
   The 10‑period WMA smooths the sum‑ROC aggressively. In markets with rapid momentum shifts, this smoothing can mask sharp turns, delaying the signal.

Because of these limitations, many practitioners recommend using the Coppock Curve in conjunction with volume indicators or trend‑strength measures to confirm signals.

## Text Formula
Let `C_t` be the closing price at time `t`.  
Define:

```
ROC_n(t) = (C_t / C_{t-n}) - 1
```

where `n` is the period (11 or 14).  
Compute the sum of the two ROCs:

```
SumROC(t) = ROC_14(t) + ROC_11(t)
```

Finally, apply a 10‑period weighted moving average (WMA) to `SumROC`:

```
Coppock(t) = WMA_10(SumROC)(t)
```

The WMA is calculated as:

```
WMA_k(x_t) = ( Σ_{i=0}^{k-1} (k-i) * x_{t-i} ) / ( Σ_{i=0}^{k-1} (k-i) )
```

where `k = 10`.  
The Coppock Curve is plotted as `Coppock(t)` against a zero baseline.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
        The dataframe may contain multiple symbols; calculations are performed
        per symbol independently.

    Returns
    -------
    pd.DataFrame
        Original dataframe with additional columns:
        - 'roc_14': 14‑period Rate‑of‑Change
        - 'roc_11': 11‑period Rate‑of‑Change
        - 'sum_roc': sum of the two ROCs
        - 'coppock': 10‑period Weighted Moving Average of sum_roc
    """
    # Ensure the dataframe is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Group by symbol to keep calculations independent
    grouped = df.groupby('symbol', group_keys=False)

    # Helper function to compute ROC
    def _roc(series: pd.Series, period: int) -> pd.Series:
        return series / series.shift(period) - 1

    # Helper function to compute weighted moving average
    def _wma(series: pd.Series, window: int) -> pd.Series:
        # Weights: most recent period gets highest weight
        weights = np.arange(window, 0, -1)  # e.g., [10,9,...,1] for window=10
        return series.rolling(window, min_periods=window).apply(
            lambda x: np.dot(x, weights) / weights.sum(), raw=True
        )

    # Apply calculations per symbol
    df['roc_14'] = grouped['close'].apply(lambda s: _roc(s, 14))
    df['roc_11'] = grouped['close'].apply(lambda s: _roc(s, 11))
    df['sum_roc'] = df['roc_14'] + df['roc_11']
    df['coppock'] = grouped['sum_roc'].apply(lambda s: _wma(s, 10))

    return df
```

The function `calculate_coppock` accepts a DataFrame with the required columns, sorts it, groups by symbol, and computes the 14‑period ROC, 11‑period ROC, their sum, and finally the 10‑period weighted moving average of that sum. The result is returned with the new columns appended, ready for plotting or further analysis.
```json
{ "model_code": "b3kp9vwx2mft", "topic": "Coppock Curve", "timer_secs": 30.81, "tokens_in": 622, "tokens_out": 2098, "cost_tokens_in": 0.00001804, "cost_tokens_out": 0.00029372, "cost_tokens_tot": 0.00031176 }
```