# Bollinger Bands

## Overview
Bollinger Bands are a volatility-focused technical indicator consisting of three lines plotted around a price series: a middle simple moving average (SMA), and upper and lower bands set a fixed number of standard deviations above and below the SMA. Developed by technical analyst John Bollinger in the 1980s, the indicator automatically adjusts to changes in price volatility, widening during high volatility and narrowing during low volatility. It appears on price charts as dynamic envelopes surrounding price action, and is used by traders to identify overbought/oversold conditions, volatility shifts, and trend strength.

## Details
### Construction
Bollinger Bands consist of three lines plotted around a price series. The middle band is a simple moving average (SMA) of closing prices, almost always a 20-period SMA by default, though traders adjust the lookback to match their timeframe (e.g., 50-period for weekly charts, 10-period for day trading). The upper and lower bands are set `k` standard deviations above and below the middle band, with `k=2` as the standard default. The standard deviation is calculated using closing prices over the same lookback window as the SMA, so bands automatically widen during high price volatility and narrow during low volatility.

### Core Interpretations
Traders use the indicator for three primary signals:
1. **Volatility signals**: A contraction of the bands (a **squeeze**) signals falling volatility, which historically precedes sharp price moves, though the direction of the breakout is not predicted by the squeeze alone. A move above the upper band or below the lower band confirms the start of a volatility expansion.
2. **Mean reversion signals**: In ranging markets, price touching the upper band is interpreted as overbought, and touching the lower band as oversold, with a high probability of price reverting to the middle band (the **Bollinger Bounce**).
3. **Trend confirmation**: In strong uptrends, price frequently rides the upper band for extended periods, with pullbacks stopping at the middle band; in strong downtrends, price clings to the lower band, with rallies stopping at the middle. This makes the middle band a dynamic support/resistance level in trending markets.

### Limitations
The biggest pitfall is treating band touches as automatic overbought/oversold signals during strong trends: in a sustained bull market, price can stay above the upper band for weeks, and selling on upper band touches leads to missed gains. Similarly, in a bear market, price can stay below the lower band for extended periods. Squeezes can also take weeks or months to resolve, leading to false breakout signals if traders enter too early on an initial move outside the bands. The indicator works best when combined with other tools, such as the Relative Strength Index (RSI) to confirm overbought/oversold conditions, or volume indicators to validate breakout strength.

## Text Formula
The standard Bollinger Band calculation uses three core inputs:
- `n`: Lookback period (default: 20)
- `k`: Standard deviation multiplier (default: 2)
- `close_t`: Closing price at period `t`

1. **Middle Band (MB)**: The `n`-period simple moving average of closing prices:
   `MB_t = (1/n) * Σ close_{t - i + 1} for i = 1 to n`
2. **Sample Standard Deviation (SD)**: The sample standard deviation of closing prices over the same `n`-period window (uses Bessel’s correction, `ddof=1`):
   `SD_t = sqrt( (1/(n-1)) * Σ (close_{t - i + 1} - MB_t)^2 for i = 1 to n )`
3. **Upper Band (UB)**:
   `UB_t = MB_t + (k * SD_t)`
4. **Lower Band (LB)**:
   `LB_t = MB_t - (k * SD_t)`

The first `n-1` periods for any given symbol will return `NaN` values, as there is insufficient historical data to compute the SMA and standard deviation.

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df: pd.DataFrame, n: int = 20, k: float = 2.0) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for a DataFrame of price data, handling multiple symbols independently.
    
    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with required columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
        Must be sorted by ['symbol', 'date'] in ascending order for correct rolling calculations.
    n : int, default 20
        Lookback period for the middle band (SMA) and standard deviation calculation.
    k : float, default 2.0
        Standard deviation multiplier for upper and lower bands.
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with three new columns:
        - 'bollinger_middle': n-period SMA of closing prices
        - 'bollinger_upper': upper band = middle + (k * n-period sample std of close)
        - 'bollinger_lower': lower band = middle - (k * n-period sample std of close)
        First n-1 rows per symbol will have NaN values for all band columns.
    """
    # Validate required columns exist
    required_cols = ['symbol', 'date', 'open', 'high', 'low', 'close']
    if not all(col in df.columns for col in required_cols):
        raise ValueError(f"Input DataFrame missing required columns: {required_cols}")
    
    # Ensure data is sorted by symbol then date for correct rolling calculations
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate rolling metrics per symbol group
    grouped = df.groupby('symbol')['close']
    
    # Middle band: n-period simple moving average of close
    df['bollinger_middle'] = grouped.rolling(window=n, min_periods=n).mean().reset_index(level=0, drop=True)
    
    # Sample standard deviation of close over n periods (ddof=1 for sample std, matching standard Bollinger Band calculation)
    rolling_std = grouped.rolling(window=n, min_periods=n).std(ddof=1).reset_index(level=0, drop=True)
    
    # Upper and lower bands
    df['bollinger_upper'] = df['bollinger_middle'] + (k * rolling_std)
    df['bollinger_lower'] = df['bollinger_middle'] - (k * rolling_std)
    
    return df
```
```json
{ "model_code": "rps2b8a4fpay", "topic": "Bollinger Bands", "timer_secs": 35.01, "tokens_in": 568, "tokens_out": 7115, "cost_tokens_in": 0.00011360, "cost_tokens_out": 0.00818225, "cost_tokens_tot": 0.00829585 }
```