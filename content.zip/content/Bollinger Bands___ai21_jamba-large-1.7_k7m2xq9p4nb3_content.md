# Bollinger Bands

## Overview
Bollinger Bands are a volatility indicator that consists of a middle band (a simple moving average) and two outer bands that are standard deviations above and below the middle band. They were created by John Bollinger in the 1980s and are used to identify overbought or oversold conditions, as well as potential trend reversals or continuations. The bands appear as three lines on a price chart, dynamically adjusting to market volatility.

## Details
Bollinger Bands are calculated using a **simple moving average (SMA)** of the closing prices and two standard deviation levels above and below this SMA. The standard deviation measures volatility, so the bands expand when volatility increases and contract when it decreases.

Traders typically interpret the following:

- **Price near the upper band**: The asset may be overbought, suggesting a potential reversal or pullback.
- **Price near the lower band**: The asset may be oversold, suggesting a potential bounce.
- **Band squeeze**: When the bands contract tightly, it indicates low volatility and often precedes a sharp price movement (a "breakout").
- **Price moving between the bands**: This can suggest a trending market, with the middle band acting as support in an uptrend or resistance in a downtrend.

However, interpretations can break down in choppy or range-bound markets where prices frequently touch both bands without clear direction. Additionally, Bollinger Bands are not predictive; they are reactive to past price action and volatility. False breakouts can occur when prices briefly move outside the bands but revert quickly.

## Text Formula
The formula for Bollinger Bands is as follows:

- **Middle Band (SMA)**: $SMA_n = \frac{1}{n} \sum_{i=1}^n C_i$
where $C_i$ is the close price and $n$ is the lookback period.
- **Upper Band**: $SMA_n + k \cdot \sigma_n$
where $\sigma_n$ is the standard deviation of prices over $n$ periods and $k$ is a multiplier (commonly 2).
- **Lower Band**: $SMA_n - k \cdot \sigma_n$

## Python Code

```python
import pandas as pd
import numpy as np

def bollinger_bands(data, n=20, k=2):
    """
    Calculate Bollinger Bands for a given DataFrame.
    
    Parameters:
    - data: Pandas DataFrame with columns `close` (closing prices).
    - n: Lookback period for the SMA and standard deviation (default 20).
    - k: Multiplier for standard deviation (default 2).
    
    Returns:
    - A DataFrame with added columns: `sma`, `upper_band`, `lower_band`.
    """
    # Calculate the SMA
    data['sma'] = data['close'].rolling(window=n).mean()
    
    # Calculate the standard deviation
    data['std_dev'] = data['close'].rolling(window=n).std()
    
    # Calculate the upper and lower bands
    data['upper_band'] = data['sma'] + k * data['std_dev']
    data['lower_band'] = data['sma'] - k * data['std_dev']
    
    return data

# Example usage:
# Assume `df` is a DataFrame with columns `symbol`, `date`, `open`, `high`, `low`, `close`.
# To calculate Bollinger Bands for each symbol independently:
# grouped = df.groupby('symbol')
# result = grouped.apply(bollinger_bands)
```

This code calculates the SMA, standard deviation, and the upper and lower bands for each symbol in the DataFrame. It assumes the input DataFrame has the required columns (`close` in this case) and handles the calculation for the specified lookback period `n` and standard deviation multiplier `k`.
```json
{ "model_code": "k7m2xq9p4nb3", "topic": "Bollinger Bands", "timer_secs": 16.77, "tokens_in": 602, "tokens_out": 899, "cost_tokens_in": 0.00120400, "cost_tokens_out": 0.00719200, "cost_tokens_tot": 0.00839600 }
```