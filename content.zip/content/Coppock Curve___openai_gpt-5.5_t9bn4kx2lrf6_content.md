# Coppock Curve

## Overview

The Coppock Curve is a long-term momentum indicator designed to identify major buying opportunities, especially in broad equity indexes. It appears as a single oscillator line, usually plotted below price, that rises and falls around a zero line.

The indicator was created by economist Edwin Sedgwick Coppock and introduced in 1962. Coppock originally designed it for monthly charts of stock market indexes, not for short-term trading. Its classic form uses 11-month and 14-month rates of change, smoothed by a 10-month weighted moving average.

## Details

The Coppock Curve is a smoothed momentum measure. It adds two rates of change together, then applies a weighted moving average to the result:

- A shorter rate of change, traditionally 11 periods
- A longer rate of change, traditionally 14 periods
- A 10-period weighted moving average of their sum

In its original use, each “period” meant one month. On a monthly chart, the Coppock Curve is slow moving and intended to capture major cyclical shifts rather than frequent trading signals. Traders sometimes apply it to weekly or daily data, but doing so changes the character of the indicator and usually increases noise.

### How the Coppock Curve Works

A rate of change measures how far price has moved compared with a prior period. For example, an 11-period rate of change compares today’s close with the close 11 bars ago. If price is higher, the ROC is positive; if price is lower, the ROC is negative.

The Coppock Curve combines an 11-period ROC and a 14-period ROC. This gives the indicator two overlapping views of medium-term momentum. The combined value is then smoothed with a weighted moving average, which gives more importance to recent observations.

The result is a momentum curve that tends to move lower during bear markets or deep corrections and turn higher as downside momentum fades. Because it is smoothed, it is intentionally late. That lag is part of the design: the indicator tries to avoid reacting to every short-term bounce.

### Typical Interpretation

The classic Coppock Curve signal is a **turn upward from below zero** on a monthly chart. This is generally interpreted as a long-term buy signal.

A typical bullish setup has three parts:

1. The market has experienced a meaningful decline.
2. The Coppock Curve is below zero, showing negative longer-term momentum.
3. The curve turns higher, suggesting that bearish momentum is easing.

Many traders do not use the Coppock Curve as a sell signal. Coppock’s original intent was to identify buying opportunities after significant market weakness, especially in stock indexes. In practice, some traders may watch for the curve to roll over from high levels, but that is a less canonical use and can produce early or ambiguous warnings during strong bull markets.

### Zero Line and Direction

The zero line is important because it separates positive and negative combined momentum.

- **Above zero:** The combined rate of change is generally positive.
- **Below zero:** The combined rate of change is generally negative.
- **Rising below zero:** Downside momentum may be improving.
- **Falling below zero:** Weakness may still be intensifying.

A simple zero-line crossover can be useful context, but the traditional signal is not merely crossing above zero. By the time the curve crosses above zero, a large part of the rebound may already have occurred. The earlier signal is the upward turn while the curve is still negative.

### Strengths

The Coppock Curve’s main strength is its focus on major trend recovery rather than short-term timing. It can help traders avoid the urge to buy every dip in a falling market. By requiring enough time for long-term momentum to stabilize, it tends to identify periods when the probability of a durable bottom has improved.

It is especially suited to:

- Broad equity indexes
- Monthly data
- Long-only market timing
- Identifying recovery phases after bear markets

The indicator can also help traders maintain perspective. In fast markets, daily volatility can distort judgment. A monthly Coppock Curve compresses that noise into a slower, more strategic signal.

### Where Interpretation Breaks Down

The Coppock Curve is not a precise entry tool. It may signal after a market has already rallied substantially from its low. This is expected because it is a lagging indicator built from smoothed historical momentum.

It can also struggle in sideways markets. If price repeatedly rises and falls without establishing a durable trend, the curve may generate turns that do not lead to meaningful follow-through.

Other limitations include:

- **Parameter sensitivity:** The traditional 11, 14, and 10 settings were designed for monthly charts. Applying them to daily data does not produce the same type of signal.
- **Asset sensitivity:** The indicator was built for stock indexes. Individual stocks, commodities, currencies, and leveraged instruments may behave differently.
- **No risk management:** The Coppock Curve does not define position size, stop placement, or downside risk.
- **Poor short signals:** It is commonly used to find long-term buy setups, not to call tops.

Traders often combine it with price structure, trend filters, breadth, moving averages, or macro context. For example, a Coppock upturn below zero may carry more weight if the index has reclaimed a long-term moving average or formed a higher low.

## Text Formula

Let:

- `Close_t` = closing price at period `t`
- `ROC_short_t` = short rate of change, traditionally 11 periods
- `ROC_long_t` = long rate of change, traditionally 14 periods
- `ROC_sum_t` = combined rate of change
- `WMA_period` = weighted moving average length, traditionally 10 periods
- `CC_t` = Coppock Curve value at period `t`

Short rate of change:

`ROC_short_t = ((Close_t / Close_{t - short_period}) - 1) * 100`

Using the traditional setting:

`ROC_11_t = ((Close_t / Close_{t - 11}) - 1) * 100`

Long rate of change:

`ROC_long_t = ((Close_t / Close_{t - long_period}) - 1) * 100`

Using the traditional setting:

`ROC_14_t = ((Close_t / Close_{t - 14}) - 1) * 100`

Combined rate of change:

`ROC_sum_t = ROC_short_t + ROC_long_t`

Weighted moving average weights:

For a `WMA_period` of `N`, use weights from `1` to `N`, with the largest weight applied to the most recent value.

`Weight_i = i`, for `i = 1, 2, ..., N`

Weighted moving average:

`WMA_t = (Value_{t-N+1} * 1 + Value_{t-N+2} * 2 + ... + Value_t * N) / (1 + 2 + ... + N)`

Coppock Curve:

`CC_t = WMA(ROC_sum_t, WMA_period)`

Traditional Coppock Curve:

`Coppock Curve_t = 10-period WMA of (11-period ROC_t + 14-period ROC_t)`

## Python Code

```python
import numpy as np
import pandas as pd


def calculate_coppock_curve(
    df: pd.DataFrame,
    short_period: int = 11,
    long_period: int = 14,
    wma_period: int = 10,
    price_col: str = "close",
) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    The traditional Coppock Curve uses:
        short_period = 11
        long_period = 14
        wma_period = 10

    On the original monthly interpretation, each row should represent one month.
    If daily or weekly data is supplied, the same formula is applied to that row frequency.

    Returns a copy of the input DataFrame with added columns:
        coppock_roc_short
        coppock_roc_long
        coppock_roc_sum
        coppock_curve
    """

    required_columns = {"symbol", "date", "open", "high", "low", "close"}
    missing_columns = required_columns.difference(df.columns)
    if missing_columns:
        raise ValueError(f"DataFrame is missing required columns: {sorted(missing_columns)}")

    if short_period <= 0 or long_period <= 0 or wma_period <= 0:
        raise ValueError("short_period, long_period, and wma_period must be positive integers.")

    if price_col not in df.columns:
        raise ValueError(f"price_col '{price_col}' is not in the DataFrame.")

    result = df.copy()
    result = result.sort_values(["symbol", "date"]).reset_index(drop=True)

    grouped_price = result.groupby("symbol", group_keys=False)[price_col]

    result["coppock_roc_short"] = grouped_price.transform(
        lambda s: s.pct_change(periods=short_period) * 100.0
    )

    result["coppock_roc_long"] = grouped_price.transform(
        lambda s: s.pct_change(periods=long_period) * 100.0
    )

    result["coppock_roc_sum"] = (
        result["coppock_roc_short"] + result["coppock_roc_long"]
    )

    weights = np.arange(1, wma_period + 1, dtype=float)
    weight_sum = weights.sum()

    def weighted_moving_average(series: pd.Series) -> pd.Series:
        return series.rolling(window=wma_period, min_periods=wma_period).apply(
            lambda values: np.dot(values, weights) / weight_sum,
            raw=True,
        )

    result["coppock_curve"] = result.groupby("symbol", group_keys=False)[
        "coppock_roc_sum"
    ].transform(weighted_moving_average)

    return result
```
```json
{ "model_code": "t9bn4kx2lrf6", "topic": "Coppock Curve", "timer_secs": 42.14, "tokens_in": 559, "tokens_out": 2603, "cost_tokens_in": 0.00279500, "cost_tokens_out": 0.07809000, "cost_tokens_tot": 0.08088500 }
```