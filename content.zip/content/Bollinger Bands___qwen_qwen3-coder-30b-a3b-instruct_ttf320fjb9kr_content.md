# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator developed by John Bollinger in the 1980s. They consist of three lines plotted on a price chart: a simple moving average (SMA) of the closing price, and two outer bands positioned a fixed number of standard deviations above and below the SMA. The bands expand during periods of high volatility and contract during low volatility, visually framing price action. Traders use them to identify potential overbought or oversold conditions, volatility shifts, and breakout opportunities.

## Details
Bollinger Bands are calculated using a 20-period simple moving average (SMA) of closing prices, with the upper and lower bands set at two standard deviations from the SMA. The default settings are widely adopted, but traders may adjust the period or multiplier based on asset characteristics or timeframes.

The indicator’s primary function is to contextualize price relative to recent volatility. When price touches or exceeds the upper band, it may suggest the asset is overbought; when it touches or falls below the lower band, it may suggest oversold conditions. However, in strong trends, price can remain near or beyond the bands for extended periods — meaning band touches alone are not reliable reversal signals.

A key insight is that Bollinger Bands measure relative price position, not absolute value. A squeeze — when the bands narrow significantly — often precedes a sharp price move, signaling a potential breakout. Traders watch for volume surges or candlestick patterns following a squeeze to confirm direction.

Interpretation breaks down when applied mechanically. For example, in trending markets, price can stay beyond the bands without reversing. Relying solely on band touches as buy/sell signals leads to false signals. Additionally, the indicator assumes price returns to the mean, which is not always valid in persistent trends or during fundamental shifts. Bollinger Bands work best when combined with other indicators (e.g., RSI, volume) and context (e.g., support/resistance levels).

## Text Formula
Let:
- `close` be the closing price for each period
- `n` be the period length (typically 20)
- `k` be the number of standard deviations (typically 2)

1. Calculate the simple moving average (SMA) of the closing price over `n` periods:  
   `SMA = mean(close[-n:])`

2. Calculate the standard deviation of the closing price over `n` periods:  
   `std = stdev(close[-n:])`

3. Compute the upper band:  
   `Upper Band = SMA + (k * std)`

4. Compute the lower band:  
   `Lower Band = SMA - (k * std)`

The result is three time series: the middle band (SMA), the upper band, and the lower band, each aligned with the corresponding price bar.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_bollinger_bands(df, period=20, std_dev=2):
    """
    Calculate Bollinger Bands for a DataFrame with columns: symbol, date, open, high, low, close.
    
    Assumes DataFrame may contain multiple symbols. Computes bands independently per symbol.
    
    Returns DataFrame with added columns:
        - bollinger_middle: SMA of close over `period`
        - bollinger_upper: SMA + (std_dev * standard deviation of close)
        - bollinger_lower: SMA - (std_dev * standard deviation of close)
    
    Parameters:
        df (pd.DataFrame): Input data with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
        period (int): Lookback period for SMA and standard deviation (default 20)
        std_dev (float): Number of standard deviations for upper/lower bands (default 2)
    
    Returns:
        pd.DataFrame: Original DataFrame with three new columns appended
    """
    # Copy to avoid modifying original
    df = df.copy()
    
    # Sort by symbol and date to ensure chronological order within groups
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Initialize new columns
    df['bollinger_middle'] = np.nan
    df['bollinger_upper'] = np.nan
    df['bollinger_lower'] = np.nan
    
    # Group by symbol and compute bands independently
    for symbol in df['symbol'].unique():
        mask = df['symbol'] == symbol
        close_series = df.loc[mask, 'close']
        
        # Calculate SMA and standard deviation using rolling window
        sma = close_series.rolling(window=period).mean()
        std = close_series.rolling(window=period).std()
        
        # Compute upper and lower bands
        upper = sma + (std_dev * std)
        lower = sma - (std_dev * std)
        
        # Assign results back to the DataFrame
        df.loc[mask, 'bollinger_middle'] = sma
        df.loc[mask, 'bollinger_upper'] = upper
        df.loc[mask, 'bollinger_lower'] = lower
    
    return df
```
```json
{ "model_code": "ttf320fjb9kr", "topic": "Bollinger Bands", "timer_secs": 8.99, "tokens_in": 564, "tokens_out": 1079, "cost_tokens_in": 0.00003948, "cost_tokens_out": 0.00029133, "cost_tokens_tot": 0.00033081 }
```