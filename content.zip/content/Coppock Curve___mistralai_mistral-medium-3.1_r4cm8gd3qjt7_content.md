# Coppock Curve

## Overview
The **Coppock Curve** is a long-term momentum indicator designed to identify major bottoms in stock market indices. It appears as a single oscillating line plotted below a price chart, typically over monthly data. Developed by economist **Edwin "Sedge" Coppock** and published in *Barron’s* in **1962**, the indicator was originally created to signal buying opportunities in the **S&P 500** after prolonged bear markets. Coppock’s inspiration came from observing that market lows often occur **11–14 months** after a significant emotional or economic shock, aligning with the average duration of human grief cycles.

Traders and investors use the Coppock Curve primarily for **monthly charts** of broad indices (e.g., S&P 500, Dow Jones) to spot potential multi-year bullish reversals. It is *not* suited for short-term trading or individual stocks due to its lagging nature and reliance on long-term trends.

---

## Details

### **How It Works**
The Coppock Curve is a **weighted moving average of two rate-of-change (ROC) indicators**, smoothed to reduce volatility. Its key features:
1. **Dual ROC Inputs**: Combines a **14-month ROC** and an **11-month ROC** to capture intermediate-term momentum.
2. **Weighted Sum**: The 14-month ROC is given slightly more weight (typically 1.0) than the 11-month ROC (weight = 0.5).
3. **Smoothing**: The sum of the weighted ROCs is smoothed with a **10-period weighted moving average (WMA)** to filter out noise.

The indicator oscillates around a **zero line**:
- **Cross above zero**: Suggests a potential long-term buy signal, historically coinciding with the end of bear markets.
- **Cross below zero**: Rarely used as a sell signal; the indicator is optimized for identifying bottoms, not tops.

### **Interpretation**
- **Buy Signal**: A cross *above* zero after a prolonged downturn (e.g., following a recession or market crash). Coppock’s original research found this often preceded multi-year bull runs.
- **Strength of Signal**: The steeper the ascent from negative to positive, the stronger the implied reversal. Shallow crosses may indicate weak or false signals.
- **False Positives**: The indicator can whipsaw in **sideways markets** or during **short-lived corrections** (e.g., 2018’s late-year drop). It is *not* reliable for timing tops or short-term trades.

### **Limitations**
1. **Lagging Nature**: The Coppock Curve is designed for **monthly data** and reacts slowly. By the time it triggers, prices may have already risen significantly.
2. **Index-Specific**: Works best for **broad market indices** (e.g., S&P 500, Nasdaq Composite). Individual stocks or sectors often produce noisy or misleading signals.
3. **No Sell Signals**: Coppock did not intend the indicator for exit timing. Traders often pair it with other tools (e.g., moving averages, RSI) to manage risk.
4. **Secular Bull Markets**: May stay positive for years (e.g., 2009–2020), rendering it useless for intermediate-term timing.

### **Practical Use Cases**
- **Long-Term Investors**: Use to confirm major bottoms before deploying capital (e.g., post-2008, post-COVID-2020).
- **Asset Allocation**: Shift between equities and cash/bonds based on zero-line crosses.
- **Avoid Overtrading**: Ignore signals in **overbought markets** (e.g., when the curve is far above zero for extended periods).

---

## Text Formula
The Coppock Curve (`CC`) is calculated as follows:

1. **Rate of Change (ROC) Components**:
   ```
   ROC_14 = [(Close_t - Close_{t-14}) / Close_{t-14}] × 100
   ROC_11 = [(Close_t - Close_{t-11}) / Close_{t-11}] × 100
   ```

2. **Weighted Sum**:
   ```
   Weighted_ROC = (ROC_14 × 1.0) + (ROC_11 × 0.5)
   ```

3. **Smoothing (10-period WMA)**:
   ```
   CC_t = [Σ (Weighted_ROC_{t-i} × (11 - i)) for i = 0 to 9] / 66
   ```
   Where `66` is the sum of weights `(11 + 10 + 9 + ... + 2 + 1)`.

The final `CC` value is plotted as a line oscillating around zero.

---

## Python Code
```python
import pandas as pd

def coppock_curve(df):
    """
    Calculate the Coppock Curve for one or more symbols in a DataFrame.

    Args:
        df (pd.DataFrame): DataFrame with columns: symbol, date, open, high, low, close.
                          Assumes monthly data sorted by symbol and date.

    Returns:
        pd.DataFrame: Original DataFrame with added column `coppock_curve`.
    """
    # Ensure data is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Calculate ROC components
    df['roc_14'] = df.groupby('symbol')['close'].pct_change(periods=14) * 100
    df['roc_11'] = df.groupby('symbol')['close'].pct_change(periods=11) * 100

    # Weighted sum (14-month ROC × 1.0 + 11-month ROC × 0.5)
    df['weighted_roc'] = (df['roc_14'] * 1.0) + (df['roc_11'] * 0.5)

    # 10-period WMA of weighted_roc (weights: 10, 9, 8, ..., 1)
    # Pre-fill NaN values to avoid edge cases in rolling calculations
    df['coppock_curve'] = (
        df.groupby('symbol')['weighted_roc']
        .rolling(window=10, min_periods=1)
        .apply(lambda x: (x * (11 - np.arange(len(x)))).sum() / 66, raw=True)
        .reset_index(level=0, drop=True)
    )

    # Drop intermediate columns
    df = df.drop(columns=['roc_14', 'roc_11', 'weighted_roc'])

    return df
```

### **Notes on Implementation**
- **Input Requirements**: The DataFrame must contain **monthly** `close` prices and be sorted by `symbol` and `date`.
- **Handling Multiple Symbols**: The function uses `groupby('symbol')` to compute the indicator independently for each asset.
- **Edge Cases**: The first `14 + 10 = 24` months for each symbol will have `NaN` values due to insufficient ROC data.
- **Dependencies**: Requires `pandas` and `numpy` (imported as `np`).
- **Output**: Returns the original DataFrame with an added column `coppock_curve`.
```json
{ "model_code": "r4cm8gd3qjt7", "topic": "Coppock Curve", "timer_secs": 18.23, "tokens_in": 569, "tokens_out": 1606, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00321200, "cost_tokens_tot": 0.00343960 }
```