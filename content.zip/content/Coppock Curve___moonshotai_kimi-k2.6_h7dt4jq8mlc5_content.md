# Coppock Curve

## Overview
The Coppock Curve, also known as the Coppock Guide, is a long-term momentum oscillator that appears on monthly charts as a single line oscillating across a zero axis. Created by Edwin Coppock and introduced in *Barron’s* in 1962, it was designed specifically to identify major buying opportunities in broad stock indexes after the end of bear markets.

## Details
The Coppock Curve is built exclusively from month-end closing prices. It was intended for capitalization-weighted indexes—most notably the Dow Jones Industrial Average and the S&P 500—and is not suitable for short-term trading or individual securities. The calculation begins with two rate-of-change (ROC) measurements: an 11-month ROC and a 14-month ROC. These are added together, and the resulting series is smoothed with a 10-month weighted moving average (WMA). The final output is a single line that can turn deeply negative during prolonged bear markets and remain positive for years during secular uptrends.

The indicator’s unusual lookback periods trace back to Coppock’s research into market psychology. He reportedly asked church ministers how long people typically grieve after a loss; the answers averaged between 11 and 14 months. He used those figures as proxies for the time it takes a market to process a major decline, effectively treating the ROC lengths as a “mourning period” before institutional capital returns. The result is an intentionally slow-moving oscillator that filters out short-term noise and focuses only on multi-quarter trend regeneration.

Traders typically interpret the Coppock Curve as a purely bullish timing tool. The classic signal occurs when the curve crosses above the zero line after having been negative. Because the indicator is already smoothed by a 10-month WMA, this crossover is meant to confirm that long-term momentum has turned positive and that a major bottom is in place. Coppock himself did not prescribe a sell signal; the curve was designed only to identify favorable entry points for long-term investors. In practice, many traders simply exit when the curve rolls over, when it crosses back below zero, or when it is confirmed by other technical tools such as a break above a long-term moving average on the underlying index.

Unlike a simple moving average, the WMA assigns linearly increasing importance to more recent observations, so the most recent month in the window carries ten times the weight of the oldest. This gives the crossover a slight responsiveness edge over an equally weighted filter, though the overall profile remains sluggish.

Where the interpretation breaks down is in the indicator’s very construction. The Coppock Curve is a lagging indicator. By the time the 10-month WMA has turned positive, a significant portion of the new bull market may already have occurred. In fast-recovering crashes, waiting for the zero-line crossover can leave substantial gains on the table. Conversely, in choppy, range-bound markets, the curve can oscillate around zero and generate whipsaws—false buy signals that are quickly reversed as the index rolls over again. These whipsaws are especially costly because the intended holding period is measured in years, not days, so transaction costs and opportunity costs accumulate.

Another limitation is the indicator’s strict requirement for a monthly timeframe. The ROC and WMA lengths are explicitly calibrated to month-end closes. Feeding daily or weekly data directly into the formula without resampling compresses the lookback periods and destroys the indicator’s intended meaning. Similarly, applying the Coppock Curve to individual stocks, commodities, or forex pairs often produces poor results because those instruments do not exhibit the same broad, mean-reverting, long-term momentum dynamics as indexes. Thinly traded stocks can gap and produce erratic monthly closes that distort the ROC calculations.

The zero line itself can also be a source of frustration. In powerful secular bull markets, the Coppock Curve may remain positive for years, offering no new entry signal to investors who missed the initial crossover. During extended bear markets, it can sit deeply negative for long stretches, suggesting patience but providing no actionable information about when the decline will end. Some practitioners look for bullish divergences—when price makes a lower monthly low but the Coppock Curve forms a higher low—as an early warning of a pending reversal. However, these divergences are far less reliable than the simple zero-crossover signal and require careful confirmation from price structure or volume.

Finally, the weighted moving average component, while smoothing the dual ROC series, cannot eliminate the risk of structural market changes. In an era of rapid monetary policy shifts or algorithm-driven volatility, the 11- and 14-month mourning periods may no longer reflect actual market psychology. The Coppock Curve is best viewed as a regime-filter rather than a precise timing mechanism: it tells you whether long-term momentum broadly supports accumulation, but it does not tell you whether the next month will be up or down. For that reason, experienced traders tend to use it as a final confirmation tool within a broader macro framework, not as a standalone trigger.

## Text Formula
Let `Close_t` be the month-end closing price.

**Rate of Change**
`ROC(n)_t = ((Close_t - Close_{t-n}) / Close_{t-n}) * 100`

**Summed ROC**
`Sum_t = ROC(11)_t + ROC(14)_t`

**10-Month Weighted Moving Average**
`WMA(10)_t = (1 * Sum_{t-9} + 2 * Sum_{t-8} + ... + 9 * Sum_{t-1} + 10 * Sum_t) / 55`

**Coppock Curve**
`Coppock_t = WMA(10)_t`

Where the denominator `55` is the sum of weights `1 + 2 + ... + 10`.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock(df):
    """
    Calculate the Coppock Curve.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input containing columns: symbol, date, open, high, low, close.
        Typically daily data; will be resampled to month-end.
    
    Returns
    -------
    pd.DataFrame
        Monthly results with columns:
        symbol, date, close, roc_11, roc_14, roc_sum, coppock.
    """
    # Select required columns and ensure date is datetime
    df = df[['symbol', 'date', 'close']].copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['symbol', 'date'])
    
    # Resample to month-end close per symbol
    df = df.set_index('date')
    monthly = (
        df.groupby('symbol')['close']
        .resample('ME')
        .last()
        .reset_index()
    )
    
    # Calculate 11-month and 14-month Rate of Change
    monthly['roc_11'] = monthly.groupby('symbol')['close'].pct_change(periods=11) * 100
    monthly['roc_14'] = monthly.groupby('symbol')['close'].pct_change(periods=14) * 100
    
    # Sum the two ROC series
    monthly['roc_sum'] = monthly['roc_11'] + monthly['roc_14']
    
    # 10-month Weighted Moving Average of roc_sum
    # Weights 1 (oldest) through 10 (most recent)
    weights = np.arange(1, 11)
    
    def wma10(x):
        return np.dot(x, weights) / weights.sum()
    
    monthly['coppock'] = (
        monthly.groupby('symbol')['roc_sum']
        .rolling(window=10, min_periods=10)
        .apply(wma10, raw=True)
        .reset_index(level=0, drop=True)
    )
    
    return monthly
```
```json
{ "model_code": "h7dt4jq8mlc5", "topic": "Coppock Curve", "timer_secs": 111.28, "tokens_in": 559, "tokens_out": 9328, "cost_tokens_in": 0.00040807, "cost_tokens_out": 0.03255472, "cost_tokens_tot": 0.03296279 }
```