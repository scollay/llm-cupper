# Clenow Momentum

## Overview
Clenow Momentum is a risk‑adjusted momentum indicator that quantifies the strength of a price trend relative to the volatility experienced during that trend. It is calculated by dividing the annualized return of a security over a lookback period by the annualized volatility of its daily returns over the same window. The metric was popularized by Swedish quantitative trader and author Andreas Clenow in his 2015 book *Stocks on the Move*, where he employed it to rank securities for a momentum‑based investment strategy. On a chart the indicator appears as a line that rises when price appreciation outpaces volatility and falls when price declines or volatility spikes. Because it normalizes return by risk, traders can compare securities with very different price swings on a like‑for‑like basis.

## Details

### Calculation
The indicator is computed in four steps for each security in the dataset:

1. **Daily returns** – Compute the percentage change in closing price from one day to the next:  
   \( r_t = \frac{Close_t}{Close_{t-1}} - 1 \).

2. **Annualized return (CAGR)** – Over a lookback window of \( N \) trading days (default 90), compound the total return and annualize it:  
   \( \text{CAGR} = \left( \frac{Close_t}{Close_{t-N}} \right)^{252/N} - 1 \).  
   The exponent \(252/N\) scales the holding period return to a one‑year basis.

3. **Annualized volatility** – Calculate the standard deviation of the daily returns in the same window and scale it to an annual basis:  
   \( \sigma = \text{std}(r_{t-N+1}, \dots, r_t) \times \sqrt{252} \).  
   Using sample standard deviation (denominator \(N-1\)) is the default in most libraries.

4. **Momentum score** – Divide the annualized return by the annualized volatility:  
   \( \text{Clenow Momentum} = \frac{\text{CAGR}}{\sigma} \).

The result is a dimensionless number. A higher value indicates stronger risk‑adjusted upward momentum; a negative value suggests the price has fallen more than its volatility would imply.

### Interpretation
Traders typically interpret Clenow Momentum as follows:

- **Positive momentum** – The security’s price has been rising faster than its own historical volatility, suggesting a bullish bias.
- **Negative momentum** – The price has been declining relative to volatility, indicating bearish pressure.
- **Ranking tool** – The indicator is most powerful when applied across a universe of assets; the highest‑scoring securities are considered for long positions, the lowest for short positions.
- **Threshold levels** – Some traders set arbitrary cut‑offs (e.g., only trade assets with momentum > 0.5) to filter out weak signals.
- **Trend confirmation** – A rising Clenow Momentum line can confirm an uptrend, while a falling line can confirm a downtrend.

### Practical Considerations
- **Lookback sensitivity** – The metric changes dramatically with the chosen window. A short window (e.g., 30 days) reacts quickly but can be noisy; a longer window (e.g., 180 days) smooths the series but lags.
- **Volatility clustering** – Sudden spikes in volatility (e.g., around earnings or macroeconomic events) can depress the momentum score even if the price trend remains intact.
- **No risk‑free rate** – Unlike the Sharpe ratio, Clenow Momentum does not subtract a risk‑free rate, so it may overstate attractiveness in high‑rate environments.
- **Zero‑volatility edge case** – If a security’s price barely moves (σ ≈ 0), the ratio becomes unstable or infinite; such cases should be handled by setting momentum to NaN.
- **Backward‑looking** – Like all momentum indicators, it reflects past price behavior and does not predict future direction.

### Comparison with Other Momentum Indicators
- **Price momentum (raw return)** – Simple price momentum only measures the magnitude of price change, ignoring risk. Clenow Momentum adjusts for volatility, providing a risk‑adjusted view.
- **Relative Strength Index (RSI)** – RSI is bounded (0‑100) and measures the speed of price changes, but it does not annualize returns or directly compare risk‑adjusted performance across assets.
- **Sharpe ratio** – The Sharpe ratio subtracts a risk‑free rate from the return before dividing by volatility, making it more suitable for risk‑adjusted performance evaluation of a portfolio rather than a single security’s momentum.

## Text Formula
For a given security and a lookback period \( N \) (e.g., 90 trading days):

1. Daily return: \( r_t = \frac{Close_t}{Close_{t-1}} - 1 \)
2. Compound Annual Growth Rate: \( \text{CAGR} = \left( \frac{Close_t}{Close_{t-N}} \right)^{252/N} - 1 \)
3. Annualized volatility: \( \sigma = \sqrt{\frac{\sum_{i=t-N+1}^{t} (r_i - \bar{r})^2}{N-1}} \times \sqrt{252} \)  
   where \( \bar{r} \) is the mean of the daily returns over the window.
4. Clenow Momentum: \( \text{Momentum} = \frac{\text{CAGR}}{\sigma} \)

If \( \sigma = 0 \), the momentum value is undefined and should be set to NaN.

## Python Code

```python
import numpy as np
import pandas as pd

def clenow_momentum(df: pd.DataFrame, lookback: int = 90) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for each symbol in `df`.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        The DataFrame may contain multiple symbols.
    lookback : int, optional
        Number of trading days to use for the momentum calculation (default 90).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: symbol, date, momentum, cagr, volatility.
        Values are aligned with the input dates; early dates for each symbol
        will contain NaN because the lookback window is not satisfied.
    """
    # Ensure data is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Compute daily returns for each symbol
    df['ret'] = df.groupby('symbol')['close'].pct_change()

    # Annualized volatility over the lookback window
    df['volatility'] = (
        df.groupby('symbol')['ret']
        .transform(lambda x: x.rolling(window=lookback).std() * np.sqrt(252))
    )

    # Lagged close price to compute CAGR
    df['close_lag'] = df.groupby('symbol')['close'].shift(lookback)

    # Compound Annual Growth Rate (CAGR)
    df['cagr'] = (df['close'] / df['close_lag']) ** (252 / lookback) - 1

    # Clenow Momentum = CAGR / volatility
    df['momentum'] = df['cagr'] / df['volatility']

    # Replace infinite values with NaN (e.g., when volatility is zero)
    df['momentum'] = df['momentum'].replace([np.inf, -np.inf], np.nan)

    # Return only the relevant columns
    result = df[['symbol', 'date', 'momentum', 'cagr', 'volatility']].copy()
    return result
```
```json
{ "model_code": "l3hb7nm4tcd8", "topic": "Clenow Momentum", "timer_secs": 301.69, "tokens_in": 588, "tokens_out": 6588, "cost_tokens_in": 0.00017640, "cost_tokens_out": 0.00790560, "cost_tokens_tot": 0.00808200 }
```