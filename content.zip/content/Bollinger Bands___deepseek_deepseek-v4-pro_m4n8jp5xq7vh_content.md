# Bollinger Bands

## Overview
Bollinger Bands are a classic volatility-based technical indicator created by John Bollinger in the early 1980s. They appear on a chart as three lines: a simple moving average in the middle and two standard deviation bands above and below it. The bands automatically widen when volatility rises and contract when it falls, giving traders a dynamic visual gauge of price extremes and relative market calm. Because the bands respond to both trend and volatility, they are used for everything from spotting overbought/oversold conditions to anticipating breakout moves.

## Details

### How the indicator is built
The standard Bollinger Band setup uses a 20‑period simple moving average (SMA) of the closing price as its centerline — the **middle band**. The **upper band** is placed two standard deviations above the middle band, and the **lower band** is placed two standard deviations below it. The standard deviation is the population version (denominator \(n\)) rather than the sample version — this is the original specification and keeps the bands slightly tighter. Every new price recalculates the SMA and the standard deviation, so the bands shift in real time.

The choice of 20 periods and a multiplier of 2 is deliberate. Under a normal distribution roughly 95% of price closes would fall inside the bands; in practice financial data are fat‑tailed, but the envelope still provides a useful reference zone that captures most price action in a sideways or gently trending market.

### What traders look for

*Mean reversion at the bands*  
Because price visits the bands only when it moves unusually far from its recent average, many traders treat touches of the upper or lower band as exhaustion signals. A test of the upper band in a range‑bound market is considered overbought and a candidate for a short entry or long exit; a test of the lower band is oversold and a candidate for a long entry or short exit. The most straightforward signal is a **tag and reverse**: price touches a band and immediately begins moving back toward the middle band.

*Trending markets — walking the band*  
In a strong trend the bands act differently. Price will often “walk” the upper band during a powerful rally, or the lower band during a steep decline, with only shallow pullbacks. The indicator does not provide a reliable reversal signal here; instead, a series of closes above the upper band or below the lower band can confirm trend strength. Traders will hold with the trend until price loses contact with the band and closes back inside, often on a counter‑trend move toward the middle band.

*The Bollinger Squeeze*  
When volatility falls to low levels the bands narrow dramatically — a compression known as the **squeeze**. It indicates the market is coiling and a large directional move is likely to follow. The squeeze itself does not predict direction; traders watch for the first breakout close outside a band to confirm which way the explosion will occur. This setup is frequently combined with volume or momentum oscillators to filter false breakouts.

*Band width and relative position*  
Two derived metrics are often monitored. **Bandwidth** (upper band – lower band) shows raw volatility and highlights squeezes and expansions. **%b** tells where the closing price sits relative to the bands — values above 1 mean price is above the upper band, values below 0 mean it is below the lower band. These help quantify the extremes and can be used to spot divergence when price makes a new high but %b fails to confirm.

### Common pitfalls and limitations
Bollinger Bands are purely reactive — they describe where price *is*, not where it *will go*. A tag of a band in a trending environment is not an automatic reversal signal; exiting too early can leave a trader missing the bulk of a move. Conversely, a breakout from a squeeze often produces a false start, rushing traders in only to reverse. Therefore the bands are almost never used in isolation: traders often overlay them with RSI, MACD, or volume‑based confirmation to filter noise.

Also, the 20‑period, 2‑standard‑deviation default is not sacred. Shorter windows make the bands more sensitive to volatility changes but increase the number of false touches; longer windows smooth everything out. A multiplier of 2 can be adjusted upward for wider, more conservative envelopes or downward to capture smaller moves. The best parameters depend on the asset and the time frame.

In all cases, Bollinger Bands define a *relative* framework — they show how far price has deviated from its own recent history, not an absolute level of value. When used that way, they help a trader ask the right question: “Is this move statistically unusual, and if so, what does the surrounding context tell me about the probability of continuation versus reversal?”

## Text Formula

Given a lookback period `n` (typically 20) and a standard deviation multiplier `m` (typically 2):

```
Middle Band = SMA(close, n)

Upper Band  = SMA(close, n) + m × σ
Lower Band  = SMA(close, n) – m × σ
```

where σ is the population standard deviation of the closing prices over the last `n` periods:

```
σ = sqrt( (1/n) × Σ (close_i – SMA(close, n))² )
```

All values are recalculated for each new bar, so the bands form a dynamic envelope around price.

## Python Code

The code below expects a `pandas.DataFrame` with columns: `symbol`, `date`, `open`, `high`, `low`, `close`. It calculates the three Bollinger Band lines (middle, upper, lower) for each symbol independently, preserving the original data and adding new columns.

```python
import pandas as pd

def bollinger_bands(df: pd.DataFrame, window: int = 20, num_std: float = 2.0) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for a DataFrame of OHLC data.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        May contain one or more symbols; each symbol is processed separately.
    window : int, default 20
        Lookback period for the simple moving average and standard deviation.
    num_std : float, default 2.0
        Number of standard deviations for the upper and lower bands.

    Returns
    -------
    pd.DataFrame
        The original DataFrame with three new columns:
        'middle_band', 'upper_band', 'lower_band'.
        The first `window - 1` rows for each symbol will have NaN values
        in the band columns due to insufficient data.
    """
    df = df.copy()
    # Ensure date column is datetime for proper sorting
    df['date'] = pd.to_datetime(df['date'])

    # Sort so rolling calculations are performed in chronological order
    df.sort_values(['symbol', 'date'], inplace=True)

    def _compute_bands(group):
        # Within each symbol, sort just in case
        group = group.sort_values('date')
        sma = group['close'].rolling(window=window).mean()
        # Population standard deviation (ddof=0), per Bollinger's original specification
        std = group['close'].rolling(window=window).std(ddof=0)

        group['middle_band'] = sma
        group['upper_band'] = sma + num_std * std
        group['lower_band'] = sma - num_std * std
        return group

    df = df.groupby('symbol', group_keys=False).apply(_compute_bands)
    return df
```

*Usage example:*  
`data = pd.DataFrame(...)` with the required columns, then `data = bollinger_bands(data)` to append the three band columns. The function processes each ticker independently, so it works seamlessly with a multi‑symbol universe.
```json
{ "model_code": "m4n8jp5xq7vh", "topic": "Bollinger Bands", "timer_secs": 97.17, "tokens_in": 561, "tokens_out": 3275, "cost_tokens_in": 0.00024123, "cost_tokens_out": 0.00284925, "cost_tokens_tot": 0.00309048 }
```