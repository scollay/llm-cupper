# Coppock Curve

## Overview

The Coppock Curve is a momentum oscillator designed to identify long-term buying opportunities in stock market indices. Created by Edwin Coppock in 1962, it combines rate-of-change calculations with a weighted moving average to smooth price momentum signals. The indicator appears as a single line oscillating around a zero line on a chart, typically applied to weekly or monthly data rather than intraday timeframes. Coppock originally developed it to signal the end of bear markets and the beginning of bull markets, making it particularly useful for longer-term investors seeking entry points after significant declines.

## Details

The Coppock Curve works by measuring the rate of change of price over two different periods, then applying an exponential moving average to smooth the result. This layered approach captures momentum while filtering out noise that might otherwise trigger false signals.

**How It Works**

The indicator begins by calculating the rate of change (ROC) over two lookback periods—typically 11 and 14 periods. These two ROC values are summed together, creating a combined momentum reading. That sum is then smoothed using a 10-period exponential moving average (EMA). The result oscillates around zero: positive values suggest upward momentum, while negative values indicate downward momentum.

The zero line serves as the primary signal threshold. When the Coppock Curve crosses above zero from below, it suggests that momentum has shifted from negative to positive—a potential buy signal. Conversely, a cross below zero from above suggests momentum has turned negative, though Coppock's original framework emphasized buy signals more heavily than sell signals.

**Interpretation and Use Cases**

Traders typically use the Coppock Curve in three ways:

1. **Zero-line crossovers**: The most common application. A bullish crossover (crossing above zero) suggests the start of a new uptrend, particularly after a prolonged decline. This aligns with Coppock's original intent to identify market bottoms.

2. **Divergence**: When price makes a new low but the Coppock Curve fails to reach a new low, bullish divergence may signal weakening downward momentum and a potential reversal.

3. **Extreme readings**: Very high positive values can indicate overbought conditions where momentum is stretched, though the indicator is less reliable for identifying tops than bottoms.

**Strengths**

The Coppock Curve excels at filtering noise through its dual ROC and EMA smoothing. It generates relatively few false signals compared to simpler momentum indicators, making it suitable for traders who prefer a higher-conviction setup. Its design specifically targets market bottoms, which appeals to value-oriented investors and those with longer time horizons.

**Limitations**

The indicator's primary weakness is lag. The 10-period EMA smoothing, combined with the lookback periods, means signals arrive well after momentum has already shifted. On fast-moving markets, this delay can result in missed entries or exits. Additionally, the Coppock Curve performs best on indices and longer timeframes (weekly or monthly); it becomes less reliable on individual stocks or intraday charts where noise increases. The indicator also struggles in choppy, sideways markets where momentum oscillates around zero without clear directional conviction. Finally, like all momentum indicators, it can remain overbought or oversold for extended periods during strong trends, leading traders to abandon the signal prematurely.

**Practical Considerations**

The Coppock Curve works best as part of a broader toolkit rather than as a standalone signal. Combining it with support and resistance levels, trend analysis, or other indicators can improve reliability. Many traders apply it to major indices (S&P 500, Nasdaq) on weekly charts to identify market-wide turning points, then use those signals to inform individual stock decisions. The indicator is less useful for short-term traders or those trading highly volatile assets where the lag becomes prohibitive.

## Text Formula

**Step 1: Calculate Rate of Change (ROC)**

ROC₁ = ((Close - Close₁₁ periods ago) / Close₁₁ periods ago) × 100

ROC₂ = ((Close - Close₁₄ periods ago) / Close₁₄ periods ago) × 100

**Step 2: Sum the Two ROC Values**

ROC Sum = ROC₁ + ROC₂

**Step 3: Apply 10-Period Exponential Moving Average**

Coppock Curve = EMA₁₀(ROC Sum)

Where EMA is calculated as:

EMA = (Close × Multiplier) + (Previous EMA × (1 - Multiplier))

Multiplier = 2 / (10 + 1) = 0.1818

For the first EMA value, use the simple average of the first 10 ROC Sum values.

## Python Code

```python
import pandas as pd

def calculate_coppock_curve(df):
    """
    Calculate the Coppock Curve indicator.
    
    Parameters:
    df : pandas.DataFrame
        DataFrame with columns: symbol, date, open, high, low, close
        Data should be sorted by symbol and date in ascending order.
    
    Returns:
    pandas.DataFrame
        Original DataFrame with added 'coppock_curve' column.
    """
    
    df = df.copy()
    df['coppock_curve'] = None
    
    # Process each symbol independently
    for symbol in df['symbol'].unique():
        symbol_data = df[df['symbol'] == symbol].copy()
        symbol_data = symbol_data.reset_index(drop=True)
        
        # Calculate ROC for 11 periods
        roc_11 = ((symbol_data['close'] - symbol_data['close'].shift(11)) / 
                  symbol_data['close'].shift(11) * 100)
        
        # Calculate ROC for 14 periods
        roc_14 = ((symbol_data['close'] - symbol_data['close'].shift(14)) / 
                  symbol_data['close'].shift(14) * 100)
        
        # Sum the two ROC values
        roc_sum = roc_11 + roc_14
        
        # Calculate 10-period EMA of ROC sum
        ema_multiplier = 2 / (10 + 1)
        ema = roc_sum.ewm(span=10, adjust=False).mean()
        
        # Assign back to original dataframe
        df.loc[df['symbol'] == symbol, 'coppock_curve'] = ema.values
    
    return df
```
```json
{ "model_code": "x2vp7k8nm4rj", "topic": "Coppock Curve", "timer_secs": 12.60, "tokens_in": 611, "tokens_out": 1530, "cost_tokens_in": 0.00061100, "cost_tokens_out": 0.00765000, "cost_tokens_tot": 0.00826100 }
```