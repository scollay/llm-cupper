# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is an arithmetic mean of a security’s closing prices over a specified lookback period. On a price chart, it appears as a continuous line overlaid on bars or candlesticks, filtering short-term noise to expose the underlying trend. Its origins are not credited to a single inventor; rather, the SMA emerged from classical statistical methods and was popularized in technical analysis during the early 20th century through Dow Theory and subsequent market practitioners.

## Details

### Mechanics and Calculation
The SMA treats each observation in its window equally. For a 20-day SMA, every value of `close` within the last twenty trading sessions receives a weight of 1/20. As each new session’s `close` enters the window, the oldest datum drops out, shifting the line incrementally. Because the calculation is strictly backward-looking, the SMA inherently lags price. The longer the window, the smoother and slower the line becomes, making the SMA a descriptive rather than predictive tool.

### Lookback Selection and Timeframes
Traders deploy SMAs across many timeframes. Short windows—such as 10 or 20 periods—capture near-term momentum and are popular among swing traders. Intermediate settings like 50 periods approximate quarterly trends on daily charts, while the 200-period SMA often serves as a proxy for the prevailing yearly trend. On intraday charts, the same logic applies using minutes or hours. The appropriate length depends on the asset’s volatility and the trader’s horizon; faster-moving instruments may require longer windows to avoid noise.

### Statistical Properties
From a signal-processing perspective, the SMA is a finite impulse response filter with a rectangular kernel. It attenuates high-frequency price noise but introduces phase lag equal to roughly (N − 1) / 2 bars. Consequently, a 20-period SMA plots approximately 9.5 bars behind price at turning points. Traders accept this lag because the reduction in variance—noise diminishes roughly by the square root of the window length—improves signal clarity.

### Interpretation and Common Strategies
**Trend identification.** The slope of an SMA indicates trend direction. A rising SMA suggests accumulation and an uptrend; a falling SMA points to distribution and a downtrend. When price trades above a long-term SMA, analysts generally consider the broad trend bullish, and vice versa.

**Dynamic support and resistance.** In strongly trending markets, price frequently retraces to an intermediate SMA before resuming the prevailing move. A bounce off the 50-period SMA in an established uptrend can be interpreted as a continuation entry, whereas a decisive break below it may signal a deeper correction.

**Crossover signals.** The most ubiquitous SMA strategy involves two averages of differing lengths. A bullish “golden cross” occurs when a shorter-term SMA crosses above a longer-term SMA; a bearish “death cross” is the inverse. Price-to-average crossovers also generate entry and exit rules—a close above the 200-day SMA, for example, is a classic macro risk-on signal.

### Limitations and Failure Modes
The SMA’s simplicity is also its weakness. Because every day in the window is weighted identically, a large price move from twenty days ago vanishes abruptly when it rolls out of the calculation, potentially causing the line to jerk and generate misleading signals at the window boundary.

In choppy, range-bound conditions, price oscillates around an SMA without establishing directional conviction. Traders who treat every crossover as a signal face repeated whipsaws and cumulative slippage. The indicator offers no prediction of magnitude or duration; it merely summarizes where price has been.

Equal weighting means the SMA dilutes recent information. Exponential moving averages address this, but purists accept the SMA’s lag as the cost of a clearer, less reactive trend line. Finally, because the SMA is a single-line overlay, it provides no information about volatility or volume context. It is most reliable when paired with confirmation tools—volume profiles, RSI divergences, or structural support and resistance levels.

## Text Formula
Given a lookback period *N* and closing price *C* at time *t*:

SMA_t = ( C_t + C_{t-1} + ... + C_{t-N+1} ) / N

In summation notation:

SMA_t = (1/N) * Σ_{i=0}^{N-1} C_{t-i}

A valid SMA value first appears once *N* consecutive closes are available.

## Python Code
```python
import pandas as pd

def calculate_sma(df, periods=(20, 50, 200)):
    """
    Calculate Simple Moving Average(s) for one or more symbols.

    Parameters
    ----------
    df : pandas.DataFrame
        Input data with columns: symbol, date, open, high, low, close.
        Data should be sorted by symbol and date.
    periods : tuple or list of int
        Lookback window lengths for SMA calculation.

    Returns
    -------
    pandas.DataFrame
        Original DataFrame with additional columns `sma_{n}` for each period.
    """
    df = df.copy()

    # Ensure chronological order within each symbol
    df = df.sort_values(by=["symbol", "date"]).reset_index(drop=True)

    for n in periods:
        col_name = f"sma_{n}"
        df[col_name] = (
            df.groupby("symbol")["close"]
            .transform(lambda x: x.rolling(window=n, min_periods=n).mean())
        )

    return df
```
```json
{ "model_code": "h7dt4jq8mlc5", "topic": "Simple Moving Average", "timer_secs": 145.97, "tokens_in": 559, "tokens_out": 7418, "cost_tokens_in": 0.00040807, "cost_tokens_out": 0.02588882, "cost_tokens_tot": 0.02629689 }
```