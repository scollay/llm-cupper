# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator developed by John Bollinger in the 1980s. The indicator consists of three lines plotted on a price chart: a simple moving average (SMA) in the middle, and an upper and lower band that are standard deviations away from the SMA. Bollinger Bands expand and contract with volatility, providing a dynamic view of price ranges and potential overbought or oversold conditions.

## Details

### Construction
Bollinger Bands are built from three components:
- **Middle Band**: A simple moving average (typically 20 periods) of closing prices.
- **Upper Band**: The middle band plus a specified number of standard deviations (typically 2) of the same period.
- **Lower Band**: The middle band minus the same number of standard deviations.

The bands automatically widen during periods of high volatility and narrow during low volatility, creating a visual representation of price volatility relative to recent history.

### Interpretation
Traders use Bollinger Bands in several ways:

1. **Volatility Measurement**: The width of the bands reflects market volatility. Narrow bands suggest low volatility, while wide bands indicate high volatility.
2. **Overbought/Oversold Conditions**: Prices near the upper band may signal overbought conditions, while prices near the lower band may indicate oversold conditions. However, prices can remain at these extremes for extended periods during strong trends.
3. **Squeeze Patterns**: When the bands narrow significantly, it suggests low volatility and often precedes a period of increased volatility and potential price breakout.
4. **Trend Identification**: Prices consistently touching or exceeding the upper band may indicate an uptrend, while prices hugging the lower band may suggest a downtrend.

### Limitations
Bollinger Bands have several important limitations:
- They are **lagging indicators**, as they are based on moving averages and standard deviations of past prices.
- The bands **do not predict price direction**, only potential volatility and relative price levels.
- During strong trends, prices can remain at or beyond the bands for extended periods, making overbought/oversold signals less reliable.
- The indicator is **highly parameter-dependent**—different lookback periods and standard deviation multipliers can produce vastly different results.

Bollinger Bands work best in ranging markets and should be combined with other indicators (such as RSI or MACD) for confirmation.

---

## Text Formula

Bollinger Bands are calculated as follows:

1. **Middle Band (MB)**:
   ```
   MB = SMA(close, n)
   ```
   Where:
   - `SMA` = Simple Moving Average
   - `close` = Closing price
   - `n` = Number of periods (typically 20)

2. **Standard Deviation (σ)**:
   ```
   σ = StandardDeviation(close, n)
   ```

3. **Upper Band (UB)**:
   ```
   UB = MB + (k × σ)
   ```
   Where `k` = Number of standard deviations (typically 2)

4. **Lower Band (LB)**:
   ```
   LB = MB - (k × σ)
   ```

5. **Bandwidth (BW)** (optional):
   ```
   BW = (UB - LB) / MB
   ```
   Bandwidth measures the width of the bands relative to the middle band, providing a normalized view of volatility.

6. **%B** (optional):
   ```
   %B = (close - LB) / (UB - LB)
   ```
   %B quantifies where the current price lies within the bands, ranging from 0 (at the lower band) to 1 (at the upper band).

---

## Python Code

```python
import pandas as pd

def calculate_bollinger_bands(
    df: pd.DataFrame,
    window: int = 20,
    num_std: float = 2.0,
    include_bandwidth: bool = False,
    include_percent_b: bool = False
) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for a DataFrame containing OHLC data.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
        Can contain data for one or more symbols.
    window : int, default 20
        Number of periods for the moving average and standard deviation.
    num_std : float, default 2.0
        Number of standard deviations for the upper and lower bands.
    include_bandwidth : bool, default False
        If True, calculates and includes the Bandwidth metric.
    include_percent_b : bool, default False
        If True, calculates and includes the %B metric.

    Returns:
    --------
    pd.DataFrame
        Original DataFrame with additional columns for Bollinger Bands:
        - 'bb_middle': Middle band (SMA)
        - 'bb_upper': Upper band
        - 'bb_lower': Lower band
        - 'bb_bandwidth': Bandwidth (if include_bandwidth=True)
        - 'bb_percent_b': %B (if include_percent_b=True)
    """
    # Ensure required columns exist
    required_columns = {'symbol', 'close'}
    if not required_columns.issubset(df.columns):
        raise ValueError("DataFrame must contain 'symbol' and 'close' columns.")

    # Group by symbol to handle multiple securities
    grouped = df.groupby('symbol')

    # Calculate middle band (SMA)
    df['bb_middle'] = grouped['close'].transform(
        lambda x: x.rolling(window=window, min_periods=1).mean()
    )

    # Calculate standard deviation
    df['bb_std'] = grouped['close'].transform(
        lambda x: x.rolling(window=window, min_periods=1).std()
    )

    # Calculate upper and lower bands
    df['bb_upper'] = df['bb_middle'] + (num_std * df['bb_std'])
    df['bb_lower'] = df['bb_middle'] - (num_std * df['bb_std'])

    # Optional: Calculate Bandwidth
    if include_bandwidth:
        df['bb_bandwidth'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']

    # Optional: Calculate %B
    if include_percent_b:
        df['bb_percent_b'] = (df['close'] - df['bb_lower']) / (
            df['bb_upper'] - df['bb_lower']
        )

    # Drop intermediate standard deviation column
    df.drop(columns=['bb_std'], inplace=True)

    return df
```

### Usage Notes:
- The function handles multiple symbols in the input DataFrame by grouping calculations by `symbol`.
- The `window` and `num_std` parameters allow customization of the lookback period and standard deviation multiplier.
- Optional metrics (`Bandwidth` and `%B`) can be included by setting the corresponding flags to `True`.
- The function returns the original DataFrame with additional columns for the Bollinger Bands components.
```json
{ "model_code": "y6fv9wp2knx5", "topic": "Bollinger Bands", "timer_secs": 21.02, "tokens_in": 569, "tokens_out": 1498, "cost_tokens_in": 0.00113800, "cost_tokens_out": 0.00898800, "cost_tokens_tot": 0.01012600 }
```