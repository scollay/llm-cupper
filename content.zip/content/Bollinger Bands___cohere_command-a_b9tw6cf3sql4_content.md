# Bollinger Bands

## Overview
Bollinger Bands are a popular technical analysis tool created by John Bollinger in the early 1980s. They consist of a middle band, typically a 20-day simple moving average (SMA), and two outer bands that are standard deviations away from the middle band. The outer bands adjust to volatility, widening during periods of high volatility and narrowing during calmer periods. Bollinger Bands are plotted on a price chart to provide insights into volatility and potential price reversals.

## Details
Bollinger Bands are designed to capture the dynamic nature of price volatility. The middle band serves as a baseline, while the upper and lower bands act as dynamic support and resistance levels. Traders interpret Bollinger Bands in several ways:

1. **Volatility Measurement**: Wider bands indicate higher volatility, while narrower bands suggest lower volatility.  
2. **Overbought/Oversold Conditions**: Prices near the upper band may indicate overbought conditions, while prices near the lower band may suggest oversold conditions.  
3. **Trend Identification**: When prices consistently touch or exceed the upper band, it may signal a strong uptrend. Conversely, consistent contact with the lower band may indicate a strong downtrend.  
4. **Reversal Signals**: A price move that originates from one band and crosses the middle band to reach the opposite band can signal a potential reversal.  

However, Bollinger Bands are not foolproof. They can give false signals during strong trends, and relying solely on band touches without confirming indicators can lead to poor trading decisions. Additionally, the bands are reactive, not predictive, meaning they reflect past volatility rather than future price movements.

## Text Formula
The Bollinger Bands are calculated as follows:

1. **Middle Band (MB)**:  
   `MB = 20-day Simple Moving Average (SMA) of Closing Prices`  

2. **Upper Band (UB)**:  
   `UB = MB + (2 * 20-day Standard Deviation of Closing Prices)`  

3. **Lower Band (LB)**:  
   `LB = MB - (2 * 20-day Standard Deviation of Closing Prices)`  

Where:  
- **Simple Moving Average (SMA)**: Sum of closing prices over the last 20 days divided by 20.  
- **Standard Deviation**: Square root of the variance of closing prices over the last 20 days.  

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_bollinger_bands(data: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for a given DataFrame.

    Parameters:
    data (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.

    Returns:
    pd.DataFrame: Original DataFrame with added columns for Middle Band, Upper Band, and Lower Band.
    """
    # Ensure the DataFrame is sorted by date for each symbol
    data = data.sort_values(by=['symbol', 'date'])
    
    # Group by symbol and calculate Bollinger Bands
    result = data.groupby('symbol').apply(lambda x: pd.concat([
        x,
        pd.DataFrame({
            'Middle Band': x['close'].rolling(window=20).mean(),
            'Upper Band': x['close'].rolling(window=20).mean() + 2 * x['close'].rolling(window=20).std(),
            'Lower Band': x['close'].rolling(window=20).mean() - 2 * x['close'].rolling(window=20).std()
        })
    ], axis=1)).reset_index(drop=True)
    
    return result

# Example usage:
# df = pd.DataFrame({...})  # Your DataFrame here
# bollinger_bands_df = calculate_bollinger_bands(df)
```
```json
{ "model_code": "b9tw6cf3sql4", "topic": "Bollinger Bands", "timer_secs": 13.35, "tokens_in": 574, "tokens_out": 819, "cost_tokens_in": 0.00143500, "cost_tokens_out": 0.00819000, "cost_tokens_tot": 0.00962500 }
```