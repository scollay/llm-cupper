# T3 Moving Average

## Overview

The **T3 moving average** is a smoothed trend-following indicator designed to reduce lag while preserving the responsiveness of a faster average. On a chart, it appears as a single line that tracks price with less noise than a simple moving average, but usually reacts more quickly than heavily lagged smoothing methods.

T3 was created by **Tim Tillson** in the mid-1990s. It belongs to the family of “triple exponential” style averages and is often used by traders who want a cleaner trend line for identifying direction, pullbacks, and dynamic support or resistance.

## Details

T3 is built from a sequence of six exponential moving averages, then blended with a smoothing factor. The key idea is to smooth price repeatedly, then combine those smoothed values in a way that produces a curve with less lag than a comparable EMA chain would normally create.

Traders usually interpret T3 in the same broad way they interpret other moving averages:

- **Price above T3** may suggest an uptrend.
- **Price below T3** may suggest a downtrend.
- A **rising T3** can confirm bullish momentum.
- A **falling T3** can confirm bearish momentum.
- **Crossovers** between price and T3, or between a faster and slower T3, are often used as entry/exit signals.

What makes T3 different is its smoother curve. That smoothness helps filter minor fluctuations and makes the trend visually easier to follow. Compared with a simple moving average, T3 typically responds faster for a similar level of smoothness. Compared with a short EMA, it is usually less noisy.

### How it is constructed

T3 begins with an EMA of price, then an EMA of that EMA, and so on through six stages:

- `e1 = EMA(close, length)`
- `e2 = EMA(e1, length)`
- `e3 = EMA(e2, length)`
- `e4 = EMA(e3, length)`
- `e5 = EMA(e4, length)`
- `e6 = EMA(e5, length)`

Those six series are then combined using coefficients derived from a volume factor, usually written as `vfactor` or `b`. The common default is `0.7`, though values between `0.5` and `0.9` are often seen in practice.

### Typical interpretation

A higher `vfactor` makes T3 more responsive, but also more prone to whipsaws. A lower `vfactor` increases smoothing and lag. This tradeoff is the core decision when using T3.

Common uses include:

1. **Trend filter**
   - Only take longs when price is above T3 and T3 is rising.
   - Only take shorts when price is below T3 and T3 is falling.

2. **Crossover signal**
   - Buy when price crosses above T3.
   - Sell when price crosses below T3.
   - Or combine a fast T3 with a slow T3 for trend confirmation.

3. **Dynamic support/resistance**
   - In strong trends, price may repeatedly pull back to T3 and bounce.
   - Traders sometimes treat the line as a moving support level in uptrends or resistance in downtrends.

### Where it breaks down

T3, like all moving averages, is **lagging**. It reflects past price action, not future movement. That means:

- In **choppy or range-bound markets**, crossovers can generate false signals.
- During **sharp reversals**, T3 may turn late.
- In **high-volatility events**, price can move far beyond the line before the trend line catches up.

The smoothing that makes T3 attractive also causes the main limitation: by the time the line clearly changes direction, a meaningful part of the move may already be over. Traders often pair T3 with momentum, volatility, or volume tools to avoid treating it as a standalone signal.

A useful way to think about T3 is as a **trend-quality filter** rather than a timing oracle. It can help define the dominant direction and reduce chart noise, but it should be validated with market structure, volatility context, and risk management.

## Text Formula

Let `c_t` be the closing price at time `t`, `n` be the lookback length, and `b` be the volume factor.

First compute the EMA smoothing constant:

- `alpha = 2 / (n + 1)`

Then compute the recursive EMA chain:

- `e1_t = EMA(c_t, n)`
- `e2_t = EMA(e1_t, n)`
- `e3_t = EMA(e2_t, n)`
- `e4_t = EMA(e3_t, n)`
- `e5_t = EMA(e4_t, n)`
- `e6_t = EMA(e5_t, n)`

The T3 coefficients are:

- `c1 = -b^3`
- `c2 = 3b^2 + 3b^3`
- `c3 = -6b^2 - 3b - 3b^3`
- `c4 = 1 + 3b + 3b^2 + b^3`

The T3 value is:

- `T3_t = c1*e6_t + c2*e5_t + c3*e4_t + c4*e3_t`

This is the standard form used in most charting platforms. The indicator is typically plotted as a single line.

## Python Code

```python
import pandas as pd

def calculate_t3(df: pd.DataFrame, length: int = 5, vfactor: float = 0.7) -> pd.DataFrame:
    """
    Calculate Tillson's T3 moving average for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    Parameters
    ----------
    df : pd.DataFrame
        Input data containing one or more symbols.
    length : int
        EMA lookback length used in each stage of the T3 calculation.
    vfactor : float
        Volume factor (b). Common default is 0.7.

    Returns
    -------
    pd.DataFrame
        Original data sorted by symbol/date with added columns:
        e1, e2, e3, e4, e5, e6, T3
    """
    required_cols = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    if length <= 0:
        raise ValueError("length must be a positive integer")

    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    c1 = -(vfactor ** 3)
    c2 = 3 * (vfactor ** 2) + 3 * (vfactor ** 3)
    c3 = -6 * (vfactor ** 2) - 3 * vfactor - 3 * (vfactor ** 3)
    c4 = 1 + 3 * vfactor + 3 * (vfactor ** 2) + (vfactor ** 3)

    def _calc_group(g: pd.DataFrame) -> pd.DataFrame:
        g = g.sort_values("date").copy()
        e1 = g["close"].ewm(span=length, adjust=False).mean()
        e2 = e1.ewm(span=length, adjust=False).mean()
        e3 = e2.ewm(span=length, adjust=False).mean()
        e4 = e3.ewm(span=length, adjust=False).mean()
        e5 = e4.ewm(span=length, adjust=False).mean()
        e6 = e5.ewm(span=length, adjust=False).mean()

        g["e1"] = e1
        g["e2"] = e2
        g["e3"] = e3
        g["e4"] = e4
        g["e5"] = e5
        g["e6"] = e6
        g["T3"] = c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3
        return g

    out = out.groupby("symbol", group_keys=False).apply(_calc_group)
    return out
```
```json
{ "model_code": "p3hg7mw5cdz8", "topic": "T3", "timer_secs": 10.49, "tokens_in": 558, "tokens_out": 1790, "cost_tokens_in": 0.00041850, "cost_tokens_out": 0.00805500, "cost_tokens_tot": 0.00847350 }
```