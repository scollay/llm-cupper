#Coppock Curve

## Overview
The Coppock Curve is a long-term momentum indicator designed to identify major bottoms in stock market cycles. Developed by economist Edwin "Sedge" Coppock in 1962, it appears on a chart as an oscillator that fluctuates above and below a zero line, typically plotted in a separate pane below the price action. Originally intended for use on monthly charts of the S&P 500 index, the indicator was built to signal the beginning of new bull markets. Coppock was asked by the Episcopal Church to find a reliable method for identifying long-term buying opportunities, and he based the indicator's parameters on the psychological recovery period of grief, which he estimated to be 11 to 14 months.

## Details
The Coppock Curve operates on the premise that market bottoms are preceded by a period of prolonged decline, followed by a stabilization and eventual shift in momentum. It achieves this by combining two Rate of Change (ROC) calculations and smoothing the result with a Weighted Moving Average (WMA).

**Calculation Mechanics**
The indicator calculates the 14-month ROC and the 11-month ROC. The 14-period ROC captures the intermediate-term momentum, while the 11-period ROC captures the shorter-term momentum. These two percentages are added together. Because the sum of the two ROCs can be highly volatile from month to month, a 10-period WMA is applied to smooth the data and generate the final curve. The weighting of the WMA assigns the greatest significance to the most recent period, ensuring the indicator responds more quickly to current momentum shifts than a simple moving average.

**Interpretation**
Traders primarily use the Coppock Curve to identify long-term buy signals. The classic buy signal occurs when the curve crosses above the zero line from negative territory. Because the indicator is heavily smoothed, this zero-line cross confirms that the momentum has definitively shifted from bearish to bullish. 

A secondary, more aggressive buy signal occurs when the curve turns up from a deep trough below the zero line, even before it crosses above zero. Traders watch for the indicator to form a bottom and tick higher as an early entry point, though this carries a higher risk of a false reversal.

While designed to spot bottoms, some traders also use the inverse logic for sell signals, taking a short position or exiting longs when the curve crosses below zero. However, because bear markets tend to play out faster than the slow grind of a market bottom, the Coppock Curve is generally considered a less reliable timing tool for tops.

**Limitations and Breakdowns**
The primary weakness of the Coppock Curve is its inherent lag. Because it relies on 11- and 14-month lookback periods smoothed by a 10-period WMA, the indicator will almost never pick the exact bottom of a market. By the time a zero-line cross occurs, the market has often already experienced a significant rally. 

Furthermore, the indicator is prone to false signals in sideways or highly choppy markets. In a range-bound environment, the ROC values can oscillate near zero, causing the Coppock Curve to whip back and forth across the zero line, generating a series of losing signals. 

Finally, the indicator was explicitly designed for monthly timeframes. While modern traders sometimes apply it to weekly or daily charts to increase sensitivity and frequency of signals, doing so distorts the original psychological premise of the 11- to 14-month grief cycle, and the indicator loses much of its statistical edge on shorter timeframes.

## Text Formula
The Coppock Curve is calculated in three steps:

1. Calculate the 14-period Rate of Change:
   `ROC_14 = ((Close - Close_14_periods_ago) / Close_14_periods_ago) * 100`

2. Calculate the 11-period Rate of Change:
   `ROC_11 = ((Close - Close_11_periods_ago) / Close_11_periods_ago) * 100`

3. Calculate the Coppock Curve as the 10-period Weighted Moving Average of the sum of the two ROCs:
   `Coppock = WMA_10(ROC_14 + ROC_11)`

The 10-period Weighted Moving Average is calculated by assigning a weight of 10 to the current period's value, 9 to the prior period's value, down to a weight of 1 for the period 10 steps back. The sum of the weighted values is then divided by the sum of the weights (55):
`WMA_10 = (10*Value_t + 9*Value_{t-1} + 8*Value_{t-2} + ... + 1*Value_{t-9}) / 55`

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock_curve(df):
    """
    Calculates the Coppock Curve for one or more symbols.
    
    Expected DataFrame columns:
    - symbol: Ticker identifier
    - date: Date of the observation
    - open: Opening price
    - high: Highest price
    - low: Lowest price
    - close: Closing price
    
    Returns the original DataFrame with added columns:
    - roc_14: 14-period Rate of Change
    - roc_11: 11-period Rate of Change
    - roc_sum: Sum of ROC_14 and ROC_11
    - coppock: 10-period WMA of roc_sum
    """
    # Ensure data is sorted chronologically for each symbol
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Calculate 14-period and 11-period Rate of Change
    df['roc_14'] = df.groupby('symbol')['close'].pct_change(periods=14) * 100
    df['roc_11'] = df.groupby('symbol')['close'].pct_change(periods=11) * 100
    
    # Sum the two ROCs
    df['roc_sum'] = df['roc_14'] + df['roc_11']
    
    # Define the Weighted Moving Average function
    def weighted_moving_average(data):
        if len(data) < 10:
            return np.nan
        # Weights: 10 for most recent, down to 1 for 10th most recent
        weights = np.arange(1, 11)
        return np.dot(data, weights) / weights.sum()
    
    # Calculate the 10-period WMA of the ROC sum, applied per symbol
    df['coppock'] = df.groupby('symbol')['roc_sum'].transform(
        lambda x: x.rolling(window=10).apply(weighted_moving_average, raw=True)
    )
    
    return df
```
```json
{ "model_code": "c5kw9bt2vrj6", "topic": "Coppock Curve", "timer_secs": 185.57, "tokens_in": 559, "tokens_out": 4036, "cost_tokens_in": 0.00054782, "cost_tokens_out": 0.01243088, "cost_tokens_tot": 0.01297870 }
```