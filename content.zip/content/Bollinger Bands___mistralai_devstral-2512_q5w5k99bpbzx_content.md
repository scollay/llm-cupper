# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator that consists of a middle band (a simple moving average) and two outer bands that are standard deviations away from the middle band. They appear on a price chart as three lines: the middle band (typically a 20-period SMA) and the upper and lower bands, which dynamically expand and contract based on market volatility. Created by John Bollinger in the 1980s, the bands help traders identify overbought or oversold conditions, potential breakouts, and periods of high or low volatility.

## Details
### How Bollinger Bands Work
Bollinger Bands are built around a simple moving average (SMA) of price, with the upper and lower bands set at a specified number of standard deviations (typically 2) above and below the SMA. The width of the bands adjusts automatically based on volatility:
- **Narrow bands** indicate low volatility (consolidation or "squeeze").
- **Wide bands** indicate high volatility (potential breakout or trend continuation).

### Interpretation
1. **Overbought/Oversold Signals**:
   - Prices touching or exceeding the **upper band** may suggest overbought conditions (potential reversal or pullback).
   - Prices touching or falling below the **lower band** may suggest oversold conditions (potential bounce).

2. **Volatility Breakouts**:
   - A squeeze (narrow bands) often precedes a sharp price move. Traders watch for breaks above/below the bands as potential entry signals.

3. **Trend Confirmation**:
   - In strong trends, prices may "ride" the upper or lower band. This is not a reversal signal but confirms trend strength.

4. **Divergence**:
   - If price makes a new high/low but the bands do not expand accordingly, it may signal weakening momentum.

### Limitations
- **Not a Standalone Tool**: Bollinger Bands work best when combined with other indicators (e.g., RSI, MACD) or price action patterns.
- **False Signals**: In ranging markets, touches of the bands can lead to whipsaws. In strong trends, prices may stay outside the bands for extended periods.
- **Standard Deviation Sensitivity**: The choice of standard deviations (e.g., 1.5 vs. 2.5) affects sensitivity. Wider bands reduce false signals but may delay entries.

## Text Formula
1. **Middle Band (MB)**:
   ```
   MB = SMA(close, n)
   ```
   where `n` is the lookback period (default = 20).

2. **Standard Deviation (SD)**:
   ```
   SD = sqrt(sum((close - MB)^2, n) / n)
   ```

3. **Upper Band (UB)** and **Lower Band (LB)**:
   ```
   UB = MB + (k * SD)
   LB = MB - (k * SD)
   ```
   where `k` is the number of standard deviations (default = 2).

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, n=20, k=2):
    """
    Calculate Bollinger Bands for a DataFrame with OHLC data.

    Parameters:
    - df: Pandas DataFrame with columns: symbol, date, open, high, low, close.
    - n: Lookback period for SMA and standard deviation (default=20).
    - k: Number of standard deviations for bands (default=2).

    Returns:
    - DataFrame with added columns: mb (middle band), ub (upper band), lb (lower band).
    - Handles multiple symbols independently.
    """
    # Ensure required columns exist
    required_cols = ['symbol', 'date', 'close']
    if not all(col in df.columns for col in required_cols):
        raise ValueError("DataFrame must contain columns: symbol, date, close")

    # Group by symbol to calculate bands independently
    df = df.copy()
    df['mb'] = df.groupby('symbol')['close'].transform(lambda x: x.rolling(n).mean())
    df['std'] = df.groupby('symbol')['close'].transform(lambda x: x.rolling(n).std(ddof=0))
    df['ub'] = df['mb'] + (k * df['std'])
    df['lb'] = df['mb'] - (k * df['std'])

    return df
```
```json
{ "model_code": "q5w5k99bpbzx", "topic": "Bollinger Bands", "timer_secs": 11.63, "tokens_in": 569, "tokens_out": 937, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00187400, "cost_tokens_tot": 0.00210160 }
```