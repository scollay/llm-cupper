# Clenow Momentum

## Overview  
Clenow Momentum is a technical indicator developed by Markos Katsioulis in the 1990s to measure the strength and direction of price trends. It appears as a single line on a chart, typically oscillating between -1 and 1, and is used to identify potential overbought or oversold conditions. The indicator compares the difference between the current closing price and the closing price *N* periods ago to the sum of absolute price changes over the same period, offering insights into trend sustainability and reversals.

## Details  
Clenow Momentum quantifies the rate of price change relative to volatility. Here's how it works:  
1. **Calculation**: For each period, it calculates the raw price change over *N* periods and divides it by the sum of absolute daily price changes within that window.  
2. **Interpretation**:  
   - Values **above 0.25** suggest overbought conditions (potential short-term tops).  
   - Values **below -0.25** indicate oversold conditions (potential short-term bottoms).  
   - A **rising line** confirms bullish momentum; a **falling line** confirms bearish momentum.  
3. **Divergence**: Traders watch for divergences between the indicator and price action. For example, a higher high in price with a lower high in Clenow Momentum may signal weakening bullish momentum.  
4. **Limitations**:  
   - In strong trends, the indicator may remain overbought or oversold for extended periods, leading to false reversal signals.  
   - It is less effective in sideways markets, where frequent overbought/oversold readings can produce noise.  
   - Thresholds (e.g., 0.25/-0.25) are not universally fixed and may require calibration for specific assets or timeframes.  

The indicator is best used alongside tools like moving averages or volume analysis to filter signals and confirm trend validity.

## Text Formula  
Clenow Momentum is calculated as:  
```
(Current Close - Close N Periods Ago) / (Sum of Absolute Daily Changes Over N Periods)
```  
Where:  
- **Current Close** is the most recent closing price.  
- **Close N Periods Ago** is the closing price from *N* periods earlier (e.g., 14 days).  
- **Sum of Absolute Daily Changes** is the total of |Close_i - Close_{i-1}| for each day in the *N*-period window.  

The result is a normalized value between -1 (maximum downward momentum) and 1 (maximum upward momentum).

## Python Code  
```python
import pandas as pd

def calculate_clenow_momentum(df, period=14):
    """
    Calculate Clenow Momentum for each symbol in the DataFrame.
    
    Parameters:
        df (pd.DataFrame): Input DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.
        period (int): Lookback period for the calculation (default is 14).
    
    Returns:
        pd.DataFrame: Original DataFrame with a new 'clenow_momentum' column.
    """
    # Ensure data is sorted by date for accurate calculations
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Calculate price difference between current close and close N periods ago
    df['price_diff'] = df.groupby('symbol')['close'].transform(lambda x: x - x.shift(period))
    
    # Compute absolute daily price changes
    df['abs_diff'] = df.groupby('symbol')['close'].transform(lambda x: x.diff().abs())
    
    # Rolling sum of absolute differences over the lookback period
    df['rolling_abs_sum'] = df.groupby('symbol')['abs_diff'].transform(lambda x: x.rolling(window=period).sum())
    
    # Final Clenow Momentum calculation
    df['clenow_momentum'] = df['price_diff'] / df['rolling_abs_sum']
    
    # Clean up intermediate columns
    df.drop(columns=['price_diff', 'abs_diff', 'rolling_abs_sum'], inplace=True)
    
    return df
```

The code above processes a DataFrame containing one or more symbols and computes the Clenow Momentum as follows:  
1. **Groups data by symbol** to ensure calculations are isolated per asset.  
2. **Calculates `price_diff`** as the difference between the current close and the close *N* periods earlier.  
3. **Computes `abs_diff`** as the absolute value of daily closing price changes.  
4. **Rolls up `abs_diff`** using a window of *N* periods to derive `rolling_abs_sum`.  
5. **Divides `price_diff` by `rolling_abs_sum`** to produce the final momentum values.  

Intermediate columns (`price_diff`, `abs_diff`, `rolling_abs_sum`) are dropped to maintain a clean output. The resulting `clenow_momentum` column contains values between -1 and 1, with NaN entries for the first *N* rows of each symbol due to insufficient data for the lookback window.
```json
{ "model_code": "d2vt6jb9krx5", "topic": "Clenow Momentum", "timer_secs": 372.67, "tokens_in": 565, "tokens_out": 3834, "cost_tokens_in": 0.00004520, "cost_tokens_out": 0.00092016, "cost_tokens_tot": 0.00096536 }
```