# T3 (T3 Moving Average)

## Overview
The T3 (T3 Moving Average) is a type of moving average designed to reduce lag while maintaining smoothness. Developed by Tim Tillson in 1998, it is a refinement of the exponential moving average (EMA) that applies multiple exponential smoothing steps to the price data. The T3 appears as a line on price charts, typically overlaid on candlestick or bar charts, and is used to identify trends and potential reversal points with less noise than traditional moving averages.

## Details
The T3 moving average is built on the concept of *Generalized Double Exponential Moving Average (GD-EMA)*, which applies exponential smoothing multiple times to reduce lag and improve responsiveness. Unlike a standard EMA, which smooths price data once, the T3 applies smoothing in a cascading fashion across multiple stages. This multi-step process helps to eliminate some of the lag inherent in single-pass smoothing while still filtering out short-term noise.

Traders use the T3 in several ways:
- **Trend identification**: When the T3 line is rising, it suggests an uptrend; when falling, a downtrend.
- **Support and resistance**: The T3 can act as dynamic support in an uptrend or resistance in a downtrend.
- **Signal generation**: Crossovers between price and the T3, or between the T3 and another moving average, are often used as entry or exit signals.
- **Smoothing volatility**: The T3’s construction helps reduce false signals during choppy market conditions.

However, the T3 is not without limitations:
- **Lag remains**: While reduced, some lag is still present, especially in strong trending markets.
- **Parameter sensitivity**: The performance of the T3 depends heavily on the choice of the *time period* and *smoothing factor* (commonly denoted as `v`). Poor parameter selection can lead to over-smoothing or excessive responsiveness.
- **False signals in ranging markets**: Like all moving averages, the T3 can produce whipsaws when price oscillates around the line without a clear trend.

The T3 is particularly popular among traders who prefer smoother indicators but want to avoid the excessive delay of traditional moving averages.

## Text Formula
The T3 indicator is calculated in five steps:

1. **Single Exponential Moving Average (EMA)**:
   Let `EMA₁` be the EMA of the closing price over `period` days:
   ```
   EMA₁ = EMA(close, period)
   ```

2. **Second EMA**:
   Compute the EMA of `EMA₁` over the same `period`:
   ```
   EMA₂ = EMA(EMA₁, period)
   ```

3. **Difference between EMAs**:
   ```
   d = EMA₁ - EMA₂
   ```

4. **Smoothed difference**:
   Apply a second smoothing step to `d` using the same `period`:
   ```
   d₂ = EMA(d, period)
   ```

5. **T3 final calculation**:
   Combine the original `EMA₁` and the smoothed difference `d₂` using a smoothing factor `v` (typically between 0 and 1):
   ```
   GD = EMA₁ + v * d₂
   T3 = GD * (1 + v) - v * GD
   ```

The final T3 value is:
```
T3 = GD * (1 + v) - v * GD
```

Where:
- `period` is the lookback window (e.g., 5, 10, 20).
- `v` is the volume factor (e.g., 0.7).

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_t3(df: pd.DataFrame, period: int = 5, v: float = 0.7) -> pd.DataFrame:
    """
    Calculate the T3 moving average for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Must be sorted by symbol and date.
    period : int
        The lookback period for the EMA calculations (default: 5).
    v : float
        The volume factor (smoothing coefficient), typically between 0 and 1 (default: 0.7).

    Returns:
    --------
    pd.DataFrame
        The input DataFrame with an additional column 't3' containing the T3 values.
    """
    # Make a copy to avoid modifying the original DataFrame
    df = df.copy()

    # Group by symbol to process each independently
    df['t3'] = np.nan

    for symbol, group in df.groupby('symbol'):
        closes = group['close'].values

        # Step 1: First EMA (EMA1)
        ema1 = pd.Series(closes).ewm(span=period, adjust=False).mean().values

        # Step 2: Second EMA (EMA2)
        ema2 = pd.Series(ema1).ewm(span=period, adjust=False).mean().values

        # Step 3: Difference d = EMA1 - EMA2
        d = ema1 - ema2

        # Step 4: Smoothed difference d2 = EMA(d, period)
        d2 = pd.Series(d).ewm(span=period, adjust=False).mean().values

        # Step 5: GD = EMA1 + v * d2
        gd = ema1 + v * d2

        # Final T3 = GD * (1 + v) - v * GD
        t3 = gd * (1 + v) - v * gd

        # Assign T3 values back to the DataFrame
        df.loc[group.index, 't3'] = t3

    return df
```
```json
{ "model_code": "k9nw5bp6vzx2", "topic": "T3", "timer_secs": 8.92, "tokens_in": 580, "tokens_out": 1267, "cost_tokens_in": 0.00008700, "cost_tokens_out": 0.00076020, "cost_tokens_tot": 0.00084720 }
```