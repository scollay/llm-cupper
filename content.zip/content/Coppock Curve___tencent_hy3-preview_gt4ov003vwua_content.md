# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum oscillator designed to identify major buying opportunities in broad equity indices. It is plotted as a single line oscillating above and below a zero baseline in a separate pane below the main price chart. The indicator was created by economist and investment advisor Edwin Coppock in 1962, developed at the request of the Episcopal Church’s national endowment fund to identify entry points for long-term S&P 500 positions following periods of market capitulation. Coppock reportedly derived the 11 and 14-period rate of change (ROC) lookbacks byasking Episcopal clergy how long it took congregants to recover from the grief of losing a loved one; the consensus answer of 11–14 months informed the indicator’s momentum windows. It is almost exclusively used on monthly timeframes, with standard parameters unchanged since its creation.

## Details
The Coppock Curve is a lagging, trend-following indicator built to filter out short-term market noise and isolate confirmed shifts from major bear markets to bull markets. Its calculation relies on two core assumptions: major market bottoms are accompanied by widespread capitulation (selling exhaustion), and long-term momentum shifts take months to confirm.

### Calculation Components
The standard calculation uses three fixed parameters: an 11-period ROC, a 14-period ROC, and a 10-period weighted moving average (WMA). Both ROC metrics measure the percentage change in closing price over their respective lookback windows. Summing the two ROC values captures momentum across medium (11 periods) and long (14 periods) timeframes. The 10-period WMA smooths this sum to eliminate volatile short-term fluctuations, producing the final Coppock Curve value.

### Standard Interpretation
The only widely accepted signal for the Coppock Curve is a zero-line crossover: when the indicator crosses from below zero to above zero, it generates a long-term buy signal. This crossover indicates that smoothed momentum has turned positive, confirming the prior bear market has ended and a new uptrend is underway. Edwin Coppock, the indicator’s creator, did not define sell signals, as the tool was designed exclusively for long-term entry. Later traders sometimes use a cross below zero as an exit signal, but this is not part of the original methodology.

Some traders also use bullish divergence to anticipate bottoms: if the index makes a lower low while the Coppock Curve makes a higher low, downward momentum is fading. However, divergence signals are rare for this slow-moving indicator and are not a primary trading trigger.

### Limitations of Interpretation
The Coppock Curve’s long lookback periods make it extremely lagging. On monthly timeframes, a zero crossover may not occur until 12–24 months after a market bottom, causing traders to miss the majority of the initial rally. It also performs poorly outside its intended use case: it is not calibrated for individual stocks, commodities, forex pairs, or small-cap indices, all of which have idiosyncratic price action that does not follow the broad capitulation pattern the indicator assumes.

In sideways, range-bound markets, the Coppock Curve will oscillate around zero, generating repeated false buy signals. Adjusting parameters for shorter timeframes (e.g., weekly or daily) invalidates the indicator’s core logic, as shorter periods cannot capture the long-term momentum shifts it is built to detect. Finally, it provides no framework for short selling, as it only identifies positive momentum shifts following major bottoms. Additionally, the Coppock Curve does not account for changes in modern market structure, such as algorithmic trading or passive indexing, which have shortened the duration of many 21st-century bear markets and reduced the reliability of historical zero-crossover signals.

## Text Formula
The Coppock Curve (CC) is calculated in four sequential steps, using closing price values `C` for period `t`, and standard parameters: `n₁=11` (short ROC period), `n₂=14` (long ROC period), `w=10` (WMA period).

1. Calculate 11-period Rate of Change (ROC₁₁):
   ROC₁₁ = [(Cₜ - Cₜ₋ₙ₁) / Cₜ₋ₙ₁] * 100
   Where `Cₜ₋ₙ₁` is the closing price `n₁` periods prior to `t`.

2. Calculate 14-period Rate of Change (ROC₁₄):
   ROC₁₄ = [(Cₜ - Cₜ₋ₙ₂) / Cₜ₋ₙ₂] * 100

3. Sum the two ROC values to get raw momentum:
   ROC_Sum = ROC₁₁ + ROC₁₄

4. Apply a 10-period linearly weighted moving average (WMAₙ) to `ROC_Sum` to get the Coppock Curve:
   WMAₙ = (Σ (i * ROC_Sumₜ₋ₙ₊ᵢ)) / 55
   Where:
   - `i` ranges from 1 to `n` (1 = oldest value in the WMA window, `n` = most recent value in the window)
   - Weights are linear: the most recent period in the window has weight `n` (10 for standard parameters), the oldest has weight 1
   - 55 is the sum of weights 1 through 10 (1+2+...+10 = 55)
   - `ROC_Sumₜ₋ₙ₊ᵢ` is the `ROC_Sum` value for the `i`-th oldest period in the `n`-period window

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(
    df: pd.DataFrame,
    roc_short: int = 11,
    roc_long: int = 14,
    wma_period: int = 10
) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols in a DataFrame.
    
    Input DataFrame Requirements:
    - Columns: `symbol`, `date`, `open`, `high`, `low`, `close`
    - `date` column must be convertible to datetime
    - Data for each symbol must be sorted chronologically (handled internally)
    
    Parameters:
    - roc_short: Short ROC lookback period (standard = 11)
    - roc_long: Long ROC lookback period (standard = 14)
    - wma_period: WMA smoothing period (standard = 10)
    
    Returns:
    - Input DataFrame with added `coppock_curve` column containing indicator values
    - NaN values will appear for periods where insufficient lookback data exists
    """
    # Create a copy to avoid modifying the original DataFrame
    df = df.copy()
    
    # Convert date to datetime and sort by symbol and date
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Define linear weights for WMA (oldest = 1, newest = wma_period)
    weights = list(range(1, wma_period + 1))
    sum_weights = sum(weights)  # 55 for standard wma_period=10
    
    # Calculate indicator per symbol group
    def _calculate_group(group: pd.DataFrame) -> pd.DataFrame:
        # Calculate short and long ROC
        group['roc_short'] = (group['close'] - group['close'].shift(roc_short)) / group['close'].shift(roc_short) * 100
        group['roc_long'] = (group['close'] - group['close'].shift(roc_long)) / group['close'].shift(roc_long) * 100
        
        # Sum ROC values
        group['roc_sum'] = group['roc_short'] + group['roc_long']
        
        # Calculate WMA of ROC sum
        # rolling window returns values ordered oldest to newest; multiply by weights (1 to wma_period)
        group['coppock_curve'] = group['roc_sum'].rolling(window=wma_period).apply(
            lambda x: (x * weights).sum() / sum_weights,
            raw=True
        )
        
        # Drop intermediate calculation columns (comment out to retain)
        group = group.drop(columns=['roc_short', 'roc_long', 'roc_sum'])
        
        return group
    
    # Apply group calculation, group_keys=False avoids adding symbol as an extra index
    df = df.groupby('symbol', group_keys=False).apply(_calculate_group)
    
    return df
```
```json
{ "model_code": "gt4ov003vwua", "topic": "Coppock Curve", "timer_secs": 129.91, "tokens_in": 565, "tokens_out": 9896, "cost_tokens_in": 0.00003560, "cost_tokens_out": 0.00207816, "cost_tokens_tot": 0.00211375 }
```