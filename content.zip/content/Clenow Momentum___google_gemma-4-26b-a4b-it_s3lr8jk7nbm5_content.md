# Clenow Momentum

## Overview
Clenow Momentum is a quantitative momentum indicator designed to rank assets based on a combination of price strength and liquidity-adjusted volatility. Unlike traditional momentum indicators that rely solely on percentage price changes over a fixed lookback period, this method seeks to identify "smooth" trends. It was popularized by trader Nick Clenow as part of a systematic trend-following framework to filter for stocks that exhibit consistent, low-volatility upward movement. On a chart, it is typically used as a ranking metric rather than an oscillator, helping traders select the top $N$ performers from a universe of stocks.

## Details
The core philosophy of Clenow Momentum is that not all price increases are equal. A stock that rises 20% in a straight line is qualitatively different from a stock that rises 20% through massive, erratic swings. The latter is more likely to experience a sharp reversal, whereas the former suggests institutional accumulation and a sustainable trend.

### The Mechanics of the Score
The indicator functions by calculating a momentum score for each asset. This score is derived from two primary components:

1.  **The Momentum Component:** This is the annualized rate of return over a specific lookback period (typically 1 year or 252 trading days). By annualizing the return, the indicator allows for a standardized comparison across different timeframes and asset classes.
2.  **The Volatility Adjustment:** To reward "smooth" trends, the momentum component is divided by the volatility of the returns. In Clenow's framework, this is often expressed as the ratio of the return to the standard deviation of those returns. This effectively creates a variation of a Sharpe-style ratio applied to price momentum.

### Interpretation and Application
Traders use Clenow Momentum to build a "momentum basket." The process generally follows these steps:
*   **Universe Selection:** Define a liquid universe (e.g., S&P 500 components).
*   **Ranking:** Calculate the Clenow Momentum score for every ticker in the universe.
*   **Selection:** Buy the top-ranked assets (e.g., the top 10 or 20) and exit positions when they fall out of the top tier or when the trend breaks.

By focusing on the ratio of return to volatility, the indicator naturally favors stocks with high "quality" momentum.

### Limitations and Failure Points
While effective in trending markets, Clenow Momentum faces several specific risks:
*   **Mean Reversion/Overextension:** Because the indicator ranks the strongest performers, it can lead to buying assets that are "overbought" in the short term, making the trader vulnerable to sharp mean-reversion events.
*   **Whipsaws in Sideways Markets:** In non-trending, range-bound markets, the indicator may produce frequent false signals as stocks rotate in and out of the top rankings without any actual trend being established.
*   **Lag:** As a trend-following metric, it is inherently lagging. It requires a trend to be well-established before the score rises significantly, meaning traders often miss the absolute bottom of a move.
*   **Volatility Spikes:** A sudden increase in volatility will cause the score to drop even if the price remains stable, potentially triggering an exit prematurely.

## Text Formula
The Clenow Momentum score is calculated as follows:

1.  **Annualized Return:** `( (Close_current / Close_n_days_ago) ^ (252 / n) ) - 1`
2.  **Volatility:** The standard deviation of the daily log returns over the same `n` period.
3.  **Clenow Momentum Score:** `Annualized Return / Volatility`

*Note: In some implementations, the volatility is calculated as the annualized standard deviation of daily returns to ensure the numerator and denominator are on the same time scale.*

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df, lookback_period=252):
    """
    Calculates the Clenow Momentum score for a DataFrame containing multiple symbols.
    
    Parameters:
    df (pd.DataFrame): Input data with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    lookback_period (int): The number of days to use for momentum and volatility calculation.
    
    Returns:
    pd.DataFrame: The original DataFrame with 'momentum_score' added.
    """
    
    # Ensure date is datetime and sorted for time-series calculations
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['symbol', 'date'])
    
    # Initialize the score column
    df['momentum_score'] = np.nan
    
    # Group by symbol to ensure calculations do not leak between different assets
    for symbol, group in df.groupby('symbol'):
        # Create a local copy for the specific symbol to avoid SettingWithCopyWarning
        indices = group.index
        
        # 1. Calculate Daily Log Returns for volatility calculation
        # Log returns are preferred for statistical properties in volatility modeling
        log_returns = np.log(group['close'] / group['close'].shift(1))
        
        # 2. Calculate Annualized Return
        # Formula: (Price_now / Price_n_days_ago)^(252/n) - 1
        # We use the price ratio over the lookback period
        price_ratio = group['close'] / group['close'].shift(lookback_period)
        annualized_return = (price_ratio ** (252 / lookback_period)) - 1
        
        # 3. Calculate Annualized Volatility
        # We calculate the rolling standard deviation of log returns and annualize it
        # Annualized Vol = StdDev(daily_log_returns) * sqrt(252)
        rolling_std = log_returns.rolling(window=lookback_period).std()
        annualized_vol = rolling_std * np.sqrt(252)
        
        # 4. Calculate Clenow Momentum Score
        # Score = Annualized Return / Annualized Volatility
        # Note: Since both are annualized, the sqrt(252) terms cancel out if 
        # using the ratio of (Return / StdDev), but we follow the explicit 
        # annualized logic for clarity.
        score = annualized_return / annualized_vol
        
        # Map the calculated values back to the main dataframe using the group indices
        df.loc[indices, 'momentum_score'] = score

    return df

# Required Input Format Documentation:
# The input DataFrame 'df' must contain:
# - symbol: str or object (the ticker identifier)
# - date: datetime or str (the observation date)
# - open: float (opening price)
# - high: float (highest price)
# - low: float (lowest price)
# - close: float (closing price)
```
```json
{ "model_code": "s3lr8jk7nbm5", "topic": "Clenow Momentum", "timer_secs": 64.65, "tokens_in": 579, "tokens_out": 1533, "cost_tokens_in": 0.00003474, "cost_tokens_out": 0.00050589, "cost_tokens_tot": 0.00054063 }
```