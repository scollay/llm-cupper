# Clenow Momentum
## Overview
The Clenow Momentum indicator is a momentum‑based oscillator that blends price change with a simple scaling factor, producing a single numeric value that moves above and below zero. It was introduced by trader Michael Clenow in the early 2000s as part of a broader set of systematic tools aimed at filtering noise in high‑frequency futures markets. On most charting platforms the indicator appears as a line that oscillates around a zero centre, often overlaid on the price pane or in a separate pane beneath the candles. Because it is calculated from the close price, it inherits the same time‑frame as the underlying chart, but the optional smoothing step can shift its visual lag. The indicator is especially popular among day‑traders and swing‑traders who need a quick gauge of whether a market is accelerating or decelerating, and it is frequently used in conjunction with trend‑following filters such as moving‑average crossovers.

### How it looks on a chart
When plotted, the raw momentum line typically ranges from –200 to +200 percent, though extreme values are rare. The smoothed version tends to stay within a narrower band, making it easier to spot sustained moves. Because the calculation is performed on a per‑symbol basis, each futures contract or equity can be displayed with its own momentum curve, allowing direct visual comparison across assets.

### Origin and adoption
Michael Clenow, a former proprietary trader turned educator, released the indicator in his 2005 book *The Complete Guide to Day Trading*. He claimed the method could capture the “true” momentum of a market by normalising price change relative to recent price levels. The approach quickly spread through online trading communities, where it was embraced for its simplicity and the fact that it can be coded in a few lines of Python or Excel.

## Details
### Core calculation
At its heart, Clenow Momentum measures the percentage change in closing price over a fixed look‑back window, then optionally adjusts that change by a volume‑based multiplier. The raw momentum for a given bar *t* is:

```
Raw_Momentum_t = (Close_t – Close_{t‑n}) / Close_{t‑n} × 100
```

where *n* is the chosen look‑back period, commonly 14 trading sessions. The raw value is then passed through a smoothing filter — most often a simple moving average (SMA) of length *m* — to produce a more stable signal:

```
Smoothed_Momentum_t = SMA(Raw_Momentum, m)_t
```

Traders typically interpret a positive raw momentum as bullish momentum and a negative value as bearish. Crossovers of the smoothed line with the zero axis are used as entry signals: a move from negative to positive suggests the start of an upward trend, while a reversal from positive to negative signals a potential exit or short entry. Some practitioners also look for divergences between price action and momentum — for example, a higher high in price accompanied by a lower high in momentum — to anticipate reversals.

### Interpretation
The sign of the smoothed momentum directly informs traders about the prevailing direction. A sustained positive value indicates that the market has been gaining ground relative to its price *n* periods ago, suggesting upward pressure. Conversely, a persistent negative value signals weakening price pressure. Because the indicator is normalized to a percentage, values can be compared across assets with different price levels, allowing a quick relative‑strength ranking.

### Limitations
While the calculation is straightforward, its predictive power hinges on several assumptions. First, it presumes that price changes over the look‑back window are representative of future dynamics, which may not hold during structural breaks. Second, the optional volume adjustment can become unstable when volume data is sparse or when order‑flow dominates price moves. Third, the indicator does not incorporate volatility, so two markets with identical momentum scores may have very different risk profiles. Finally, because the raw momentum is a percentage, extreme values can be misleading; a 200 % spike often reflects a brief spike rather than a durable trend.

### Parameter selection
Choosing the look‑back *n* and smoothing *m* is a trade‑off between responsiveness and noise reduction. Shorter *n* values (e.g., 5) generate more frequent signals but also increase false positives, especially in choppy markets. Longer *n* values (e.g., 30) smooth out short‑term fluctuations but may delay the detection of emerging trends. The smoothing window *m* typically mirrors the look‑back or is slightly shorter; a 9‑period SMA on a 14‑period raw momentum provides a balance between lag and stability. Back‑testing different combinations on historical data helps identify a setting that matches a trader’s risk tolerance and time horizon.

### Practical usage tips
- **Combine with trend filters**: Apply a longer‑term moving average (e.g., 200‑day SMA) and only take Clenow Momentum signals in the direction of that trend.
- **Scan a watchlist**: Since the indicator is computed per symbol, you can flag those with raw momentum crossing above zero while the broader market remains in an uptrend.
- **Monitor extreme values**: Values above +150 or below –150 often precede strong moves, but they are rare; treating them as high‑probability setups can improve win rates.
- **Account for transaction costs**: Because the indicator can generate frequent signals, realistic slippage and commission assumptions are essential for evaluating performance.

## Text Formula
The core calculation can be expressed in a single line of mathematics:

```
CM_raw(t) = (Close_t – Close_{t‑n}) / Close_{t‑n} × 100
CM_smooth(t) = SMA(CM_raw, m)_t
```

The first line computes the raw momentum as a percentage change over *n* periods. The second line smooths that percentage using an *m*-period simple moving average, yielding the final Clenow Momentum value that traders typically plot. If a volume filter is desired, the raw momentum may be multiplied by a volume ratio:

```
CM_adj(t) = CM_raw(t) × (Volume_t / SMA(Volume, m)_t)
```

This adjustment is optional and only meaningful when a volume column is present in the dataset.

## Python Code
```python
import pandas as pd

def clenow_momentum(df, lookback=14, smooth=9):
    """
    Calculate Clenow Momentum for each symbol.
    Expected columns: symbol, date, open, high, low, close
    Returns a DataFrame with original data plus:
        Raw_Momentum   – percentage change over `lookback` periods
        Smoothed_Momentum – SMA of Raw_Momentum over `smooth` periods
    """
    # Ensure chronological order within each symbol
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Raw momentum: (close - close shifted by lookback) / close shifted by lookback * 100
    df['Raw_Momentum'] = (df['close'] - df['close'].shift(lookback)) / df['close'].shift(lookback) * 100

    # Smoothed momentum: simple moving average of the raw momentum
    df['Smoothed_Momentum'] = df['Raw_Momentum'].rolling(window=smooth, min_periods=1).mean()

    # Preserve original DataFrame structure while keeping per‑symbol grouping
    result = df.groupby('symbol', group_keys=False).apply(lambda x: x)

    return result
```
```json
{ "model_code": "m5dw8jc4vyq7", "topic": "Clenow Momentum", "timer_secs": 141.52, "tokens_in": 583, "tokens_out": 9541, "cost_tokens_in": 0.00002915, "cost_tokens_out": 0.00190820, "cost_tokens_tot": 0.00193735 }
```