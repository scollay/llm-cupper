# Bollinger Bands

## Overview
Bollinger Bands are a technical analysis tool used to gauge market volatility and identify overbought or oversold conditions. They appear on a chart as three lines: a moving average and two standard deviations plotted above and below it. John Bollinger created Bollinger Bands in the 1980s.

## Details
Bollinger Bands consist of three components:
* A moving average, usually a simple moving average (SMA), which serves as the base line.
* An upper band, which is a specified number of standard deviations above the moving average.
* A lower band, which is the same number of standard deviations below the moving average.

The bands expand and contract based on volatility. When volatility increases, the bands widen; when it decreases, they narrow. Traders use Bollinger Bands to identify potential trading opportunities. Common interpretations include:
* When the price touches or breaks through the upper band, the asset may be overbought, and a reversal or correction is possible.
* When the price touches or breaks through the lower band, the asset may be oversold, and a bounce or reversal is possible.
* A squeeze, where the bands are close together, can indicate a potential breakout.
* A price move that starts at one band and reaches the other can be a sign of strength or weakness.

However, Bollinger Bands are not foolproof. Interpretation can be challenging during periods of low volatility or when the price is trending strongly. In such cases, the bands may remain narrow or the price may ride the band for an extended period, leading to false signals.

## Text Formula
To calculate Bollinger Bands, you need to compute the following:
* `SMA(n) = (sum(close, n)) / n`
* `std_dev(n) = sqrt((sum((close - SMA(n))^2, n)) / n)`
* `upper_band = SMA(n) + (k * std_dev(n))`
* `lower_band = SMA(n) - (k * std_dev(n))`
* `bandwidth = upper_band - lower_band`
* `%b = (close - lower_band) / bandwidth`

where `n` is the number of periods for the moving average and standard deviation, and `k` is the number of standard deviations for the bands.

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, n=20, k=2):
    # Ensure the dataframe is sorted by date
    df = df.sort_values(by='date')
    
    # Group by symbol to handle multiple symbols
    df['sma'] = df.groupby('symbol')['close'].transform(lambda x: x.rolling(n).mean())
    df['std_dev'] = df.groupby('symbol')['close'].transform(lambda x: x.rolling(n).std())
    df['upper_band'] = df['sma'] + (k * df['std_dev'])
    df['lower_band'] = df['sma'] - (k * df['std_dev'])
    df['bandwidth'] = df['upper_band'] - df['lower_band']
    df['percent_b'] = (df['close'] - df['lower_band']) / df['bandwidth']
    
    return df
```
```json
{ "model_code": "n7gx4mc8btf3", "topic": "Bollinger Bands", "timer_secs": 8.16, "tokens_in": 561, "tokens_out": 670, "cost_tokens_in": 0.00008415, "cost_tokens_out": 0.00040200, "cost_tokens_tot": 0.00048615 }
```