# Clenow Momentum

## Overview
Clenow Momentum is a trend-following indicator designed to measure the smooth, annualized rate of change in a security’s price. Created by professional trader and author Andreas Clenow, it appears as a single oscillating line on a chart, typically plotted below the price pane. Unlike raw percentage returns, Clenow Momentum uses an exponential regression to fit a smooth curve to historical prices, making it less sensitive to short-term noise and more reflective of the underlying trend’s strength and stability. It is a core component of the momentum ranking system detailed in Clenow’s book *Stocks on the Move*.

## Details
The indicator’s foundation is the idea that markets trend, and the best way to capture that trend is to measure it smoothly. A simple 12-month return, for example, can be heavily distorted by a single outlier price 12 months ago. Clenow Momentum solves this by fitting an exponential regression line to the closing prices over a lookback period, typically 90 trading days. The slope of this regression line is then annualized and expressed as a percentage.

**Calculation Logic**
The process involves three main steps:
1.  **Log Transformation:** The natural logarithm of each closing price in the lookback window is taken. This converts exponential price growth into a linear relationship, which is a requirement for linear regression.
2.  **Exponential Regression:** An ordinary least squares linear regression is performed, with the log prices as the dependent variable `y` and the day index (0, 1, 2, ...) as the independent variable `x`. The slope of this regression line represents the daily logarithmic rate of return.
3.  **Annualization and Scaling:** The daily slope is multiplied by the number of trading days in a year (commonly 252) to annualize it. The result is then exponentiated and subtracted by 1 to convert the continuous log return into a simple percentage return. Finally, it is multiplied by 100 to express it as a percentage.

**Interpretation**
Traders use Clenow Momentum primarily for relative strength ranking and absolute trend filtering.
- **Positive Values:** A reading above zero indicates an upward annualized trend. The higher the value, the stronger the momentum.
- **Negative Values:** A reading below zero indicates a downward annualized trend.
- **Cross-Sectional Ranking:** The most common use case is to calculate the indicator for a universe of stocks and rank them from highest to lowest momentum. The top-ranked stocks are candidates for long positions, while the bottom-ranked are candidates for shorts or avoidance.
- **Absolute Filter:** A threshold, such as requiring momentum to be above 0 or 5%, can be applied to ensure only stocks in established uptrends are considered.

**Limitations and Breakdowns**
The indicator’s smoothness is a double-edged sword. It inherently lags price action, sometimes significantly. A sharp, V-shaped reversal in price will take time to be reflected in the exponential regression slope, causing late entry and exit signals. During choppy, sideways markets, the slope can hover near zero and whipsaw, generating false signals. The indicator also assumes that the exponential trend of the past 90 days will persist, a condition that fails at every major trend change. Finally, the calculation is sensitive to the lookback period; a shorter period makes it more responsive but noisier, while a longer period increases the lag.

## Text Formula
The Clenow Momentum value for a given date `t` is calculated using a lookback window of `n` days (typically 90).

1.  **Prepare Data:**
    For `i` from 0 to `n-1` (where `i=0` is the oldest day in the window and `i=n-1` is the most recent day `t`):
    `x_i = i`
    `y_i = ln(close_{t - (n - 1 - i)})`

2.  **Calculate Slope of Linear Regression (y = a + b * x):**
    `b = [ n * Σ(x_i * y_i) - Σ(x_i) * Σ(y_i) ] / [ n * Σ(x_i^2) - (Σ(x_i))^2 ]`
    All summations are over `i` from 0 to `n-1`.

3.  **Annualize and Scale:**
    `Clenow_Momentum = ( e^{b * 252} - 1 ) * 100`
    Where `e` is Euler's number and 252 is the assumed number of trading days in a year.

## Python Code
```python
import pandas as pd
import numpy as np

def clenow_momentum(df: pd.DataFrame, window: int = 90, trading_days: int = 252) -> pd.Series:
    """
    Calculate Clenow Momentum for each symbol in a DataFrame independently.

    The indicator performs an exponential regression on the closing prices over
    a rolling window and returns the annualized slope as a percentage.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'close'.
        Data can contain one or more symbols. The DataFrame should be sorted by
        date within each symbol group for correct rolling window behavior.
    window : int
        Lookback period in trading days (default 90).
    trading_days : int
        Number of trading days per year for annualization (default 252).

    Returns
    -------
    pd.Series
        A Series of Clenow Momentum values aligned with the input DataFrame's index.
    """
    # Ensure data is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Calculate log closing prices
    df['log_close'] = np.log(df['close'])

    # Prepare the independent variable (x) for regression: 0, 1, 2, ..., window-1
    x = np.arange(window)

    # Pre-calculate sums for x to use in the regression formula
    sum_x = x.sum()
    sum_x_sq = (x ** 2).sum()
    denominator = window * sum_x_sq - sum_x ** 2

    def rolling_exp_regression(series):
        """
        Apply the exponential regression slope calculation to a rolling window.
        """
        # series is a rolling window of log_close values
        if len(series) < window:
            return np.nan

        y = series.values
        sum_y = np.sum(y)
        sum_xy = np.sum(x * y)

        # Calculate the slope (b) of the linear regression on log prices
        numerator = window * sum_xy - sum_x * sum_y
        slope = numerator / denominator

        # Annualize the slope and convert to percentage
        annualized_return = np.exp(slope * trading_days) - 1
        return annualized_return * 100

    # Group by symbol to ensure independence, then apply the rolling calculation
    momentum_series = df.groupby('symbol')['log_close'].transform(
        lambda group: group.rolling(window=window, min_periods=window).apply(
            rolling_exp_regression, raw=True
        )
    )

    # Clean up the temporary log column
    df.drop('log_close', axis=1, inplace=True)

    return momentum_series
```
```json
{ "model_code": "m4n8jp5xq7vh", "topic": "Clenow Momentum", "timer_secs": 44.65, "tokens_in": 561, "tokens_out": 1564, "cost_tokens_in": 0.00024123, "cost_tokens_out": 0.00136068, "cost_tokens_tot": 0.00160191 }
```