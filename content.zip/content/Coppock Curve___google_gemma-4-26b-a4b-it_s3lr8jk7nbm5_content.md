# Coppock Curve

## Overview
The Coppock Curve is a momentum indicator used primarily to identify long-term buying opportunities in cyclical markets. It appears as a line graph plotted in a separate window below the main price chart. Developed by Edwin Coppock in 1962, the indicator was originally designed to filter out short-term market noise and identify major market bottoms in large-cap stocks and broad market indices.

## Details
The Coppock Curve is a "momentum of momentum" indicator. Unlike oscillators that measure price relative to a range (like the RSI), the Coppock Curve measures the rate of change of a weighted combination of two different rates of change. This dual-layer approach smooths out volatility, making it a lagging but highly reliable signal for trend reversals.

### How It Works
The indicator relies on two distinct components:
1.  **The Long-Term Rate of Change (ROC):** This captures the broad trend of the asset over a significant period.
2.  **The Short-Term Rate of Change (ROC):** This captures more recent price momentum.

By calculating the ROC for both periods and then applying a Weighted Moving Average (WMA) to their sum, the indicator creates a smoothed curve. The primary goal is to identify when the downward momentum of a bear market is exhausting itself and turning upward.

### Trading Interpretation
Traders typically look for a specific signal: the **Zero-Line Cross**.
*   **Bullish Signal:** When the Coppock Curve crosses from a negative value to a positive value (moving upward through the zero line), it suggests that long-term momentum has shifted from bearish to bullish. This is often interpreted as a signal to enter a long position.
*   **Bearish Signal:** While the indicator is primarily used for bottom-fishing, a move from positive to negative can signal a loss of upward momentum, though it is less commonly used as a primary sell signal compared to its use as a buy signal.

### Limitations and Weaknesses
Because the Coppock Curve uses long lookback periods and a smoothing moving average, it is a **lagging indicator**. By the time the curve crosses the zero line, a significant portion of the initial price recovery may have already occurred.

Furthermore, the indicator is less effective in:
*   **Trending Markets:** In a strong, continuous bull market, the indicator may stay positive for extended periods, providing little actionable information.
*   **Sideways/Chop Markets:** In non-trending environments, the curve may oscillate around the zero line, generating "whipsaw" signals that lead to false entries.
*   **Short-Term Trading:** It is not designed for day trading or swing trading; using it on low timeframes (like 5-minute or 1-hour charts) will result in excessive noise and unreliable signals.

## Text Formula
To calculate the Coppock Curve, follow these steps:

1.  Calculate the Long-Term Rate of Change: `ROC_Long = ((Close - Close_n) / Close_n) * 100`, where `n` is typically 14 months.
2.  Calculate the Short-Term Rate of Change: `ROC_Short = ((Close - Close_m) / Close_m) * 100`, where `m` is typically 11 months.
3.  Sum the two rates: `Sum_ROC = ROC_Long + ROC_Short`.
4.  Calculate the Weighted Moving Average (WMA) of the `Sum_ROC` over a period `w` (typically 10 months).

`Coppock_Curve = WMA(ROC_Long + ROC_Short, w)`

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df, long_period=14, short_period=11, wma_period=10):
    """
    Calculates the Coppock Curve for a DataFrame containing one or more symbols.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    long_period (int): Lookback for the long-term ROC (standard is 14)
    short_period (int): Lookback for the short-term ROC (standard is 11)
    wma_period (int): Period for the Weighted Moving Average (standard is 10)
    
    Returns:
    pd.DataFrame: Original DataFrame with 'coppock_curve' column added.
    """
    
    # Ensure the dataframe is sorted by symbol and date to prevent calculation errors
    df = df.sort_values(['symbol', 'date']).copy()
    
    def compute_group(group):
        # 1. Calculate Long-Term Rate of Change (ROC)
        # Formula: ((Price / Price_n_periods_ago) - 1) * 100
        roc_long = group['close'].pct_change(periods=long_period) * 100
        
        # 2. Calculate Short-Term Rate of Change (ROC)
        roc_short = group['close'].pct_change(periods=short_period) * 100
        
        # 3. Sum the ROCs
        sum_roc = roc_long + roc_short
        
        # 4. Calculate the Weighted Moving Average (WMA) of the sum
        # WMA formula: sum(price_i * weight_i) / sum(weights)
        # where weights are 1, 2, 3... up to wma_period
        weights = range(1, wma_period + 1)
        
        def wma(series):
            if len(series) < wma_period:
                return float('nan')
            # Apply weights to the window
            return series.rolling(window=wma_period).apply(
                lambda x: (x * pd.Series(weights, index=range(wma_period))).sum() / sum(weights),
                raw=True
            )

        group['coppock_curve'] = wma(sum_roc)
        return group

    # Apply the calculation independently to each symbol group
    result_df = df.groupby('symbol', group_keys=False).apply(compute_group)
    
    return result_df

# Required Input Format Documentation:
# The input DataFrame 'df' must contain:
# - symbol: string/object (identifier for the asset)
# - date: datetime (chronological order)
# - open: float
# - high: float
# - low: float
# - close: float
```
```json
{ "model_code": "s3lr8jk7nbm5", "topic": "Coppock Curve", "timer_secs": 104.93, "tokens_in": 578, "tokens_out": 1457, "cost_tokens_in": 0.00003468, "cost_tokens_out": 0.00048081, "cost_tokens_tot": 0.00051549 }
```