# T3 Moving Average

## Overview
The T3 moving average is a sophisticated trend-following indicator developed by Tim Tillson. It is designed to reduce the lag associated with traditional moving averages while maintaining a smooth curve, effectively filtering out market noise without the "overshoot" common in other zero-lag attempts. On a chart, it appears as a single line that tracks price action more closely than a Simple Moving Average (SMA) but with significantly less jaggedness than an Exponential Moving Average (EMA).

## Details
The T3 is essentially a "triple-smoothed" moving average. While a standard moving average calculates a single average of price, the T3 applies a smoothing process multiple times to the same data set. This recursive smoothing creates a line that is highly responsive to price changes but remains visually fluid.

### How it Works
The core of the T3 is the `vFactor` (volume factor), a constant typically set between 0 and 1. This factor determines the balance between smoothness and responsiveness. A higher `vFactor` makes the indicator more responsive to price changes (reducing lag) but increases the risk of reacting to noise. A lower `vFactor` produces a smoother line that is more reliable for long-term trend identification but lags more behind current price.

The T3 calculation involves a series of six EMA-like steps. It calculates a first EMA, then uses that result to calculate a second, and so on, until it reaches the final T3 value. This layering process is what allows the indicator to "bend" more naturally with price pivots.

### Interpretation
Traders typically use the T3 in three ways:
1. **Trend Direction:** When price is above the T3 and the T3 is sloping upward, the trend is bullish. Conversely, price below a downward-sloping T3 indicates a bearish trend.
2. **Crossovers:** Traders may use a fast T3 and a slow T3. A crossover of the fast line above the slow line is a bullish signal.
3. **Support and Resistance:** In strong trending markets, the T3 often acts as a dynamic support or resistance level where price may bounce during pullbacks.

### Limitations
The T3 is a lagging indicator, regardless of how much the lag is reduced. In sideways or "choppy" markets, the T3 can produce frequent false signals (whipsaws) as the line flattens and price oscillates across it. Additionally, because it is a recursive calculation, the initial values of the indicator require a "warm-up" period of data before the line becomes mathematically stable.

## Text Formula
The T3 is calculated using a series of smoothed averages (`EMA`) based on a period `n` and a volume factor `vFactor`.

1. `a = vFactor * (n - 1) / (n + 2)`
2. `EMA1 = EMA(Price, n)`
3. `EMA2 = EMA(EMA1, n)`
4. `EMA3 = EMA(EMA2, n)`
5. `EMA4 = EMA(EMA3, n)`
6. `EMA5 = EMA(EMA4, n)`
7. `EMA6 = EMA(EMA5, n)`
8. `T3 = c1 * EMA6 + c2 * EMA5 + c3 * EMA4 + c4 * EMA3`

Where the constants are:
* `c1 = -a^3`
* `c2 = 3*a^2 + 3*a^3`
* `c3 = -6*a^2 - 3*a^3`
* `c4 = 1 + 3*a^2 + 3*a^3`

## Python Code
```python
import pandas as pd

def calculate_t3(df, period=5, v_factor=0.7):
    """
    Calculates the T3 Moving Average for a DataFrame.
    
    Input DataFrame format:
    - symbol: string
    - date: datetime
    - open: float
    - high: float
    - low: float
    - close: float
    
    Returns:
    - DataFrame with a new column 'T3'
    """
    
    # Calculate the constant 'a' based on v_factor and period
    a = v_factor * (period - 1) / (period + 2)
    
    # Calculate constants for the final T3 summation
    c1 = -a**3
    c2 = 3 * (a**2) + 3 * (a**3)
    c3 = -6 * (a**2) - 3 * (a**3)
    c4 = 1 + 3 * (a**2) + 3 * (a**3)
    
    def get_t3_series(series):
        # The T3 requires 6 successive EMA calculations
        ema1 = series.ewm(span=period, adjust=False).mean()
        ema2 = ema1.ewm(span=period, adjust=False).mean()
        ema3 = ema2.ewm(span=period, adjust=False).mean()
        ema4 = ema3.ewm(span=period, adjust=False).mean()
        ema5 = ema4.ewm(span=period, adjust=False).mean()
        ema6 = ema5.ewm(span=period, adjust=False).mean()
        
        # Final T3 combination
        t3 = (c1 * ema6) + (c2 * ema5) + (c3 * ema4) + (c4 * ema3)
        return t3

    # Process each symbol independently to avoid data leakage between assets
    df = df.copy()
    df['T3'] = df.groupby('symbol')['close'].transform(get_t3_series)
    
    return df
```
```json
{ "model_code": "d4vh9pq2xtw6", "topic": "T3", "timer_secs": 86.23, "tokens_in": 577, "tokens_out": 1286, "cost_tokens_in": 0.00006924, "cost_tokens_out": 0.00047582, "cost_tokens_tot": 0.00054506 }
```