# Clenow Momentum

## Overview
Clenow Momentum is a volatility-adjusted momentum indicator designed to identify assets exhibiting strong, smooth, and persistent upward trends. Unlike traditional oscillators that are plotted as overlays or lower-panel lines on a single price chart, Clenow Momentum is primarily used as a cross-sectional ranking metric to compare a large universe of stocks against one another. The indicator was created by hedge fund manager Andreas F. Clenow and introduced to the retail trading public in his 2015 book, *Stocks on the Move*. 

## Details

### The Problem with Traditional Momentum
Traditional momentum indicators, such as the Rate of Change (ROC), typically measure performance by comparing the current price to a historical price (for example, the price 90 days ago). While effective at identifying absolute growth, this point-A-to-point-B approach completely ignores the path the asset took to get there. 

A stock that grinds steadily upward by 30% over 90 days will have the exact same traditional momentum score as a stock that traded flat for 89 days and then gapped up 30% on a single earnings announcement. For active trend followers, the former is highly desirable because it indicates sustained institutional buying with a high signal-to-noise ratio. The latter is erratic, difficult to manage from a risk perspective, and prone to mean reversion. Clenow Momentum was engineered specifically to solve this problem by mathematically rewarding smoothness and penalizing volatility.

### The Mechanics of Smoothness
To measure the quality of a trend, Clenow Momentum relies on exponential regression. Because financial assets compound over time, a healthy trend curves upward on an absolute price chart. To analyze this linearly, the indicator first converts the closing prices over a specific lookback period (the default is 90 trading days) into their natural logarithms. 

Once the prices are log-transformed, the indicator calculates a linear regression line (a line of best fit) through the data points. The slope of this regression line represents the average daily growth rate of the asset. This daily rate is then annualized to give traders a recognizable percentage figure—for instance, an annualized slope of 45 means the stock is growing at a pace of 45% per year.

### The Volatility Penalty
The true ingenuity of Clenow Momentum lies in its use of the coefficient of determination, commonly known as R-squared ($R^2$). In statistics, $R^2$ measures how closely the actual data points hug the regression line. An $R^2$ value of 1.0 means the stock's price perfectly matches the upward trend line every single day. An $R^2$ value of 0.2 means the price is wildly fluctuating around the trend line.

To calculate the final Clenow Momentum score, the annualized slope is multiplied by the $R^2$ value. If a stock has a massive annualized growth rate of 100% but a terrible $R^2$ of 0.4 due to extreme volatility, its final momentum score is reduced to 40. Conversely, a stock with a more modest 60% growth rate but a beautifully smooth $R^2$ of 0.9 will achieve a final score of 54. In a ranking system, the smoother, slower stock will rightfully beat the erratic, explosive stock.

### Interpretation and Application
Traders do not typically use Clenow Momentum to generate standalone buy or sell signals for a single asset. Instead, it is used for portfolio construction. A trader will calculate the Clenow Momentum score for an entire index (such as the S&P 500 or Russell 1000), rank the stocks from highest to lowest, and buy the top 20 or 30 names. 

The portfolio is then rebalanced on a regular schedule—usually weekly or bi-weekly. If a stock drops out of the top tier (e.g., falls below rank 100), it is sold and replaced by a stock that has newly entered the top 20. This creates a dynamic, self-cleansing portfolio that constantly rotates into the market's smoothest leaders.

### Where the Indicator Breaks Down
Because Clenow Momentum relies on a relatively long lookback period (90 days), it is inherently lagging. This creates several specific vulnerabilities:

*   **Market Crashes and V-Bottoms:** During a sudden, severe market correction, the 90-day lookback will still contain older, bullish data. The indicator will be slow to downgrade formerly strong stocks. Conversely, during a sharp V-bottom recovery, the indicator will initially rank the stocks that fell the least, entirely missing the explosive early gains of the most beaten-down assets.
*   **Earnings Gaps:** If a stock in a smooth, steady uptrend suddenly gaps up 15% on stellar earnings, the actual price will deviate sharply from the historical regression line. Paradoxically, this massive positive event ruins the $R^2$ value, heavily penalizing the stock's momentum score and potentially causing a ranking system to sell a winning position.
*   **Choppy Regimes:** Like all trend-following metrics, Clenow Momentum breaks down in sideways, mean-reverting markets. To mitigate this, traders almost always pair it with a broader market regime filter, such as only taking new positions when the S&P 500 is trading above its 200-day moving average.

## Text Formula

To calculate the Clenow Momentum score and its underlying components over a lookback period of $N$ days (default $N = 90$):

1.  **Log Transformation:** For each day in the lookback period, calculate the natural logarithm of the closing price: $y = \ln(Close)$.
2.  **Time Array:** Create an array of integers representing time to serve as the independent variable: $x = [0, 1, 2, ..., N-1]$.
3.  **Linear Regression:** Perform a standard linear regression of $y$ on $x$ to find the line of best fit ($y = mx + b$). Extract the slope ($m$).
4.  **R-Squared Calculation:** Calculate the coefficient of determination ($R^2$) between the actual log prices and the predicted log prices from the regression line.
5.  **Annualized Slope:** Convert the daily log slope into an annualized percentage rate (assuming 252 trading days in a year): 
    `Annualized Slope = (exp(Slope * 252) - 1) * 100`
6.  **Clenow Momentum:** Multiply the annualized slope by the $R^2$ value to apply the volatility penalty:
    `Clenow Momentum = Annualized Slope * R-squared`

## Python Code

```python
import numpy as np
import pandas as pd

def calculate_clenow_momentum(df, lookback=90):
    """
    Calculates Clenow Momentum and its underlying components for a DataFrame of stock prices.
    
    Expected input format:
    A Pandas DataFrame containing the columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
    The DataFrame can contain data for multiple symbols.
    
    Returns:
    A copy of the original DataFrame with four new columns:
    - 'log_slope': The daily slope of the log-transformed prices.
    - 'r_squared': The coefficient of determination (smoothness penalty).
    - 'annualized_slope': The slope annualized as a percentage.
    - 'clenow_momentum': The final volatility-adjusted momentum score.
    """
    # Create a copy and sort to ensure chronological order per symbol
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Initialize output columns with NaNs
    df['log_slope'] = np.nan
    df['r_squared'] = np.nan
    df['annualized_slope'] = np.nan
    df['clenow_momentum'] = np.nan
    
    # Pre-calculate the independent variable (x) array for the regression
    x = np.arange(lookback)
    
    # Process each symbol independently
    for symbol, group in df.groupby('symbol'):
        closes = group['close'].values
        
        # Skip symbols that do not have enough data for the lookback window
        if len(closes) < lookback:
            continue
            
        log_closes = np.log(closes)
        
        # Initialize arrays to store results for the current symbol
        log_slopes = np.full(len(closes), np.nan)
        r_squareds = np.full(len(closes), np.nan)
        ann_slopes = np.full(len(closes), np.nan)
        momentums = np.full(len(closes), np.nan)
        
        # Iterate through the data using a rolling window
        for i in range(lookback - 1, len(closes)):
            # Extract the log prices for the current window
            y = log_closes[i - lookback + 1 : i + 1]
            
            # Calculate linear regression: y = mx + b
            slope, intercept = np.polyfit(x, y, 1)
            
            # Calculate R-squared
            y_pred = slope * x + intercept
            ss_res = np.sum((y - y_pred)**2) # Residual sum of squares
            ss_tot = np.sum((y - np.mean(y))**2) # Total sum of squares
            
            # Handle edge case where price is perfectly flat (ss_tot = 0)
            r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0
            
            # Calculate annualized slope (assuming 252 trading days)
            ann_slope = (np.exp(slope * 252) - 1) * 100
            
            # Store calculated values
            log_slopes[i] = slope
            r_squareds[i] = r2
            ann_slopes[i] = ann_slope
            momentums[i] = ann_slope * r2
            
        # Map the calculated arrays back to the main DataFrame using the group's index
        df.loc[group.index, 'log_slope'] = log_slopes
        df.loc[group.index, 'r_squared'] = r_squareds
        df.loc[group.index, 'annualized_slope'] = ann_slopes
        df.loc[group.index, 'clenow_momentum'] = momentums
        
    return df
```
```json
{ "model_code": "t5pz4nm8vqj7", "topic": "Clenow Momentum", "timer_secs": 55.20, "tokens_in": 567, "tokens_out": 6960, "cost_tokens_in": 0.00113400, "cost_tokens_out": 0.08352000, "cost_tokens_tot": 0.08465400 }
```