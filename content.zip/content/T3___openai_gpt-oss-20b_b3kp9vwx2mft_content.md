# T3 Moving Average

## Overview
The T3 (Triple Exponential Moving Average) is a smoothed trend‑following indicator that reduces lag while preserving the responsiveness of a standard moving average. It was introduced by *Tushar Chande* in the early 2000s as an improvement over the classic EMA and TEMA. On a chart the T3 appears as a single line that tracks price but reacts more quickly to recent changes than a standard EMA of the same period.

## Details
### How it works
The T3 is built from a series of exponential smoothing operations. It starts with a simple EMA of the closing price, then applies the EMA operator three times (hence “triple”). Finally, a *volume factor* `v` (typically 0.7–0.95) blends the TEMA with an additional smoothing step, producing a curve that is both smooth and responsive.

The standard parameter set is:
- `period` (n): the number of bars used for the EMA calculations (commonly 20 or 30).
- `volume_factor` (v): a value between 0 and 1 that controls the amount of smoothing. A higher `v` yields a smoother line but increases lag.

Traders use the T3 to:
- Identify the direction of the underlying trend (upward or downward).
- Generate entry signals when price crosses the T3 line.
- Set dynamic stop‑loss levels that trail the T3.

### Where it breaks down
Because the T3 is a lagging indicator, it can produce false signals during sideways or highly volatile markets. The volume factor can mitigate this, but a very high `v` may cause the T3 to lag behind sharp reversals. Additionally, the T3’s reliance on a fixed period means it may not adapt well to changing market conditions unless the period is adjusted manually.

## Text Formula
Let `C_t` be the close price at time `t`, `n` the period, and `v` the volume factor.

1. Compute the first EMA:
   ```
   EMA1_t = (C_t * (2/(n+1))) + (EMA1_{t-1} * (1 - 2/(n+1)))
   ```

2. Compute the second EMA (EMA of EMA1):
   ```
   EMA2_t = (EMA1_t * (2/(n+1))) + (EMA2_{t-1} * (1 - 2/(n+1)))
   ```

3. Compute the third EMA (EMA of EMA2):
   ```
   EMA3_t = (EMA2_t * (2/(n+1))) + (EMA3_{t-1} * (1 - 2/(n+1)))
   ```

4. Compute the TEMA (triple EMA):
   ```
   TEMA_t = 3 * EMA1_t - 3 * EMA2_t + EMA3_t
   ```

5. Compute the T3:
   ```
   T3_t = (1 - v) * TEMA_t + v * TEMA_{t-1}
   ```

The final `T3_t` is the value of the T3 moving average at time `t`.

## Python Code
```python
import pandas as pd

def calculate_t3(df: pd.DataFrame, period: int = 20, volume_factor: float = 0.7) -> pd.DataFrame:
    """
    Calculate the T3 moving average for each symbol in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
        The DataFrame may contain multiple symbols; calculations are performed per symbol.
    period : int, default 20
        Number of bars used for the EMA calculations.
    volume_factor : float, default 0.7
        Smoothing factor between 0 and 1. Higher values produce a smoother line.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with an additional column 't3' containing the T3 value.
    """
    # Ensure the data is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Helper function to compute EMA series
    def ema(series: pd.Series, span: int) -> pd.Series:
        return series.ewm(span=span, adjust=False).mean()

    # Group by symbol to keep calculations independent
    def compute_group(group: pd.DataFrame) -> pd.DataFrame:
        close = group['close']

        # First EMA
        ema1 = ema(close, period)

        # Second EMA (EMA of EMA1)
        ema2 = ema(ema1, period)

        # Third EMA (EMA of EMA2)
        ema3 = ema(ema2, period)

        # TEMA calculation
        tema = 3 * ema1 - 3 * ema2 + ema3

        # T3 calculation: blend current TEMA with previous TEMA
        t3 = (1 - volume_factor) * tema + volume_factor * tema.shift(1)

        group['t3'] = t3
        return group

    # Apply per symbol
    result = df.groupby('symbol', group_keys=False).apply(compute_group)

    return result
```
```json
{ "model_code": "b3kp9vwx2mft", "topic": "T3", "timer_secs": 121.04, "tokens_in": 621, "tokens_out": 7383, "cost_tokens_in": 0.00001801, "cost_tokens_out": 0.00103362, "cost_tokens_tot": 0.00105163 }
```