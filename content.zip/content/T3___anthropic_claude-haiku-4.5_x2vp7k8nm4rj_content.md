# T3

## Overview

The T3 moving average is a smoothed, trend-following indicator designed to reduce lag while filtering out market noise. Created by Tillson in the early 2000s, T3 applies a series of exponential moving averages (EMAs) in sequence to produce a responsive yet stable line that adapts well to different market conditions. On a chart, T3 appears as a smooth curve that typically hugs price action more closely than traditional moving averages while remaining less prone to whipsaws than raw price data.

## Details

The T3 moving average solves a common problem in technical analysis: the trade-off between responsiveness and smoothness. Simple moving averages lag significantly but are stable; exponential moving averages respond faster but can be choppy. T3 bridges this gap by applying multiple layers of exponential smoothing, creating a composite indicator that is both smooth and relatively quick to react to trend changes.

**How T3 Works**

T3 begins with a single EMA of the closing price, then feeds that result into a second EMA, and continues this process through multiple stages. The standard T3 uses six sequential EMAs, though some traders adjust this parameter. Each successive EMA smooths the previous one, progressively reducing noise while maintaining directional sensitivity.

The key to T3's responsiveness lies in its volume factor (often called the "hot" parameter), which adjusts how aggressively the indicator responds to price changes. A higher volume factor makes T3 more reactive; a lower one makes it smoother. Most implementations use a volume factor between 0.5 and 1.0, with 0.7 being a common default.

**Interpretation and Use Cases**

Traders use T3 primarily as a trend-following tool. When price trades above T3, the trend is considered up; when price trades below, the trend is down. Because T3 is smoother than price but faster than traditional long-period moving averages, it can serve as both a trend filter and an entry/exit signal.

Common applications include:

- **Trend confirmation**: Price crossing above T3 suggests an emerging uptrend; crossing below suggests a downtrend.
- **Support and resistance**: T3 often acts as dynamic support in uptrends and dynamic resistance in downtrends.
- **Momentum divergence**: When price makes a new high but T3 does not, it may signal weakening momentum.
- **Multiple timeframe analysis**: Traders often apply T3 to both short-term and longer-term charts to align bias and filter false signals.

**Where T3 Breaks Down**

Despite its elegance, T3 has limitations. In choppy, range-bound markets, the smoothing can cause T3 to lag behind price reversals, leading to late entries and exits. The indicator also performs poorly during flash crashes or gap moves, where the sequential EMA calculations cannot keep pace with sudden price dislocations.

Additionally, T3 is not predictive—it follows price, not leads it. Traders who rely solely on T3 crossovers without considering volume, volatility, or broader market structure often find themselves entering trades after significant moves have already occurred. The choice of volume factor and the number of EMA stages are also subjective; different settings produce different results, and there is no universally optimal configuration.

Finally, T3 can generate false signals in low-liquidity environments or during news events when spreads widen and price action becomes erratic.

## Text Formula

**Step 1: Calculate the first EMA**

```
EMA1 = EMA(close, period)
```

where `period` is typically 5 for T3.

**Step 2: Calculate subsequent EMAs**

```
EMA2 = EMA(EMA1, period)
EMA3 = EMA(EMA2, period)
EMA4 = EMA(EMA3, period)
EMA5 = EMA(EMA4, period)
EMA6 = EMA(EMA5, period)
```

**Step 3: Apply the volume factor and combine**

```
T3 = c1 * EMA6 + c2 * EMA5 + c3 * EMA4 + c4 * EMA3
```

where the coefficients are derived from the volume factor `v`:

```
a = v
c1 = -a^3
c2 = 3 * a^2 + 3 * a^3
c3 = -6 * a^2 - 3 * a - 3 * a^3
c4 = 1 + 3 * a + a^3 + 3 * a^2
```

The standard volume factor is `v = 0.7`.

**EMA calculation (standard exponential moving average)**

```
multiplier = 2 / (period + 1)
EMA = previous_EMA + multiplier * (price - previous_EMA)
```

For the first value, EMA equals the simple moving average of the first `period` bars.

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_t3(df, period=5, volume_factor=0.7):
    """
    Calculate T3 moving average for a DataFrame containing one or more symbols.
    
    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame with columns: symbol, date, open, high, low, close
    period : int
        Period for the initial EMA (default 5)
    volume_factor : float
        Volume factor controlling responsiveness (default 0.7)
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with added column 't3'
    """
    
    df = df.copy()
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)
    
    # Calculate coefficients based on volume factor
    a = volume_factor
    c1 = -a**3
    c2 = 3 * a**2 + 3 * a**3
    c3 = -6 * a**2 - 3 * a - 3 * a**3
    c4 = 1 + 3 * a + a**3 + 3 * a**2
    
    # Multiplier for EMA calculation
    multiplier = 2 / (period + 1)
    
    # Initialize columns for each EMA stage
    for i in range(1, 7):
        df[f'ema{i}'] = np.nan
    df['t3'] = np.nan
    
    # Process each symbol independently
    for symbol in df['symbol'].unique():
        mask = df['symbol'] == symbol
        symbol_df = df[mask].copy()
        indices = df[mask].index
        
        # Calculate EMA1 from close prices
        ema1_values = np.full(len(symbol_df), np.nan)
        close_values = symbol_df['close'].values
        
        # Initialize first EMA with SMA of first 'period' bars
        if len(symbol_df) >= period:
            ema1_values[period - 1] = close_values[:period].mean()
            for j in range(period, len(symbol_df)):
                ema1_values[j] = ema1_values[j - 1] + multiplier * (close_values[j] - ema1_values[j - 1])
        
        df.loc[indices, 'ema1'] = ema1_values
        
        # Calculate EMA2 through EMA6 by applying EMA to previous EMA
        for stage in range(2, 7):
            prev_ema_col = f'ema{stage - 1}'
            curr_ema_col = f'ema{stage}'
            ema_values = np.full(len(symbol_df), np.nan)
            prev_ema_values = df.loc[indices, prev_ema_col].values
            
            # Initialize with SMA of first 'period' valid values
            valid_mask = ~np.isnan(prev_ema_values)
            valid_indices = np.where(valid_mask)[0]
            
            if len(valid_indices) >= period:
                first_valid_idx = valid_indices[period - 1]
                ema_values[first_valid_idx] = prev_ema_values[valid_indices[:period]].mean()
                
                for j in range(first_valid_idx + 1, len(symbol_df)):
                    if not np.isnan(prev_ema_values[j]) and not np.isnan(ema_values[j - 1]):
                        ema_values[j] = ema_values[j - 1] + multiplier * (prev_ema_values[j] - ema_values[j - 1])
            
            df.loc[indices, curr_ema_col] = ema_values
        
        # Calculate T3 as weighted combination of EMA3, EMA4, EMA5, EMA6
        ema3 = df.loc[indices, 'ema3'].values
        ema4 = df.loc[indices, 'ema4'].values
        ema5 = df.loc[indices, 'ema5'].values
        ema6 = df.loc[indices, 'ema6'].values
        
        t3_values = np.full(len(symbol_df), np.nan)
        for j in range(len(symbol_df)):
            if not (np.isnan(ema3[j]) or np.isnan(ema4[j]) or np.isnan(ema5[j]) or np.isnan(ema6[j])):
                t3_values[j] = c1 * ema6[j] + c2 * ema5[j] + c3 * ema4[j] + c4 * ema3[j]
        
        df.loc[indices, 't3'] = t3_values
    
    # Drop intermediate EMA columns, keep only T3
    df = df.drop(columns=[f'ema{i}' for i in range(1, 7)])
    
    return df
```
```json
{ "model_code": "x2vp7k8nm4rj", "topic": "T3", "timer_secs": 16.27, "tokens_in": 607, "tokens_out": 2443, "cost_tokens_in": 0.00060700, "cost_tokens_out": 0.01221500, "cost_tokens_tot": 0.01282200 }
```