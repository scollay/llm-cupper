# Clenow Momentum

## Overview
The Clenow Momentum indicator, developed by Andreas Clenow, is a trend-following tool designed to identify and quantify the strength and direction of price trends. It appears on a chart as a line oscillating around a central value, typically zero, with positive values indicating bullish momentum and negative values signaling bearish momentum. Clenow introduced this indicator in his book *Stocks on the Move: Beating the Market with Hedge Fund Momentum Strategies* (2015), emphasizing its use in momentum-based trading strategies.

## Details
The Clenow Momentum indicator calculates the rate of change (ROC) of a security's price over a specified period, typically 9 days, and then smooths the result using a shorter-term moving average, often 3 days. This dual-layer approach helps filter out noise while maintaining sensitivity to trend changes. Traders use the indicator to:

1. **Identify Trends**: Positive values suggest an uptrend, while negative values indicate a downtrend.
2. **Generate Signals**: Crosses above or below the zero line can signal trend shifts, with crosses above zero potentially indicating a buy signal and crosses below zero a sell signal.
3. **Assess Momentum Strength**: The magnitude of the indicator's value reflects the strength of the trend. Higher positive or negative values indicate stronger momentum.

However, the Clenow Momentum indicator is not without limitations. Like other momentum indicators, it can produce false signals during sideways or choppy markets. Additionally, its effectiveness depends on the chosen parameters, which may need adjustment based on the asset and market conditions. Traders should use it in conjunction with other tools for confirmation.

## Text Formula
The Clenow Momentum (`CM`) is calculated as follows:

1. **Rate of Change (ROC)**:  
   \[
   \text{ROC} = \frac{\text{Close}_t - \text{Close}_{t-n}}{\text{Close}_{t-n}} \times 100
   \]  
   Where:  
   - `Close_t` = Current closing price  
   - `Close_{t-n}` = Closing price `n` periods ago  
   - `n` = Lookback period (typically 9)  

2. **Smoothed Momentum**:  
   \[
   \text{CM} = \text{SMA}(\text{ROC}, m)
   \]  
   Where:  
   - `SMA` = Simple Moving Average  
   - `m` = Smoothing period (typically 3)  

## Python Code
```python
import pandas as pd

def clenow_momentum(data: pd.DataFrame, lookback: int = 9, smoothing: int = 3) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for each symbol in the DataFrame.

    Parameters:
    - data (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.
    - lookback (int): Lookback period for ROC (default=9).
    - smoothing (int): Smoothing period for SMA (default=3).

    Returns:
    - pd.DataFrame: Input DataFrame with added 'clenow_momentum' column.
    """
    # Group by symbol to handle multiple symbols independently
    result = data.copy()
    for symbol, group in data.groupby('symbol'):
        # Calculate Rate of Change (ROC)
        group['roc'] = (group['close'] - group['close'].shift(lookback)) / group['close'].shift(lookback) * 100
        # Apply smoothing using SMA
        group['clenow_momentum'] = group['roc'].rolling(window=smoothing, min_periods=1).mean()
        # Update the result DataFrame
        result.loc[result['symbol'] == symbol, 'clenow_momentum'] = group['clenow_momentum']
    return result
```
```json
{ "model_code": "b9tw6cf3sql4", "topic": "Clenow Momentum", "timer_secs": 12.83, "tokens_in": 575, "tokens_out": 825, "cost_tokens_in": 0.00143750, "cost_tokens_out": 0.00825000, "cost_tokens_tot": 0.00968750 }
```