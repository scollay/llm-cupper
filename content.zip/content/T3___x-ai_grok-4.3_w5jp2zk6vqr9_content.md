# T3

## Overview
The T3 is a smoothed moving-average indicator designed to reduce lag while filtering noise more effectively than conventional exponential moving averages. It plots as a single continuous line overlaid on price. Tim Tillson introduced the T3 in 1997 as part of his work on multiple-smoothed moving averages that incorporate a volume-factor parameter to control responsiveness.

## Details
T3 is constructed from six successive exponential moving averages of the same length. The final value is a weighted linear combination of the third through sixth EMAs. The weighting coefficients are derived from a single “volume factor” parameter, conventionally set between 0.7 and 1.0. Higher values increase smoothing at the cost of additional lag; lower values produce a faster but noisier line.

Traders interpret the T3 much like other moving averages: price above the line and the line rising signals an uptrend, while price below a falling line signals a downtrend. Crossovers between price and the T3, or between two T3 lines of different periods, are used to generate signals. Because the indicator already embeds six smoothing passes, it rarely whipsaws in ranging markets and tends to stay on the correct side of sustained trends.

The principal limitation appears in the early stages of a new trend. The heavy smoothing delays the first meaningful turn of the T3, so traders relying solely on the indicator for timing often enter well after the initial move. In addition, the volume-factor setting is arbitrary; no universal optimum exists across instruments or time frames, requiring empirical calibration.

## Text Formula
Let \(e_1\) be the EMA of close with length \(n\).  
\(e_2 =\) EMA(\(e_1\), \(n\)), …, \(e_6 =\) EMA(\(e_5\), \(n\)).  

With volume factor \(v\):  
\[
T3 = (1+v)^3 e_3 - 3v(1+v)^2 e_4 + 3v^2(1+v) e_5 - v^3 e_6
\]

## Python Code
```python
import pandas as pd

def calculate_t3(df, period=5, v=0.7):
    df = df.sort_values(['symbol', 'date']).copy()
    
    def t3_one_symbol(group):
        close = group['close']
        e1 = close.ewm(span=period, adjust=False).mean()
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()
        
        t3 = ((1 + v)**3 * e3
              - 3 * v * (1 + v)**2 * e4
              + 3 * v**2 * (1 + v) * e5
              - v**3 * e6)
        group['t3'] = t3
        return group
    
    return df.groupby('symbol', group_keys=False).apply(t3_one_symbol)
```
```json
{ "model_code": "w5jp2zk6vqr9", "topic": "T3", "timer_secs": 12.69, "tokens_in": 676, "tokens_out": 1765, "cost_tokens_in": 0.00084500, "cost_tokens_out": 0.00441250, "cost_tokens_tot": 0.00525750 }
```