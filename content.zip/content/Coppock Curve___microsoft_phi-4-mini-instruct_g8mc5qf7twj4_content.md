# Coppock Curve

## Overview
The Coppock Curve is a momentum indicator developed by economist and trader Joseph Coppock in the 1970s. It is designed to identify long-term trends in the stock market and is particularly useful for spotting potential bullish reversals. The Coppock Curve is plotted by calculating the 14-day exponential moving average (EMA) of the 11-month moving average of the difference between the high and low prices of a stock. Traders typically look for a positive crossover of the Coppock Curve with the zero line as a bullish signal, indicating that it may be time to consider buying.

## Details
The Coppock Curve is constructed by first calculating the 11-month moving average of the difference between the high and low prices of a stock over a 14-day period. This is then smoothed using an exponential moving average with a period of 10 days. A positive crossover of the Coppock Curve with the zero line is generally interpreted as a bullish signal, suggesting that the stock may be entering a new uptrend. Conversely, a negative crossover is seen as a bearish signal, indicating a potential downtrend. However, traders should be cautious, as the Coppock Curve can produce false signals, and it is often best used in conjunction with other indicators to confirm trends.

## Text Formula
The Coppock Curve is calculated using the following steps:

1. Calculate the 11-month moving average of the difference between the high and low prices of a stock over a 14-day period.
2. Smooth the result using an exponential moving average with a period of 10 days.
3. Plot the resulting values on a chart.

## Python Code
```python
import pandas as pd

def coppock_curve(data):
    # Ensure the data is sorted by date
    data = data.sort_values('date')
    
    # Calculate the 14-day high-low difference
    data['high_low_diff'] = data['high'] - data['low']
    
    # Calculate the 11-month moving average of the high-low difference
    data['11_month_ma'] = data['high_low_diff'].rolling(window=252).mean(periods=11).shift(252)
    
    # Calculate the Coppock Curve
    data['coppock_curve'] = data['11_month_ma'].ewm(span=10, adjust=False).mean()
    
    return data[['date', 'coppock_curve']]

# Example usage:
# data = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL'],
#     'date': ['2021-01-01', '2021-01-08'],
#     'open': [150, 152],
#     'high': [155, 157],
#     'low': [148, 150],
#     'close': [149, 153]
# })
# coppock_curve(data)
```

This Python code assumes a Pandas DataFrame input with columns: `symbol`, `date`, `open`, `high`, `low`, `close`. The Coppock Curve is calculated for each symbol independently, and the resulting values are returned as a DataFrame with columns `date` and `coppock_curve`. The code uses the `ewm` function to calculate the exponential moving average, and the `rolling` function to calculate the 11-month moving average. The resulting Coppock Curve values can then be plotted on a chart to identify potential bullish or bearish signals.
```json
{ "model_code": "g8mc5qf7twj4", "topic": "Coppock Curve", "timer_secs": 3.11, "tokens_in": 555, "tokens_out": 707, "cost_tokens_in": 0.00004440, "cost_tokens_out": 0.00024745, "cost_tokens_tot": 0.00029185 }
```