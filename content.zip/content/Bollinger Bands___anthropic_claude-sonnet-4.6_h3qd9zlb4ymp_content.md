# Bollinger Bands

## Overview

Bollinger Bands are a volatility-based technical indicator developed by John Bollinger in the early 1980s and formally introduced in his 2001 book *Bollinger on Bollinger Bands*. The indicator plots three lines directly on a price chart: a middle band (a simple moving average), an upper band above it, and a lower band below it. The distance between the upper and lower bands expands and contracts dynamically as market volatility rises and falls, giving the indicator its distinctive envelope shape.

---

## Details

### Construction

Bollinger Bands are built from two inputs: a **lookback period** (most commonly 20 bars) and a **multiplier** for the standard deviation (most commonly 2.0). The middle band is simply the 20-period simple moving average (SMA) of closing prices. The upper and lower bands are placed a fixed number of standard deviations above and below that average, where the standard deviation is calculated over the same 20-period rolling window.

The standard deviation used is the *population* standard deviation of the prices in the window — not the sample standard deviation — consistent with Bollinger's original specification.

### The Bandwidth and %B Derivatives

Two additional values are commonly derived from the raw bands:

- **Bandwidth** measures how wide the bands are relative to the middle band. It is expressed as a percentage and rises during volatile periods and falls during quiet ones. Traders watch for extremely low bandwidth readings — sometimes called a *Bollinger Squeeze* — as a potential precursor to a sharp directional move.
- **%B** (percent B) expresses where the current price sits within the bands, scaled from 0 to 1. A reading of 1.0 means price is exactly at the upper band; 0.0 means it is exactly at the lower band; 0.5 means it is at the middle band. Readings above 1.0 or below 0.0 indicate price has moved outside the bands entirely.

### Typical Interpretations

**Volatility cycles.** Because the bands widen in high-volatility environments and narrow in low-volatility ones, they provide a visual map of the market's volatility cycle. A prolonged squeeze (narrow bands) often precedes a breakout, though the bands themselves do not indicate *direction*.

**Mean reversion.** In ranging markets, prices tend to oscillate between the upper and lower bands. A touch of the upper band can signal an overbought condition; a touch of the lower band can signal oversold. Some traders fade these touches, expecting a reversion toward the middle band.

**Trend following.** In strong trends, price can "walk the band" — repeatedly closing at or beyond the upper band in an uptrend, or at or beyond the lower band in a downtrend. In this context, a touch of the upper band is *not* a sell signal; it is a sign of momentum.

**Breakout confirmation.** A close outside the bands after a squeeze can signal the start of a new trend. Traders often wait for a second close outside the band, or combine the signal with a volume or momentum filter, to reduce false breakouts.

### Where Interpretation Breaks Down

- **No directional bias.** The bands signal *that* volatility is changing, not *which way* price will move. A squeeze resolves in one direction or the other, and the bands alone cannot tell you which.
- **Trend vs. range confusion.** The mean-reversion interpretation and the trend-following interpretation are contradictory. Applying the wrong one to the current market regime is a common source of losses.
- **Parameter sensitivity.** Changing the period or multiplier significantly alters the signals. The default 20/2 settings work reasonably well across many markets, but there is no universally optimal setting.
- **Lagging nature.** Because the middle band is an SMA, all three bands lag price. In fast-moving markets, the bands may not widen quickly enough to contain price action.

---

## Text Formula

**Middle Band (MB)**
```
MB = SMA(close, n)
   = (close_1 + close_2 + ... + close_n) / n
```

**Rolling Population Standard Deviation (σ)**
```
σ = sqrt( (1/n) * Σ (close_i - MB)² )   for i = 1 to n
```

**Upper Band (UB) and Lower Band (LB)**
```
UB = MB + (k * σ)
LB = MB - (k * σ)
```

**Bandwidth (BW)**
```
BW = (UB - LB) / MB
```

**%B**
```
%B = (close - LB) / (UB - LB)
```

Where `n` is the lookback period (default 20) and `k` is the standard deviation multiplier (default 2.0).

---

## Python Code

```python
import pandas as pd

def bollinger_bands(
    df: pd.DataFrame,
    period: int = 20,
    multiplier: float = 2.0,
    price_col: str = "close",
) -> pd.DataFrame:
    """
    Calculate Bollinger Bands and derived values for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        May contain data for one or more symbols.
    period : int
        Lookback window for the SMA and standard deviation (default 20).
    multiplier : float
        Number of standard deviations for the upper/lower bands (default 2.0).
    price_col : str
        Column to use as the price series (default "close").

    Returns
    -------
    pd.DataFrame
        Original DataFrame with five additional columns appended:
          bb_middle    - Simple moving average (middle band)
          bb_upper     - Upper Bollinger Band
          bb_lower     - Lower Bollinger Band
          bb_bandwidth - Bandwidth: (upper - lower) / middle
          bb_pct_b     - %B: (price - lower) / (upper - lower)
    """

    # Work on a copy to avoid mutating the caller's DataFrame
    result = df.copy()

    # Sort so rolling windows are computed in chronological order per symbol
    result = result.sort_values(["symbol", "date"]).reset_index(drop=True)

    def _calc_bands(group: pd.DataFrame) -> pd.DataFrame:
        price = group[price_col]

        # Middle band: simple moving average (population ddof=0 matches Bollinger spec)
        middle = price.rolling(window=period, min_periods=period).mean()

        # Rolling population standard deviation (ddof=0)
        std = price.rolling(window=period, min_periods=period).std(ddof=0)

        upper = middle + multiplier * std
        lower = middle - multiplier * std

        # Bandwidth: relative width of the bands
        bandwidth = (upper - lower) / middle

        # %B: position of price within the bands
        pct_b = (price - lower) / (upper - lower)

        group = group.copy()
        group["bb_middle"] = middle
        group["bb_upper"] = upper
        group["bb_lower"] = lower
        group["bb_bandwidth"] = bandwidth
        group["bb_pct_b"] = pct_b

        return group

    result = result.groupby("symbol", group_keys=False).apply(_calc_bands)

    return result
```
```json
{ "model_code": "h3qd9zlb4ymp", "topic": "Bollinger Bands", "timer_secs": 31.76, "tokens_in": 610, "tokens_out": 1777, "cost_tokens_in": 0.00183000, "cost_tokens_out": 0.02665500, "cost_tokens_tot": 0.02848500 }
```