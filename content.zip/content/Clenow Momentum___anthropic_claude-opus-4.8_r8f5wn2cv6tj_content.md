# Clenow Momentum

## Overview

**Clenow Momentum** is a stock-ranking measure popularized by Andreas Clenow in his book *Stocks on the Move* (2015). Rather than a line plotted under price like an oscillator, it produces a single number per stock that lets a trader rank a universe of securities from strongest to weakest momentum. It is the engine behind a class of systematic momentum strategies that rotate capital into the highest-ranked names while filtering out erratic movers.

The core idea is to fit an *exponential regression* to the logarithm of closing prices over a lookback window (Clenow uses 90 trading days), convert the slope into an annualized return, and then penalize stocks whose price action does not fit a clean trend. The result is a momentum score that rewards smooth, persistent advances over volatile, choppy ones.

## Details

### How it works

Clenow Momentum is built in three steps.

1. **Exponential regression slope.** Take the natural log of closing prices and run an ordinary least-squares regression of `log(close)` against time (an integer day index `0, 1, 2, ...`). Because the prices are logged, the slope represents a continuously compounded *daily* growth rate.

2. **Annualization.** Convert the daily slope to an annualized percentage return. Clenow assumes 250 trading days per year:

   `annualized_return = (exp(slope) ^ 250 - 1) * 100`

   This expresses the trend as "what return would this pace produce over a year," making stocks of different price levels directly comparable.

3. **R² adjustment.** Multiply the annualized return by the regression's coefficient of determination, `R²`. The `R²` measures how well the straight line fits the logged prices — a value near `1.0` means a smooth, consistent trend, while a low value flags a jumpy or noisy move. Multiplying by `R²` discounts stocks whose gains came from a single gap or erratic spikes.

The final number is the **momentum score**:

`score = annualized_return * R²`

### How traders interpret it

- **Ranking, not signaling.** The score is most useful as a *relative* ranking across a universe (for example, the S&P 500 constituents). Each rebalance, traders sort by score and allocate to the top names.
- **Quality filter.** Because of the `R²` term, a stock that doubled in a straight line outranks a stock that doubled through violent swings. This biases the strategy toward orderly trends that tend to persist.
- **Companion filters.** Clenow pairs the score with additional rules: only buy stocks trading above their 100-day moving average, exclude stocks that have had a recent large single-day gap (often `>15%`), and trade only when a broad index is above its long-term average. Position sizes are typically set by volatility (e.g., ATR-based) so each holding contributes similar risk.

### Where interpretation breaks down

- **Lookback sensitivity.** The 90-day window is a convention, not a law. Shorter windows react faster but produce noisier rankings; longer windows lag. The score can change character meaningfully with the window choice.
- **R² masks magnitude — and vice versa.** A modest trend with very high `R²` can outrank a powerful trend with mediocre `R²`. Whether that is desirable depends on the strategy's goals; it is not always intuitive.
- **Mean reversion and reversals.** Momentum ranking is backward-looking. High scorers can be late-stage moves vulnerable to sharp reversals, which is precisely why the gap filter and trend filters exist.
- **Survivorship and universe choice.** Rankings are only as good as the universe. Applying the score to a static, hand-picked list introduces bias; the original method uses a broad, evolving index membership.
- **Data requirements.** With fewer than the full lookback of observations, the regression is unreliable. Stocks with insufficient history should be excluded rather than scored on partial data.

## Text Formula

For a single stock over a lookback window of `N` trading days (Clenow uses `N = 90`):

```
Let the closing prices be C[0], C[1], ..., C[N-1]
Let x = 0, 1, 2, ..., N-1   (time index)
Let y = ln(C)               (natural log of closing prices)

Fit ordinary least squares:  y = a + b*x

  b (slope)     = covariance(x, y) / variance(x)
  a (intercept) = mean(y) - b * mean(x)

R-squared:
  y_hat   = a + b*x
  ss_res  = sum( (y - y_hat)^2 )
  ss_tot  = sum( (y - mean(y))^2 )
  R2      = 1 - (ss_res / ss_tot)

Annualized return (250 trading days, in percent):
  annualized_return = ( exp(b) ^ 250 - 1 ) * 100

Momentum score:
  score = annualized_return * R2
```

## Python Code

```python
import numpy as np
import pandas as pd

# Expected input: a pandas DataFrame `df` with the columns:
#   symbol : str   ticker identifier
#   date   : datetime-like   trading date
#   open   : float
#   high   : float
#   low    : float
#   close  : float
# The DataFrame may contain one or more symbols stacked together.


def clenow_momentum(df, lookback=90, trading_days=250):
    """
    Compute Clenow Momentum for each symbol using the most recent
    `lookback` closes.

    Returns a DataFrame with one row per symbol and the columns:
        symbol, slope, annualized_return, r_squared, score
    Symbols with fewer than `lookback` observations are skipped.
    """
    results = []

    # Process each symbol independently.
    for symbol, group in df.groupby("symbol"):
        # Sort chronologically so the regression uses the correct order.
        group = group.sort_values("date")
        closes = group["close"].to_numpy(dtype=float)

        # Need a full lookback window of valid data.
        if len(closes) < lookback:
            continue

        # Use only the most recent `lookback` closes.
        window = closes[-lookback:]

        # Guard against non-positive prices (log is undefined).
        if np.any(window <= 0):
            continue

        # Independent variable: integer time index 0..lookback-1.
        x = np.arange(lookback, dtype=float)
        # Dependent variable: natural log of closing prices.
        y = np.log(window)

        # Ordinary least squares slope and intercept.
        x_mean = x.mean()
        y_mean = y.mean()
        x_dev = x - x_mean
        y_dev = y - y_mean

        var_x = np.sum(x_dev ** 2)
        slope = np.sum(x_dev * y_dev) / var_x
        intercept = y_mean - slope * x_mean

        # R-squared of the fit.
        y_hat = intercept + slope * x
        ss_res = np.sum((y - y_hat) ** 2)
        ss_tot = np.sum(y_dev ** 2)
        r_squared = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 0.0

        # Annualized return in percent.
        annualized_return = ((np.exp(slope) ** trading_days) - 1.0) * 100.0

        # Final momentum score: annualized return penalized by fit quality.
        score = annualized_return * r_squared

        results.append({
            "symbol": symbol,
            "slope": slope,
            "annualized_return": annualized_return,
            "r_squared": r_squared,
            "score": score,
        })

    # Build the output and rank from strongest to weakest momentum.
    out = pd.DataFrame(results)
    if not out.empty:
        out = out.sort_values("score", ascending=False).reset_index(drop=True)
    return out
```
```json
{ "model_code": "r8f5wn2cv6tj", "topic": "Clenow Momentum", "timer_secs": 34.37, "tokens_in": 846, "tokens_out": 2627, "cost_tokens_in": 0.00423000, "cost_tokens_out": 0.06567500, "cost_tokens_tot": 0.06990500 }
```