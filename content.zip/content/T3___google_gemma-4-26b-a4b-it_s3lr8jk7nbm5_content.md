# T3 Moving Average

## Overview
The T3 Moving Average is a sophisticated technical indicator designed to reduce the inherent lag found in traditional moving averages while simultaneously smoothing out price noise. Developed by Tim Tillson in the late 1990s, the T3 is a "triple-smoothed" moving average that utilizes a series of exponential moving averages (EMAs) passed through a specific damping factor. On a chart, it appears as a single, fluid line that tracks price action more closely than a Simple Moving Average (SMA) or a standard Exponential Moving Average (EMA), but with significantly less "jitter" than a standard EMA.

## Details

### The Lag-Smoothing Paradox
In technical analysis, traders face a constant trade-off: the more you smooth a moving average to remove market noise, the more "lag" you introduce, meaning the indicator reacts slowly to new price trends. Conversely, the more you reduce lag to catch turns early, the more "noise" or false signals you invite into your strategy.

The T3 indicator attempts to solve this paradox through a recursive smoothing process. Instead of simply averaging prices, the T3 applies a volume factor (often called the `vFactor` or `multiplier`) to a series of nested EMA calculations. This allows the indicator to stay "tight" to the price action during strong trends while remaining smooth enough to avoid being whipsawed by minor fluctuations.

### How the T3 Works
The T3 is not a single calculation but a composite of multiple EMA layers. The process involves calculating a series of intermediate values (often referred to as `e1` through `e6`). Each stage uses the previous stage's result as the input for the next, with the damping factor applied at each step.

The core of the T3's behavior is controlled by the `vFactor`. A common default value for this multiplier is `0.7`. 
*   **Low vFactor:** Results in a smoother line with more lag, behaving more like a traditional long-term trend follower.
*   **High vFactor:** Results in a line that tracks price very closely with minimal lag, but increases the risk of false signals during sideways markets.

### Trading Interpretations
Traders typically use the T3 in three primary ways:

1.  **Trend Direction:** When the price is trading above the T3 line, the immediate bias is considered bullish. When the price is below the T3, the bias is bearish.
2.  **Slope Analysis:** The angle of the T3 line serves as a momentum gauge. A steepening slope suggests accelerating trend strength, while a flattening slope suggests a potential trend exhaustion or consolidation.
3.  **Crossovers:** Like other moving averages, the T3 can be used in crossover strategies. A "fast" T3 (with a lower period) crossing a "slow" T3 (with a higher period) can signal a change in market regime.

### Limitations and Failure Points
The T3 is not a crystal ball and is subject to specific market conditions where it may fail:

*   **Chop/Sideways Markets:** In non-trending, range-bound markets, the T3 can produce "whipsaws." Because it is designed to be responsive, it may flip its slope frequently, leading to multiple false entries and exits.
*   **Extreme Volatility:** During "black swan" events or sudden news-driven spikes, the T3 may still lag behind the instantaneous price move, potentially leading to late entries if used as a standalone signal.
*   **Over-optimization:** Because the `vFactor` is a customizable parameter, traders may be tempted to "curve-fit" the indicator to past data, creating a setting that looks perfect on historical charts but fails in live trading.

## Text Formula

To calculate the T3, we first define the Exponential Moving Average (EMA) for a given period `n`:
`EMA = Price * (2 / (n + 1)) + Previous_EMA * (1 - (2 / (n + 1)))`

The T3 calculation uses a damping factor `a` (where `a = vFactor * (6 / (6 + 1))` is a common derivation, though most implementations simply use the `vFactor` directly in the coefficient). The recursive steps are:

1.  `e1 = EMA(Price, n)`
2.  `e2 = EMA(e1, n)`
3.  `e3 = EMA(e2, n)`
4.  `e4 = EMA(e3, n)`
5.  `e5 = EMA(e4, n)`
6.  `e6 = EMA(e5, n)`

The final T3 value is calculated using the coefficients derived from the `vFactor` (let `c = vFactor`):
`T3 = c * e6 + (1 - c) * e5`

*(Note: In many standard implementations, the formula is expanded to a more complex polynomial of the EMA stages to ensure the triple-smoothing effect is mathematically consistent with the damping factor.)*

A more standard implementation of the T3 formula used in algorithmic trading is:
`c1 = -a^3`
`c2 = 3a^2 + 3a^3`
`c3 = -6a^2 - 3a - 3a^3`
`c4 = 1 + 3a + 3a^2 + 4a^3`
`T3 = c1*e6 + c2*e5 + c3*e4 + c4*e3`

## Python Code

```python
import pandas as pd

def calculate_t3(df, period=10, v_factor=0.7):
    """
    Calculates the T3 Moving Average for a DataFrame.
    
    Parameters:
    df (pd.DataFrame): Input data containing 'symbol' and 'close' columns.
    period (int): The lookback period for the EMA calculations.
    v_factor (float): The damping factor (multiplier).
    
    Returns:
    pd.DataFrame: The original DataFrame with a new 't3' column.
    """
    
    # Ensure the dataframe is sorted by symbol and date for correct EMA calculation
    # Expected columns: symbol, date, open, high, low, close
    df = df.sort_values(['symbol', 'date']).copy()
    
    def compute_group_t3(group):
        close = group['close']
        
        # Step 1: Calculate the nested EMAs
        # e1 is the standard EMA
        e1 = close.ewm(span=period, adjust=False).mean()
        # e2 through e6 are successive EMAs of the previous result
        e2 = e1.ewm(span=period, adjust=False).mean()
        e3 = e2.ewm(span=period, adjust=False).mean()
        e4 = e3.ewm(span=period, adjust=False).mean()
        e5 = e4.ewm(span=period, adjust=False).mean()
        e6 = e5.ewm(span=period, adjust=False).mean()
        
        # Step 2: Calculate coefficients based on the v_factor (a)
        a = v_factor
        c1 = -a**3
        c2 = 3*a**2 + 3*a**3
        c3 = -6*a**2 - 3*a - 3*a**3
        c4 = 1 + 3*a + 3*a**2 + 4*a**3
        
        # Step 3: Combine the EMAs using the coefficients
        t3_values = (c1 * e6) + (c2 * e5) + (c3 * e4) + (c4 * e3)
        
        group['t3'] = t3_values
        return group

    # Apply the calculation independently to each symbol group
    return df.groupby('symbol', group_keys=False).apply(compute_group_t3)

# Required DataFrame Format Documentation:
# The input 'df' must be a pandas DataFrame with the following columns:
# - 'symbol': string/object, unique identifier for the asset
# - 'date': datetime, the timestamp of the price bar
# - 'open': float, opening price
# - 'high': float, highest price
# - 'low': float, lowest price
# - 'close': float, closing price
```
```json
{ "model_code": "s3lr8jk7nbm5", "topic": "T3", "timer_secs": 40.03, "tokens_in": 560, "tokens_out": 1776, "cost_tokens_in": 0.00003360, "cost_tokens_out": 0.00058608, "cost_tokens_tot": 0.00061968 }
```