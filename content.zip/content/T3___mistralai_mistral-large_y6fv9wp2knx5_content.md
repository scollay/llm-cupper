# T3 Moving Average

## Overview

The T3 Moving Average is a technical indicator designed to reduce lag while maintaining smoothness in trend-following applications. Created by Tim Tillson in 1998, the T3 is an enhanced version of the exponential moving average (EMA) that applies multiple smoothing passes to produce a more responsive yet stable curve. On charts, the T3 appears as a single line that hugs price action more closely than traditional moving averages during trends but avoids the whipsaws of raw price data.

## Details

### How the T3 Works
The T3 is built from a series of six EMAs, each smoothed by the previous one. This cascade of smoothing creates a composite curve that reacts faster to price changes than a single EMA of the same length while retaining a smooth profile. The key innovation is the use of a volume factor (`vFactor`) that controls the degree of smoothing. When `vFactor` is 0, the T3 reduces to a simple EMA; when `vFactor` is 1, it becomes a triple-smoothed EMA with minimal lag.

### Interpretation
Traders typically use the T3 in the same way as other moving averages:
- **Trend Identification**: Price above the T3 suggests an uptrend; price below suggests a downtrend.
- **Crossovers**: A shorter-period T3 crossing above a longer-period T3 may signal a bullish entry, and vice versa.
- **Support/Resistance**: The T3 line often acts as dynamic support in uptrends and resistance in downtrends.

### Limitations
- **Lag**: Despite its reduced lag, the T3 still lags price action, especially during sharp reversals.
- **Parameter Sensitivity**: The `vFactor` and period length require optimization for different assets and timeframes.
- **False Signals**: Like all moving averages, the T3 can produce false crossovers in choppy or sideways markets.

## Text Formula

The T3 is calculated in stages:

1. Compute the initial EMA:
   ```
   EMA1 = EMA(close, period)
   ```

2. Compute five additional EMAs, each smoothed by the previous one:
   ```
   EMA2 = EMA(EMA1, period)
   EMA3 = EMA(EMA2, period)
   EMA4 = EMA(EMA3, period)
   EMA5 = EMA(EMA4, period)
   EMA6 = EMA(EMA5, period)
   ```

3. Apply the volume factor (`vFactor`, typically 0.7) to create the T3:
   ```
   c1 = -vFactor^3
   c2 = 3 * vFactor^2 + 3 * vFactor^3
   c3 = -6 * vFactor^2 - 3 * vFactor - 3 * vFactor^3
   c4 = 1 + 3 * vFactor + vFactor^3 + 3 * vFactor^2

   T3 = c1 * EMA6 + c2 * EMA5 + c3 * EMA4 + c4 * EMA3
   ```

## Python Code

```python
import pandas as pd

def calculate_t3(data: pd.DataFrame, period: int = 5, v_factor: float = 0.7) -> pd.DataFrame:
    """
    Calculate the T3 Moving Average for one or more symbols in a DataFrame.

    Parameters:
    - data: DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    - period: Lookback period for the T3 calculation (default: 5)
    - v_factor: Volume factor controlling smoothing (default: 0.7)

    Returns:
    - DataFrame with original columns plus 't3' column containing the T3 values
    """
    if not all(col in data.columns for col in ['symbol', 'close']):
        raise ValueError("DataFrame must contain 'symbol' and 'close' columns")

    # Calculate coefficients for the T3 formula
    v_factor_cubed = v_factor ** 3
    c1 = -v_factor_cubed
    c2 = 3 * (v_factor ** 2) + 3 * v_factor_cubed
    c3 = -6 * (v_factor ** 2) - 3 * v_factor - 3 * v_factor_cubed
    c4 = 1 + 3 * v_factor + v_factor_cubed + 3 * (v_factor ** 2)

    def _ema(series: pd.Series, period: int) -> pd.Series:
        """Helper function to calculate EMA with pandas"""
        return series.ewm(span=period, adjust=False).mean()

    def _calculate_single_symbol(group: pd.DataFrame) -> pd.DataFrame:
        """Calculate T3 for a single symbol"""
        close = group['close']

        # Calculate the six EMAs
        ema1 = _ema(close, period)
        ema2 = _ema(ema1, period)
        ema3 = _ema(ema2, period)
        ema4 = _ema(ema3, period)
        ema5 = _ema(ema4, period)
        ema6 = _ema(ema5, period)

        # Apply T3 formula
        t3 = c1 * ema6 + c2 * ema5 + c3 * ema4 + c4 * ema3
        group['t3'] = t3
        return group

    # Apply calculation to each symbol independently
    result = data.groupby('symbol', group_keys=False).apply(_calculate_single_symbol)
    return result
```
```json
{ "model_code": "y6fv9wp2knx5", "topic": "T3", "timer_secs": 17.36, "tokens_in": 568, "tokens_out": 1207, "cost_tokens_in": 0.00113600, "cost_tokens_out": 0.00724200, "cost_tokens_tot": 0.00837800 }
```