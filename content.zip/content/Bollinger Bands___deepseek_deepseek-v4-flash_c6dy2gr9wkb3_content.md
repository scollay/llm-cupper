# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator consisting of a simple moving average (middle band) and two outer bands plotted at a fixed number of standard deviations above and below that average. On a price chart, the bands expand and contract as volatility increases and decreases, visually framing price action. The indicator was developed by John Bollinger in the 1980s and remains one of the most widely used tools for assessing overbought/oversold conditions, identifying breakout opportunities, and gauging market volatility.

## Details

### Construction and Core Logic
The middle band is typically a 20‑period simple moving average (SMA) of the closing price. The upper and lower bands are calculated using a volatility measure — the standard deviation of the same closing price series — multiplied by a constant (commonly 2). The formula is applied to each period independently, meaning the bands are dynamic and self‑adjusting.

Two additional derived values are often used alongside the bands:

- **%B** – indicates where the last close lies relative to the bands. For example, a %B above 1.0 means price is above the upper band, and below 0.0 means price is below the lower band.
- **BandWidth** – measures the width of the bands relative to the middle band, expressed as a percentage. It serves as a volatility indicator.

### Typical Interpretation
Traders use Bollinger Bands in several ways, but none of these readings should be taken as automatic trading signals without additional context.

- **Overbought / Oversold** – Price touching or exceeding the upper band is considered overbought; touching or breaching the lower band is oversold. In strong trends, prices can “walk the band” — staying above the upper band in an uptrend or below the lower band in a downtrend — making simple overbought/oversold readings unreliable.
- **The Squeeze** – When the BandWidth contracts to a multi‑period low, volatility is low and a strong directional move (breakout) often follows. The squeeze does not indicate direction; it only warns that a large move is probable.
- **Reverting to the Mean** – Many traders expect price to revert toward the middle band after an extreme. This works best in range‑bound markets but fails in trending conditions because bands can remain in an extended state.
- **Pattern Confirmation** – For example, a bullish breakout above the upper band after a squeeze can confirm a new uptrend. Conversely, a bearish breakdown below the lower band can validate a downtrend.

### Limitations and Interpretation Pitfalls
- Bollinger Bands are *lagging* because the middle band is a moving average; sudden changes in volatility are only reflected after the standard deviation recalculates.
- In very low‑volatility environments, the bands are tight and small price moves can cause %B to flash extreme readings, leading to false signals.
- The indicator does not predict the *direction* of a breakout from a squeeze — it only signals that a large move is likely.
- Using a different period or standard deviation multiplier changes the sensitivity. A 2‑std, 20‑period setting is a starting point, but it should be optimized for each time frame and asset.

## Text Formula

Let:

- `close` = closing price series  
- `n` = lookback period (commonly 20)  
- `k` = number of standard deviations (commonly 2)  
- `MA(close, n)` = simple moving average of `close` over the last `n` periods  
- `σ(close, n)` = population standard deviation of `close` over the last `n` periods  

**Middle Band (SMA):**  
`BB_middle = MA(close, n)`

**Upper Band:**  
`BB_upper = BB_middle + k × σ(close, n)`

**Lower Band:**  
`BB_lower = BB_middle − k × σ(close, n)`

**BandWidth:**  
`BB_width = (BB_upper − BB_lower) / BB_middle × 100`

**%B:**  
`%B = (close − BB_lower) / (BB_upper − BB_lower)`

Note: The standard deviation used is typically the *population* standard deviation (dividing by `n`, not `n−1`) to match common implementations.

## Python Code

```python
import pandas as pd
import numpy as np

def compute_bollinger_bands(
    df: pd.DataFrame,
    window: int = 20,
    num_std: float = 2.0
) -> pd.DataFrame:
    """
    Compute Bollinger Bands, BandWidth, and %B for one or more symbols.

    The input DataFrame must contain columns:
        symbol  - asset identifier (string)
        date    - datetime or similar (order is preserved within each symbol)
        close   - closing price (float)

    All other columns (open, high, low) are ignored.

    Returns a new DataFrame with the original columns plus:
        BB_middle    - 20-period SMA of close
        BB_upper     - middle + num_std * rolling std (population)
        BB_lower     - middle - num_std * rolling std
        BB_width     - (upper - lower) / middle * 100
        BB_percent_B - (close - lower) / (upper - lower)
    """
    # Sort by symbol and date to ensure correct rolling calculation
    df = df.sort_values(['symbol', 'date']).copy()

    # Group by symbol; for each group compute rolling statistics
    def _bands_for_group(group):
        # Rolling SMA and population standard deviation
        rolling = group['close'].rolling(window=window, min_periods=window)
        middle = rolling.mean()
        std = rolling.std(ddof=0)  # population std (divide by N)
        upper = middle + num_std * std
        lower = middle - num_std * std
        # Derived indicators
        width = (upper - lower) / middle * 100
        # Avoid division by zero where upper == lower (rare before enough data)
        denom = upper - lower
        percent_b = np.where(denom != 0, (group['close'] - lower) / denom, np.nan)

        group = group.assign(
            BB_middle=middle,
            BB_upper=upper,
            BB_lower=lower,
            BB_width=width,
            BB_percent_B=percent_b
        )
        return group

    result = df.groupby('symbol', group_keys=False).apply(_bands_for_group)
    return result
```
```json
{ "model_code": "c6dy2gr9wkb3", "topic": "Bollinger Bands", "timer_secs": 22.30, "tokens_in": 561, "tokens_out": 1914, "cost_tokens_in": 0.00007854, "cost_tokens_out": 0.00053592, "cost_tokens_tot": 0.00061446 }
```