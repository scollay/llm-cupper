# T3

## Overview
The T3 indicator is a third‑order exponential moving average (EMA) that was introduced by Tim Tillson in the mid‑1990s to reduce lag while preserving responsiveness. It appears on a price chart as a smooth line that follows the underlying series more closely than a standard EMA, often rendered in a distinct color such as teal or orange to differentiate it from the raw price or a simple EMA. Tillson designed T3 to address the inherent lag of traditional moving averages by applying a series of smoothing steps to the EMA, thereby creating a “triple‑smoothed” version that reacts faster to price changes without sacrificing stability. Because of its balanced behavior, T3 has become a staple in many traders’ toolkits, especially those who rely on trend‑following systems that require a clearer signal than the noisy fluctuations of raw price data.

## Details
T3 is built on the concept of recursive EMA smoothing, but it goes a step further by applying three successive EMA calculations and then combining them with weighted coefficients that depend on the chosen period. The core idea is to replace the single EMA with a composite formula that incorporates the original price, the first EMA, the second EMA, and the third EMA, each weighted by powers of the smoothing constant **α**. The typical workflow for a trader is:

1. **Select a look‑back period** (often denoted as *N*). Common choices range from 5 to 30 bars, depending on the market and the desired sensitivity.
2. **Compute α** using the formula `α = 2 / (N + 1)`. This constant determines the weight of each price point in the EMA calculation.
3. **Calculate the first EMA** (EMA1) of the closing price over *N* periods.
4. **Calculate the second EMA** (EMA2) of EMA1 over the same period.
5. **Calculate the third EMA** (EMA3) of EMA2 over the same period.
6. **Apply the T3 weighting formula** to combine these three EMAs with the original price, producing a single smoothed value for each bar.

Traders typically interpret T3 in a few key ways:

- **Trend direction**: When the T3 line is rising, it signals an upward trend; a falling line indicates a downtrend.
- **Signal line crossovers**: Many strategies use a faster T3 (shorter period) crossing above a slower T3 (longer period) as a buy signal, and vice‑versa for a sell signal.
- **Divergence detection**: Divergence between price action and the T3 line can hint at weakening momentum, even if the price is still moving in the prevailing direction.

However, the interpretation can break down under certain conditions:

- **Extreme volatility**: In markets with erratic price spikes, the smoothing may lag behind sudden moves, causing delayed signals.
- **Short‑term noise**: On very short timeframes, the triple smoothing can over‑smooth, causing the indicator to flatten and miss brief but profitable opportunities.
- **Parameter sensitivity**: Because the weighting coefficients are highly dependent on *N*, small changes in the period can lead to markedly different T3 values, making it easy to over‑optimize a strategy.

Understanding these nuances helps traders decide when T3 is appropriate and when to supplement it with other tools such as volume‑based filters or momentum oscillators.

## Text Formula
The T3 value for a given bar *t* can be expressed mathematically as:

```
T3_t = ( α³ * Close_t
        + 3 * α² * (α - 1) * EMA1_t
        + 3 * α * (α - 1)² * EMA2_t
        + (α - 1)³ * EMA3_t )
       / ( α³ + 3 * α² * (α - 1) + 3 * α * (α - 1)² + (α - 1)³ )
```

where:

- **α** = 2 / (N + 1) is the smoothing constant,
- **EMA1_t** is the EMA of the closing price at time *t*,
- **EMA2_t** is the EMA of EMA1 at time *t*,
- **EMA3_t** is the EMA of EMA2 at time *t*.

The denominator normalizes the weighted sum so that the output stays within the same scale as the price series. This formula yields a single T3 value per bar, which can be plotted alongside the price chart for visual analysis.

## Python Code
```python
import pandas as pd
import numpy as np

def t3(series: pd.Series, period: int) -> pd.Series:
    """
    Compute the T3 indicator for a single price series.
    
    Parameters
    ----------
    series : pd.Series
        The price series (typically 'close') indexed by date.
    period : int
        Look‑back period N used to calculate the smoothing constant.
    
    Returns
    -------
    pd.Series
        T3 values aligned with the input index.
    """
    # Smoothing constant
    alpha = 2 / (period + 1)
    alpha_minus_1 = alpha - 1
    
    # First EMA (EMA1)
    ema1 = series.ewm(alpha=alpha, adjust=False).mean()
    
    # Second EMA (EMA2) of EMA1
    ema2 = ema1.ewm(alpha=alpha, adjust=False).mean()
    
    # Third EMA (EMA3) of EMA2
    ema3 = ema2.ewm(alpha=alpha, adjust=False).mean()
    
    # Numerator components
    term1 = alpha**3 * series
    term2 = 3 * alpha**2 * alpha_minus_1 * ema1
    term3 = 3 * alpha * alpha_minus_1**2 * ema2
    term4 = alpha_minus_1**3 * ema3
    
    # Denominator (constant for given period)
    denominator = alpha**3 + 3 * alpha**2 * alpha_minus_1 + \
                  3 * alpha * alpha_minus_1**2 + alpha_minus_1**3
    
    # Final T3 calculation
    t3_series = (term1 + term2 + term3 + term4) / denominator
    return t3_series

def calculate_t3(df: pd.DataFrame, price_col: str = 'close', period: int = 14) -> pd.DataFrame:
    """
    Calculate T3 for all symbols in a DataFrame containing at least:
    - 'symbol'   : identifier for the security
    - 'date'     : timestamp
    - 'open'     : opening price
    - 'high'     : highest price
    - 'low'      : lowest price
    - 'close'    : closing price
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data with the columns listed above.
    price_col : str, optional
        Name of the column to use as the price source (default 'close').
    period : int, optional
        Look‑back period for T3 (default 14).
    
    Returns
    -------
    pd.DataFrame
        Original DataFrame with an additional column 't3' containing the
        calculated T3 values for each symbol independently.
    """
    # Ensure the DataFrame is sorted for proper EMA calculation
    df = df.sort_values(['symbol', 'date'])
    
    # Apply T3 calculation per symbol
    df['t3'] = df.groupby('symbol')[price_col].apply(t3, period=period)
    
    return df
```
```json
{ "model_code": "m5dw8jc4vyq7", "topic": "T3", "timer_secs": 52.27, "tokens_in": 580, "tokens_out": 4270, "cost_tokens_in": 0.00002900, "cost_tokens_out": 0.00085400, "cost_tokens_tot": 0.00088300 }
```