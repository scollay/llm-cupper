# Coppock Curve

## Overview
The Coppock Curve is a momentum indicator used to identify long-term buying opportunities in the stock market. It is a weighted moving average of the rate of change (ROC) of a market index, typically displayed as a line chart below the price chart. The indicator was developed by **Edward Coppock** in 1962 to help identify entry points for long-term investors.

## Details
The Coppock Curve is designed to capture turning points in the market by smoothing out short-term fluctuations in momentum. It is particularly useful for identifying **buy signals** in long-term trends, as it is slow-moving and less reactive to noise compared to shorter-term momentum indicators.

The indicator works by calculating the **weighted moving average** of the sum of two rates of change (ROC) over different time periods, typically 11 and 14 months. These ROC values measure the percentage change in the index over those periods. By summing the ROCs and smoothing them with a longer-term weighted moving average, the Coppock Curve highlights when momentum is shifting from negative to positive, suggesting a potential **bullish reversal**.

Traders typically interpret the Coppock Curve as follows:

- A **cross above zero** from below is considered a **buy signal**, indicating that the market may be entering a new uptrend.
- A **cross below zero** from above can signal a potential downtrend, though this is less commonly used as a sell signal since the Coppock Curve is primarily a bullish indicator.

The Coppock Curve is most effective in **long-term timeframes** (e.g., monthly charts) and is less reliable for short-term trading. One limitation is that it can produce **lagging signals** because of its reliance on long lookback periods. This means that by the time a buy signal is generated, a significant portion of the uptrend may have already occurred. Additionally, in **choppy or sideways markets**, the Coppock Curve can give false signals, as the smoothed momentum might not accurately reflect the lack of a clear trend.

## Text Formula
The Coppock Curve is calculated as follows:

1. Compute the **11-month ROC**:

$$\text{ROC}_{11} = \frac{\text{Close} - \text{Close}_{11\text{ months ago}}}{\text{Close}_{11\text{ months ago}}}$$

1. Compute the **14-month ROC**:

$$\text{ROC}_{14} = \frac{\text{Close} - \text{Close}_{14\text{ months ago}}}{\text{Close}_{14\text{ months ago}}}$$

1. Sum the two ROCs:

$$\text{Sum} = \text{ROC}_{11} + \text{ROC}_{14}$$

1. Apply a **10-month weighted moving average (WMA)** to the sum of the ROCs:

$$\text{Coppock Curve} = \text{WMA}_{10}(\text{Sum})$$

Here, the **10-month WMA** is used as the smoothing function to generate the final curve.

## Python Code

```python
import pandas as pd

def coppock_curve(data):
    # Ensure the data is sorted by symbol and date
    data = data.sort_values(by=['symbol', 'date'])
    
    # Initialize a column for the Coppock Curve
    data['Coppock Curve'] = 0.0

    for symbol in data['symbol'].unique():
        # Filter data for the current symbol
        symbol_data = data[data['symbol'] == symbol]
        
        # Calculate 11-month and 14-month ROC
        symbol_data['ROC_11'] = (
            (symbol_data['close'] - symbol_data['close'].shift(11)) /
            symbol_data['close'].shift(11)
        )
        symbol_data['ROC_14'] = (
            (symbol_data['close'] - symbol_data['close'].shift(14)) /
            symbol_data['close'].shift(14)
        )
        
        # Sum the ROCs
        symbol_data['ROC_SUM'] = symbol_data['ROC_11'] + symbol_data['ROC_14']
        
        # Calculate the 10-month WMA of the sum of ROCs
        # Use Pandas `.ewm` for weighted moving average
        symbol_data['Coppock Curve'] = (
            symbol_data['ROC_SUM']
            .ewm(span=10, adjust=False)  # 10-month WMA equivalent
            .mean()
        )
    
    return data

# Example usage:
# Assuming `df` is a DataFrame with columns: symbol, date, open, high, low, close
# result = coppock_curve(df)
# The resulting DataFrame will include a new column `Coppock Curve` for each symbol.
```

This code calculates the Coppock Curve for each symbol in the input DataFrame. It handles multiple symbols independently and uses the `ewm` method to compute the 10-month weighted moving average of the summed ROCs. The function assumes the input DataFrame is already sorted by `symbol` and `date` to ensure proper sequential calculations.
```json
{ "model_code": "k7m2xq9p4nb3", "topic": "Coppock Curve", "timer_secs": 24.79, "tokens_in": 602, "tokens_out": 1223, "cost_tokens_in": 0.00120400, "cost_tokens_out": 0.00978400, "cost_tokens_tot": 0.01098800 }
```