# Coppock Curve

## Overview
The Coppock Curve, also known as the Coppock Indicator, is a momentum oscillator used in technical analysis to identify potential buy signals in bear markets. Developed by economist Edwin Coppock in 1962, it was initially designed for the Episcopal Church to identify long-term buying opportunities. The indicator appears as a single line on a chart, oscillating above and below zero, with crossovers above the zero line generating buy signals.

## Details
The Coppock Curve is calculated using the weighted moving average of the sum of the 11-month and 14-month rates of change (ROC) of the asset's price. It is primarily used to identify major bottoms in the market, making it a tool for long-term investors rather than short-term traders. When the Coppock Curve rises above the zero line, it suggests a potential upward trend, signaling a buying opportunity. Conversely, movements below the zero line are not typically used as sell signals, as the indicator is focused on identifying long-term bullish reversals.

Traders often use the Coppock Curve in conjunction with other technical indicators to confirm signals. While it is effective in identifying major market bottoms, it can produce false positives during choppy or sideways markets. Additionally, its long-term focus means it may lag behind shorter-term price movements, making it less suitable for active traders.

## Text Formula
The Coppock Curve (`CC`) is calculated as follows:

1. **Rate of Change (ROC)**:  
   - `ROC11 = (Price_t - Price_{t-11}) / Price_{t-11}`  
   - `ROC14 = (Price_t - Price_{t-14}) / Price_{t-14}`  

2. **Weighted Moving Average (WMA)**:  
   - `CC = WMA(ROC11 + ROC14, 10)`  
   where `WMA` is a 10-period weighted moving average.

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(data: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for a given DataFrame.

    Parameters:
    data (pd.DataFrame): DataFrame with columns 'symbol', 'date', 'open', 'high', 'low', 'close'.

    Returns:
    pd.DataFrame: Original DataFrame with additional 'Coppock_Curve' column.
    """
    # Group by symbol to handle multiple symbols independently
    result = data.copy()
    for symbol in data['symbol'].unique():
        symbol_data = data[data['symbol'] == symbol]
        
        # Calculate 11-month and 14-month Rate of Change (ROC)
        symbol_data['ROC11'] = (symbol_data['close'] - symbol_data['close'].shift(11)) / symbol_data['close'].shift(11)
        symbol_data['ROC14'] = (symbol_data['close'] - symbol_data['close'].shift(14)) / symbol_data['close'].shift(14)
        
        # Calculate the sum of ROC11 and ROC14
        symbol_data['ROC_Sum'] = symbol_data['ROC11'] + symbol_data['ROC14']
        
        # Calculate the 10-period Weighted Moving Average (WMA)
        weights = np.arange(1, 11)
        symbol_data['Coppock_Curve'] = symbol_data['ROC_Sum'].rolling(10, min_periods=10).apply(lambda x: (x * weights).sum() / weights.sum(), raw=True)
        
        # Drop intermediate columns
        symbol_data.drop(['ROC11', 'ROC14', 'ROC_Sum'], axis=1, inplace=True)
        
        # Update the result DataFrame
        result.loc[result['symbol'] == symbol, 'Coppock_Curve'] = symbol_data['Coppock_Curve']
    
    return result
```
```json
{ "model_code": "b9tw6cf3sql4", "topic": "Coppock Curve", "timer_secs": 12.80, "tokens_in": 574, "tokens_out": 861, "cost_tokens_in": 0.00143500, "cost_tokens_out": 0.00861000, "cost_tokens_tot": 0.01004500 }
```