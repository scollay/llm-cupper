# T3

## Overview
**T3** (Tillson’s T3) is a smooth, trend-following indicator designed to reduce lag compared with traditional moving averages, while still filtering out a good amount of noise. It’s typically plotted as a single line on the price chart (often overlaid with price or another moving average) and is most commonly used to identify trend direction and visually time entries/exits when the line turns.

T3 was developed by **Timothy A. Tillson** and introduced in the mid-1990s as part of his work on “less lag” smoothing techniques. It’s widely found in retail charting platforms because it can look remarkably responsive without being as jittery as lighter filters.

## Details
### What T3 is (conceptually)
T3 takes a price series (usually `close`) and applies a **cascade of exponential moving averages (EMAs)**—then combines them with nonlinear weighting to control smoothing and overshoot. The key idea is that you’re not just smoothing once; you’re smoothing repeatedly (to create a “shape” that has desirable responsiveness), and then mixing intermediate results in a way that dampens unwanted oscillations.

In practice, traders treat T3 as a **trend line**:

- **Bullish bias:** T3 rising over a sustained period; slope stays positive.
- **Bearish bias:** T3 falling; slope stays negative.
- **Turning points:** Crosses between T3 and price (or between T3 and another MA) are sometimes used for timing, though T3 is primarily a smoothing/trend tool rather than a strict oscillator.

### Typical parameter usage
Most implementations expose two parameters:

1. **`length`** (lookback / effective period)
2. **`v`** (often called the “volume factor” in Tillson’s original formulation, but it behaves more like a **smoothing/overshoot control knob**)

Common heuristics:
- **Shorter `length`** → faster response, more noise.
- **Longer `length`** → smoother line, more lag.
- **Higher `v`** → changes the balance between smoothness and responsiveness; values near extremes can increase overshoot risk.

### How traders interpret T3
Because T3 is smoother than a standard EMA (but still relatively responsive), traders typically use it in a few ways:

- **Slope / direction filter:** Only take long trades when T3 slope is up; only take shorts when slope is down.
- **Pullback behavior:** In trends, price often oscillates around T3; sustained holding of T3 as price pulls back can be interpreted as trend strength.
- **Cross strategies:** Some strategies watch for price crossing T3, or T3 crossing another moving average (like a faster EMA or a slower T3). This is popular but can be inconsistent in chop.

### Where interpretation breaks down
T3 is not magic; its smoothing is still a form of lag. The most common failure modes are:

- **Range-bound markets (chop):** Smoothing reduces noise but does not create signal. In sideways conditions, T3 can “whipsaw” when price repeatedly crosses or when its slope slowly flips.
- **Sudden regime changes:** During fast reversals (news-driven), even reduced-lag filters can lag enough to generate late entries.
- **Parameter sensitivity (`v` in particular):** Different `v` values can alter overshoot and turning behavior. Backtests that work with one `v` may fail with another.
- **Overfitting risk:** Because T3 can be tuned to look good on historical charts, it’s easy to optimize parameters too aggressively. Robustness matters more than a single visually perfect run.

### Practical cautions
- Treat T3 as a **trend component**, not a confirmation of immediate edge by itself. Use it alongside context (volatility regime, higher timeframe trend, or a separate trigger).
- If you use crosses, consider adding a slope filter (e.g., require T3 slope to agree with the trade direction) to reduce counter-trend signals.
- Validate that your platform’s T3 definition matches Tillson’s formulation; small implementation differences can exist across charting packages.

## Text Formula
Let the smoothing factor be:

- `α = 2 / (length + 1)`
- `e1 = EMA(close, α)`
- `e2 = EMA(e1, α)`
- `e3 = EMA(e2, α)`
- `e4 = EMA(e3, α)`
- `c1 = -v^3`
- `c2 = 3v^2 + 3v^3`
- `c3 = -6v^2 - 3v - 3v^3`
- `c4 = 1 + 3v + 3v^2 + v^3`

Then the T3 value is the weighted combination of the final four EMAs:

- `T3 = c1*e4 + c2*e3 + c3*e2 + c4*e1`

Notes:
- `v` is a user-specified factor (commonly between 0 and 1 in many implementations, but the exact valid range depends on the charting convention).
- All EMAs are computed sequentially on the same series with the same `α`, and the weights control smoothness vs. responsiveness.

## Python Code
```python
import pandas as pd

def compute_t3(df: pd.DataFrame, length: int = 10, v: float = 0.7,
               price_col: str = "close",
               date_col: str = "date",
               symbol_col: str = "symbol") -> pd.DataFrame:
    """
    Expected input DataFrame columns:
      - symbol, date, open, high, low, close

    This function computes Tillson's T3 for each symbol independently.

    Parameters
    ----------
    df : pd.DataFrame
        Input OHLCV-like data (OHLC required by prompt, but only close is used here).
    length : int
        Lookback period used to compute EMA smoothing factor alpha.
    v : float
        Tillson T3 factor controlling smoothness/overshoot.
    price_col : str
        Column containing the price series used for smoothing (default: 'close').

    Returns
    -------
    pd.DataFrame
        Copy of input with additional columns:
          - 't3_length_{length}_v_{v}'
          - 't3_e1', 't3_e2', 't3_e3', 't3_e4'
          - 't3_alpha', 't3_c1', 't3_c2', 't3_c3', 't3_c4'
        (Per-symbol series; constants repeated per row.)
    """

    if symbol_col not in df.columns or date_col not in df.columns:
        raise KeyError("DataFrame must include 'symbol' and 'date' columns.")
    if price_col not in df.columns:
        raise KeyError(f"DataFrame must include '{price_col}' column.")

    if length <= 0:
        raise ValueError("length must be a positive integer.")
    
    alpha = 2.0 / (length + 1.0)

    # Tillson coefficients
    c1 = -(v ** 3)
    c2 = 3.0 * (v ** 2) + 3.0 * (v ** 3)
    c3 = -6.0 * (v ** 2) - 3.0 * v - 3.0 * (v ** 3)
    c4 = 1.0 + 3.0 * v + 3.0 * (v ** 2) + (v ** 3)

    out = df.copy()

    # Ensure chronological order per symbol for correct EMA behavior
    out = out.sort_values([symbol_col, date_col])

    # Compute per-symbol EMAs sequentially: e1 -> e2 -> e3 -> e4
    # Using pandas ewm(span=..., adjust=False) so it behaves like standard EMA with alpha.
    # Relationship: alpha = 2/(span+1) -> span = (2/alpha)-1 = length
    span = float(length)

    def per_symbol_t3(g: pd.DataFrame) -> pd.DataFrame:
        x = g[price_col]

        e1 = x.ewm(span=span, adjust=False).mean()
        e2 = e1.ewm(span=span, adjust=False).mean()
        e3 = e2.ewm(span=span, adjust=False).mean()
        e4 = e3.ewm(span=span, adjust=False).mean()

        t3 = (c1 * e4) + (c2 * e3) + (c3 * e2) + (c4 * e1)

        g = g.copy()
        g["t3_alpha"] = alpha
        g["t3_c1"] = c1
        g["t3_c2"] = c2
        g["t3_c3"] = c3
        g["t3_c4"] = c4
        g["t3_e1"] = e1
        g["t3_e2"] = e2
        g["t3_e3"] = e3
        g["t3_e4"] = e4
        g[f"t3_length_{length}_v_{v}"] = t3
        return g

    out = out.groupby(symbol_col, group_keys=False).apply(per_symbol_t3)
    return out
```
```json
{ "model_code": "r6jq2vk9btx4", "topic": "T3", "timer_secs": 13.57, "tokens_in": 558, "tokens_out": 2010, "cost_tokens_in": 0.00011160, "cost_tokens_out": 0.00251250, "cost_tokens_tot": 0.00262410 }
```