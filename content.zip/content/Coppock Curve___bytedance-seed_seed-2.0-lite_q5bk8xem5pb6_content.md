# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum oscillator designed to identify the start of new bull markets, plotting as a single line below a security’s price chart. It was created by economist Edwin Coppock, who published the indicator in 1962 in *Barron’s* after being commissioned by the Episcopal Church to develop a reliable tool for long-term institutional investing. Originally built exclusively to generate buy signals for broad market indices like the S&P 500, it is now used by position traders and buy-and-hold investors to time entries in individual stocks, bonds, commodities, and cryptocurrencies, though it remains unsuitable for short-term trading strategies.

## Details
Coppock developed the indicator after researching that the average U.S. bear market lasts roughly 12 months, and that sustained momentum shifts at the end of a downtrend precede durable new bull markets. The original formulation relied exclusively on monthly price data, using 11-month and 14-month rates of change (ROC) summed and smoothed with a 10-month weighted moving average. Modern charting platforms have standardized on a near-identical iteration using 12-month and 14-month ROCs smoothed with a 10-month simple moving average, which aligns with most retail traders’ access to consistent monthly historical price data.

Standard interpretation of the Coppock Curve is straightforward: a core buy signal triggers when the curve crosses above the zero line from negative territory. This cross indicates that long-term downward momentum has shifted to positive, a shift Coppock found reliably predicted 3+ years of bull market gains across 100 years of U.S. market data. While Coppock never intended the indicator to generate sell signals, many modern traders use a cross back below zero to exit long positions, though this use case has not been validated to the same degree as the core buy signal. Traders also use bullish divergence—when a security’s price hits a new low but the Coppock Curve forms a higher low—to confirm that a bear market’s end is near, reinforcing an upcoming zero-line cross buy signal.

Interpretation of the Coppock Curve fails most often when traders misuse it for short-term timeframes or ignore its inherent limitations. First, it is a heavily lagging indicator: the 10-period smoothing and long ROC lookbacks mean it can signal a buy entry months after a bull market has started, leading to missed gains in sharp, fast-rising post-crash markets. Second, in prolonged sideways (range-bound) markets, the Coppock Curve can generate multiple false zero-line crosses, leading to costly whipsaw trades as the indicator oscillates above and below zero without a sustained trend. Third, it performs poorly on illiquid assets like micro-cap stocks or low-volume cryptocurrencies, where momentum can be manipulated by large market participants, leading to false signals that do not align with underlying fundamentals. Finally, the indicator does not distinguish between minor 10-20% bull market corrections and full bear markets, so it will never generate sell signals during routine pullbacks, a feature that makes it useless for traders looking to time short-term exits even in long-term uptrends.

## Text Formula
The standard Coppock Curve calculation used by modern trading platforms relies on three core steps, with default period settings calibrated for monthly price data:
1. First, calculate the rate of change (ROC), which measures percentage price change over a set lookback window, for two separate periods:
   `ROC(n) = [(Current Period Close / Close n Periods Prior) - 1] * 100`
2. Sum the 12-period ROC and 14-period ROC to generate a raw momentum value:
   `Raw Coppock = ROC(12) + ROC(14)`
3. Smooth the stream of raw Coppock values with a 10-period simple moving average (SMA) to produce the final Coppock Curve at any time t:
   `Coppock Curve(t) = SMA(Raw Coppock, window=10)`
The original 1962 formulation used 11-period and 14-period ROCs smoothed with a 10-period weighted moving average, but the formula above is the default for all major retail charting platforms.

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df, roc1_period=12, roc2_period=14, sma_period=10):
    """
    Calculates Coppock Curve values for a multi-symbol price dataframe.
    Input dataframe must have columns: ['symbol', 'date', 'open', 'high', 'low', 'close']
    Data will be sorted by symbol and date internally to ensure accurate sequential calculations.
    
    Args:
        df (pd.DataFrame): Input price dataframe
        roc1_period (int): Lookback period for first rate of change (default 12 for standard monthly Coppock)
        roc2_period (int): Lookback period for second rate of change (default 14)
        sma_period (int): Lookback period for smoothing SMA of raw Coppock values (default 10)
    
    Returns:
        pd.DataFrame: Input dataframe with 4 new columns:
            `roc1`: First ROC value
            `roc2`: Second ROC value
            `raw_coppock`: Sum of roc1 and roc2
            `coppock_curve`: Final smoothed Coppock Curve
    """
    # Sort data to ensure sequential, symbol-aligned calculations
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Calculate all values independently per symbol to avoid cross-symbol data leakage
    def compute_coppock_group(group):
        # Calculate ROCs: matches text formula (current/previous - 1) * 100
        group['roc1'] = group['close'].pct_change(periods=roc1_period) * 100
        group['roc2'] = group['close'].pct_change(periods=roc2_period) * 100
        # Sum ROCs to get raw Coppock values
        group['raw_coppock'] = group['roc1'] + group['roc2']
        # Smooth raw values with SMA to generate final Coppock Curve
        group['coppock_curve'] = group['raw_coppock'].rolling(window=sma_period).mean()
        return group
    
    # Apply calculation to each symbol's price history separately
    df = df.groupby('symbol', group_keys=False).apply(compute_coppock_group)
    
    return df
```
```json
{ "model_code": "q5bk8xem5pb6", "topic": "Coppock Curve", "timer_secs": 294.70, "tokens_in": 628, "tokens_out": 4918, "cost_tokens_in": 0.00015700, "cost_tokens_out": 0.00983600, "cost_tokens_tot": 0.00999300 }
```