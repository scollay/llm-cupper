# Clenow Momentum

## Overview

Clenow Momentum is a trend-following indicator developed by hedge fund manager and author Andreas Clenow, detailed in his 2014 book *Stocks on the Move*. Unlike simple rate-of-change or cross-sectional momentum, it measures both the **direction** and the **strength** of a trend by combining the slope of a linear regression on logarithmic prices with the regression’s goodness-of-fit (R²). On a chart, the indicator appears as a single line (or two lines for raw and smoothed versions) that oscillates around zero. Positive values indicate an uptrend, negative values a downtrend, and the magnitude reflects how consistent and steep the trend is.

## Details

### How It Works

Clenow Momentum is built on two key ideas:

1. **Trend direction** – captured by the slope of a linear regression on the natural logarithm of closing prices over a fixed lookback period (commonly 90 trading days). The slope represents the daily rate of change in log price, which approximates the percentage change per day.

2. **Trend quality** – captured by the R² of that regression. R² ranges from 0 to 1 and measures how well the price series fits a straight line. A high R² (close to 1) indicates a clean, persistent trend; a low R² signals noise or a weak trend that may reverse.

The raw momentum score is simply **slope × R²**. The multiplication penalises trends that are steep but erratic (high slope, low R²) and rewards trends that are both steep and well‑structured (high slope, high R²). The result is often smoothed with an exponential moving average (e.g., 10‑day EMA) to reduce whipsaws and produce a more tradable signal.

### Typical Interpretation

- **Above zero** → uptrend. The higher and more consistent the value, the stronger the bullish momentum.
- **Below zero** → downtrend. The lower (more negative) the value, the stronger the bearish momentum.
- **Cross above zero** from below can be seen as a bullish entry signal.
- **Cross below zero** from above can be seen as a bearish entry or exit signal.
- **Divergences** between price and the indicator (e.g., price making higher highs while momentum makes lower highs) may warn of trend exhaustion.

### Where Interpretation Breaks Down

- **Range‑bound markets**: In sideways or choppy conditions, R² tends to be low, so the momentum score will hover near zero regardless of price swings. This can produce many false signals if used for crossings.
- **Sudden gaps**: The regression slope reacts slowly to large overnight moves. A price gap can temporarily distort the regression until the window passes.
- **Lookback sensitivity**: The 90‑day default is arbitrary. Shorter lookbacks produce faster but noisier signals; longer lookbacks are smoother but lag more. Traders must tune the period to their timeframe.
- **Multi‑asset comparison**: Because the raw slope depends on the price level, Clenow Momentum is not directly comparable across stocks with very different volatilities. Normalising by volatility (e.g., dividing by the standard deviation of residuals) is sometimes applied, but the classic form does not do this.

## Text Formula

Let `close_t` be the closing price on day `t`, and let `N` be the lookback period (typically 90 days).

1. **Log prices**  
   `log_price_t = ln(close_t)`

2. **Perform linear regression** over the last `N` days on `log_price` against the time index `x = [0, 1, 2, ..., N‑1]`.  
   - Obtain the **slope** `b` (the regression coefficient).  
   - Obtain the **R‑squared** `R²` (the coefficient of determination).

3. **Raw Clenow Momentum**  
   `raw_momentum = b × R²`

4. **Smoothed Clenow Momentum (optional)**  
   Let `α = 2 / (K + 1)` where `K` is the smoothing period (commonly 10).  
   `smoothed_momentum_t = α × raw_momentum_t + (1 − α) × smoothed_momentum_(t−1)`  
   The first smoothed value is equal to the first raw value.

The indicator is typically plotted as the smoothed line, but both values are of interest.

## Python Code

```python
import pandas as pd
import numpy as np

def clenow_momentum(df: pd.DataFrame, lookback: int = 90, smooth_period: int = 10) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for one or more symbols.

    Input DataFrame must have columns: symbol, date, open, high, low, close
    The function processes each symbol independently.

    Returns a DataFrame with one row per original row, containing:
        - raw_momentum: slope * R^2 of log(close) regression over lookback days
        - smoothed_momentum: EMA of raw_momentum (period = smooth_period)
    """
    df = df.copy()
    df = df.sort_values(['symbol', 'date'])

    # Log of closing prices
    df['log_close'] = np.log(df['close'])

    # Helper function to compute slope and r2 for a rolling window
    def _regression_coeffs(series: pd.Series) -> tuple:
        """Return (slope, r2) for a series of log prices."""
        if len(series) < 2:
            return (np.nan, np.nan)
        x = np.arange(len(series))
        y = series.values
        # Linear regression using polyfit (degree 1)
        slope, intercept = np.polyfit(x, y, 1)
        # Predicted values
        y_pred = slope * x + intercept
        # r2 = 1 - SS_res / SS_tot
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        if ss_tot == 0:
            r2 = np.nan
        else:
            r2 = 1 - ss_res / ss_tot
        return (slope, r2)

    # Rolling apply per symbol
    def _apply_rolling(group: pd.DataFrame) -> pd.DataFrame:
        group = group.copy()
        # Rolling regression on log_close
        rolling = group['log_close'].rolling(window=lookback, min_periods=lookback)
        # Extract slope and r2 using apply, resulting in a DataFrame
        reg_result = rolling.apply(lambda s: pd.Series(_regression_coeffs(s), index=['slope', 'r2']),
                                   raw=False)
        group[['slope', 'r2']] = reg_result
        # Raw momentum
        group['raw_momentum'] = group['slope'] * group['r2']
        # Smoothed momentum (EMA)
        group['smoothed_momentum'] = group['raw_momentum'].ewm(span=smooth_period, adjust=False).mean()
        # Drop intermediate columns
        group = group.drop(columns=['log_close', 'slope', 'r2'])
        return group

    result = df.groupby('symbol', group_keys=False).apply(_apply_rolling)
    # Keep original order and columns
    result = result.sort_index()
    return result[['symbol', 'date', 'open', 'high', 'low', 'close', 'raw_momentum', 'smoothed_momentum']]
```
```json
{ "model_code": "c6dy2gr9wkb3", "topic": "Clenow Momentum", "timer_secs": 64.95, "tokens_in": 561, "tokens_out": 2368, "cost_tokens_in": 0.00007854, "cost_tokens_out": 0.00066304, "cost_tokens_tot": 0.00074158 }
```