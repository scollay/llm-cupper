# Simple Moving Average

## Overview

The Simple Moving Average (SMA) is one of the oldest and most widely used technical indicators in financial analysis. It smooths price data by calculating the arithmetic mean of a security's closing prices over a specified lookback period, producing a line that trails price action on a chart. Longer-period SMAs appear flatter and lag more; shorter-period SMAs hug price more closely. The SMA has no single inventor — it predates modern computing and has been a staple of chart analysis since at least the early twentieth century.

## Details

### How It Works

An SMA takes the closing prices for the last *n* periods, sums them, and divides by *n*. As each new bar closes, the oldest price drops off and the newest price is added, so the average "moves" forward in time. Common period choices include 10, 20, 50, 100, and 200 bars, though the right choice depends on the trader's timeframe and objective.

On a chart, the SMA appears as a smooth, continuous line beneath or above the price bars. Multiple SMAs are often plotted simultaneously — for example, a 50-period and a 200-period — to give both a medium-term and long-term perspective at a glance.

### Typical Interpretations

**Trend direction.** When price is consistently above its SMA, the trend is considered up; below, it is considered down. The slope of the SMA itself reinforces this: a rising SMA signals upward momentum, a flat SMA signals consolidation, and a falling SMA signals downward momentum.

**Dynamic support and resistance.** Traders often treat widely watched SMAs — especially the 50-day and 200-day — as support in uptrends and resistance in downtrends. A pullback to the 50-day SMA in a rising market is a common entry trigger.

**Crossover signals.** Two of the most referenced crossover patterns are:

- *Golden Cross* — the 50-period SMA crosses above the 200-period SMA, widely interpreted as a bullish regime change.
- *Death Cross* — the 50-period SMA crosses below the 200-period SMA, interpreted as bearish.

Single-line crossovers are also used: a price close above a declining SMA can signal a potential reversal, while a close below a rising SMA may warn of a breakdown.

**Price distance.** The percentage spread between current price and a long-term SMA (such as the 200-day) is sometimes used as a mean-reversion gauge. Prices stretched far above their long-term average have historically tended to revert, though the timing is unpredictable.

### Where Interpretation Breaks Down

The SMA's simplicity is also its main weakness.

- **Lag.** Because every period in the window receives equal weight, the SMA responds slowly to recent price changes. By the time a crossover signal fires, a significant portion of the move may already be over.
- **Whipsaws in ranging markets.** In sideways, choppy conditions, price crosses the SMA repeatedly, generating a stream of false signals. Filters — such as requiring two consecutive closes on one side, or combining the SMA with a momentum indicator — are commonly applied to reduce noise.
- **Equal weighting.** Assigning the same weight to a price from 200 days ago as to yesterday's close is an arbitrary choice. Exponential and weighted moving averages address this by emphasizing more recent data, at the cost of added complexity.
- **Self-fulfilling dynamics.** The 50-day and 200-day SMAs are so widely watched that reactions at those levels can be partly self-fulfilling, which makes backtested results on those specific parameters less reliable as a guide to future edge.

## Text Formula

**Single SMA value at time t:**

```
SMA(t, n) = (Close(t) + Close(t-1) + Close(t-2) + ... + Close(t-n+1)) / n
```

Where `n` is the lookback period and `Close(t)` is the closing price at bar *t*.

**Golden Cross condition:**

```
Golden Cross at t: SMA_short(t) > SMA_long(t)  AND  SMA_short(t-1) <= SMA_long(t-1)
```

**Death Cross condition:**

```
Death Cross at t: SMA_short(t) < SMA_long(t)  AND  SMA_short(t-1) >= SMA_long(t-1)
```

**Price distance from SMA (percent):**

```
Distance(t, n) = ((Close(t) - SMA(t, n)) / SMA(t, n)) * 100
```

## Python Code

The function below computes, for each symbol independently: the SMA for one or more user-specified periods, Golden Cross and Death Cross signals based on a configurable short/long period pair, and the percentage distance of price from each SMA.

```python
import pandas as pd

def calculate_sma(
    df: pd.DataFrame,
    periods: list[int] = [20, 50, 200],
    cross_short: int = 50,
    cross_long: int = 200,
) -> pd.DataFrame:
    """
    Calculate Simple Moving Average indicators for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Input data with columns: symbol, date, open, high, low, close.
        May contain rows for multiple symbols.
    periods : list[int]
        List of SMA lookback periods to compute.
    cross_short : int
        Short period used for Golden/Death Cross detection.
    cross_long : int
        Long period used for Golden/Death Cross detection.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with added columns:
          sma_{n}           – SMA value for each period n in `periods`
          sma_{n}_dist_pct  – % distance of close from sma_{n}
          golden_cross      – True on the bar the short SMA crosses above the long SMA
          death_cross       – True on the bar the short SMA crosses below the long SMA
    """

    # Ensure both cross periods are included in the SMA calculation
    all_periods = sorted(set(periods) | {cross_short, cross_long})

    result_parts = []

    for symbol, group in df.groupby("symbol", sort=False):
        # Work on a copy sorted by date to ensure correct rolling order
        g = group.sort_values("date").copy()

        for n in all_periods:
            col = f"sma_{n}"
            g[col] = g["close"].rolling(window=n, min_periods=n).mean()
            g[f"{col}_dist_pct"] = ((g["close"] - g[col]) / g[col]) * 100

        # Golden Cross: short SMA crosses above long SMA
        short_col = f"sma_{cross_short}"
        long_col = f"sma_{cross_long}"

        short_above = g[short_col] > g[long_col]
        short_above_prev = short_above.shift(1)

        g["golden_cross"] = short_above & ~short_above_prev
        g["death_cross"] = ~short_above & short_above_prev

        # Fill the first row where shift produces NaN (no prior bar to compare)
        g["golden_cross"] = g["golden_cross"].fillna(False)
        g["death_cross"] = g["death_cross"].fillna(False)

        result_parts.append(g)

    result = pd.concat(result_parts).sort_values(["symbol", "date"]).reset_index(drop=True)

    # Drop SMA columns that were added only to support cross detection,
    # not explicitly requested by the caller
    extra_periods = set(all_periods) - set(periods)
    for n in extra_periods:
        result.drop(columns=[f"sma_{n}", f"sma_{n}_dist_pct"], inplace=True)

    return result
```
```json
{ "model_code": "h3qd9zlb4ymp", "topic": "Simple Moving Average", "timer_secs": 36.73, "tokens_in": 608, "tokens_out": 1916, "cost_tokens_in": 0.00182400, "cost_tokens_out": 0.02874000, "cost_tokens_tot": 0.03056400 }
```