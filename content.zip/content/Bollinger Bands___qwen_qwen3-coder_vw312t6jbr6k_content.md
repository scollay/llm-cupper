# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical indicator consisting of three lines plotted on a price chart: a middle moving average line, and an upper and lower band that expand and contract based on recent price volatility. The indicator was developed by John Bollinger in the 1980s and is widely used by traders to identify potential overbought or oversold conditions, as well as periods of increasing or decreasing volatility.

## Details
Bollinger Bands consist of three components:

- **Middle Band**: Typically a 20-period simple moving average (SMA) of the closing price.
- **Upper Band**: The middle band plus two standard deviations of the closing price over the same period.
- **Lower Band**: The middle band minus two standard deviations of the closing price over the same period.

The bands dynamically adjust to price volatility: when volatility increases, the bands widen; when it decreases, the bands contract. This makes Bollinger Bands useful for spotting potential breakouts or reversals.

### Common Interpretations
- **Price near upper band**: May indicate overbought conditions and potential for a pullback.
- **Price near lower band**: May indicate oversold conditions and potential for a bounce.
- **Band contraction**: Often signals a period of low volatility, which may precede a significant price move.
- **Band expansion**: Suggests increasing volatility and possible continuation of the current trend.

### Limitations
- Bollinger Bands are **not predictive**; they are **reactive** and lag price movements.
- Price can remain at or beyond the bands during strong trends, leading to false signals if used in isolation.
- The default settings (20-period SMA, 2 standard deviations) may not suit all markets or timeframes.

## Text Formula
To calculate Bollinger Bands for a given period `n` (typically 20) and deviation factor `k` (typically 2):

1. **Middle Band** = `SMA(close, n)`
2. **Standard Deviation** = `std(close, n)`
3. **Upper Band** = `Middle Band + (k × Standard Deviation)`
4. **Lower Band** = `Middle Band - (k × Standard Deviation)`

Where:
- `SMA(close, n)` is the simple moving average of closing prices over `n` periods.
- `std(close, n)` is the standard deviation of closing prices over `n` periods.

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std_dev=2):
    """
    Calculate Bollinger Bands for one or more symbols in a DataFrame.
    
    Parameters:
        df (pd.DataFrame): DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
        window (int): The rolling window size for moving average and standard deviation
        num_std_dev (int): The number of standard deviations for the bands
    
    Returns:
        pd.DataFrame: Original DataFrame with added columns:
                      'middle_band', 'upper_band', 'lower_band'
    """
    # Sort by symbol and date to ensure correct rolling window behavior
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Group by symbol to calculate per-symbol Bollinger Bands
    def compute_bands(group):
        close = group['close']
        middle_band = close.rolling(window=window, min_periods=1).mean()
        std_dev = close.rolling(window=window, min_periods=1).std()
        upper_band = middle_band + (num_std_dev * std_dev)
        lower_band = middle_band - (num_std_dev * std_dev)
        
        group = group.copy()
        group['middle_band'] = middle_band
        group['upper_band'] = upper_band
        group['lower_band'] = lower_band
        return group

    result = df.groupby('symbol').apply(compute_bands).reset_index(drop=True)
    return result
```
```json
{ "model_code": "vw312t6jbr6k", "topic": "Bollinger Bands", "timer_secs": 9.13, "tokens_in": 564, "tokens_out": 842, "cost_tokens_in": 0.00012408, "cost_tokens_out": 0.00151560, "cost_tokens_tot": 0.00163968 }
```