# Clenow Momentum

## Overview
Clenow Momentum is a trend-following indicator designed to identify the strength and direction of price trends by comparing an asset's current price to its historical performance over a specified lookback period. It appears as a single line oscillating around a zero baseline, with positive values indicating upward momentum and negative values signaling downward momentum. Developed by Andreas Clenow, a quantitative hedge fund manager and author, the indicator is featured in his 2013 book *Following the Trend*. It is particularly favored by systematic traders for its simplicity and effectiveness in capturing sustained trends across multiple asset classes.

## Details

### Core Mechanics
Clenow Momentum measures the percentage change between the current closing price and the closing price `n` periods ago. Unlike traditional momentum oscillators (e.g., ROC), it does not normalize the result or bound it within a fixed range. This raw percentage change makes it sensitive to both the magnitude and duration of price moves, making it well-suited for trend-following strategies.

### Interpretation
- **Positive Values**: A reading above zero suggests the asset is trading higher than it was `n` periods ago, indicating bullish momentum. The higher the value, the stronger the uptrend.
- **Negative Values**: A reading below zero indicates the asset is trading lower than `n` periods ago, signaling bearish momentum. The more negative the value, the stronger the downtrend.
- **Crossovers**: Traders often use zero-line crossovers as entry/exit signals. A crossover from below to above zero may trigger a long position, while a crossover from above to below may prompt a short position or exit.
- **Divergence**: Divergence between price action and Clenow Momentum (e.g., price making higher highs while momentum makes lower highs) can signal potential trend exhaustion.

### Common Lookback Periods
The lookback period (`n`) is typically set between 20 and 200 days, depending on the trading horizon:
- **Short-term (e.g., 20–50 days)**: More sensitive to price changes, generating frequent signals but with higher noise.
- **Medium-term (e.g., 50–100 days)**: Balances responsiveness and smoothness, often used in swing trading.
- **Long-term (e.g., 100–200 days)**: Filters out shorter-term volatility, ideal for positional or macro trends.

### Limitations
- **Lagging Nature**: Like all momentum indicators, Clenow Momentum is lagging—it reacts to past price movements and may not predict reversals.
- **Whipsaws in Ranging Markets**: In sideways or choppy markets, frequent zero-line crossovers can lead to false signals and increased transaction costs.
- **Volatility Sensitivity**: The indicator does not account for volatility. A 10% move in a low-volatility stock may carry different implications than the same move in a high-volatility stock.
- **Single-Period Dependency**: The indicator relies solely on the comparison between two points (`close` and `close[n]`), ignoring intermediate price action.

### Practical Applications
- **Trend Filter**: Use Clenow Momentum to confirm the direction of the primary trend. For example, only take long trades when the indicator is positive.
- **Signal Generation**: Combine with other indicators (e.g., moving averages) to reduce false signals. For instance, enter long only if Clenow Momentum is positive *and* the price is above a 200-day moving average.
- **Portfolio Rotation**: In multi-asset strategies, rank assets by their Clenow Momentum values to allocate capital to the strongest trends.

## Text Formula
The Clenow Momentum (`CM`) for a given period `n` is calculated as:

```
CM = (close - close[n]) / close[n] * 100
```

Where:
- `close` = current closing price
- `close[n]` = closing price `n` periods ago
- The result is expressed as a percentage.

## Python Code
```python
import pandas as pd

def clenow_momentum(df, n=100):
    """
    Calculate Clenow Momentum for each symbol in a DataFrame.

    Parameters:
    - df: pandas.DataFrame with columns: symbol, date, open, high, low, close.
          Assumes data is sorted by symbol and date in ascending order.
    - n: int, lookback period (default=100).

    Returns:
    - pandas.DataFrame with original columns plus a new column 'clenow_momentum'.
    """
    # Ensure 'date' is in datetime format and set as index for time-based operations
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.set_index('date')

    # Group by symbol to handle multiple assets independently
    grouped = df.groupby('symbol')

    # Calculate Clenow Momentum for each group
    def calculate_momentum(group):
        group['clenow_momentum'] = (group['close'] - group['close'].shift(n)) / group['close'].shift(n) * 100
        return group

    df = grouped.apply(calculate_momentum)

    # Reset index to restore original structure
    df = df.reset_index()

    return df
```
```json
{ "model_code": "q5w5k99bpbzx", "topic": "Clenow Momentum", "timer_secs": 14.06, "tokens_in": 571, "tokens_out": 1137, "cost_tokens_in": 0.00022840, "cost_tokens_out": 0.00227400, "cost_tokens_tot": 0.00250240 }
```