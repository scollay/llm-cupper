# Clenow Momentum

## Overview
**Clenow Momentum** is a trend-following indicator designed to identify the strength and persistence of price trends across multiple timeframes. Developed by quantitative trader **Andreas Clenow**, it combines absolute and relative momentum to filter out weak or choppy trends, focusing only on assets with sustained directional movement. On a chart, it appears as a single line oscillating between -100 and +100, with readings above/below zero indicating bullish/bearish bias. The indicator is particularly favored by systematic traders for its ability to reduce whipsaws in ranging markets while capturing prolonged trends.

---

## Details

### **Core Concept**
Clenow Momentum integrates two key components:
1. **Absolute Momentum**: Measures an asset’s standalone trend strength over a lookback period.
2. **Relative Momentum**: Compares the asset’s performance to a benchmark (e.g., a market index or peer group) over the same period.

By combining these, the indicator avoids the pitfalls of pure absolute momentum (which can fire signals in strongly trending but underperforming assets) or pure relative momentum (which may ignore absolute downtrends).

### **Interpretation**
- **Positive Values (>0)**: Bullish regime. The asset’s absolute momentum is strong *and* it outperforms the benchmark.
- **Negative Values (<0)**: Bearish regime. Absolute momentum is weak *or* the asset underperforms the benchmark.
- **Crosses of Zero**: Potential entry/exit signals. A cross from negative to positive suggests a new uptrend; the reverse signals a downtrend.
- **Extreme Readings (±80 to ±100)**: Indicate exceptionally strong/weak trends, often used for confirmation rather than timing.

### **Strengths**
- **Reduces False Signals**: Filters out assets in weak trends or those rising/falling solely due to market beta.
- **Adaptable to Any Asset Class**: Works for equities, futures, forex, and crypto with appropriate benchmark selection.
- **Timeframe Agnostic**: Effective on daily, weekly, or intraday charts (though Clenow originally applied it to monthly data for asset allocation).

### **Limitations**
- **Lagging**: Like all momentum indicators, it reacts to past price action. Late entries are common in fast-moving markets.
- **Benchmark Dependency**: Poor benchmark choice (e.g., comparing a tech stock to a gold ETF) renders signals meaningless.
- **Whipsaws in Choppy Markets**: While better than pure absolute momentum, it can still generate false signals during consolidations.
- **No Volatility Adjustment**: Doesn’t account for risk (e.g., a +100 reading in a low-volatility asset may differ from one in a high-volatility asset).

### **Practical Applications**
1. **Trend Filter**: Use as a binary filter (e.g., only trade long when Clenow Momentum > 0).
2. **Ranking System**: Sort a universe of assets by their Clenow Momentum scores to allocate capital to the strongest trends.
3. **Regime Detection**: Combine with volatility measures (e.g., ATR) to distinguish between trending and mean-reverting environments.
4. **Divergence**: Bearish/bullish divergences between price and Clenow Momentum can signal weakening trends.

### **Parameter Selection**
- **Lookback Period (`n`)**: Typically 6–12 months for asset allocation, 20–50 days for tactical trading. Shorter periods increase sensitivity; longer periods smooth noise but delay signals.
- **Benchmark**: Should represent the asset’s broader market (e.g., S&P 500 for US stocks, Bitcoin for altcoins). Cash (0% return) is a valid benchmark for absolute-only analysis.

---

## Text Formula

The Clenow Momentum (`CM`) for an asset at time `t` is calculated as:

```
CM[t] = 100 × (MA_asset[t] - MA_benchmark[t]) / (|MA_asset[t]| + |MA_benchmark[t]|)
```

Where:
- `MA_asset[t]` = Absolute momentum of the asset over `n` periods:
  `MA_asset[t] = (close[t] - close[t-n]) / close[t-n]`
- `MA_benchmark[t]` = Absolute momentum of the benchmark over `n` periods (same formula as `MA_asset`).
- The denominator normalizes the result to a -100 to +100 range, ensuring comparability across assets.

**Notes**:
- If `MA_asset[t]` and `MA_benchmark[t]` have the same sign, `CM[t]` emphasizes the *relative* outperformance.
- If signs differ, `CM[t]` approaches ±100, indicating strong divergence.
- For cash benchmarks (0% return), `MA_benchmark[t] = 0`, reducing the formula to:
  `CM[t] = 100 × MA_asset[t] / |MA_asset[t]|` (i.e., ±100 if `MA_asset[t] ≠ 0`).

---

## Python Code

```python
import pandas as pd

def clenow_momentum(df, benchmark_df=None, n=252, cash_benchmark=False):
    """
    Calculate Clenow Momentum for one or more symbols in a DataFrame.

    Parameters:
    - df: Pandas DataFrame with columns: symbol, date, close (and optionally benchmark_close).
         Must be sorted by symbol, then date.
    - benchmark_df: Optional DataFrame with columns: symbol, date, close for benchmark assets.
                   If None, uses cash_benchmark or a 'benchmark_close' column in df.
    - n: Lookback period (e.g., 252 for 1-year daily data).
    - cash_benchmark: If True, treats benchmark return as 0% (e.g., comparing to cash).

    Returns:
    - DataFrame with original columns + 'clenow_momentum'.
    """

    # Validate input
    required_cols = {'symbol', 'date', 'close'}.issubset(df.columns)
    if not required_cols:
        raise ValueError("DataFrame must contain: symbol, date, close")

    # Handle benchmark logic
    if cash_benchmark:
        benchmark_returns = 0
    elif benchmark_df is not None:
        if not {'symbol', 'date', 'close'}.issubset(benchmark_df.columns):
            raise ValueError("benchmark_df must contain: symbol, date, close")
        # Merge benchmark closes into df (assumes 1:1 symbol-date alignment)
        df = df.merge(
            benchmark_df[['symbol', 'date', 'close']],
            on=['symbol', 'date'],
            suffixes=('', '_benchmark')
        )
    elif 'benchmark_close' not in df.columns:
        raise ValueError("Provide benchmark_df or include 'benchmark_close' in df")

    # Calculate absolute momentum for asset and benchmark
    df['ma_asset'] = df.groupby('symbol')['close'].pct_change(n)
    if cash_benchmark:
        df['ma_benchmark'] = 0
    else:
        benchmark_col = 'benchmark_close' if 'benchmark_close' in df else 'close_benchmark'
        df['ma_benchmark'] = df.groupby('symbol')[benchmark_col].pct_change(n)

    # Compute Clenow Momentum
    numerator = df['ma_asset'] - df['ma_benchmark']
    denominator = df['ma_asset'].abs() + df['ma_benchmark'].abs()
    # Avoid division by zero (assign 0 where denominator is 0)
    df['clenow_momentum'] = 100 * numerator / denominator.replace(0, pd.NA)
    df['clenow_momentum'] = df['clenow_momentum'].fillna(0)  # Neutral if no momentum

    return df[['symbol', 'date', 'close', 'clenow_momentum']]
```

**Usage Example**:
```python
# Assume:
# - df_assets: DataFrame with your assets' OHLC data (must include 'symbol', 'date', 'close')
# - df_benchmark: DataFrame with benchmark OHLC data (e.g., S&P 500 closes)

result = clenow_momentum(df_assets, benchmark_df=df_benchmark, n=20)
print(result.tail())
```
```json
{ "model_code": "r4cm8gd3qjt7", "topic": "Clenow Momentum", "timer_secs": 38.78, "tokens_in": 571, "tokens_out": 1812, "cost_tokens_in": 0.00022840, "cost_tokens_out": 0.00362400, "cost_tokens_tot": 0.00385240 }
```