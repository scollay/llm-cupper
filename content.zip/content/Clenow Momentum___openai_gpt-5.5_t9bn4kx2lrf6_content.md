# Clenow Momentum

## Overview

Clenow Momentum is a trend-strength and ranking indicator that measures the annualized slope of an asset’s price trend, then adjusts that slope by how well price fits the trend line. It is typically shown as a single line or histogram in a lower chart pane, but its most common use is as a ranking column across a watchlist or trading universe.

The indicator was popularized by Andreas F. Clenow, especially in his 2015 book *Stocks on the Move*. It is closely associated with systematic trend-following and relative momentum strategies.

## Details

Clenow Momentum is designed to answer a practical trading question: *Which instruments are rising the fastest in the cleanest trend?* It does this in two steps.

First, it fits a linear regression line to the natural log of closing prices over a lookback window, often 90 trading days. Using log prices makes the regression effectively measure an exponential growth rate rather than a simple price-point change. A $10 stock moving to $11 and a $100 stock moving to $110 are treated as similar percentage moves.

Second, it annualizes the regression slope and multiplies it by the regression’s R-squared value. The slope measures trend direction and speed. R-squared measures how closely prices follow the fitted trend. A strong but erratic advance receives a lower score than a similarly strong, smooth advance.

A typical Clenow Momentum value can be read as an R-squared-adjusted annualized return estimate. For example, a raw annualized regression return of 40% with an R-squared of 0.75 produces a Clenow Momentum score of 30%, or 0.30 in decimal form.

**How traders interpret it**

Clenow Momentum is usually interpreted cross-sectionally:

- Higher positive values indicate stronger, smoother upside momentum.
- Values near zero indicate either little trend or a trend too noisy to be statistically useful.
- Negative values indicate downside momentum.
- A ranking of 1 usually identifies the strongest instrument in the universe on that date.

This makes the indicator especially useful for systematic stock selection. A trader might calculate Clenow Momentum for all liquid stocks, rank them from highest to lowest, and focus only on the top-ranked names that also pass liquidity, volatility, and market-regime filters.

Unlike oscillators such as RSI or Stochastic, Clenow Momentum is not mainly an overbought/oversold tool. A high value does not automatically mean a stock is due to reverse. In trend-following logic, a high value may be exactly what the trader wants: persistent upward movement with limited noise.

**Common settings**

A 90-day lookback and 252-day annualization factor are common for equities. Shorter windows make the indicator more responsive but noisier. Longer windows produce more stable rankings but react more slowly when leadership changes.

Traders may use the indicator with additional filters, such as:

- Price above a long-term moving average.
- Minimum dollar volume.
- Maximum volatility or maximum gap risk.
- Broad market trend confirmation.
- Position sizing based on volatility rather than equal dollars.

**Where interpretation breaks down**

Clenow Momentum is still a backward-looking indicator. It can rank a stock highly after much of the move has already occurred, especially following sharp breakouts. It can also penalize profitable but volatile trends because the R-squared adjustment favors smoothness.

The indicator can struggle around:

- Earnings gaps and news shocks.
- Mean-reverting markets.
- Sudden leadership rotations.
- Thinly traded securities with stale prices.
- Very short histories with insufficient lookback data.
- Unadjusted price data affected by splits or large dividends.

It is also sensitive to the selected universe. Ranking 500 large-cap stocks is different from ranking leveraged ETFs, small caps, futures, or crypto assets. The score is best viewed as a relative momentum ranking tool, not a standalone forecast.

## Text Formula

Let:

- `C_t` = closing price at time `t`
- `N` = lookback length, commonly 90 trading days
- `K` = annualization factor, commonly 252 trading days
- `x_j = j` for `j = 0, 1, ..., N - 1`
- `y_j = ln(C_{t-N+1+j})`

Fit an ordinary least squares regression line to log price:

`y_j = a + b*x_j + e_j`

Where:

`b = sum((x_j - mean(x)) * (y_j - mean(y))) / sum((x_j - mean(x))^2)`

`a = mean(y) - b*mean(x)`

The fitted value is:

`yhat_j = a + b*x_j`

The coefficient of determination is:

`R_squared = 1 - sum((y_j - yhat_j)^2) / sum((y_j - mean(y))^2)`

If `sum((y_j - mean(y))^2) = 0`, a practical convention is to set `R_squared = 0`.

Annualized regression return is:

`Annualized_Return = exp(b*K) - 1`

Clenow Momentum is:

`Clenow_Momentum = Annualized_Return * R_squared`

If expressed as a percentage:

`Clenow_Momentum_Percent = 100 * Clenow_Momentum`

For cross-sectional ranking on a given date:

`Rank = 1 + count(other symbols with Clenow_Momentum greater than this symbol's Clenow_Momentum)`

## Python Code

```python
import numpy as np
import pandas as pd


def calculate_clenow_momentum(
    df: pd.DataFrame,
    lookback: int = 90,
    annualization: int = 252,
    add_rank: bool = True,
) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for one or more symbols.

    Required input columns:
        symbol, date, open, high, low, close

    Returns the original DataFrame with added columns:
        cm_log_close
        cm_slope_daily_log
        cm_r_squared
        cm_annualized_return
        clenow_momentum
        clenow_momentum_percent
        clenow_momentum_rank  # optional, if add_rank=True

    Notes:
        - Each symbol is calculated independently.
        - Rows are sorted internally by symbol and date for calculation.
        - The final result is returned in the original row order.
        - Closing prices must be positive to compute log prices.
        - For real equity research, adjusted close data is usually preferred.
    """
    required_columns = {"symbol", "date", "open", "high", "low", "close"}
    missing = required_columns.difference(df.columns)
    if missing:
        raise ValueError(f"DataFrame is missing required columns: {sorted(missing)}")

    if lookback < 2:
        raise ValueError("lookback must be at least 2")

    work = df.copy()
    work["_original_order"] = np.arange(len(work))
    work = work.sort_values(["symbol", "date"]).reset_index(drop=True)

    work["cm_log_close"] = np.nan
    positive_close = work["close"] > 0
    work.loc[positive_close, "cm_log_close"] = np.log(
        work.loc[positive_close, "close"].astype(float)
    )

    x = np.arange(lookback, dtype=float)
    x_mean = x.mean()
    x_demeaned = x - x_mean
    ss_x = np.dot(x_demeaned, x_demeaned)

    def rolling_slope(y: np.ndarray) -> float:
        """OLS slope of log price over the rolling window."""
        if np.isnan(y).any():
            return np.nan

        y_mean = y.mean()
        y_demeaned = y - y_mean
        return float(np.dot(x_demeaned, y_demeaned) / ss_x)

    def rolling_r_squared(y: np.ndarray) -> float:
        """R-squared of the OLS regression over the rolling window."""
        if np.isnan(y).any():
            return np.nan

        y_mean = y.mean()
        y_demeaned = y - y_mean
        ss_y = np.dot(y_demeaned, y_demeaned)

        if ss_y == 0:
            return 0.0

        slope = np.dot(x_demeaned, y_demeaned) / ss_x
        intercept = y_mean - slope * x_mean
        y_hat = intercept + slope * x

        ss_residual = np.dot(y - y_hat, y - y_hat)
        r_squared = 1.0 - (ss_residual / ss_y)

        return float(max(0.0, min(1.0, r_squared)))

    calculated_groups = []

    for _, group in work.groupby("symbol", sort=False):
        group = group.copy()

        rolling_log_close = group["cm_log_close"].rolling(
            window=lookback,
            min_periods=lookback,
        )

        group["cm_slope_daily_log"] = rolling_log_close.apply(
            rolling_slope,
            raw=True,
        )

        group["cm_r_squared"] = rolling_log_close.apply(
            rolling_r_squared,
            raw=True,
        )

        group["cm_annualized_return"] = (
            np.exp(group["cm_slope_daily_log"] * annualization) - 1.0
        )

        group["clenow_momentum"] = (
            group["cm_annualized_return"] * group["cm_r_squared"]
        )

        group["clenow_momentum_percent"] = group["clenow_momentum"] * 100.0

        calculated_groups.append(group)

    if calculated_groups:
        result = pd.concat(calculated_groups, axis=0)
    else:
        result = work.copy()

    if add_rank:
        result["clenow_momentum_rank"] = np.nan
        valid = result["clenow_momentum"].notna()

        result.loc[valid, "clenow_momentum_rank"] = (
            result.loc[valid]
            .groupby("date")["clenow_momentum"]
            .rank(method="min", ascending=False)
        )

    result = result.sort_values("_original_order").drop(columns="_original_order")
    return result
```
```json
{ "model_code": "t9bn4kx2lrf6", "topic": "Clenow Momentum", "timer_secs": 77.61, "tokens_in": 560, "tokens_out": 4235, "cost_tokens_in": 0.00280000, "cost_tokens_out": 0.12705000, "cost_tokens_tot": 0.12985000 }
```