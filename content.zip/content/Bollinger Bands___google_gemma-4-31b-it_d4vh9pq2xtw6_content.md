# Bollinger Bands

## Overview
Bollinger Bands are a volatility indicator consisting of a central moving average and two outer bands that expand and contract based on market volatility. Developed by John Bollinger in the 1980s, the indicator appears as a "channel" enveloping the price action on a chart. It is primarily used to identify overbought or oversold conditions and to gauge the volatility of an asset.

## Details
Bollinger Bands operate on the principle of standard deviation. By plotting a range around a trend line, the indicator creates a dynamic boundary that adapts to the current price environment.

### Components and Mechanics
The indicator consists of three lines:
1. **Middle Band**: A Simple Moving Average (SMA), typically set to a 20-period window.
2. **Upper Band**: The Middle Band plus a specified number of standard deviations (usually two).
3. **Lower Band**: The Middle Band minus a specified number of standard deviations.

Because standard deviation measures the dispersion of prices from the average, the bands widen during periods of high volatility and narrow during periods of low volatility.

### Common Interpretations
Traders typically use Bollinger Bands in three primary ways:

*   **Mean Reversion**: In a ranging market, prices tend to return to the Middle Band. A touch or break of the Upper Band may be interpreted as an overbought signal (potential short), while a touch of the Lower Band may be seen as oversold (potential long).
*   **The Squeeze**: When the Upper and Lower bands tighten significantly, it indicates a period of extremely low volatility. Traders interpret this "squeeze" as a precursor to a violent price breakout, though the bands themselves do not predict the direction of the move.
*   **Walking the Bands**: In a strong trend, prices can "hug" or "walk" along the Upper or Lower band for extended periods. In this context, touching a band is a sign of strength (momentum) rather than a reversal signal.

### Limitations
The primary weakness of Bollinger Bands is the risk of "false" reversal signals during strong trends. A trader who shorts simply because the price touched the Upper Band during a parabolic rally may be caught in a "walking the bands" scenario. Consequently, Bollinger Bands are most effective when paired with momentum oscillators (like the RSI) or volume analysis to confirm whether a touch of the band represents a climax or a trend continuation.

## Text Formula
The calculation for Bollinger Bands is as follows:

1.  `Middle Band` = (Sum of Close prices over N periods) / N
2.  `Standard Deviation` = Square Root of (Sum of (Close - Middle Band)^2 over N periods) / N
3.  `Upper Band` = `Middle Band` + (K * `Standard Deviation`)
4.  `Lower Band` = `Middle Band` - (K * `Standard Deviation`)

*Where `N` is the lookback period (default 20) and `K` is the multiplier (default 2).*

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, window=20, num_std=2):
    """
    Calculates Bollinger Bands for a given DataFrame.
    
    Input DataFrame format:
    - symbol: string
    - date: datetime
    - open: float
    - high: float
    - low: float
    - close: float
    
    Returns:
    DataFrame with additional columns: 'bb_middle', 'bb_upper', 'bb_lower'
    """
    # Ensure data is sorted by date to prevent look-ahead bias or calculation errors
    df = df.sort_values(['symbol', 'date'])
    
    # Group by symbol to ensure calculations are independent for each asset
    grouped = df.groupby('symbol')['close']
    
    # Calculate the Middle Band (Simple Moving Average)
    df['bb_middle'] = grouped.transform(lambda x: x.rolling(window=window).mean())
    
    # Calculate the Rolling Standard Deviation
    df['std_dev'] = grouped.transform(lambda x: x.rolling(window=window).std())
    
    # Calculate Upper and Lower Bands
    df['bb_upper'] = df['bb_middle'] + (num_std * df['std_dev'])
    df['bb_lower'] = df['bb_middle'] - (num_std * df['std_dev'])
    
    # Remove the temporary standard deviation column before returning
    df = df.drop(columns=['std_dev'])
    
    return df
```
```json
{ "model_code": "d4vh9pq2xtw6", "topic": "Bollinger Bands", "timer_secs": 87.73, "tokens_in": 577, "tokens_out": 990, "cost_tokens_in": 0.00006924, "cost_tokens_out": 0.00036630, "cost_tokens_tot": 0.00043554 }
```