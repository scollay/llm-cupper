# Bollinger Bands

## Overview
Bollinger Bands are a technical volatility indicator overlay consisting of three lines: a middle band, an upper band, and a lower band. On a chart, they form an envelope or ribbon that expands and contracts around price action, widening during periods of high volatility and narrowing during periods of low volatility. The indicator was created by financial analyst John Bollinger in the early 1980s to provide a relative definition of high and low prices based on volatility.

## Details

### Core Mechanics
The middle band is a Simple Moving Average (SMA) of the closing price, typically set to 20 periods. The upper and lower bands are drawn at a specified number of standard deviations above and below the middle band, typically two. Because standard deviation is a statistical measure of volatility, the bands dynamically adapt to market conditions. When price volatility increases, the bands widen; when volatility decreases, the bands contract.

### Interpretation
Traders use Bollinger Bands primarily to assess volatility and identify potential overbought or oversold conditions relative to recent price action.

**The Squeeze**
A squeeze occurs when the bands contract tightly, indicating low volatility and a period of market consolidation. Traders view a squeeze as a precursor to a sharp directional move. The direction of the breakout from the squeeze often establishes the new trend, though the bands themselves do not predict the direction of the breakout.

**Overbought and Oversold**
When price touches or pierces the upper band, it is considered relatively overbought. When it touches or pierces the lower band, it is relatively oversold. However, these are not standalone buy or sell signals. In a strong trending market, price can "ride the band" by hugging the upper or lower boundary for an extended period. A tag of the band simply indicates that price is statistically extreme relative to its recent range.

**Mean Reversion**
In range-bound markets, traders often use the bands as dynamic support and resistance, expecting price to revert to the mean (the middle band). A common strategy is to buy when price touches the lower band and sell when it reaches the middle or upper band, and vice versa.

### Derived Indicators
Two standard indicators are derived directly from Bollinger Bands:
*   **BandWidth:** Measures the distance between the upper and lower bands relative to the middle band. It is used to quantitatively identify the squeeze.
*   **%B:** Quantifies where the current price is relative to the bands. A value of 1 means price is at the upper band, 0 means price is at the lower band, and 0.5 means price is at the middle band.

### Limitations and Breakdowns
Bollinger Bands are lagging indicators because they rely on historical moving averages and standard deviations. During sudden volatility shocks, price will gap outside the bands before the bands have time to expand, rendering the overbought/oversold interpretation useless in real-time. Furthermore, the indicator assumes a normal distribution of price data (where two standard deviations contain roughly 95% of outcomes), but financial markets exhibit "fat tails." Extreme moves beyond the bands occur more frequently than statistical normality would suggest. Finally, the default 20-period, 2-standard-deviation settings are not universally optimal; they require adjustment for different assets, timeframes, and trading styles.

## Text Formula
Let `Close` be the closing price, `N` be the lookback period (typically 20), and `K` be the standard deviation multiplier (typically 2).

Middle Band = SMA(Close, N)

Standard Deviation = StdDev(Close, N) 
*(Note: Use population standard deviation, dividing by N rather than N-1)*

Upper Band = Middle Band + (K * Standard Deviation)

Lower Band = Middle Band - (K * Standard Deviation)

BandWidth = (Upper Band - Lower Band) / Middle Band

%B = (Close - Lower Band) / (Upper Band - Lower Band)

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df, n=20, k=2):
    """
    Calculates Bollinger Bands, BandWidth, and %B.
    
    Expected DataFrame columns: symbol, date, open, high, low, close
    Handles multiple symbols independently via groupby.
    
    Parameters:
    df (pd.DataFrame): Market data with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    n (int): Lookback period for the SMA and standard deviation. Default is 20.
    k (int or float): Standard deviation multiplier for the bands. Default is 2.
    
    Returns:
    pd.DataFrame: Original DataFrame augmented with:
                  'bb_middle', 'bb_upper', 'bb_lower', 'bb_bandwidth', 'bb_pct_b'
    """
    # Ensure data is sorted chronologically for accurate rolling calculations
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    def compute_bands(group):
        # Calculate the middle band (Simple Moving Average)
        group['bb_middle'] = group['close'].rolling(window=n).mean()
        
        # Calculate population standard deviation (ddof=0)
        std_dev = group['close'].rolling(window=n).std(ddof=0)
        
        # Calculate upper and lower bands
        group['bb_upper'] = group['bb_middle'] + (k * std_dev)
        group['bb_lower'] = group['bb_middle'] - (k * std_dev)
        
        # Calculate BandWidth
        group['bb_bandwidth'] = (group['bb_upper'] - group['bb_lower']) / group['bb_middle']
        
        # Calculate %B
        group['bb_pct_b'] = (group['close'] - group['bb_lower']) / (group['bb_upper'] - group['bb_lower'])
        
        return group
    
    # Apply calculation per symbol to prevent data leakage across different assets
    result = df.groupby('symbol', group_keys=False).apply(compute_bands)
    
    return result
```
```json
{ "model_code": "c5kw9bt2vrj6", "topic": "Bollinger Bands", "timer_secs": 108.35, "tokens_in": 560, "tokens_out": 3064, "cost_tokens_in": 0.00054880, "cost_tokens_out": 0.00943712, "cost_tokens_tot": 0.00998592 }
```