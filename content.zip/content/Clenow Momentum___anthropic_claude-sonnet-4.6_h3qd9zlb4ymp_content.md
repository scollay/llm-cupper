# Clenow Momentum

## Overview

Clenow Momentum is a trend-following momentum indicator developed by Andreas Clenow and described in his book *Stocks on the Move* (2015). It quantifies the strength and consistency of a stock's upward trend by combining the slope of an exponential regression with a measure of how tightly prices adhere to that trend. The result is a single score that ranks stocks by the quality of their momentum — not just how fast they are rising, but how smoothly. It is most commonly used in systematic, cross-sectional momentum strategies where a universe of stocks is ranked and the top performers are held in a portfolio.

---

## Details

### The Core Idea

Raw price returns can be noisy. A stock that doubled in a straight line is a very different proposition from one that doubled while swinging 30% in every direction. Clenow Momentum captures this distinction by rewarding both *speed* (the annualized slope of the trend) and *consistency* (the R² of the regression that produced that slope).

### How It Is Calculated

The indicator is built on an **exponential regression** — a linear regression applied to the *natural log* of closing prices over a lookback window, typically 90 trading days. Taking the log transforms exponential price growth into a straight line, so the regression slope represents a constant *percentage* rate of change rather than an absolute dollar change.

The regression produces two outputs:

- **Slope** — the daily rate of change in log-price. Multiplied by 252 (trading days per year), it becomes an *annualized percentage return*.
- **R²** — the coefficient of determination, measuring how well the straight line fits the actual log-price path. An R² of 1.0 means prices moved in a perfect straight line; an R² near 0 means the trend line explains almost none of the price movement.

These two values are multiplied together:

> **Clenow Momentum = Annualized Slope × R²**

A stock rising at 40% per year with an R² of 0.90 scores 0.36. A stock rising at 80% per year with an R² of 0.40 also scores 0.32 — ranked lower, because its trend is erratic. This penalization of noisy trends is the indicator's defining feature.

### Typical Use in a Strategy

Clenow Momentum is almost always used for *ranking*, not for generating buy/sell signals on a single stock. A typical workflow:

1. Calculate the score for every stock in a universe (e.g., S&P 500 constituents) at a weekly or monthly rebalance date.
2. Rank all stocks by their score, highest to lowest.
3. Hold the top *N* stocks (commonly 20–50) in equal or volatility-weighted positions.
4. Apply a market filter — for example, only hold positions when the index itself is above its 200-day moving average — to avoid deploying capital in broad downtrends.

The lookback window of 90 days is Clenow's original choice, but practitioners commonly test windows between 60 and 180 days. Shorter windows are more reactive; longer windows are smoother but slower to respond to trend changes.

### Where Interpretation Breaks Down

- **Momentum crashes.** Cross-sectional momentum strategies are vulnerable to sharp reversals after prolonged trends. High-scoring stocks can unwind violently when sentiment shifts.
- **Survivorship and universe selection.** The score is only as useful as the universe it ranks. Comparing scores across very different universes (e.g., micro-caps vs. large-caps) is not meaningful.
- **R² flatters slow, low-volatility trends.** A stock drifting upward at 5% per year in a straight line can outscore a stock rising at 30% per year with moderate noise. Whether that is a feature or a bug depends on the strategy's objectives.
- **Lookback sensitivity.** The score can change substantially with small changes to the window length, so out-of-sample robustness testing is essential.

---

## Text Formula

```
Log Price      = ln(close)

Exponential regression of Log Price over the lookback window (default = 90 days):
  Slope (daily)      = regression coefficient on the time index
  R²                 = coefficient of determination of the regression

Annualized Slope = Slope (daily) × 252

Clenow Momentum Score = Annualized Slope × R²
```

---

## Python Code

The function below calculates, for each symbol independently, the `annualized_slope`, `r_squared`, and `clenow_momentum` score at every date that has a full lookback window of data.

```python
import pandas as pd
import numpy as np
from scipy import stats

# Expected input: a Pandas DataFrame with columns:
#   symbol  : str   – ticker identifier
#   date    : date/datetime – trading date
#   open    : float
#   high    : float
#   low     : float
#   close   : float
# The DataFrame may contain one or more symbols.
# Rows need not be pre-sorted.

def clenow_momentum(df: pd.DataFrame, lookback: int = 90) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for each symbol in the DataFrame.

    Parameters
    ----------
    df       : DataFrame with columns [symbol, date, open, high, low, close]
    lookback : int – number of trading days for the regression window (default 90)

    Returns
    -------
    DataFrame with original columns plus:
        log_close         – natural log of the closing price
        annualized_slope  – regression slope scaled to annual (x252)
        r_squared         – R² of the log-price regression
        clenow_momentum   – annualized_slope * r_squared
    Rows with insufficient history (fewer than `lookback` rows) will have
    NaN for the three calculated columns.
    """

    df = df.copy()
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)
    df["log_close"] = np.log(df["close"])

    # Pre-allocate output columns
    df["annualized_slope"] = np.nan
    df["r_squared"]        = np.nan
    df["clenow_momentum"]  = np.nan

    x = np.arange(lookback, dtype=float)  # time index: 0, 1, ..., lookback-1

    for symbol, group in df.groupby("symbol", sort=False):
        idx = group.index  # original DataFrame index labels for this symbol
        log_prices = group["log_close"].values

        for i in range(lookback - 1, len(log_prices)):
            window = log_prices[i - lookback + 1 : i + 1]

            # Linear regression of log price on time index
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, window)

            annualized_slope = slope * 252
            r_squared        = r_value ** 2
            score            = annualized_slope * r_squared

            row_label = idx[i]
            df.at[row_label, "annualized_slope"] = annualized_slope
            df.at[row_label, "r_squared"]        = r_squared
            df.at[row_label, "clenow_momentum"]  = score

    return df
```
```json
{ "model_code": "h3qd9zlb4ymp", "topic": "Clenow Momentum", "timer_secs": 36.37, "tokens_in": 611, "tokens_out": 1775, "cost_tokens_in": 0.00183300, "cost_tokens_out": 0.02662500, "cost_tokens_tot": 0.02845800 }
```