# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a lagging technical indicator used to smooth out price action by filtering out short-term "noise" to reveal a clearer trend. It appears on a chart as a line overlaying the price bars, representing the average price over a specific number of previous periods. While its origins are rooted in basic statistics, it became a staple of technical analysis in the early 20th century as traders sought objective ways to identify trend direction.

## Details
The SMA calculates the arithmetic mean of a security's closing price over a defined window of time. Because it assigns equal weight to every price point in the window, it provides a steady baseline for trend identification.

### Trend Identification and Crossovers
Traders primarily use the SMA to determine the current market bias. If the price is trading above the SMA, the trend is generally considered bullish; if below, it is bearish. 

A common strategy involves the "Moving Average Crossover," where a shorter-term SMA (e.g., 50-day) is plotted alongside a longer-term SMA (e.g., 200-day). 
* **Golden Cross**: Occurs when the shorter SMA crosses above the longer SMA, signaling a potential long-term bullish reversal.
* **Death Cross**: Occurs when the shorter SMA crosses below the longer SMA, signaling a potential long-term bearish reversal.

### Dynamic Support and Resistance
In trending markets, the SMA often acts as dynamic support or resistance. During a strong uptrend, prices frequently pull back to the SMA and bounce, treating the average as a floor. Conversely, in a downtrend, the SMA often acts as a ceiling that prevents price from rallying.

### Limitations and Failures
The primary weakness of the SMA is its **lag**. Because it relies on past data, the SMA does not predict price movement; it confirms it. In volatile or sideways (ranging) markets, the SMA can produce "whipsaws," where the price crosses the average multiple times in a short period, generating false signals. Furthermore, because the SMA is an unweighted average, a significant price spike from many periods ago will impact the average just as much as today's price, even as that old data becomes irrelevant to current market conditions.

## Text Formula
The SMA for a given period `n` is calculated as the sum of the closing prices for the last `n` periods divided by `n`.

`SMA = (P1 + P2 + ... + Pn) / n`

Where:
* `P` = Closing price of the asset
* `n` = The lookback period (e.g., 20, 50, or 200)

## Python Code
```python
import pandas as pd

def calculate_sma(df, window=20):
    """
    Calculates the Simple Moving Average (SMA) for a given window.
    
    Input:
    df - Pandas DataFrame containing columns: 'symbol', 'date', 'open', 'high', 'low', 'close'
    window - Integer representing the lookback period (default 20)
    
    Returns:
    DataFrame with an additional column 'sma' containing the calculated values.
    """
    # Ensure the data is sorted by symbol and date to prevent look-ahead bias 
    # or incorrect windowing across different assets
    df = df.sort_values(by=['symbol', 'date'])
    
    # Group by symbol to ensure the SMA is calculated independently for each asset
    # .rolling(window=window) creates the sliding window
    # .mean() calculates the arithmetic average of the 'close' column
    df[f'sma_{window}'] = df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=window).mean()
    )
    
    return df
```
```json
{ "model_code": "d4vh9pq2xtw6", "topic": "Simple Moving Average", "timer_secs": 81.84, "tokens_in": 578, "tokens_out": 832, "cost_tokens_in": 0.00006936, "cost_tokens_out": 0.00030784, "cost_tokens_tot": 0.00037720 }
```