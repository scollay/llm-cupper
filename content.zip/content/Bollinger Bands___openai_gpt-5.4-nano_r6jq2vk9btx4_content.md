# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based price envelope plotted above and below a moving average. They expand and contract as market volatility changes, making them a popular tool for identifying periods of relative “stretch” and potential mean reversion. On a chart, you’ll typically see three lines: the **middle band** (a moving average) and two **outer bands** (standard deviation bands around the middle).

Bollinger Bands were developed by **John Bollinger** and popularized in the late 20th century, notably through his trading work and published materials in the 1980s and 1990s.

## Details
Bollinger Bands are built from a moving average plus/minus a multiple of the standard deviation of price over a lookback window. While many traders use Bollinger Bands as a standalone indicator, they’re most powerful when paired with context (trend, liquidity, event risk) and used to frame volatility regimes.

### Core construction
For a given symbol and date:
- Compute a **moving average** of `close` over `N` periods (commonly `N=20`).
- Compute the **rolling standard deviation** of `close` over the same `N` periods.
- Set:
  - **Upper Band** = middle band + `k` × std dev  
  - **Lower Band** = middle band − `k` × std dev  
Common parameters are `N=20` and `k=2`. Traders often reference these as “20,2 bands,” though other settings exist.

### How traders interpret them
Bollinger Bands interpretations are typically grouped into volatility and price-position concepts.

#### 1) Volatility expansion and contraction
- When bands **expand**, realized volatility is rising. This often occurs during breakouts, reversals, and news-driven repricing.
- When bands **contract**, realized volatility is falling. This can precede a larger move, but direction is not determined by the bands alone.

A widely cited heuristic is the “**squeeze**,” where bands become unusually narrow relative to their own history. Traders use this to mark “coiling” volatility, then look for a subsequent volatility expansion and/or a break beyond the bands as a trigger.

#### 2) Price “stretch” relative to the bands
Because the bands are tied to volatility, a touch or penetration can mean different things depending on market regime:
- In **range-bound** markets, price often oscillates around the middle band, and touches near the outer bands are treated as potential **mean-reversion** opportunities.
- In **trending** markets, price can ride the outer band for extended periods. In that case, “walking the band” is often interpreted as *trend continuation*, not exhaustion.

Traders commonly watch:
- **Band width**: the distance between upper and lower bands as a proxy for volatility.
- **%B**: where price sits within the bands (0 at lower band, 1 at upper band).
- **Band position vs. trend**: e.g., whether price is above/below the middle band.

#### 3) The middle band as a regime filter
The middle band (the moving average) is often used as a *bias* line:
- Price above the middle band suggests bullish bias; below suggests bearish bias.
- Crosses and closes relative to the middle band can help filter whether you expect mean reversion (often when price keeps reverting to the middle) or continuation (often in strong trends).

### Where interpretation tends to break down
Bollinger Bands are probabilistic and regime-dependent. Common failure modes include:

1. **Assuming band touches always mean reversal**  
   In strong trends, price frequently stays near or beyond an outer band. Mean-reversion logic is less reliable unless you confirm a range-bound environment.

2. **Ignoring volatility regime differences**  
   Bands are adaptive, but “adaptive” doesn’t mean “predictive by itself.” A squeeze can break in any direction; direction typically needs additional information (trend filters, order flow, momentum, or market structure).

3. **Using the wrong price scale or transformation**  
   Bollinger Bands are typically applied to raw price. For some instruments with structural breaks or rapidly changing behavior, traders may prefer returns or other transformations. If you change the input series, the behavior changes.

4. **Parameter mismatch**  
   Different `N` and `k` settings change responsiveness and band tightness:
   - Shorter `N` reacts faster but can produce more noise.
   - Larger `k` widens bands and reduces frequency of touches.
   Parameter selection should match your timeframe and holding period.

### Practical checklist for traders
- Identify whether you’re in a **trend** or **range** regime (e.g., using moving averages, higher timeframe structure).
- Use **band width** (or a squeeze heuristic) to gauge volatility state.
- If using mean reversion, require additional confirmation (e.g., rejection signals, momentum turning, or failure to hold beyond a band).
- If using breakout logic, avoid expecting immediate reversals; watch for **follow-through** and volatility expansion.

## Text Formula
Let:
- `N` = lookback window length (e.g., 20)
- `k` = standard deviation multiplier (e.g., 2)
- `close_t` = closing price at time `t` for a given `symbol`

For each symbol and date `t` (when at least `N` observations are available):

1. **Middle band** (simple moving average):
- `MB_t = SMA_N(close)_t`

2. **Rolling standard deviation**:
- `SD_t = STD_N(close)_t`

3. **Upper and lower bands**:
- `UB_t = MB_t + k * SD_t`
- `LB_t = MB_t - k * SD_t`

4. **Band width** (absolute):
- `BW_t = UB_t - LB_t`

5. **Band width** (relative, optional but common):
- `BWRel_t = (UB_t - LB_t) / MB_t`

6. **%B** (position of price within the bands):
- `%B_t = (close_t - LB_t) / (UB_t - LB_t)`

7. **(Optional) Z-score relative to middle band**:
- `Z_t = (close_t - MB_t) / SD_t`

All calculations above use rolling window operations applied **per symbol**.

## Python Code
```python
import pandas as pd
import numpy as np

def bollinger_bands(df: pd.DataFrame, n: int = 20, k: float = 2.0) -> pd.DataFrame:
    """
    Expected input DataFrame columns:
      - 'symbol'
      - 'date' (sortable; will be used for ordering within each symbol)
      - 'open', 'high', 'low', 'close' (we use 'close' for Bollinger Bands)

    Returns a DataFrame with original columns plus:
      - 'bb_middle'  : middle band (SMA of close over N)
      - 'bb_upper'   : upper band = middle + k * rolling std
      - 'bb_lower'   : lower band = middle - k * rolling std
      - 'bb_width'   : absolute width = upper - lower
      - 'bb_width_rel' : relative width = (upper - lower) / middle
      - 'bb_percent_b' : %B = (close - lower) / (upper - lower)
      - 'bb_zscore'  : z-score = (close - middle) / rolling std
      - 'bb_squeeze' : boolean heuristic for squeeze based on lower quantile of width
                        (computed per symbol using a rolling-history quantile on width)
    """
    required = {"symbol", "date", "open", "high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()

    # Ensure ordering for rolling window correctness
    out = out.sort_values(["symbol", "date"])

    # Group by symbol to compute independent rolling statistics
    g = out.groupby("symbol", group_keys=False)

    close = out["close"]

    # Rolling mean and std (sample std vs population std can differ; Pandas uses ddof=1 by default)
    # We keep Pandas default for std to match typical library behavior.
    rolling_mean = g["close"].transform(lambda s: s.rolling(window=n, min_periods=n).mean())
    rolling_std = g["close"].transform(lambda s: s.rolling(window=n, min_periods=n).std())

    out["bb_middle"] = rolling_mean
    out["bb_upper"] = out["bb_middle"] + k * rolling_std
    out["bb_lower"] = out["bb_middle"] - k * rolling_std

    # Width measures
    out["bb_width"] = out["bb_upper"] - out["bb_lower"]
    out["bb_width_rel"] = out["bb_width"] / out["bb_middle"]

    # %B: handle division by zero when bands collapse (upper == lower)
    denom = out["bb_width"].replace(0, np.nan)
    out["bb_percent_b"] = (out["close"] - out["bb_lower"]) / denom

    # Z-score: handle std==0 with NaN
    out["bb_zscore"] = (out["close"] - out["bb_middle"]) / rolling_std.replace(0, np.nan)

    # Optional squeeze heuristic:
    # Define squeeze as width being below a rolling historical quantile.
    # This is not a single canonical definition; it's a practical heuristic.
    # Parameters for the heuristic:
    squeeze_lookback = max(50, n * 5)  # enough history relative to N
    squeeze_quantile = 0.20

    def squeeze_flag(width_series: pd.Series) -> pd.Series:
        # rolling quantile requires enough samples
        q = width_series.rolling(window=squeeze_lookback, min_periods=squeeze_lookback).quantile(squeeze_quantile)
        return width_series < q

    out["bb_squeeze"] = g["bb_width"].transform(squeeze_flag)

    return out
```
```json
{ "model_code": "r6jq2vk9btx4", "topic": "Bollinger Bands", "timer_secs": 14.67, "tokens_in": 559, "tokens_out": 2158, "cost_tokens_in": 0.00011180, "cost_tokens_out": 0.00269750, "cost_tokens_tot": 0.00280930 }
```