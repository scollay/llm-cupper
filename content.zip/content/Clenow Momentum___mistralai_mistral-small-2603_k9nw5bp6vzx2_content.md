# Clenow Momentum

## Overview
Clenow Momentum is a trend-following indicator designed to identify the strength and persistence of a price trend. Developed by Andreas Clenow, it combines price momentum with volatility normalization to generate signals that are less prone to false breakouts than traditional momentum indicators. The indicator appears as a single line on a price chart, typically oscillating around a zero line, with positive values indicating bullish momentum and negative values suggesting bearish momentum.

## Details
Clenow Momentum is rooted in the concept of *price velocity*—the rate of change in price adjusted for volatility. Unlike raw momentum indicators that simply compare closing prices over a fixed lookback period, Clenow’s approach normalizes the momentum by the standard deviation of recent returns. This adjustment reduces the impact of volatile but directionless price swings, making the indicator more reliable in choppy markets.

The indicator is calculated using a two-step process:
1. **Raw Momentum**: The difference between the current closing price and the closing price *n* periods ago, divided by the closing price *n* periods ago.
2. **Volatility Normalization**: The raw momentum is divided by the standard deviation of returns over the same lookback period. This step ensures that strong moves in low-volatility assets are treated similarly to moderate moves in high-volatility assets.

Traders interpret Clenow Momentum in several ways:
- **Trend Identification**: Values above zero suggest an uptrend, while values below zero indicate a downtrend. The stronger the deviation from zero, the stronger the trend.
- **Signal Generation**: Crossovers of the zero line are often used as entry or exit signals, though false signals can occur in ranging markets.
- **Divergence**: If price makes a new high but Clenow Momentum fails to confirm, it may signal weakening momentum and a potential reversal.

**Limitations**:
- Like all momentum indicators, Clenow Momentum performs poorly in sideways or choppy markets. The volatility normalization helps, but it cannot eliminate all noise.
- The indicator is lagging by nature, as it relies on past price data. In rapidly reversing trends, it may produce delayed signals.
- The choice of lookback period (e.g., 200 days) is subjective and may need adjustment based on the asset class or timeframe.

## Text Formula
Clenow Momentum is calculated as follows:

1. Compute the raw momentum over *n* periods:
   `raw_momentum = (close_t - close_t-n) / close_t-n`

2. Compute the standard deviation of returns over *n* periods:
   `volatility = std(returns_t-n to t)`
   where `returns_t = (close_t - close_t-1) / close_t-1`

3. Normalize the raw momentum by volatility:
   `clenow_momentum = raw_momentum / volatility`

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df: pd.DataFrame, n: int = 200) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for one or more symbols in a DataFrame.

    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with columns: symbol, date, open, high, low, close.
        Assumed to be sorted by symbol and date.
    n : int
        Lookback period for momentum and volatility calculation (default: 200).

    Returns:
    --------
    pd.DataFrame
        Original DataFrame with added column `clenow_momentum`.
    """
    # Group by symbol to handle multi-symbol DataFrames
    grouped = df.groupby('symbol')

    # Initialize output column
    df['clenow_momentum'] = np.nan

    for name, group in grouped:
        # Sort by date to ensure chronological order
        group = group.sort_values('date').copy()

        # Calculate raw returns (daily)
        group['return'] = group['close'].pct_change()

        # Calculate raw momentum: (close_t - close_t-n) / close_t-n
        group['raw_momentum'] = (group['close'] - group['close'].shift(n)) / group['close'].shift(n)

        # Calculate rolling volatility (standard deviation of returns over n periods)
        group['volatility'] = group['return'].rolling(window=n).std()

        # Compute Clenow Momentum: raw_momentum / volatility
        group['clenow_momentum'] = group['raw_momentum'] / group['volatility']

        # Update the original DataFrame
        df.loc[group.index, 'clenow_momentum'] = group['clenow_momentum']

    return df
```
```json
{ "model_code": "k9nw5bp6vzx2", "topic": "Clenow Momentum", "timer_secs": 6.18, "tokens_in": 583, "tokens_out": 1014, "cost_tokens_in": 0.00008745, "cost_tokens_out": 0.00060840, "cost_tokens_tot": 0.00069585 }
```