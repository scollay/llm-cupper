# T3 Moving Average

## Overview

The T3 Moving Average is a smoothed moving average developed by **Tim Tillson** and introduced in the January 1998 issue of *Technical Analysis of Stocks & Commodities*. On a chart it appears as a notably smooth, responsive curve—visually similar to an EMA but with significantly less noise. T3 achieves this by cascading multiple exponential moving averages and then combining them through a weighted polynomial controlled by a single **volume factor** (typically set to 0.7). The result is a trend line that adapts quickly to price changes while filtering out minor fluctuations that cause false signals.

## Details

### How T3 Works

The T3 builds on the idea that a single EMA can be improved. Tillson's key insight was to generalize the Double Exponential Moving Average (DEMA) concept into a *Generalized DEMA* (GD), controlled by a parameter he called the volume factor, **v**:

> GD(v) = (1 + v) × EMA₁ − v × EMA₂

where EMA₁ is the EMA of price and EMA₂ is the EMA of EMA₁. When v = 0, GD collapses to a plain EMA. As v approaches 1, GD moves closer to DEMA. The volume factor lets the trader dial in exactly how much smoothing they want.

T3 applies this GD operation **three successive times**. Fully expanded, this requires six cascaded EMAs—each built on the prior one—which are then combined into four weighted terms. The volume factor (default **0.7**) determines the coefficients of those four terms. Because the smoothing is polynomial rather than purely exponential, T3 produces a curve that is both smoother than a comparable-period EMA and exhibits less phase lag than a simple moving average of similar length.

### Interpreting T3

Traders use T3 in several standard ways:

- **Trend direction.** Price consistently above T3 signals an uptrend; price below signals a downtrend. The slope of T3 itself can reinforce or contradict that reading.
- **Crossover signals.** Plotting two T3 lines—one short-period, one longer—and trading the crossover is a popular approach. Because T3 is inherently smooth, crossovers tend to be more reliable than those from raw EMAs.
- **Support and resistance.** In trending conditions, T3 often acts as a dynamic support (in uptrends) or resistance (in downtrends) level.
- **Signal line in oscillators.** T3 can replace the standard MA component inside indicators like MACD, creating a "T3 MACD" with reduced whipsaw.

### Where Interpretation Breaks Down

- **Lag is reduced, not eliminated.** T3 still reacts after price has already moved. In fast reversals—especially sharp V-shaped turns—the T3 line will trail.
- **Range-bound markets.** When price oscillates without a clear trend, even the smooth T3 will generate whipsaws. No moving average, however sophisticated, solves a sideways market.
- **Volume factor sensitivity.** Setting v too high (approaching 1.0) produces extreme smoothing that can mask genuine early reversals. Setting it too low negates T3's advantage over a standard EMA. The choice of v is itself a trade-off with no universally optimal value.
- **Not predictive.** T3 is built entirely from historical closes. It describes where the trend *has been*, not where it will go. It should be combined with volume analysis, momentum oscillators, or price-pattern context.

## Text Formula

**Inputs:**

- `close` = closing price series
- `n` = EMA lookback period (e.g., 20)
- `v` = volume factor (default 0.7, valid range 0 to 1)

**Step 1 — Cascade six EMAs:**

```
e1 = EMA(close, n)
e2 = EMA(e1, n)
e3 = EMA(e2, n)
e4 = EMA(e3, n)
e5 = EMA(e4, n)
e6 = EMA(e5, n)
```

where EMA uses the standard multiplier `α = 2 / (n + 1)`.

**Step 2 — Compute coefficients:**

```
c1 = −v³
c2 = 3v²(1 + v)
c3 = −3v(1 + v)²
c4 = (1 + v)³
```

**Step 3 — Compute T3:**

```
T3 = c1 × e6 + c2 × e5 + c3 × e4 + c4 × e3
```

The four coefficients always sum to 1.0, which preserves the scale of the price data.

## Python Code

```python
import pandas as pd


def t3_moving_average(df, period=20, vfactor=0.7):
    """
    Calculate the T3 Moving Average for every symbol in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        May include one or more symbols; each is processed independently.
    period : int
        Span used for every cascaded EMA (default 20).
    vfactor : float
        Volume factor controlling the degree of smoothing (default 0.7).
        Range 0–1; higher values produce a smoother, more lagged curve.

    Returns
    -------
    pd.DataFrame
        Original columns plus: e1, e2, e3, e4, e5, e6 (cascaded EMAs)
        and t3 (the T3 Moving Average).
    """
    result = df.copy()

    # ---- coefficients derived from the volume factor ----
    v = vfactor
    c1 = -(v ** 3)
    c2 = 3 * (v ** 2) * (1 + v)
    c3 = -3 * v * ((1 + v) ** 2)
    c4 = (1 + v) ** 3

    def _compute(group):
        g = group.copy()
        close = g["close"]

        # six cascaded EMAs
        g["e1"] = close.ewm(span=period, adjust=False).mean()
        g["e2"] = g["e1"].ewm(span=period, adjust=False).mean()
        g["e3"] = g["e2"].ewm(span=period, adjust=False).mean()
        g["e4"] = g["e3"].ewm(span=period, adjust=False).mean()
        g["e5"] = g["e4"].ewm(span=period, adjust=False).mean()
        g["e6"] = g["e5"].ewm(span=period, adjust=False).mean()

        # weighted combination
        g["t3"] = c1 * g["e6"] + c2 * g["e5"] + c3 * g["e4"] + c4 * g["e3"]

        return g

    result = result.groupby("symbol", group_keys=False).apply(_compute)

    return result
```
```json
{ "model_code": "s7hp3qw8nmc4", "topic": "T3", "timer_secs": 122.45, "tokens_in": 805, "tokens_out": 4581, "cost_tokens_in": 0.00080500, "cost_tokens_out": 0.01374300, "cost_tokens_tot": 0.01454800 }
```