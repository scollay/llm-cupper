# Coppock Curve

## Overview
The Coppock Curve is a long-term price momentum indicator primarily used to identify major market bottoms. Developed by economist Edwin Coppock in 1962 and originally published in *Barron’s*, it was designed to signal buying opportunities for long-term investors rather than day traders. On a chart, the indicator appears as a single line oscillating above and below a zero baseline. When the curve crosses from negative to positive, it is traditionally interpreted as a signal that a bear market has concluded and a new bull market cycle has begun.

## Details
The Coppock Curve is a momentum oscillator that combines a Rate of Change (ROC) calculation with a Weighted Moving Average (WMA). By design, it is a lagging indicator, which is intentional; its purpose is to filter out the "noise" of short-term market volatility to capture the broader, structural shifts in market sentiment.

### How It Works
The calculation begins by summing two different ROC periods—typically 14 months and 11 months. This sum is then smoothed using a 10-month Weighted Moving Average. The resulting value fluctuates around the zero line. 
*   **Buy Signal:** When the Coppock Curve is below zero and turns upward, crossing above the zero line, it suggests that the market has bottomed and momentum is shifting toward a long-term uptrend.
*   **Sell Signal:** While Coppock originally intended the indicator to identify buy signals, some traders use the curve to identify sell signals when the indicator peaks and turns downward, even if it remains in positive territory.

### Limitations and Breakdowns
Because the Coppock Curve relies on monthly data, it is inherently slow. It is not designed for tactical asset allocation or short-term swing trading. Traders often encounter three primary issues:
1.  **Lag:** By the time the curve crosses the zero line, a significant portion of the initial recovery may have already occurred.
2.  **False Positives:** In sideways or "choppy" markets, the indicator can produce whipsaws where the line crosses the zero threshold multiple times without a sustained trend following.
3.  **Asset Class Sensitivity:** While originally calibrated for the S&P 500, applying the standard 11/14/10 parameters to more volatile assets (like individual equities or cryptocurrencies) often results in excessive noise, requiring the trader to adjust the look-back periods to suit the specific asset's volatility profile.

## Text Formula
The Coppock Curve is calculated using the following steps:

1.  **ROC1:** Calculate the 14-period Rate of Change: `((Close - Close_14_periods_ago) / Close_14_periods_ago) * 100`
2.  **ROC2:** Calculate the 11-period Rate of Change: `((Close - Close_11_periods_ago) / Close_11_periods_ago) * 100`
3.  **Sum:** Add the two ROC values together: `ROC_Sum = ROC1 + ROC2`
4.  **Coppock Curve:** Calculate the 10-period Weighted Moving Average (WMA) of the `ROC_Sum`. The WMA assigns higher weights to more recent data points.

## Python Code
```python
import pandas as pd

def calculate_coppock_curve(df, roc1_period=14, roc2_period=11, wma_period=10):
    """
    Calculates the Coppock Curve for a DataFrame containing 'symbol' and 'close' columns.
    
    Expected DataFrame format:
    - symbol: str
    - date: datetime
    - close: float
    """
    
    def get_roc(series, period):
        return ((series - series.shift(period)) / series.shift(period)) * 100

    def get_wma(series, period):
        # WMA calculation using rolling window
        weights = pd.Series(range(1, period + 1))
        return series.rolling(window=period).apply(
            lambda x: (x * weights).sum() / weights.sum(), raw=True
        )

    results = []
    
    # Group by symbol to ensure independent calculation
    for symbol, group in df.groupby('symbol'):
        group = group.sort_values('date').copy()
        
        roc1 = get_roc(group['close'], roc1_period)
        roc2 = get_roc(group['close'], roc2_period)
        roc_sum = roc1 + roc2
        
        group['coppock_curve'] = get_wma(roc_sum, wma_period)
        results.append(group)
        
    return pd.concat(results)
```
```json
{ "model_code": "p2qm6vw4rzc8", "topic": "Coppock Curve", "timer_secs": 4.61, "tokens_in": 565, "tokens_out": 1048, "cost_tokens_in": 0.00014125, "cost_tokens_out": 0.00157200, "cost_tokens_tot": 0.00171325 }
```