# Bollinger Bands

## Overview
Bollinger Bands are a volatility‑based envelope placed around a price series. They consist of three lines: a middle simple moving average (SMA) and two outer bands that sit a set number of standard deviations above and below that average. Developed by John Bollinger in the early 1980s, the bands appear on a chart as a dynamic channel that expands during periods of high volatility and contracts when the market quiets down.

## Details
### Calculation
The core of Bollinger Bands is a rolling statistical measure applied to the closing price. For a chosen look‑back period *N* (commonly 20 periods) and a multiplier *k* (usually 2):

1. **Middle Band (MB)** – the SMA of the close over *N* periods.  
2. **Standard Deviation (σ)** – the population standard deviation of the close over the same *N* periods.  
3. **Upper Band (UB)** – MB + *k*·σ.  
4. **Lower Band (LB)** – MB − *k*·σ.

Mathematically:
- MBₜ = (1/N) Σ_{i=0}^{N‑1} C_{t‑i}  
- σₜ = sqrt[(1/N) Σ_{i=0}^{N‑1} (C_{t‑i} − MBₜ)²]  
- UBₜ = MBₜ + k·σₜ  
- LBₜ = MBₜ − k·σₜ  

where Cₜ is the closing price at time *t*.

Traders often derive two additional metrics from the bands:
- **Bandwidth** = (UB − LB) / MB – a normalized measure of volatility.
- **% B** = (Close − LB) / (UB − LB) – the position of the price within the band, ranging from 0 (at the lower band) to 1 (at the upper band).

### Interpretation
- **Overbought/Oversold Signals** – When the price touches or exceeds the upper band, the market may be overbought; touching or falling below the lower band suggests oversold conditions. These extremes are more meaningful in ranging markets.
- **Volatility Squeeze** – A narrowing of the bands (low bandwidth) indicates decreasing volatility and often precedes a breakout or strong move.
- **Trend Strength** – In a strong uptrend, prices tend to hug the upper band; in a downtrend, they stay near the lower band. Persistent contact with one band can therefore signal trend continuation rather than reversal.
- **% B Extremes** – Values above 1 or below 0 imply the price has moved outside the bands, which can precede a reversal or indicate a powerful breakout.

### Where Interpretation Breaks Down
- **Strong Trends** – In a trending market, the price can remain outside one band for extended periods, rendering overbought/oversold signals false.
- **Band Width Misreads** – A sudden expansion of bandwidth may reflect a volatility spike unrelated to direction, leading to premature breakout expectations.
- **Parameter Sensitivity** – The choice of *N* and *k* affects band tightness; inappropriate settings can produce either too many whipsaws or overly sluggish signals.
- **Non‑Normal Price Distribution** – Bollinger Bands assume roughly normal distribution of price changes; fat‑tailed or skewed returns can distort the standard‑deviation‑based bands.

Overall, Bollinger Bands are most effective when used alongside other tools (e.g., volume, momentum oscillators) and when the trader remains aware of the prevailing market regime.

## Text Formula
Middle Band: MBₜ = SMAₙ(Cₜ) = (1/N) Σ_{i=0}^{N‑1} C_{t‑i}  
Standard Deviation: σₜ = sqrt[(1/N) Σ_{i=0}^{N‑1} (C_{t‑i} − MBₜ)²]  
Upper Band: UBₜ = MBₜ + k·σₜ  
Lower Band: LBₜ = MBₜ − k·σₜ  
Bandwidth: BWₜ = (UBₜ − LBₜ) / MBₜ  
% B: % Bₜ = (Cₜ − LBₜ) / (UBₜ − LBₜ)  

Typical defaults: N = 20, k = 2.

## Python Code
```python
import pandas as pd

def bollinger_bands(
    df: pd.DataFrame,
    window: int = 20,
    num_std: float = 2.0
) -> pd.DataFrame:
    """
    Calculate Bollinger Bands for one or more symbols.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain the columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
        The DataFrame can hold data for multiple symbols; each symbol is processed
        independently.
    window : int, default 20
        Look‑back period for the moving average and standard deviation.
    num_std : float, default 2.0
        Number of standard deviations for the upper and lower bands.

    Returns
    -------
    pd.DataFrame
        A copy of the input with the following additional columns:
        - middle_band
        - upper_band
        - lower_band
        - bandwidth
        - percent_b
    """
    # Work on a copy to avoid side‑effects
    result = df.copy()

    # Ensure chronological order per symbol before rolling calculations
    result = result.sort_values(['symbol', 'date'])

    # Middle band: simple moving average of close
    result['middle_band'] = (
        result.groupby('symbol')['close']
              .transform(lambda s: s.rolling(window, min_periods=window).mean())
    )

    # Rolling standard deviation of close (population std, ddof=0)
    rolling_std = (
        result.groupby('symbol')['close']
              .transform(lambda s: s.rolling(window, min_periods=window).std(ddof=0))
    )

    # Upper and lower bands
    result['upper_band'] = result['middle_band'] + num_std * rolling_std
    result['lower_band'] = result['middle_band'] - num_std * rolling_std

    # Bandwidth (normalized width)
    result['bandwidth'] = (
        (result['upper_band'] - result['lower_band']) / result['middle_band']
    )

    # Percent B (position of close within the bands)
    result['percent_b'] = (
        (result['close'] - result['lower_band']) /
        (result['upper_band'] - result['lower_band'])
    )

    return result
```
The function respects multiple symbols by grouping on the `symbol` column before applying rolling windows, ensuring that each symbol’s bands are calculated independently. All derived values—middle, upper, lower bands, bandwidth, and % B—are returned as new columns in the DataFrame.
```json
{ "model_code": "x6kp3hr9bln2", "topic": "Bollinger Bands", "timer_secs": 38.30, "tokens_in": 562, "tokens_out": 1553, "cost_tokens_in": 0.00005058, "cost_tokens_out": 0.00069885, "cost_tokens_tot": 0.00074943 }
```