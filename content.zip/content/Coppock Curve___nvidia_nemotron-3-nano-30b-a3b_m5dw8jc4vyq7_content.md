# Coppock Curve

## Overview
The Coppock Curve is a momentum‑based technical indicator that blends two rate‑of‑change (ROC) periods with a long‑term weighted moving average to smooth out short‑term noise. It was introduced by Edwin Coppock in 1962 for the New York Stock Exchange to identify bullish turning points in broad market indices. On a price chart the indicator appears as a line that oscillates around a zero baseline; positive values signal emerging upward momentum, while negative values suggest weakening or bearish pressure. Because the calculation smooths the combined ROC signals with a 100‑day weighted moving average, the Coppock Curve is best suited for weekly or monthly timeframes rather than intraday charts. Although originally designed for equity indices, traders have adapted it to individual stocks, commodities, and even crypto assets, using it as a confirmation tool alongside other trend‑following studies.

## Details
The core idea behind the Coppock Curve is to capture the natural “slow‑burn” nature of sustained price appreciation. First, the indicator calculates a 14‑day ROC, which measures the percentage change in closing price over the past 14 periods. A second ROC of 11 days is computed in the same way. These two ROC values are added together, producing a raw momentum figure that can be both positive and negative. To prevent the resulting line from reacting to fleeting spikes, the sum is then passed through a 100‑day weighted moving average (WMA). The weighting scheme assigns higher importance to the most recent observations, with weights decreasing linearly from 100 down to 1. This WMA smooths the combined ROC while preserving the directional bias of the underlying momentum.

Traders typically interpret a rising Coppock Curve crossing above zero as a signal that a new uptrend may be forming, especially when the crossover is accompanied by a bullish price pattern or volume surge. Conversely, a drop back below zero is often taken as a warning that the prior uptrend may be losing steam. Because the indicator is inherently slow — its 100‑day WMA means that signals can lag by several weeks — it works best in markets with clear, persistent trends and is less reliable in choppy or sideways conditions. Moreover, the Coppock Curve can generate false signals during sharp reversals or when a market experiences a rapid shift in sentiment; therefore, many practitioners combine it with other filters such as moving‑average crossovers, volume spikes, or higher‑timeframe trend analysis to reduce noise.

The indicator also respects the multi‑symbol nature of many data feeds. Since the calculation is performed independently for each symbol, the Coppock Curve can be plotted alongside price action for each ticker, allowing traders to compare momentum across different securities on a common timeframe. This makes it particularly useful for relative‑strength assessments, where a stock with a rising Coppock Curve while its peers are flat or declining may be identified as a relative strength candidate.

## Text Formula
The Coppock Curve (CC) for a given symbol can be expressed as:

\[
\text{CC}_t = \text{WMA}_{100}\!\left( \text{ROC}_{14,t} + \text{ROC}_{11,t} \right)
\]

where  

\[
\text{ROC}_{n,t} = \frac{C_t - C_{t-n}}{C_{t-n}} \times 100
\]

and **WMA** denotes a weighted moving average with weights \(w_k = 100, 99, \dots, 1\) applied to the most recent 100 observations of the summed ROC series. The division by the sum of the weights normalizes the result, yielding a value that can be plotted directly on the price chart.

## Python Code
The following function receives a Pandas DataFrame that may contain rows for multiple symbols. It assumes the DataFrame has the columns `symbol`, `date`, `open`, `high`, `low`, `close`. The function returns a DataFrame with an additional column `coppock` that holds the computed Coppock Curve value for each row, calculated separately for each symbol.

```python
import pandas as pd
import numpy as np

def calculate_coppock(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the Coppock Curve for each symbol in the input DataFrame.
    
    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data is expected to be sorted by symbol and date ascending.
    
    Returns
    -------
    pd.DataFrame
        The original DataFrame with an extra column 'coppock' containing
        the Coppock Curve values. Missing values (NaN) appear where the
        calculation cannot be performed due to insufficient history.
    """
    # Ensure proper sorting for rolling calculations
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Helper to compute ROC for a given period
    def roc(series, period):
        return (series - series.shift(period)) / series.shift(period) * 100

    # Compute the two ROC components
    df['roc_14'] = roc(df['close'], 14)
    df['roc_11'] = roc(df['close'], 11)

    # Sum the ROCs
    df['roc_sum'] = df['roc_14'] + df['roc_11']

    # Define weights for a 100‑day WMA (most recent weight = 100)
    weights = np.arange(100, 0, -1)  # [100, 99, ..., 1]
    weight_sum = weights.sum()

    # Function to apply WMA to a rolling window
    def wma(series, w=weights):
        return series.rolling(window=len(w)).apply(
            lambda x: np.dot(x, w) / weight_sum, raw=True
        )

    # Apply 100‑day WMA to the summed ROC series, grouped by symbol
    df['coppock'] = (
        df.groupby('symbol')['roc_sum']
        .rolling(window=100, min_periods=100)
        .apply(wma, raw=False)
        .reset_index(level=0, drop=True)
    )

    # Clean up intermediate columns if desired (optional)
    # df.drop(columns=['roc_14', 'roc_11', 'roc_sum'], inplace=True)

    return df
```

The function first sorts the data to guarantee chronological order within each symbol, then calculates the 14‑day and 11‑day ROC values. After summing these ROCs, it applies a 100‑day weighted moving average using a linearly decreasing weight set from 100 to 1. The result is stored in the `coppock` column, which can be plotted alongside price data to visualize momentum shifts. Because the operation is performed inside a `groupby('symbol')` context, each symbol’s series is processed independently, ensuring that the indicator reflects the specific historical context of each asset. This implementation is vectorized where possible and will run efficiently on moderately sized datasets, though very large multi‑symbol universes may benefit from chunked processing or optimized libraries.
```json
{ "model_code": "m5dw8jc4vyq7", "topic": "Coppock Curve", "timer_secs": 31.36, "tokens_in": 581, "tokens_out": 2996, "cost_tokens_in": 0.00002905, "cost_tokens_out": 0.00059920, "cost_tokens_tot": 0.00062825 }
```