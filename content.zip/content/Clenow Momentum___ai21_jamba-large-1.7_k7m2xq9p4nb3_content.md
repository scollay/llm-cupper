# Clenow Momentum

## Overview
Clenow Momentum is a trend-following indicator designed to measure the relative strength of an asset's price movement over a specified period. It was introduced by Andreas Clenow in his book *Following the Trend* to help identify assets with strong momentum for inclusion in systematic trading strategies. The indicator appears as a ranked or scaled value, often normalized to compare momentum across multiple assets.

## Details
Clenow Momentum is based on the rate of change (ROC) of an asset's price over a lookback period, typically 100 days. It is used to rank assets by their momentum to identify those with the strongest upward price trends. The indicator is calculated as the percentage change of the closing price over the lookback period relative to the current close.

Traders interpret Clenow Momentum as a way to prioritize assets for long positions in trend-following systems. Assets with higher momentum values are considered stronger candidates for investment, while those with lower or negative values are avoided. This approach assumes that assets with strong past performance are likely to continue their trend in the short term.

However, the interpretation can break down during periods of high volatility or when markets experience sudden reversals. Momentum is a lagging indicator, so it may give false signals in choppy or range-bound markets. Additionally, the fixed lookback period may not suit all market conditions, requiring traders to adapt the period based on the asset class or timeframe.

## Text Formula
The formula for Clenow Momentum is:

$$\text{Momentum} = \frac{\text{close} - \text{close}_{t-n}}{\text{close}_{t-n}}$$

Where:

- `close` is the most recent closing price.
- `close_{t-n}` is the closing price `n` periods ago (e.g., 100 days ago).
- `n` is the lookback period (commonly 100).

The result is expressed as a percentage, representing the relative price change over the lookback period.

## Python Code
```python
import pandas as pd

def clenow_momentum(data, lookback=100):
    """
    Calculate Clenow Momentum for each symbol in the input DataFrame.
    
    Parameters:
    - data: Pandas DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close'].
    - lookback: Integer specifying the lookback period (default is 100).
    
    Returns:
    - A DataFrame with added column 'clenow_momentum' for each symbol.
    """
    # Ensure data is sorted by symbol and date
    data = data.sort_values(by=['symbol', 'date'])
    
    # Initialize an empty list to store momentum values
    momentum_values = []
    
    # Group data by symbol to handle each symbol independently
    for symbol, group in data.groupby('symbol'):
        # Calculate lookback period close
        group['clenow_momentum'] = (group['close'] - group['close'].shift(lookback)) / group['close'].shift(lookback)
        momentum_values.append(group)
    
    # Combine results back into a single DataFrame
    result = pd.concat(momentum_values)
    return result

# Example usage:
# Assume `df` is your input DataFrame with columns: symbol, date, open, high, low, close
# result = clenow_momentum(df)
# The output will include a new column `clenow_momentum` for each symbol.
```

This code calculates Clenow Momentum for each symbol in the DataFrame independently. It assumes the input DataFrame is already sorted by `symbol` and `date`. The `clenow_momentum` column will contain the percentage change over the specified lookback period for each asset.
```json
{ "model_code": "k7m2xq9p4nb3", "topic": "Clenow Momentum", "timer_secs": 19.17, "tokens_in": 604, "tokens_out": 885, "cost_tokens_in": 0.00120800, "cost_tokens_out": 0.00708000, "cost_tokens_tot": 0.00828800 }
```