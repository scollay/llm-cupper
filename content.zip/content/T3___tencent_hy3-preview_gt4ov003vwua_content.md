# T3 Moving Average

## Overview
The T3 is a trend-following moving average designed to minimize lag while reducing false signals (whipsaw) common in traditional moving averages. It appears as a single smooth line overlaid on the price chart, similar to simple or exponential moving averages. Technical analyst Tim Tillson developed the T3 in 1998, introducing it in a *Technical Analysis of Stocks & Commodities* article as an improvement over earlier smoothed moving averages like DEMA and TEMA.

## Details
The T3 builds on successive exponential moving average (EMA) calculations to balance smoothness and responsiveness. It requires two user-defined parameters:
- **n**: Lookback period (default 10), which sets the base EMA window.
- **a**: Smoothing factor (default 0.7, range 0 to 1), which adjusts the tradeoff between lag and noise.

Unlike simple moving averages (SMA) which weight all lookback periods equally, or standard EMAs which only apply single-pass smoothing, the T3 uses multi-pass smoothing with tunable weighting to avoid the typical tradeoff between lag and noise. Calculation steps:
1. Compute 6 successive EMAs of the `close` price, each using period **n**:
   - `e1` = EMA(close, n)
   - `e2` = EMA(e1, n)
   - `e3` = EMA(e2, n)
   - `e4` = EMA(e3, n)
   - `e5` = EMA(e4, n)
   - `e6` = EMA(e5, n)
2. Apply weighted coefficients to the 3rd through 6th EMA values using the smoothing factor **a** to produce the final T3 value. Higher **a** values shift weight toward less-smoothed EMAs, reducing lag but increasing sensitivity to price noise. Lower **a** values shift weight toward more-smoothed EMAs, increasing lag but producing a smoother line.

### Typical Interpretation
Traders use the T3 identically to other moving averages for trend identification and signal generation:
- Trend direction: Price trading above the T3 indicates an uptrend; price below indicates a downtrend. The slope of the T3 confirms trend strength: a rising T3 signals strengthening uptrend, falling T3 signals strengthening downtrend.
- Crossovers: Bullish signals occur when a shorter-period T3 crosses above a longer-period T3 (or a slower moving average like the 200-period SMA). Bearish signals occur on the reverse cross. Many trend-following strategies replace traditional MAs with T3 to reduce the number of false signals, particularly in volatile markets where standard EMAs produce frequent whipsaws.
- Dynamic support/resistance: In confirmed uptrends, pullbacks to the T3 often act as support; in downtrends, rallies to the T3 often act as resistance.

### Interpretation Breakdowns
- Lag persists: While T3 reduces lag compared to SMA or EMA, it remains a lagging indicator. It will never lead price action, only confirm trend changes after they begin.
- Ranging markets: Sideways, low-volatility markets cause frequent T3 crossovers and false breakouts, especially with higher **a** values. No moving average performs well in chop.
- Parameter sensitivity: Default settings (n=10, a=0.7) are not universal. Traders must backtest parameters for specific assets and timeframes, which requires significant effort.
- No oscillator context: T3 only tracks trend direction, not overbought/oversold conditions. Traders often pair it with momentum oscillators like RSI to filter weak signals.
- Extreme smoothing factor values: Setting **a** near 1 makes T3 track price too closely, losing smoothing benefits. Setting **a** near 0 produces an overly laggy, 3x-smoothed EMA with no practical advantage over simpler MAs.
- Gap divergence: T3 values can diverge significantly from price during gap moves, as EMAs are based on closing prices and do not account for after-hours gaps until the next session's close.

## Text Formula
Define all variables first:
- `n`: User-defined lookback period (positive integer, default 10)
- `a`: User-defined smoothing factor (float, 0 ≤ a ≤ 1, default 0.7)
- `Close_t`: Closing price at period t
- `EMA(x, n)`: Exponential Moving Average of series x with period n, calculated recursively as:
  EMA_t(x, n) = (2/(n+1)) * x_t + (1 - 2/(n+1)) * EMA_{t-1}(x, n)
- `e1` to `e6`: Successive EMAs of Close, each with period n:
  - e1_t = EMA(Close, n)_t
  - e2_t = EMA(e1, n)_t
  - e3_t = EMA(e2, n)_t
  - e4_t = EMA(e3, n)_t
  - e5_t = EMA(e4, n)_t
  - e6_t = EMA(e5, n)_t

Final T3 formula (compact form):
T3_t = (1 + a)³ * e3_t - 3a(1 + a)² * e4_t + 3a²(1 + a) * e5_t - a³ * e6_t

Expanded form (for coefficient clarity):
T3_t = (1 + 3a + 3a² + a³) * e3_t - (3a + 6a² + 3a³) * e4_t + (3a² + 3a³) * e5_t - a³ * e6_t

## Python Code
```python
import pandas as pd

def calculate_t3(df, period_n=10, smoothing_a=0.7):
    """
    Calculate T3 Moving Average for each symbol in the input DataFrame.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with columns [symbol, date, open, high, low, close]
    period_n (int): Lookback period for EMA calculations (default 10)
    smoothing_a (float): Smoothing factor between 0 and 1 (default 0.7)
    
    Returns:
    pd.DataFrame: Original DataFrame with added 't3' column containing T3 values
    """
    # Make a copy to avoid modifying the original DataFrame
    df = df.copy()
    
    # Sort data by symbol and date to ensure chronological order per symbol
    df = df.sort_values(by=["symbol", "date"]).reset_index(drop=True)
    
    # Precompute T3 coefficients from smoothing factor a
    coef_e3 = (1 + smoothing_a) ** 3
    coef_e4 = -3 * smoothing_a * (1 + smoothing_a) ** 2
    coef_e5 = 3 * (smoothing_a ** 2) * (1 + smoothing_a)
    coef_e6 = -(smoothing_a ** 3)
    
    # Group by symbol to calculate T3 independently per symbol
    def compute_t3_for_symbol(group):
        # Calculate successive EMAs (e1 to e6) for the group's close prices
        e1 = group["close"].ewm(span=period_n, adjust=False).mean()
        e2 = e1.ewm(span=period_n, adjust=False).mean()
        e3 = e2.ewm(span=period_n, adjust=False).mean()
        e4 = e3.ewm(span=period_n, adjust=False).mean()
        e5 = e4.ewm(span=period_n, adjust=False).mean()
        e6 = e5.ewm(span=period_n, adjust=False).mean()
        
        # Calculate T3 using precomputed coefficients
        group["t3"] = (coef_e3 * e3) + (coef_e4 * e4) + (coef_e5 * e5) + (coef_e6 * e6)
```json
{ "model_code": "gt4ov003vwua", "topic": "T3", "timer_secs": 82.90, "tokens_in": 563, "tokens_out": 10000, "cost_tokens_in": 0.00003547, "cost_tokens_out": 0.00210000, "cost_tokens_tot": 0.00213547 }
```