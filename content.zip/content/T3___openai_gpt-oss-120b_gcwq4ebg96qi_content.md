# Triple Exponential Moving Average (T3)

## Overview
The Triple Exponential Moving Average, commonly called **T3**, is a smoothed trend‑following indicator that reduces lag more aggressively than a traditional simple or exponential moving average. Visually, it appears as a single line that tracks price, often sitting closer to the market action than a 20‑period EMA while still filtering out most noise. The T3 was introduced by Tim Tillson in 1998 as a refinement of his earlier **TEMA** (Triple Exponential Moving Average) concept, adding a configurable smoothing factor `b` (typically 0.7) to further flatten the curve.

## Details
### How T3 Is Built
T3 is not a single EMA; it is the result of **six successive EMA calculations** applied to the same price series, followed by a final adjustment that blends the last two EMA layers. The construction steps are:

1. **EMA₁** – an exponential moving average of the price series (usually the close) with period `n`.
2. **EMA₂** – EMA of EMA₁, using the same period `n`.
3. **EMA₃** – EMA of EMA₂.
4. **EMA₄** – EMA of EMA₃.
5. **EMA₅** – EMA of EMA₄.
6. **EMA₆** – EMA of EMA₅.

After the six layers, the indicator applies a **bias correction** that pulls the line toward the most recent price, controlled by the smoothing factor `b`. The bias term `v` is defined as  

```
v = (1 - b) / (1 + b)
```

The final T3 value is then:

```
T3 = EMA₆ + (EMA₆ - EMA₅) * v
```

Because each EMA step already smooths the data, the extra bias correction yields a line that reacts faster than a plain EMA₆ yet retains the low‑noise characteristics of a multi‑EMA construct.

### Typical Parameter Choices
- **Period (`n`)** – 5 to 20 are common for short‑term trading; longer periods (30‑50) are used for swing or position trading.
- **Smoothing factor (`b`)** – 0.7 is the default, but traders may experiment with 0.5 (more lag) or 0.9 (more responsiveness).

### Interpretation in Practice
| Situation | Typical Reading | Trading Implication |
|-----------|----------------|---------------------|
| **Price crosses above T3** | Bullish signal | Consider long entries, especially if other momentum tools confirm. |
| **Price crosses below T3** | Bearish signal | Consider short entries or tighten stops. |
| **T3 slope turns upward** | Emerging uptrend | May be used to add to existing longs. |
| **T3 slope turns downward** | Emerging downtrend | May be used to add to shorts or exit longs. |

Because T3 sits close to price, **crossovers occur more frequently** than with a standard EMA. Traders therefore often combine T3 with a secondary filter—such as a higher‑timeframe T3, a volatility‑based stop, or a momentum oscillator—to avoid whipsaws.

### Where Interpretation Breaks Down
1. **Extreme Smoothing (`b` → 1)** – The bias term `v` approaches zero, making T3 essentially identical to EMA₆. Lag re‑appears, and the advantage of T3 disappears.
2. **Very Low `b` (e.g., 0.1)** – `v` becomes large, causing T3 to overshoot price and generate false signals during choppy markets.
3. **Low‑volume or thinly traded assets** – EMA calculations rely on price continuity; gaps or irregular ticks can produce erratic EMA₅/EMA₆ values, leading to spurious T3 spikes.
4. **Multi‑symbol portfolios** – If the same T3 parameters are applied indiscriminately across assets with vastly different volatility profiles, the indicator’s sensitivity will be mismatched. Always back‑test per symbol.

### Practical Tips
- **Use a trailing stop** based on a percentage of the T3 distance from price; this respects the indicator’s tighter tracking while protecting against sudden reversals.
- **Combine with volume**: A price‑above‑T3 breakout accompanied by above‑average volume tends to be more reliable.
- **Layered T3**: Plot a longer‑period T3 (e.g., 30) beneath a short‑period T3 (e.g., 10). The short‑term line crossing the long‑term line can act as a “double‑confirmation” of trend changes.

## Text Formula
Let `P_t` be the price (typically close) at time `t`, `n` the look‑back period, and `b` the smoothing factor (0 < b < 1). Define the EMA operator `EMA_k(·)` as the exponential moving average applied `k` times with period `n`.

```
EMA_1(t) = EMA(P_t, n)
EMA_2(t) = EMA(EMA_1(t), n)
EMA_3(t) = EMA(EMA_2(t), n)
EMA_4(t) = EMA(EMA_3(t), n)
EMA_5(t) = EMA(EMA_4(t), n)
EMA_6(t) = EMA(EMA_5(t), n)

v = (1 - b) / (1 + b)

T3(t) = EMA_6(t) + (EMA_6(t) - EMA_5(t)) * v
```

All EMA calculations use the standard smoothing constant `α = 2 / (n + 1)` and are performed recursively without bias adjustment (`adjust=False` in pandas).

## Python Code
```python
import pandas as pd

def calculate_t3(df: pd.DataFrame, period: int = 14, b: float = 0.7) -> pd.DataFrame:
    """
    Compute the Triple Exponential Moving Average (T3) for each symbol in the input DataFrame.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data containing at least the columns ['symbol', 'date', 'close'].
        The DataFrame may hold multiple symbols; calculations are performed per symbol.
    period : int, default 14
        Look‑back period `n` for each EMA layer.
    b : float, default 0.7
        Smoothing factor controlling the bias term. Must satisfy 0 < b < 1.
    
    Returns
    -------
    pd.DataFrame
        Original columns plus three new columns:
        - 'EMA5' : the fifth EMA layer (EMA_5)
        - 'EMA6' : the sixth EMA layer (EMA_6)
        - 'T3'   : the final Triple Exponential Moving Average.
        Rows are sorted by ['symbol', 'date'].
    """
    # Validate inputs
    required_cols = {'symbol', 'date', 'close'}
    if not required_cols.issubset(df.columns):
        missing = required_cols - set(df.columns)
        raise ValueError(f"Input DataFrame missing required columns: {missing}")

    if not (0 < b < 1):
        raise ValueError("Parameter 'b' must be between 0 and 1 (exclusive).")

    # Bias term v
    v = (1 - b) / (1 + b)

    # Helper to compute six successive EMAs for a single series
    def _t3_series(series: pd.Series) -> pd.DataFrame:
        ema1 = series.ewm(span=period, adjust=False).mean()
        ema2 = ema1.ewm(span=period, adjust=False).mean()
        ema3 = ema2.ewm(span=period, adjust=False).mean()
        ema4 = ema3.ewm(span=period, adjust=False).mean()
        ema5 = ema4.ewm(span=period, adjust=False).mean()
        ema6 = ema5.ewm(span=period, adjust=False).mean()
        t3 = ema6 + (ema6 - ema5) * v
        return pd.DataFrame({
            'EMA5': ema5,
            'EMA6': ema6,
            'T3': t3
        })

    # Apply the calculation per symbol while preserving original order
    result = (
        df.sort_values(['symbol', 'date'])
          .groupby('symbol', group_keys=False)
          .apply(lambda g: pd.concat([g.reset_index(drop=True),
                                      _t3_series(g['close'].reset_index(drop=True))],
                                     axis=1))
    )

    # Ensure the output retains the original column order plus the new ones
    output_cols = list(df.columns) + ['EMA5', 'EMA6', 'T3']
    return result[output_cols].reset_index(drop=True)
```
```json
{ "model_code": "gcwq4ebg96qi", "topic": "T3", "timer_secs": 22.82, "tokens_in": 617, "tokens_out": 2341, "cost_tokens_in": 0.00002406, "cost_tokens_out": 0.00042138, "cost_tokens_tot": 0.00044544 }
```