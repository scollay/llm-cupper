# Bollinger Bands

## Overview  
Bollinger Bands are a volatility-based technical analysis tool developed by John Bollinger in the early 1980s. They consist of three lines plotted on a price chart: a middle band (typically a 20-period simple moving average of closing prices), an upper band (two standard deviations above the middle band), and a lower band (two standard deviations below the middle band). The bands dynamically adjust to market volatility, expanding during periods of high price movement and contracting during low volatility. Traders use Bollinger Bands to identify potential overbought or oversold conditions, assess price trends, and detect volatility shifts.

---

## Details  
Bollinger Bands work by combining a moving average with standard deviation measurements to create a channel around price action. The middle band smooths price data, while the outer bands represent statistical boundaries. Key concepts include:  

- **Volatility Measurement**: The distance between the upper and lower bands reflects volatility. Wider bands indicate higher volatility; narrower bands suggest consolidation.  
- **Overbought/Oversold Signals**: Prices near the upper band may signal overbought conditions (potential sell opportunities), while prices near the lower band may indicate oversold conditions (potential buy opportunities). However, these signals are context-dependent and often unreliable in trending markets.  
- **Bollinger Bounce**: In ranging markets, prices may oscillate between the bands, creating trade opportunities when they "bounce" off the upper or lower boundaries.  
- **Bollinger Squeeze**: A contraction of the bands (low volatility) often precedes a sharp price move. Traders watch for breakouts after a squeeze to confirm directional momentum.  

### Interpretation Breakdowns  
1. **False Signals in Sideways Markets**: Prices can linger near bands during consolidation, leading to premature trades.  
2. **Trending Markets**: Strong trends may push prices outside the bands for extended periods, invalidating overbought/oversold assumptions.  
3. **Lagging Nature**: As a moving average-based indicator, Bollinger Bands react to price changes rather than predict them.  

To enhance reliability, traders often combine Bollinger Bands with other indicators like the RSI or MACD. For example, a price near the upper band *and* an RSI above 70 strengthens an overbought signal.  

---

## Text Formula  
Bollinger Bands are calculated using three components:  

1. **Middle Band (SMA)**:  
   $ \text{SMA}_N = \frac{\sum_{i=1}^{N} \text{Close}_i}{N} $  

2. **Upper Band**:  
   $ \text{Upper Band} = \text{SMA}_N + 2 \times \sigma_N $  

3. **Lower Band**:  
   $ \text{Lower Band} = \text{SMA}_N - 2 \times \sigma_N $  

Where:  
- $ N $ = number of periods (commonly 20)  
- $ \sigma_N $ = standard deviation of closing prices over $ N $ periods:  
  $ \sigma_N = \sqrt{\frac{\sum_{i=1}^{N} (\text{Close}_i - \text{SMA}_N)^2}{N - 1}} $  

4. **%B (Band Width Ratio)**:  
   $ \%B = \frac{\text{Close} - \text{Lower Band}}{\text{Upper Band} - \text{Lower Band}} $  
   - $ \%B > 1 $: Price above upper band (overbought)  
   - $ \%B < 0 $: Price below lower band (oversold)  

---

## Python Code  
```python
import pandas as pd

def calculate_bollinger_bands(df):
    # Ensure data is sorted by date for each symbol
    df = df.sort_values(by=['symbol', 'date'])
    
    # Calculate 20-period simple moving average (middle band)
    df['middle_band'] = df.groupby('symbol')['close'].rolling(window=20).mean().reset_index(level=0, drop=True)
    
    # Calculate 20-period standard deviation (used for upper/lower bands)
    df['rolling_std'] = df.groupby('symbol')['close'].rolling(window=20).std().reset_index(level=0, drop=True)
    
    # Compute upper and lower bands
    df['upper_band'] = df['middle_band'] + 2 * df['rolling_std']
    df['lower_band'] = df['middle_band'] - 2 * df['rolling_std']
    
    # Calculate %B to assess price position relative to bands
    df['b_percent'] = (df['close'] - df['lower_band']) / (df['upper_band'] - df['lower_band'])
    
    return df
```

---

The code above processes a DataFrame with columns `symbol`, `date`, `open`, `high`, `low`, and `close`. It calculates the middle band (SMA), upper/lower bands (SMA ± 2σ), and %B for each symbol independently. The `groupby('symbol')` ensures calculations are isolated per asset, while sorting by `date` guarantees correct rolling window alignment. Standard deviation uses the default sample calculation (`ddof=1`), matching most financial implementations.  

For practical use, apply the function to a pre-sorted DataFrame containing at least 20 data points per symbol to avoid NaN values in the output. The resulting bands adapt to price volatility, and %B provides a normalized view of where the price sits within the channel. Always validate signals with additional context (e.g., volume, trend direction) to reduce false trades.
```json
{ "model_code": "d2vt6jb9krx5", "topic": "Bollinger Bands", "timer_secs": 397.83, "tokens_in": 565, "tokens_out": 4028, "cost_tokens_in": 0.00004520, "cost_tokens_out": 0.00096672, "cost_tokens_tot": 0.00101192 }
```