# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a trend-following indicator that smooths price data by calculating the arithmetic mean of closing prices over a chosen lookback period. On a chart it appears as a single continuous line overlaid on price, lagging behind recent action by design. No individual is credited with its invention; the technique has been used in various forms for centuries to reduce noise in time-series data.

## Details
Traders calculate an SMA by summing the most recent n closing prices and dividing by n. The resulting value is plotted for each successive bar, creating a smooth curve. Common periods include 20, 50, 100, and 200 bars; shorter lengths hug price more closely while longer lengths emphasize the primary trend.

Interpretation centers on direction and slope. An upward-sloping SMA signals that average prices are rising, indicating a bullish bias; a downward slope signals the opposite. Price trading above a rising SMA is often viewed as supportive of long positions, while price below a falling SMA supports shorts. Crossovers between two SMAs of different lengths (for example, 50-period crossing above the 200-period) are used to identify potential trend changes.

The indicator’s main limitation is lag. Because every price in the window receives equal weight, the SMA reacts slowly to sudden reversals. In sideways markets it frequently generates whipsaw signals when price oscillates around the line. It also provides no information about volatility or momentum, so it is rarely used in isolation.

## Text Formula
SMA_n = (C_t + C_{t-1} + ... + C_{t-n+1}) / n  
where C_t is the close at time t and n is the chosen period.

## Python Code
```python
import pandas as pd

def add_sma(df: pd.DataFrame, period: int = 20, column: str = "close") -> pd.DataFrame:
    """
    Add a Simple Moving Average column to a DataFrame containing one or more symbols.
    
    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
        Data should be sorted by symbol and date.
    period : int
        Lookback window for the SMA.
    column : str
        Price column to average (default 'close').
    
    Returns
    -------
    pd.DataFrame
        Original DataFrame with new column 'sma_{period}' added.
    """
    if not {"symbol", "date", column}.issubset(df.columns):
        raise ValueError("DataFrame must contain 'symbol', 'date', and the price column.")
    
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["symbol", "date"])
    
    df[f"sma_{period}"] = (
        df.groupby("symbol")[column]
        .transform(lambda x: x.rolling(window=period, min_periods=period).mean())
    )
    
    return df
```
```json
{ "model_code": "w5jp2zk6vqr9", "topic": "Simple Moving Average", "timer_secs": 8.21, "tokens_in": 677, "tokens_out": 1103, "cost_tokens_in": 0.00084625, "cost_tokens_out": 0.00275750, "cost_tokens_tot": 0.00360375 }
```