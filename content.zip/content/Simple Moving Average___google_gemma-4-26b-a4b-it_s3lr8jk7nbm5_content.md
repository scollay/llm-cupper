# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is one of the most fundamental technical analysis tools used to smooth out price data by creating a constantly updated average price. It appears on a chart as a single line that follows the price action of an asset, lagging behind current price movements. While it does not have a single "inventor," it is a cornerstone of trend-following methodologies used by traders across all asset classes to identify the direction and strength of a market trend.

## Details
The SMA functions by calculating the arithmetic mean of a security's price over a specific number of periods. As new data becomes available, the oldest data point is dropped from the calculation, and the newest is added, causing the average to "move" along the time series.

### Mechanics and Period Selection
The behavior of an SMA is dictated by its lookback period, often denoted as `n`. 
* **Short-term SMAs:** Periods such as 5, 10, or 20 days are used to capture immediate momentum and are highly sensitive to recent price changes.
* **Long-term SMAs:** Periods such as 50, 100, or 200 days are used to identify major structural trends. The 200-day SMA, in particular, is widely regarded by institutional investors as a benchmark for determining whether a market is in a long-term bull or bear phase.

### Common Trading Interpretations
Traders typically utilize the SMA in three primary ways:

1.  **Trend Identification:** If the price is trading above the SMA, the trend is considered bullish; if the price is below the SMA, the trend is considered bearish.
2.  **Support and Resistance:** In trending markets, the SMA often acts as a dynamic level of support or resistance. For example, in a strong uptrend, prices may pull back to the 50-day SMA and bounce, treating it as a floor.
3.  **Crossovers:** Traders look for "crossovers" to signal shifts in momentum. 
    * A **Golden Cross** occurs when a short-term SMA (e.g., 50-day) crosses above a long-term SMA (e.g., 200-day), signaling a potential long-term bullish reversal.
    * A **Death Cross** occurs when a short-term SMA crosses below a long-term SMA, signaling a potential long-term bearish reversal.

### Limitations and Failures
The primary weakness of the SMA is its **lagging nature**. Because it is based on historical data, the SMA cannot predict future price movements; it can only confirm trends that have already begun. This lag can result in "whipsaws"—false signals that occur when the price oscillates around the SMA in a sideways or range-bound market. In non-trending, choppy markets, the SMA loses its predictive utility and can lead to frequent, unprofitable entries and exits.

## Text Formula
The Simple Moving Average for a given period `n` is calculated as:

`SMA = (P1 + P2 + ... + Pn) / n`

Where:
* `P` is the closing price of the asset.
* `n` is the number of periods in the moving average.

## Python Code
```python
import pandas as pd

def calculate_sma(df, periods=[20, 50, 200]):
    """
    Calculates the Simple Moving Average (SMA) for specified periods.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame containing at least:
                       'symbol' (str), 'date' (datetime), 'close' (float)
    periods (list of int): List of window sizes for the SMA calculation.
    
    Returns:
    pd.DataFrame: The original DataFrame with new columns for each SMA period.
    """
    
    # Ensure the dataframe is sorted by symbol and date to maintain 
    # chronological integrity during the rolling calculation.
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Group by 'symbol' to ensure the moving average does not 
    # bleed data from one asset into another.
    grouped = df.groupby('symbol')['close']
    
    for n in periods:
        column_name = f'sma_{n}'
        # Calculate the rolling mean for the specified period
        df[column_name] = grouped.transform(lambda x: x.rolling(window=n).mean())
        
    return df

# Required Input Format Documentation:
# The input DataFrame 'df' must contain the following columns:
# - symbol: The ticker or identifier for the asset (e.g., 'AAPL')
# - date: The timestamp for the price data
# - open: The opening price
# - high: The highest price during the period
# - low: The lowest price during the period
# - close: The closing price used for the SMA calculation
```
```json
{ "model_code": "s3lr8jk7nbm5", "topic": "Simple Moving Average", "timer_secs": 66.53, "tokens_in": 561, "tokens_out": 996, "cost_tokens_in": 0.00003366, "cost_tokens_out": 0.00032868, "cost_tokens_tot": 0.00036234 }
```