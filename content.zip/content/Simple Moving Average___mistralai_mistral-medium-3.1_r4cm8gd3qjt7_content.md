# Simple Moving Average (SMA)

## Overview
The **Simple Moving Average (SMA)** is a foundational technical indicator that smooths price data by calculating the average closing price over a specified number of periods (`n`). It appears on charts as a single line that lags behind price action, helping traders identify trends by filtering out short-term volatility. The SMA is one of the oldest and most widely used indicators, with origins tracing back to early 20th-century market analysis. Its simplicity makes it a staple for trend-following strategies, though its lagging nature means it often confirms trends rather than predicts them.

---

## Details

### **How the SMA Works**
The SMA is calculated by summing the closing prices over `n` periods and dividing by `n`. Each new data point drops the oldest price in the series and adds the latest, creating a "moving" average. The result is a line that:
- **Rises** when prices are trending upward over the lookback period.
- **Falls** when prices are trending downward.
- **Flattens** during sideways or choppy markets.

### **Common Interpretations**
Traders use the SMA in several ways:
1. **Trend Identification**:
   - Price above SMA: Uptrend (bullish bias).
   - Price below SMA: Downtrend (bearish bias).
   - The steeper the SMA’s slope, the stronger the trend.

2. **Support/Resistance**:
   - In uptrends, the SMA often acts as dynamic support (price bounces off it).
   - In downtrends, it acts as dynamic resistance (price rejects at the SMA).
   - Breaks above/below the SMA can signal potential reversals.

3. **Crossovers**:
   - **Price vs. SMA**: A close above the SMA may signal a buy; a close below, a sell.
   - **SMA Crossover**: A shorter-term SMA (e.g., 50-day) crossing above a longer-term SMA (e.g., 200-day) generates a "golden cross" (bullish). The inverse is a "death cross" (bearish).

4. **Multiple SMAs**:
   - Combining SMAs of different lengths (e.g., 10-day, 50-day, 200-day) helps gauge trend strength and duration. Parallel, upward-sloping SMAs suggest a strong uptrend; converging or flat SMAs suggest weakness.

### **Limitations**
- **Lag**: The SMA is inherently reactive. A 200-day SMA, for example, reflects the past 200 days and will always trail the current price.
- **Whipsaws**: In ranging markets, price may oscillate around the SMA, generating false signals.
- **No Volatility Context**: The SMA doesn’t account for volatility. A sharp price drop will impact the SMA the same as a gradual decline, even though the market dynamics differ.
- **Fixed Lookback**: The SMA gives equal weight to all `n` periods, ignoring recent price action’s potential importance (addressed by the *Exponential Moving Average*, or EMA).

### **Practical Adjustments**
- **Period Selection**: Shorter SMAs (e.g., 10–20 periods) react faster but are noisier; longer SMAs (e.g., 50–200 periods) are smoother but lag more. Common defaults:
  - *Short-term*: 10, 20.
  - *Medium-term*: 50.
  - *Long-term*: 100, 200.
- **Timeframe Alignment**: Use daily SMAs for swing trading, hourly SMAs for intraday, etc. The "200-day SMA" is iconic for institutional trend analysis.
- **Combination with Other Tools**: Pair the SMA with momentum indicators (e.g., RSI) or volume analysis to filter signals.

---

## Text Formula
The SMA for a given period `n` at time `t` is calculated as:

```
SMA(t) = (P(t) + P(t-1) + P(t-2) + ... + P(t-n+1)) / n
```

Where:
- `P(t)` = Closing price at time `t`.
- `n` = Number of periods in the lookback window.

For a rolling calculation (e.g., updating the SMA each day):
```
SMA(t) = SMA(t-1) + (P(t) - P(t-n)) / n
```
*(This recursive form is computationally efficient but requires storing the prior SMA value.)*

---

## Python Code
```python
import pandas as pd

def calculate_sma(data, n=20, price_col='close'):
    """
    Calculate Simple Moving Average (SMA) for one or more symbols.

    Parameters:
    -----------
    data : pandas.DataFrame
        Must contain columns: `symbol`, `date`, `open`, `high`, `low`, `close`.
        Assumes data is sorted by `symbol` and `date` in ascending order.
    n : int, optional
        Lookback period for SMA (default: 20).
    price_col : str, optional
        Column name for price data (default: 'close').

    Returns:
    --------
    pandas.DataFrame
        Original DataFrame with added column `sma_{n}` for each symbol.
        Example: If n=20, the column will be `sma_20`.
    """
    # Validate input
    required_cols = {'symbol', 'date', 'open', 'high', 'low', 'close'}
    if not required_cols.issubset(data.columns):
        raise ValueError(f"Data must contain columns: {required_cols}")

    if n <= 0:
        raise ValueError("Lookback period `n` must be > 0")

    # Calculate SMA for each symbol
    data['sma'] = data.groupby('symbol')[price_col].transform(
        lambda x: x.rolling(window=n, min_periods=1).mean()
    )

    # Rename column to include the period (e.g., sma_20)
    data.rename(columns={'sma': f'sma_{n}'}, inplace=True)

    return data
```

### **Usage Example**
```python
# Assume `df` is a DataFrame with columns: symbol, date, open, high, low, close
df = calculate_sma(df, n=50)  # Adds `sma_50` column for each symbol
```
```json
{ "model_code": "r4cm8gd3qjt7", "topic": "Simple Moving Average", "timer_secs": 15.74, "tokens_in": 569, "tokens_out": 1391, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00278200, "cost_tokens_tot": 0.00300960 }
```