# Clenow Momentum

## Overview
Clenow Momentum is a simple yet powerful momentum indicator created by John Clenow, the author of *The Complete TurtleTrader*. It measures the relative price change over a fixed look‑back period and is often plotted as a separate pane beneath the price chart. The indicator is essentially a Rate‑of‑Change (ROC) calculation, but it is favored by trend‑following traders for its clarity and ease of use. Clenow introduced the concept in the 1980s as part of the Turtle Trading system, which has since become a staple in systematic trading literature.

## Details
### Calculation
The indicator is calculated by comparing the current close to the close `n` periods ago:

```
Momentum_t = (Close_t / Close_{t-n}) – 1
```

or, equivalently,

```
Momentum_t = (Close_t – Close_{t-n}) / Close_{t-n}
```

Multiplying by 100 converts the result to a percentage, which is the form most traders use. The look‑back period `n` is typically 20 days, but can be adjusted to match the trader’s time horizon or market volatility.

### Interpretation
- **Positive values** indicate that the price has risen relative to `n` periods ago; the larger the value, the stronger the upward momentum.
- **Negative values** signal a decline; the more negative, the stronger the downward momentum.
- Traders often set **thresholds** to filter noise:
  - `> 2 %` → strong bullish momentum
  - `< –2 %` → strong bearish momentum
  - `|Momentum| < 0.5 %` → weak or consolidating market

These thresholds are not hard rules; they are guidelines that traders adjust based on market context and risk tolerance.

### Common Uses
1. **Trend Confirmation**  
   When a price breakout occurs, a rising Clenow Momentum line confirms that the move is sustained. A declining momentum line can signal a false breakout or a reversal.

2. **Entry and Exit Timing**  
   Traders may enter a long position when momentum turns positive after a period of consolidation, and exit when it turns negative.

3. **Position Sizing**  
   In the Turtle system, the Clenow factor (often 1.5) is used with the Average True Range (ATR) to determine position size. While the factor itself is separate from the momentum calculation, the momentum line helps gauge whether the market is suitable for a new position.

4. **Risk Management**  
   A sudden drop in momentum can prompt a trader to tighten stops or reduce exposure, anticipating a potential reversal.

### Limitations and Where It Breaks Down
- **Sideways Markets**  
  In choppy or range‑bound markets, momentum oscillates around zero, producing many false signals. Traders may need to combine the indicator with a trend filter (e.g., moving averages) to avoid whipsaws.

- **High Volatility**  
  In markets with extreme volatility, a single large price move can inflate momentum, masking the underlying trend. Using a longer look‑back period or smoothing the indicator can mitigate this.

- **Low Liquidity**  
  Thin markets can generate spurious momentum spikes due to large, infrequent trades. In such cases, the indicator’s reliability diminishes.

- **Lag**  
  Like all lagging indicators, Clenow Momentum reacts after the price move has already occurred. It is best used in conjunction with leading signals or fundamental catalysts.

- **Parameter Sensitivity**  
  The choice of `n` heavily influences the indicator’s responsiveness. A period that works well in one market may be too slow or too fast in another. Traders should backtest different look‑back lengths to find the optimal setting for their strategy.

## Text Formula
```
Clenow Momentum (raw)   = (Close_t / Close_{t-n}) – 1
Clenow Momentum (percent) = ((Close_t / Close_{t-n}) – 1) × 100
```
Where:
- `Close_t` is the current period’s closing price.
- `Close_{t-n}` is the closing price `n` periods ago.
- `n` is the look‑back period (commonly 20).

## Python Code
```python
import pandas as pd

def calculate_clenow_momentum(df, period=20):
    """
    Calculate Clenow Momentum for each symbol in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'open', 'high', 'low', 'close'.
    period : int, default 20
        Look‑back period used in the momentum calculation.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with two new columns:
        - 'clenow_momentum' : raw momentum (close_t / close_{t-period} - 1)
        - 'clenow_momentum_pct' : momentum expressed as a percentage
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(['symbol', 'date'])

    # Compute the momentum
    df['clenow_momentum'] = df.groupby('symbol')['close'].transform(
        lambda x: (x / x.shift(period)) - 1
    )

    # Percentage form
    df['clenow_momentum_pct'] = df['clenow_momentum'] * 100

    return df
```
```json
{ "model_code": "b3kp9vwx2mft", "topic": "Clenow Momentum", "timer_secs": 43.36, "tokens_in": 608, "tokens_out": 2467, "cost_tokens_in": 0.00001763, "cost_tokens_out": 0.00034538, "cost_tokens_tot": 0.00036301 }
```