# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based technical analysis indicator consisting of three overlaid lines on a price chart. The middle band is a simple moving average (SMA) of the asset’s `close` price, while the upper and lower bands are set a fixed number of standard deviations above and below the middle band. Developed by chartered financial analyst John Bollinger in the early 1980s, the indicator was formally published in 1992 and remains a widely used tool for assessing volatility, potential reversal points, and trend strength.

## Details

### Core Mechanics
Bollinger Bands are volatility-adjusted envelope indicators. The three bands are mathematically derived from the asset’s recent `close` price action, with no subjective input from the trader beyond parameter selection. The default configuration uses a 20-period SMA for the middle band and sets the upper and lower bands 2 population standard deviations away from the middle band.

Standard deviation measures the dispersion of price data around the mean: higher standard deviation indicates wider price swings (higher volatility), while lower standard deviation indicates tighter price consolidation (lower volatility). As volatility rises, the upper and lower bands expand away from the middle band; as volatility falls, the bands contract toward the middle band. This dynamic adjustment is the indicator’s core utility, as it adapts to changing market conditions rather than using fixed percentage envelopes (e.g., 5% above/below a moving average) that do not account for volatility shifts.

Traders may adjust two key parameters to suit their strategy or asset class:
- Lookback period (n): Shorter periods (e.g., 10) make bands more sensitive to recent price changes; longer periods (e.g., 50) smooth out noise but increase lag.
- Standard deviation multiplier (k): Lower multipliers (e.g., 1.5) produce tighter bands that generate more frequent signals; higher multipliers (e.g., 2.5) produce wider bands that filter out minor volatility.

### Common Trading Interpretations
Three primary signals are associated with Bollinger Bands:

1. **The Squeeze**: When the upper and lower bands contract to a historically narrow width relative to the asset’s prior band spread, it signals a period of abnormally low volatility. This is often interpreted as a precursor to a high-volatility breakout, as markets tend to alternate between low-volatility consolidation and high-volatility trending phases. Traders typically wait for a clear break above the upper band or below the lower band on high volume to confirm the breakout direction.
2. **Band Touches and Reversion**: In rangebound, non-trending markets, price often reverts to the middle band after touching an outer band. A touch of the upper band is interpreted as a short-term overbought signal, while a touch of the lower band is interpreted as oversold. This is often called the **Bollinger Bounce**.
3. **Walking the Band**: In strong trending markets, price may hug the upper band during uptrends or the lower band during downtrends for extended periods. This "walking" indicates sustained momentum, and counter-trend trades based on overbought/oversold signals will often result in losses. Traders use the middle band as a dynamic trailing stop in these scenarios: for uptrends, the middle band acts as support; for downtrends, it acts as resistance.

A derived metric called **%B** quantifies price position relative to the bands, calculated as (`close` - lower band) / (upper band - lower band). Values above 1 indicate price is above the upper band; values below 0 indicate price is below the lower band; values between 0 and 1 indicate price is between the bands. %B is used to standardize band signals across assets with different price scales, avoiding the bias of absolute price levels.

### Limitations and Misinterpretations
Bollinger Bands are not predictive, and their signals are frequently misinterpreted:
- **False Squeezes**: Not all band contractions lead to sustained breakouts. Low-volatility periods can persist for weeks or months, especially in large-cap equities during low-volume summer trading. Traders should confirm squeeze breakouts with volume or momentum indicators to avoid false signals.
- **Normal Distribution Assumption**: Bollinger Bands assume price returns follow a normal distribution, where 95% of values fall within 2 standard deviations of the mean. In reality, financial returns have fat tails (leptokurtosis), meaning extreme price moves occur far more frequently than a normal distribution predicts. For this reason, band touches are more common than expected, and overbought/oversold signals are less reliable in volatile assets like crypto or small-cap stocks.
- **Trend vs. Range Mismatch**: The Bollinger Bounce (reversion to middle band) only applies in rangebound markets. Applying this strategy in trending markets will result in repeated stop-outs as price walks the outer band. Traders should first identify market regime (trending vs. ranging) using tools like the Average Directional Index (ADX) before acting on band signals.
- **Lag**: The middle band is a simple moving average, which is a lagging indicator. During sudden volatility shocks (e.g., earnings gaps, geopolitical events), the bands will not adjust immediately, leading to delayed signals.

## Text Formula
Bollinger Bands use two user-defined parameters:
- n: Lookback period for the simple moving average and standard deviation (default 20)
- k: Number of standard deviations to offset the upper and lower bands (default 2)

All calculations use the `close` column value of the asset over the prior n periods. The population standard deviation (divided by n, not n-1) is used for all volatility calculations, per the indicator’s original specification.

1. Middle Band (MB) = n-period Simple Moving Average of Close
   MB = (C₁ + C₂ + ... + Cₙ) / n

2. Standard Deviation (SD) = Population standard deviation of Close over n periods
   SD = √[ ( (C₁ - MB)² + (C₂ - MB)² + ... + (Cₙ - MB)² ) / n ]

3. Upper Band (UB) = MB + (k * SD)

4. Lower Band (LB) = MB - (k * SD)

5. %B (derived metric) = (Current Close - LB) / (UB - LB)

Optional adjustments to parameters are common: shorter n values increase band sensitivity, while larger k values widen the bands to filter out minor volatility.

## Python Code
The following function calculates Bollinger Bands and %B for a DataFrame containing one or more symbols, grouped to ensure independent calculation per symbol.

```python
import pandas as pd
import numpy as np

def calculate_bollinger_bands(df, n=20, k=2):
    """
    Calculate Bollinger Bands and %B for a DataFrame of price data with one or more symbols.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame with columns: `symbol`, `date`, `open`, `high`, `low`, `close`
    n (int): Lookback period for SMA and standard deviation (default 20)
    k (float): Number of standard deviations for band offset (default 2)
    
    Returns:
    pd.DataFrame: Original DataFrame with added columns: `bb_middle`, `bb_std`, `bb_upper`, `bb_lower`, `bb_percent_b`
    """
    # Avoid modifying the original input DataFrame
    df = df.copy()
    
    def compute_bands(group, n, k):
        # Ensure chronological order for accurate rolling calculations
        group = group.sort_values('date')
        # Middle band: n-period SMA of close
        group['bb_middle'] = group['close'].rolling(window=n, min_periods=n).mean()
        # Standard deviation: population (ddof=0) over n periods per original specification
        group['bb_std'] = group['close'].rolling(window=n, min_periods=n).std(ddof=0)
        # Upper and lower bands
        group['bb_upper'] = group['bb_middle'] + (k * group['bb_std'])
        group['bb_lower'] = group['bb_middle'] - (k * group['bb_std'])
        # %B derived metric
        group['bb_percent_b'] = (group['close'] - group['bb_lower']) / (group['bb_upper'] - group['bb_lower'])
        return group
    
    # Apply band calculation to each symbol independently
    df = df.groupby('symbol', group_keys=False).apply(lambda x: compute_bands(x, n, k))
    
    return df
```
```json
{ "model_code": "gt4ov003vwua", "topic": "Bollinger Bands", "timer_secs": 103.18, "tokens_in": 565, "tokens_out": 9177, "cost_tokens_in": 0.00003560, "cost_tokens_out": 0.00192717, "cost_tokens_tot": 0.00196276 }
```