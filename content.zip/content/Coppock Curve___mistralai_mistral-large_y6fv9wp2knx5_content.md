# Coppock Curve

## Overview

The Coppock Curve is a long-term momentum indicator designed to identify major bottoms in stock market indexes. Developed by economist Edwin Coppock in 1962 and first published in *Barron's*, the indicator appears as a smoothed line plotted below price charts. It combines rate-of-change calculations with a weighted moving average to generate buy signals when the curve turns upward from negative territory. While originally intended for monthly data on broad market indexes like the S&P 500, traders have adapted the Coppock Curve for use on individual securities and shorter timeframes.

## Details

The Coppock Curve is built on two core ideas: (1) major market bottoms are emotional events that produce sharp, sustained reversals, and (2) these reversals can be detected by combining short- and long-term momentum. The indicator uses a 14-period rate of change (ROC) for short-term momentum and an 11-period ROC for long-term momentum, then applies a 10-period weighted moving average (WMA) to smooth the sum. The result is a single line that oscillates above and below zero.

Traders typically interpret the Coppock Curve as follows:
- A buy signal occurs when the curve turns upward from below zero, suggesting the downtrend has exhausted and a new uptrend may begin.
- The curve rising above zero reinforces the bullish signal, while falling below zero suggests weakening momentum.
- Because the indicator is designed for long-term analysis, signals are rare—often only a few per decade on monthly charts.

The Coppock Curve has several limitations:
- **Lag**: The 10-period WMA introduces significant lag, meaning signals often appear well after the actual market bottom.
- **False signals**: In choppy or sideways markets, the curve may generate whipsaws—brief upward turns that fail to sustain.
- **Index focus**: The indicator was designed for broad market indexes, not individual stocks, where volatility can distort signals.
- **No sell signals**: The Coppock Curve is a one-way indicator; it does not identify market tops or sell conditions.

Despite these drawbacks, the Coppock Curve remains popular among long-term investors and market historians for its simplicity and historical reliability in spotting major market lows.

## Text Formula

The Coppock Curve is calculated in three steps:

1. Calculate the 14-period rate of change (ROC₁₄) and 11-period rate of change (ROC₁₁) of the closing price:
   ```
   ROC₁₄ = (Close_t / Close_t₋₁₄ - 1) × 100
   ROC₁₁ = (Close_t / Close_t₋₁₁ - 1) × 100
   ```

2. Sum the two ROC values:
   ```
   Coppock Raw = ROC₁₄ + ROC₁₁
   ```

3. Apply a 10-period weighted moving average (WMA) to the raw sum:
   ```
   Coppock Curve = WMA₁₀(Coppock Raw)
   ```
   Where the WMA is calculated as:
   ```
   WMA = (n × P₀ + (n-1) × P₋₁ + ... + 1 × P₋(n-1)) / (n + (n-1) + ... + 1)
   ```
   For a 10-period WMA, the denominator is 55 (10 + 9 + ... + 1).

## Python Code

```python
import pandas as pd

def calculate_coppock_curve(df):
    """
    Calculate the Coppock Curve for a DataFrame containing OHLCV data.

    Parameters:
    df (pd.DataFrame): DataFrame with columns: symbol, date, open, high, low, close.
                       Must be sorted by symbol and date.

    Returns:
    pd.DataFrame: Original DataFrame with added 'coppock_raw' and 'coppock_curve' columns.
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Calculate 14-period and 11-period rate of change (ROC)
    df['roc_14'] = df.groupby('symbol')['close'].pct_change(14) * 100
    df['roc_11'] = df.groupby('symbol')['close'].pct_change(11) * 100

    # Sum the ROC values to get the raw Coppock value
    df['coppock_raw'] = df['roc_14'] + df['roc_11']

    # Calculate 10-period weighted moving average (WMA) for each symbol
    def wma(series, period=10):
        weights = pd.Series(range(1, period + 1))
        return series.rolling(period).apply(lambda x: (x * weights).sum() / weights.sum(), raw=True)

    df['coppock_curve'] = df.groupby('symbol')['coppock_raw'].transform(lambda x: wma(x, 10))

    # Drop intermediate columns if not needed
    df = df.drop(columns=['roc_14', 'roc_11', 'coppock_raw'], errors='ignore')

    return df
```

The function `calculate_coppock_curve` processes each symbol independently, ensuring calculations are not contaminated by data from other securities. The output DataFrame includes the final `coppock_curve` column, which can be plotted or used for signal generation. For monthly data, the curve will typically produce a smooth line with infrequent but potentially significant buy signals.
```json
{ "model_code": "y6fv9wp2knx5", "topic": "Coppock Curve", "timer_secs": 18.64, "tokens_in": 569, "tokens_out": 1211, "cost_tokens_in": 0.00113800, "cost_tokens_out": 0.00726600, "cost_tokens_tot": 0.00840400 }
```