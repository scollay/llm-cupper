# Bollinger Bands

## Overview
Bollinger Bands are a highly popular technical analysis tool designed to measure market volatility and identify potential overbought or oversold conditions. On a price chart, the indicator appears as an overlay consisting of three lines: a central moving average flanked by an upper and a lower band. Created by technical trader John Bollinger in the 1980s, the bands are dynamic; they automatically expand during periods of high market volatility and contract when price action becomes quiet and consolidated. 

## Details
At their core, Bollinger Bands are a visual representation of standard deviation applied to a moving average. Standard deviation is a mathematical measure of variance—how far data points stray from the average. By plotting standard deviation bands around a simple moving average, the indicator adapts to the market's natural ebb and flow.

Traders typically apply Bollinger Bands to identify volatility cycles, spot potential trend reversals, and clarify pure price patterns. 

**The Squeeze and Volatility Cycles**
Markets naturally alternate between periods of low volatility and high volatility. When the upper and lower bands contract tightly around the price, it indicates a period of extreme quiet known as a "squeeze." Active traders monitor the squeeze closely because historically, low volatility is the precursor to an explosive directional breakout. While the squeeze warns that a major move is imminent, it does not predict the direction of the breakout. Traders must wait for the price to pierce a band on heavy volume to confirm the new trend's direction.

**Mean Reversion vs. Trend Following**
In a sideways or ranging market, Bollinger Bands act as dynamic support and resistance levels. Prices tend to bounce between the outer bands, making a touch of the lower band a potential oversold buy signal, and a touch of the upper band a potential overbought sell signal. 

However, this interpretation flips during a strong trend. When a market breaks out and establishes a powerful directional move, the price will frequently touch or even exceed the outer bands. This phenomenon is known as "walking the band." In a strong uptrend, the price may repeatedly ride the upper band while the lower band actually turns downward due to the sudden expansion in volatility. 

**Pattern Recognition**
John Bollinger heavily emphasized using the bands to clarify traditional price patterns, specifically "W-bottoms" and "M-tops." 
*   **W-Bottoms:** A classic Bollinger W-bottom occurs when the price makes a first low that touches or penetrates the lower band. The price then bounces toward the middle band, followed by a second low. If this second low holds *above* the lower band—even if it is lower in absolute price than the first low—it signals waning downside momentum and a high-probability reversal.
*   **M-Tops:** Conversely, an M-top forms when a first high pushes outside the upper band, but the subsequent second high fails to reach the upper band, indicating exhausted buying pressure.

**Derived Indicators**
To quantify the visual information provided by the bands, traders use two secondary metrics:
*   **BandWidth:** This measures the absolute distance between the upper and lower bands. It is used to mathematically identify the squeeze rather than relying on visual estimation.
*   **%b (Percent b):** This oscillator plots exactly where the current closing price sits relative to the bands. A value of 1.0 means the price is at the upper band, 0.0 means it is at the lower band, and 0.5 means it is exactly on the middle moving average. Traders use `%b` to program automated trading systems and spot divergences.

**Where the Indicator Breaks Down**
The most common and costly mistake traders make is assuming that a tag of the upper or lower band is an automatic, contrarian trading signal. Because prices can "walk the band" during strong trends, blindly fading a band touch in a trending market will lead to severe drawdowns. 

Furthermore, traders often fall victim to a statistical illusion. In a standard normal distribution, two standard deviations encompass roughly 95% of all data points. Many traders incorrectly assume this means price will stay inside the Bollinger Bands 95% of the time. However, financial markets do not follow a normal distribution; they exhibit "fat tails," meaning extreme price moves happen much more frequently than standard statistics imply. 

Finally, Bollinger Bands are a lagging indicator. Because they are derived from a simple moving average, they react to past price movements rather than predicting future ones. To mitigate false signals, Bollinger Bands should never be used as a standalone trading system. They are best paired with non-correlated indicators, such as momentum oscillators (like the RSI) or volume metrics, to confirm price action.

## Text Formula
The standard Bollinger Bands calculation uses a 20-period lookback and a 2-standard deviation multiplier.

*   **Middle Band:** The 20-period Simple Moving Average (SMA) of the closing price.
    Middle Band = Sum of the closing prices over the last 20 periods / 20

*   **Upper Band:** The Middle Band plus two times the 20-period rolling standard deviation of the closing price.
    Upper Band = Middle Band + (20-period Standard Deviation * 2)

*   **Lower Band:** The Middle Band minus two times the 20-period rolling standard deviation of the closing price.
    Lower Band = Middle Band - (20-period Standard Deviation * 2)

*   **BandWidth:** The normalized width of the bands.
    BandWidth = (Upper Band - Lower Band) / Middle Band

*   **%b (Percent b):** The location of the close relative to the bands.
    %b = (Close - Lower Band) / (Upper Band - Lower Band)

## Python Code
```python
import pandas as pd

def calculate_bollinger_bands(df: pd.DataFrame, period: int = 20, std_dev: float = 2.0) -> pd.DataFrame:
    """
    Calculates Bollinger Bands, BandWidth, and %b for a given DataFrame.
    
    Assumes the input DataFrame contains the following columns:
    - symbol: string identifier for the asset
    - date: datetime or string representing the date
    - open: float
    - high: float
    - low: float
    - close: float
    
    Returns a copy of the DataFrame with new columns:
    - middle_band
    - upper_band
    - lower_band
    - bandwidth
    - percent_b
    """
    # Create a copy to avoid modifying the original dataframe
    result_df = df.copy()
    
    # Sort by symbol and date to ensure accurate rolling calculations
    result_df = result_df.sort_values(by=['symbol', 'date'])
    
    # Calculate the Middle Band (Simple Moving Average)
    result_df['middle_band'] = result_df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=period).mean()
    )
    
    # Calculate the rolling standard deviation.
    # Note: Technical analysis traditionally uses population standard deviation.
    # Pandas uses sample standard deviation (ddof=1) by default. 
    # We set ddof=0 to match standard charting platforms.
    rolling_std = result_df.groupby('symbol')['close'].transform(
        lambda x: x.rolling(window=period).std(ddof=0)
    )
    
    # Calculate Upper and Lower Bands
    result_df['upper_band'] = result_df['middle_band'] + (rolling_std * std_dev)
    result_df['lower_band'] = result_df['middle_band'] - (rolling_std * std_dev)
    
    # Calculate BandWidth
    result_df['bandwidth'] = (result_df['upper_band'] - result_df['lower_band']) / result_df['middle_band']
    
    # Calculate %b (Percent b)
    band_spread = result_df['upper_band'] - result_df['lower_band']
    result_df['percent_b'] = (result_df['close'] - result_df['lower_band']) / band_spread
    
    return result_df
```
```json
{ "model_code": "t5pz4nm8vqj7", "topic": "Bollinger Bands", "timer_secs": 41.48, "tokens_in": 564, "tokens_out": 4954, "cost_tokens_in": 0.00112800, "cost_tokens_out": 0.05944800, "cost_tokens_tot": 0.06057600 }
```