# Coppock Curve

## Overview
The Coppock Curve is a long-term momentum indicator designed to identify major bottoms in the stock market. It appears as a single oscillating line plotted below the price chart. Developed by economist Edwin "Sedge" Coppock and first published in *Barron's* in October 1962, the indicator was originally intended to signal buying opportunities in the S&P 500 index. The curve is smoothed and lagging, making it most useful for investors with a multi-month to multi-year horizon rather than short-term traders.

## Details

### Construction
The Coppock Curve is calculated using two rate-of-change (ROC) periods and a weighted moving average. The standard parameters are:
- A **short ROC period** of 11 months.
- A **long ROC period** of 14 months.
- A **weighted moving average (WMA) period** of 10 months.

The indicator sums the ROC values over the two periods and then smooths the result with a 10-month WMA. This combination filters out short-term noise and focuses on longer-term momentum shifts.

### Interpretation
- **Buy Signal**: The Coppock Curve generates a buy signal when it crosses above zero from below. This typically occurs after a prolonged downturn and suggests that a new uptrend may be beginning.
- **Sell Signal**: While the original indicator was not designed for sell signals, some traders use a cross below zero as a warning of weakening momentum. However, the curve is less reliable for timing exits.
- **Magnitude**: The depth of the trough below zero can indicate the severity of the preceding decline. Deeper troughs often precede stronger rallies.

### Limitations
- **Lagging Nature**: Due to its long lookback periods, the Coppock Curve is slow to react. It is not suitable for timing short-term trades.
- **False Signals**: In ranging or choppy markets, the curve can whipsaw around zero, producing false buy or sell signals.
- **Market-Specific**: The indicator was optimized for broad market indices (e.g., S&P 500). Its effectiveness on individual stocks or other asset classes (e.g., commodities, forex) is less established.
- **Secular Trends**: In strong bull markets, the curve may stay positive for extended periods, reducing its utility. Conversely, in prolonged bear markets, it may remain negative.

### Practical Use
Traders often use the Coppock Curve in conjunction with other indicators (e.g., moving averages, trend lines) to confirm signals. It is particularly popular among investors who follow the "buy and hold" strategy but want to avoid major drawdowns by entering after significant declines.

## Text Formula
The Coppock Curve is calculated as follows:

1. Calculate the **11-month rate of change (ROC)**:
   ```
   ROC_11 = (Close_t / Close_{t-11}) * 100 - 100
   ```

2. Calculate the **14-month rate of change (ROC)**:
   ```
   ROC_14 = (Close_t / Close_{t-14}) * 100 - 100
   ```

3. Sum the two ROC values:
   ```
   ROC_Sum = ROC_11 + ROC_14
   ```

4. Apply a **10-month weighted moving average (WMA)** to the sum:
   ```
   Coppock_t = (ROC_Sum_t + (2 * ROC_Sum_{t-1}) + (3 * ROC_Sum_{t-2}) + ... + (10 * ROC_Sum_{t-9})) / (1 + 2 + 3 + ... + 10)
   ```
   The denominator is the sum of the weights (55).

## Python Code
```python
import pandas as pd

def coppock_curve(df, short_roc=11, long_roc=14, wma_period=10):
    """
    Calculate the Coppock Curve for a given DataFrame.

    Parameters:
    - df: Pandas DataFrame with columns: symbol, date, open, high, low, close.
          Must be sorted by symbol and date in ascending order.
    - short_roc: Short ROC period in months (default: 11).
    - long_roc: Long ROC period in months (default: 14).
    - wma_period: WMA smoothing period in months (default: 10).

    Returns:
    - DataFrame with original columns plus a new column `coppock`.
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Calculate ROC for each period
    df['roc_short'] = (df['close'] / df.groupby('symbol')['close'].shift(short_roc) - 1) * 100
    df['roc_long'] = (df['close'] / df.groupby('symbol')['close'].shift(long_roc) - 1) * 100

    # Sum the ROC values
    df['roc_sum'] = df['roc_short'] + df['roc_long']

    # Calculate the 10-month WMA of the ROC sum
    # Weights are 1, 2, 3, ..., 10 (sum = 55)
    weights = pd.Series(range(1, wma_period + 1))
    df['coppock'] = (
        df.groupby('symbol')['roc_sum']
        .rolling(window=wma_period)
        .apply(lambda x: (x * weights).sum() / weights.sum(), raw=True)
        .reset_index(level=0, drop=True)
    )

    # Drop intermediate columns
    df = df.drop(columns=['roc_short', 'roc_long', 'roc_sum'])

    return df
```

### Notes on the Code
- The function handles multiple symbols by grouping operations by `symbol`.
- The DataFrame must be sorted by `symbol` and `date` before processing.
- The WMA is calculated using a rolling window with linearly increasing weights.
- Intermediate columns (`roc_short`, `roc_long`, `roc_sum`) are dropped from the final output.
- The default parameters match the original Coppock Curve specification (11, 14, 10). Adjust these for experimentation.
```json
{ "model_code": "q5w5k99bpbzx", "topic": "Coppock Curve", "timer_secs": 17.15, "tokens_in": 569, "tokens_out": 1345, "cost_tokens_in": 0.00022760, "cost_tokens_out": 0.00269000, "cost_tokens_tot": 0.00291760 }
```