# T3 (Tillson's T3 Moving Average)

## Overview
The **T3** is a smoothed moving average developed by **Tim Tillson** in 1998 as an improvement over traditional exponential moving averages (EMAs). It appears on charts as a single, fluid line that adapts to price action with minimal lag while filtering out noise. Unlike standard EMAs, T3 uses a **volume factor** (`vf`) to control responsiveness and applies a **triple-smoothing** process, making it highly effective for trend identification in volatile markets. Traders often use T3 to spot trend direction, dynamic support/resistance, and potential reversals when price crosses the line.

---

## Details

### How T3 Works
T3 is a **recursive, weighted moving average** that iteratively smooths price data through multiple passes. Key features:
- **Volume Factor (`vf`)**: A user-defined parameter (typically between `0.618` and `0.7`) that balances smoothness and responsiveness. Higher values reduce lag but increase noise; lower values increase smoothness but add lag.
- **Triple Smoothing**: The indicator applies a modified EMA-like calculation **three times** to the price series, with each pass using a dynamically adjusted smoothing factor derived from `vf`.
- **Adaptive Lag Reduction**: The triple-smoothing process effectively reduces lag compared to a single EMA of the same period, while avoiding the whipsaws of shorter-term averages.

### Interpretation
Traders use T3 in three primary ways:
1. **Trend Identification**:
   - Price above T3 → **Uptrend** (look for long entries on pullbacks to the line).
   - Price below T3 → **Downtrend** (look for short entries on rallies to the line).
   - *Caveat*: In ranging markets, T3 can generate false signals as price oscillates around the line.

2. **Dynamic Support/Resistance**:
   - The T3 line often acts as a magnet for price in trending markets. Bounces off the line can signal continuation, while breaks may indicate reversals.
   - *Breakdown*: In strong momentum moves (e.g., news-driven gaps), price may ignore the T3 line entirely.

3. **Crossovers**:
   - **Price vs. T3**: A close above/below the T3 line can trigger entries, but works best when aligned with higher-timeframe trends.
   - **Dual T3 Cross**: Using two T3s (e.g., fast `vf=0.7` and slow `vf=0.618`) to generate cross signals, similar to a MACD crossover.
   - *Limitation*: Crossovers lag in fast markets and may require additional filters (e.g., volume or momentum confirmation).

### Strengths and Weaknesses
**Advantages**:
- Smoother than EMAs with less lag than SMAs.
- Adapts to volatility without arbitrary period adjustments.
- Works across all timeframes (scalping to swing trading).

**Weaknesses**:
- **Parameter Sensitivity**: Poor `vf` choices (e.g., `>0.8`) introduce noise; values `<0.5` create excessive lag.
- **Range-Bound Whipsaws**: Struggles in choppy, non-trending markets.
- **Lookback Bias**: Like all moving averages, it reacts to past prices and cannot predict reversals.

### Optimal Parameters
- **Default `vf`**: `0.7` (balanced for most markets).
- **Aggressive Trading**: `vf=0.75–0.8` (shorter-term, higher noise).
- **Swing Trading**: `vf=0.618–0.65` (smoother, less sensitive).
- **Period**: Typically applied to `close` prices, but can use `hl2` (`(high + low)/2`) for additional smoothing.

---

## Text Formula
The T3 calculation involves three iterative smoothing steps. Let:
- `price[t]` = Current price (e.g., `close`).
- `vf` = Volume factor (`0 < vf ≤ 1`).
- `n` = Number of smoothing passes (fixed at `3` for T3).

**Step 1: Calculate the smoothing factor (`a`)**
```
a = 2 / (1 + vf)
```

**Step 2: First Smoothing Pass (EMA-like)**
```
e1[t] = a * price[t] + (1 - a) * e1[t-1]
```
*Initialize* `e1[0] = price[0]`.

**Step 3: Second Smoothing Pass**
```
e2[t] = a * e1[t] + (1 - a) * e2[t-1]
```
*Initialize* `e2[0] = e1[0]`.

**Step 4: Third Smoothing Pass**
```
e3[t] = a * e2[t] + (1 - a) * e3[t-1]
```
*Initialize* `e3[0] = e2[0]`.

**Step 5: Final T3 Output**
The T3 value is a weighted combination of the three smoothing passes:
```
T3[t] = (1 - c1) * e1[t] + c1 * (1 - c2) * e2[t] + c1 * c2 * e3[t]
```
Where:
```
c1 = - (vf^2 * (1.5 * vf - 2.5) + 1)
c2 = 2 * vf^2
```
*Note*: `c1` and `c2` are derived to optimize the lag reduction.

---

## Python Code
```python
import pandas as pd

def calculate_t3(data, vf=0.7, price_col='close'):
    """
    Calculate Tillson's T3 Moving Average for one or more symbols in a DataFrame.

    Parameters:
    - data: Pandas DataFrame with columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
    - vf: Volume factor (0 < vf ≤ 1). Default = 0.7.
    - price_col: Column to use for price input ('close', 'hl2', etc.). Default = 'close'.

    Returns:
    - DataFrame with original data + new column 't3'.
    """
    if price_col == 'hl2':
        data = data.assign(hl2=(data['high'] + data['low']) / 2)
        price_col = 'hl2'

    # Calculate smoothing factor
    a = 2 / (1 + vf)

    # Coefficients for final T3 combination
    c1 = - (vf**2 * (1.5 * vf - 2.5) + 1)
    c2 = 2 * vf**2

    # Initialize output column
    data['t3'] = pd.NA

    # Process each symbol independently
    for symbol in data['symbol'].unique():
        symbol_data = data[data['symbol'] == symbol].copy()
        price = symbol_data[price_col].values

        # Initialize smoothing arrays
        e1 = pd.Series(index=symbol_data.index, dtype='float64')
        e2 = pd.Series(index=symbol_data.index, dtype='float64')
        e3 = pd.Series(index=symbol_data.index, dtype='float64')

        # First pass (e1)
        e1.iloc[0] = price[0]
        for i in range(1, len(price)):
            e1.iloc[i] = a * price[i] + (1 - a) * e1.iloc[i-1]

        # Second pass (e2)
        e2.iloc[0] = e1.iloc[0]
        for i in range(1, len(price)):
            e2.iloc[i] = a * e1.iloc[i] + (1 - a) * e2.iloc[i-1]

        # Third pass (e3)
        e3.iloc[0] = e2.iloc[0]
        for i in range(1, len(price)):
            e3.iloc[i] = a * e2.iloc[i] + (1 - a) * e3.iloc[i-1]

        # Combine into T3
        t3 = (1 - c1) * e1 + c1 * (1 - c2) * e2 + c1 * c2 * e3
        data.loc[symbol_data.index, 't3'] = t3

    return data
```

### Usage Example
```python
# Example DataFrame structure (do not run; illustrative only):
# df = pd.DataFrame({
#     'symbol': ['AAPL', 'AAPL', 'MSFT', 'MSFT'],
#     'date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-01', '2023-01-02']),
#     'open': [150, 152, 250, 248],
#     'high': [155, 153, 255, 250],
#     'low': [149, 150, 245, 247],
#     'close': [152, 151, 252, 249]
# })

# df_with_t3 = calculate_t3(df, vf=0.7)
```
```json
{ "model_code": "r4cm8gd3qjt7", "topic": "T3", "timer_secs": 23.69, "tokens_in": 568, "tokens_out": 2072, "cost_tokens_in": 0.00022720, "cost_tokens_out": 0.00414400, "cost_tokens_tot": 0.00437120 }
```