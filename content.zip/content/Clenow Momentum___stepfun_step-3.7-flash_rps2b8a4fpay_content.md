# Clenow Momentum

## Overview
Clenow Momentum is a trend-following momentum indicator designed to identify assets with strong, persistent positive price momentum, developed by quantitative analyst Andreas Clenow and first introduced in his 2013 book *Stocks on the Move*. On a chart, it appears as a single line plotted below the price series, with a horizontal zero line serving as a baseline for interpretation. It is primarily used by active traders to screen for assets that are outperforming the broader market, rather than to time short-term overbought or oversold conditions.

## Details
### Core Calculation Logic
Clenow Momentum is built on the principle that sustained, linear price trends are more predictive of future outperformance than short-term volatile moves. To calculate it:
1. First, the natural logarithm of each closing price in a fixed lookback window (standard length = 90 trading days, or ~4.5 months) is taken to normalize multiplicative price changes into additive log returns.
2. A simple linear regression is run on these log prices against a sequential time index (1 for the oldest day in the window, 90 for the most recent) to derive two key values:
   - The slope of the regression line, which represents the average daily log return over the lookback period
   - The R-squared (R²) of the regression, which measures how much of the total price movement in the window is explained by the linear trend (higher R² = more consistent, less noisy trend)
3. The daily slope is annualized using the standard 252 trading days per year, then multiplied by the R² to produce the final Clenow Momentum score.

### Typical Trader Interpretation
Unlike oscillators such as the RSI, Clenow Momentum is not used to identify overbought or oversold conditions. Instead, it is almost exclusively used for cross-sectional ranking of assets:
- A positive Clenow Momentum score indicates the asset has a positive annualized trend, with higher scores signaling stronger, more consistent upward momentum.
- Traders typically screen for assets in the top decile or quintile of Clenow Momentum scores to identify candidates for long positions, while avoiding assets with negative or near-zero scores.
- Some traders add a secondary confirmation layer by plotting a short-term (e.g., 20-day) moving average of the Clenow Momentum line: a cross of the CM line above its moving average signals strengthening momentum, while a cross below signals weakening momentum and a potential exit trigger.

### Limitations and Signal Breakdowns
Clenow Momentum has well-documented weaknesses that traders must account for:
- **Lagging nature**: The 90-day lookback means the indicator confirms a trend only after it has already been in place for months, leading to late entry and exit signals. Assets that peak and reverse quickly will still show positive CM scores for weeks after the peak, as the lookback window still includes the prior uptrend.
- **Poor performance in sideways markets**: In choppy, range-bound markets, even small positive slopes will produce positive CM scores if R² is high enough, leading to false trend signals. The R² filter reduces but does not eliminate this risk.
- **No volatility adjustment**: The raw CM score does not account for asset volatility, so a high score for a low-volatility utility stock may be less attractive than a slightly lower score for a high-volatility growth stock for risk-seeking traders.
- **Lookback period sensitivity**: The standard 90-day window is optimized for US large-cap equities; applying the same window to faster-moving assets like cryptocurrencies or forex pairs will produce overly lagged signals, while slower-moving assets like bonds may require a longer lookback.

## Text Formula
For a given asset and lookback period `N` (standard value = 90 trading days):
1. Let `ln(C_t)` denote the natural logarithm of the closing price on day `t` within the lookback window, where `t = 1` is the oldest day in the window and `t = N` is the most recent day.
2. Run a simple linear regression of `ln(C_t)` against the time index `t`, yielding:
   - `slope`: the regression coefficient for the time variable, representing average daily log return over the window
   - `R²`: the coefficient of determination of the regression, measuring the share of total log price movement explained by the linear time trend
3. Clenow Momentum (CM) is calculated as:
   `CM = slope * 252 * R²`
   where 252 is the standard number of trading days in a year, used to annualize the daily slope.

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df: pd.DataFrame, lookback_period: int = 90) -> pd.DataFrame:
    """
    Calculate Clenow Momentum for a DataFrame of price data.
    
    Parameters:
    -----------
    df : pd.DataFrame
        Input DataFrame with required columns: symbol, date, open, high, low, close
        Can contain data for one or more symbols, with chronological data per symbol.
    lookback_period : int, optional
        Number of trailing trading days to use for the regression, default 90.
    
    Returns:
    --------
    pd.DataFrame
        Original DataFrame with an added 'clenow_momentum' column containing the
        calculated Clenow Momentum value for each row. Rows with insufficient
        historical data for the lookback window will have NaN values.
    """
    # Sort data by symbol and date to ensure chronological order per group
    df = df.sort_values(by=['symbol', 'date']).reset_index(drop=True)
    
    # Helper function to calculate CM for a single window of log close prices
    def _cm_from_window(window: np.ndarray) -> float:
        n = len(window)
        if n < 2:  # Guard against insufficient data for regression
            return np.nan
        # Time index for regression: 1 to n (matches formula definition)
        x = np.arange(1, n + 1)
        y = window
        # Fit linear regression to get slope and intercept
        slope, intercept = np.polyfit(x, y, 1)
        # Calculate predicted values and R-squared
        y_pred = slope * x + intercept
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        # Handle case where all prices in window are identical (no variance)
        r_squared = 0 if ss_tot == 0 else 1 - (ss_res / ss_tot)
        # Annualize slope and adjust for trend consistency via R-squared
        return slope * 252 * r_squared
    
    # Calculate log closing prices for regression
    df['log_close'] = np.log(df['close'])
    
    # Calculate rolling CM per symbol group to avoid cross-symbol data leakage
    df['clenow_momentum'] = df.groupby('symbol')['log_close'].transform(
        lambda x: x.rolling(window=lookback_period, min_periods=lookback_period).apply(
            _cm_from_window, raw=True
        )
    )
    
    # Remove temporary calculation column
    df = df.drop(columns=['log_close'])
    
    return df
```
```json
{ "model_code": "rps2b8a4fpay", "topic": "Clenow Momentum", "timer_secs": 36.17, "tokens_in": 568, "tokens_out": 7656, "cost_tokens_in": 0.00011360, "cost_tokens_out": 0.00880440, "cost_tokens_tot": 0.00891800 }
```