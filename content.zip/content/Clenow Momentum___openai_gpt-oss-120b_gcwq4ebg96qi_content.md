# Clenow Momentum

## Overview
Clenow Momentum is a trend‑following indicator introduced by quantitative trader **Andreas Clenow** in his book *Stocks on the Move*. It visualizes the **annualized slope of a linear regression** fitted to the logarithm of an asset’s price over a configurable look‑back window. On a chart the indicator appears as a smooth line that can be plotted above or below the price series; positive values suggest an upward trend, negative values a downtrend. Because it is based on a regression of log‑prices, the metric is dimensionless and comparable across assets and time‑frames.

## Details
### How the indicator works
1. **Log‑price transformation** – For each bar the close price `C_t` is transformed to `y_t = ln(C_t)`. This converts exponential price moves into linear ones, making a simple regression a reasonable proxy for compound growth.
2. **Rolling regression** – Over a fixed look‑back `N` (commonly 252 trading days, i.e., one year), a **ordinary least‑squares (OLS)** regression is fitted:
   \[
   y_{t-i} = a + b \cdot i,\qquad i = 0,\dots,N-1
   \]
   where `i` is the lag index (0 = most recent bar). The slope `b` captures the average **log‑return per period**.
3. **Annualization** – To express momentum in familiar “percent‑per‑year” terms, the slope is multiplied by the number of periods in a year (`K`). For daily data `K = 252` (trading days) or `365` (calendar days). The resulting value is the **Clenow Momentum**:
   \[
   \text{CM}_t = b \times K
   \]
   Because `b` is a log‑return, `CM_t` approximates the **continuous compounded annual return** implied by the recent price path.

### Typical interpretation
| Momentum value | Interpretation |
|----------------|----------------|
| **CM > 0**     | Recent price path is, on average, increasing; the asset is in an uptrend. |
| **CM < 0**     | Recent price path is decreasing; the asset is in a downtrend. |
| **|CM| > 0.2** (≈ 20 % p.a.) | Strong trend; many systematic strategies treat this as a signal to stay fully invested. |
| **|CM| < 0.05** (≈ 5 % p.a.) | Weak or sideways market; risk‑off or cash allocation may be preferred. |

Traders often combine Clenow Momentum with volatility filters (e.g., ATR) or with a **trend‑strength threshold** to avoid whipsaws. Because the indicator smooths out daily noise, it is well‑suited for **position‑sizing** and **portfolio rotation** rather than high‑frequency entry/exit timing.

### Where interpretation breaks down
- **Short look‑backs**: Using a very small `N` (e.g., 20 days) yields a noisy slope that reacts to intraday spikes, defeating the purpose of a trend‑following metric.
- **Regime shifts**: A sudden market crash can produce a large negative slope that lingers even after the market stabilizes, causing the indicator to stay bearish longer than warranted.
- **Non‑log‑linear moves**: Assets that exhibit abrupt jumps (e.g., crypto or low‑liquidity stocks) may not be well‑approximated by a linear log‑price trend, leading to misleading momentum values.
- **Different trading calendars**: Applying the same annual factor `K` to assets with non‑daily data (e.g., weekly or hourly) without adjusting `K` will distort the magnitude of the momentum reading.

Understanding these limits helps traders use Clenow Momentum as a **guideline** rather than an absolute rule.

## Text Formula
Let  

- `C_t` = close price at time `t`  
- `N` = look‑back window (number of periods)  
- `K` = periods per year (e.g., 252 for daily data)  

Define the log‑price series for the window:

\[
y_i = \ln(C_{t-i}),\qquad i = 0,\dots,N-1
\]

Compute the OLS slope `b`:

\[
b = \frac{N\sum_{i=0}^{N-1} i\,y_i - \left(\sum_{i=0}^{N-1} i\right)\left(\sum_{i=0}^{N-1} y_i\right)}{N\sum_{i=0}^{N-1} i^{2} - \left(\sum_{i=0}^{N-1} i\right)^{2}}
\]

Annualized Clenow Momentum:

\[
\text{CM}_t = b \times K
\]

The indicator value `CM_t` is calculated for each bar `t` where at least `N` prior observations exist.

## Python Code
```python
import numpy as np
import pandas as pd

def clenow_momentum(df: pd.DataFrame,
                    lookback: int = 252,
                    periods_per_year: int = 252,
                    price_col: str = "close") -> pd.DataFrame:
    """
    Calculate Clenow Momentum for each symbol in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input data with columns: ['symbol', 'date', 'open', 'high', 'low', 'close'].
        Must be sorted by ['symbol', 'date'] in ascending order.
    lookback : int, default 252
        Number of periods to use for the rolling regression.
    periods_per_year : int, default 252
        Annualization factor (e.g., trading days per year for daily data).
    price_col : str, default "close"
        Column name containing the price series to use.

    Returns
    -------
    pd.DataFrame
        Original DataFrame with an additional column ``clenow_momentum``.
        NaN values appear for rows where the look‑back window is incomplete.
    """
    # Ensure required columns exist
    required = {"symbol", "date", price_col}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Input DataFrame missing required columns: {missing}")

    # Work on a copy to avoid side‑effects
    df = df.copy()

    # Sort for deterministic rolling calculations
    df.sort_values(["symbol", "date"], inplace=True)

    # Helper: compute slope of log‑price regression for a 1‑D array
    def _slope_log_price(series: np.ndarray) -> float:
        """
        series: array of prices ordered from most recent (index 0) to oldest (index N-1)
        Returns the OLS slope of ln(price) vs lag index.
        """
        # Convert to log‑price
        y = np.log(series)
        # Lag indices: 0, 1, ..., N-1
        x = np.arange(len(y))
        # Use np.polyfit of degree 1 (linear) – returns [slope, intercept]
        slope, _ = np.polyfit(x, y, 1)
        return slope

    # Apply rolling regression per symbol
    def _apply_symbol(group: pd.DataFrame) -> pd.DataFrame:
        # Rolling object on the price column; window includes the current row
        roll = group[price_col].rolling(window=lookback, min_periods=lookback)

        # Compute slope for each window; result aligns with the right edge (current row)
        slopes = roll.apply(_slope_log_price, raw=True)

        # Annualize
        group["clenow_momentum"] = slopes * periods_per_year
        return group

    # Process each symbol independently
    result = df.groupby("symbol", group_keys=False).apply(_apply_symbol)

    return result
```
```json
{ "model_code": "gcwq4ebg96qi", "topic": "Clenow Momentum", "timer_secs": 43.50, "tokens_in": 632, "tokens_out": 2076, "cost_tokens_in": 0.00002465, "cost_tokens_out": 0.00037368, "cost_tokens_tot": 0.00039833 }
```