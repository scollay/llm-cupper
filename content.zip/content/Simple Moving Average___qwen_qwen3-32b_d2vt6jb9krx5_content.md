# Simple Moving Average

## Overview  
The Simple Moving Average (SMA) is a foundational technical indicator that smooths price data by calculating the arithmetic mean of an asset’s price over a defined number of periods. It appears on charts as a single line that shifts upward or downward in response to new price data. SMA is widely used to identify trends, gauge momentum, and pinpoint potential support/resistance levels. While its origins are unclear, it has been a staple in technical analysis since the early 20th century, popularized by pioneers like Charles Dow.

## Details  
The SMA calculates the average closing price of an asset over a specified window (e.g., 10 days, 50 days). As new data becomes available, the oldest data point drops out of the calculation, ensuring the average "moves" with time. Traders use SMA in several ways:  
- **Trend identification**: A rising SMA suggests an uptrend; a falling SMA indicates a downtrend.  
- **Crossovers**: When an asset’s price crosses above its SMA, it may signal bullish momentum; a cross below could indicate weakness.  
- **Support/resistance**: In trending markets, the SMA often acts as dynamic support (in uptrends) or resistance (in downtrends).  

Common SMA periods include 10, 20, 50, 100, and 200 days, with longer periods producing smoother lines and shorter periods reacting more sensitively to price changes. However, SMA has limitations:  
- **Lag**: Because it relies on historical data, SMA is inherently reactive, often trailing price action.  
- **Noise in sideways markets**: In range-bound conditions, SMA crossovers can generate false signals.  
- **Equal weighting**: All periods in the window are weighted equally, which may downplay recent price movements.  

## Text Formula  
The SMA for period $ n $ is calculated as:  
$$
\text{SMA}_t(n) = \frac{1}{n} \sum_{i=1}^{n} P_{t - i + 1}
$$  
Where:  
- $ P $ = closing price at period $ t - i + 1 $  
- $ n $ = number of periods in the SMA window  
- $ t $ = current period  

For example, a 5-day SMA on day 10 would average the closing prices from days 6 through 10.  

## Python Code  
```python
import pandas as pd

def calculate_sma(df: pd.DataFrame, window: int) -> pd.DataFrame:
    """
    Calculate the Simple Moving Average (SMA) for each symbol in the DataFrame.
    
    Parameters:
        df (pd.DataFrame): Input DataFrame with columns: symbol, date, open, high, low, close.
        window (int): Number of periods for the SMA calculation.
        
    Returns:
        pd.DataFrame: Original DataFrame with an additional column 'SMA_{window}'.
    """
    # Ensure data is sorted by date for accurate rolling calculations
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Calculate SMA using a rolling window, grouped by symbol
    df[f'SMA_{window}'] = df.groupby('symbol')['close'].rolling(window=window, min_periods=1).mean().reset_index(level=0, drop=True)
    
    return df
```

The function `calculate_sma` processes a DataFrame containing one or more symbols, computing the SMA for the specified window. Key features:  
- **Grouping by symbol**: Ensures calculations are isolated per asset.  
- **Rolling mean**: Uses `pandas.DataFrame.rolling` with `min_periods=1` to avoid NaN values during partial windows.  
- **Date sorting**: Prevents look-ahead bias by ensuring chronological order.  

To use this code, pass a properly formatted DataFrame and a window size. For example, `calculate_sma(data, 50)` adds a `SMA_50` column with 50-period averages. The output retains all original columns, enabling direct comparison of price and SMA values.
```json
{ "model_code": "d2vt6jb9krx5", "topic": "Simple Moving Average", "timer_secs": 30.42, "tokens_in": 564, "tokens_out": 1544, "cost_tokens_in": 0.00004512, "cost_tokens_out": 0.00037056, "cost_tokens_tot": 0.00041568 }
```