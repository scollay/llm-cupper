# Bollinger Bands

## Overview
Bollinger Bands are a volatility-based indicator that wrap a price chart in three lines: a middle band (a simple moving average) and an upper and lower band placed a set number of standard deviations away. As volatility rises, the bands widen; as it falls, they contract. The result is a dynamic envelope that visually frames how far price has stretched relative to its recent average.

The indicator was developed by technical analyst **John Bollinger** in the early 1980s. It remains one of the most widely used tools for gauging relative price levels and volatility regimes, and it appears as standard on virtually every charting platform.

## Details

### Construction
Bollinger Bands have three components, all derived from closing prices over a lookback window (commonly 20 periods):

- **Middle Band** — a simple moving average (SMA) of the close.
- **Upper Band** — the middle band plus *k* standard deviations of price.
- **Lower Band** — the middle band minus *k* standard deviations of price.

The standard settings are a 20-period SMA with a multiplier of `2`. Bollinger himself noted that if you change the period, you may want to adjust the multiplier: shorter periods often pair with a smaller multiplier, longer periods with a larger one.

### Derived measures
Two values are commonly computed from the bands:

- **Bandwidth** measures how wide the bands are relative to the middle band. It quantifies volatility and is the basis for identifying the *Squeeze* — a period of unusually low volatility that often precedes a sharp move.
- **%B** (percent B) tells you where the close sits *within* the bands on a normalized scale. A `%B` of `1.0` means price is at the upper band, `0.0` at the lower band, and `0.5` at the middle band. Values above `1` or below `0` indicate price has closed outside the bands.

### Interpretation
Traders typically use Bollinger Bands in two broad ways:

1. **Mean reversion.** When price tags or pierces the upper band it is considered relatively high, and relatively low at the lower band. In a sideways market, traders may fade these extremes, expecting a return toward the middle band.
2. **Volatility and breakouts.** A narrow band (low bandwidth) signals compressed volatility. Because volatility is mean-reverting, contraction tends to be followed by expansion — so a Squeeze can foreshadow a breakout, though it does not predict direction.

The middle band also doubles as a dynamic support/resistance and trend reference: price holding above it suggests an uptrend bias, below it a downtrend bias.

### Where interpretation breaks down
The single biggest mistake is treating band touches as automatic reversal signals. **Touching the upper band is not by itself a sell signal.** In a strong trend, price can "walk the band," riding the upper band higher (or lower band lower) for an extended run, repeatedly stopping out mean-reversion traders.

Other caveats:

- The bands describe *relative*, not absolute, levels. They tell you where price is versus its recent history, not whether it is fundamentally cheap or expensive.
- Using closing prices and a normal-distribution assumption is a simplification; real returns have fat tails, so closes outside the bands occur more often than a strict statistical reading would suggest.
- Settings are not universal. The 20/2 default is a starting point, and over-optimizing parameters to past data invites curve-fitting.
- Bollinger advised against using the bands in isolation, pairing them instead with non-correlated indicators (e.g., volume or momentum) for confirmation.

## Text Formula

```
Let n = lookback period (default 20)
Let k = standard deviation multiplier (default 2)

Middle Band (MB) = SMA(Close, n)

StdDev = population standard deviation of Close over the last n periods

Upper Band (UB) = MB + (k * StdDev)
Lower Band (LB) = MB - (k * StdDev)

Bandwidth = (UB - LB) / MB

%B = (Close - LB) / (UB - LB)
```

Note: Bollinger Bands use the *population* standard deviation (dividing by `n`), not the sample standard deviation (dividing by `n - 1`).

## Python Code

```python
import pandas as pd

# Expected input: a Pandas DataFrame `df` with the following columns:
#   symbol : str    - ticker/identifier (one or more symbols may be present)
#   date   : date   - trading date (parseable as datetime)
#   open   : float  - opening price
#   high   : float  - high price
#   low    : float  - low price
#   close  : float  - closing price
#
# The function returns a copy of the input with these added columns:
#   bb_middle    - middle band (SMA of close)
#   bb_upper     - upper band
#   bb_lower     - lower band
#   bb_bandwidth - (upper - lower) / middle
#   bb_percent_b - (close - lower) / (upper - lower)


def bollinger_bands(df, period=20, num_std=2.0):
    """
    Compute Bollinger Bands and derived measures for one or more symbols.

    Each symbol is processed independently so that the rolling window
    never leaks data across tickers.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: symbol, date, open, high, low, close.
    period : int
        Lookback window for the SMA and standard deviation (default 20).
    num_std : float
        Standard deviation multiplier for the bands (default 2.0).

    Returns
    -------
    pd.DataFrame
        Copy of input sorted by symbol/date with Bollinger columns added.
    """
    out = df.copy()

    # Ensure correct ordering before any rolling calculation.
    out["date"] = pd.to_datetime(out["date"])
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Group by symbol so each ticker is handled in isolation.
    grouped = out.groupby("symbol")["close"]

    # Middle band: simple moving average of close.
    out["bb_middle"] = grouped.transform(
        lambda s: s.rolling(window=period).mean()
    )

    # Population standard deviation (ddof=0) per Bollinger's definition.
    rolling_std = grouped.transform(
        lambda s: s.rolling(window=period).std(ddof=0)
    )

    # Upper and lower bands.
    out["bb_upper"] = out["bb_middle"] + num_std * rolling_std
    out["bb_lower"] = out["bb_middle"] - num_std * rolling_std

    # Bandwidth: width of the channel relative to the middle band.
    out["bb_bandwidth"] = (out["bb_upper"] - out["bb_lower"]) / out["bb_middle"]

    # %B: position of close within the bands (0 = lower, 1 = upper).
    band_range = out["bb_upper"] - out["bb_lower"]
    out["bb_percent_b"] = (out["close"] - out["bb_lower"]) / band_range

    return out
```

Rows before the `period` is filled will contain `NaN` values for the band columns, which is expected. Because the multiplier scales both bands symmetrically, `bb_percent_b` is independent of `num_std`'s effect on the band *range*'s ratio but still reflects the chosen width through `bb_lower` and `bb_upper`.
```json
{ "model_code": "r8f5wn2cv6tj", "topic": "Bollinger Bands", "timer_secs": 30.78, "tokens_in": 846, "tokens_out": 2491, "cost_tokens_in": 0.00423000, "cost_tokens_out": 0.06227500, "cost_tokens_tot": 0.06650500 }
```