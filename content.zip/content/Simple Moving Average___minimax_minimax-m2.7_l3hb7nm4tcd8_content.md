# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a basic technical indicator that smooths price data by calculating the arithmetic mean of a security’s closing prices over a set number of periods. On a chart the SMA appears as a line that follows the price action, rising or falling as the average updates. It was formalized in modern technical analysis decades ago and remains one of the most widely used tools for identifying trend direction, support and resistance levels, and potential entry or exit signals.

## Details
The SMA gives traders a quick view of the average price over a chosen time window, dampening short‑term volatility so that underlying trends become visible.

### How it works
1. **Select a window (period)** – for example, 20, 50, or 200 candles.
2. **Sum the closing prices** for the most recent *N* periods.
3. **Divide by N** to obtain the average.
4. **Repeat** as each new candle closes, dropping the oldest price from the sum.

The result is a series of averages that trail the price. A short window (e.g., 10‑period) reacts quickly to price changes; a long window (e.g., 200‑period) moves slowly, filtering out noise but introducing lag.

### Typical interpretation
- **Trend direction**: When the price is above its SMA, the short‑term trend is considered bullish; when below, bearish.
- **Crossovers**: A **short‑term SMA** crossing above a **long‑term SMA** (a “golden cross”) is seen as a bullish signal, while the reverse (“death cross”) is bearish.
- **Support/Resistance**: In an uptrend, the SMA often acts as a support level; in a downtrend, it can act as resistance.
- **Momentum**: The angle of the SMA (steeper = stronger momentum) helps gauge the strength of a move.

### Where interpretation breaks down
- **Lag**: Because the SMA relies on past prices, it reacts slowly to rapid reversals. In fast‑moving markets the signal can arrive after the move has already begun.
- **Whipsaws**: In sideways or choppy markets the price repeatedly crosses the SMA, generating false signals.
- **Equal weighting**: All periods receive the same weight, so recent price action is not emphasized. Traders who want more relevance on recent data often turn to exponential or weighted moving averages.
- **No predictive power**: The SMA is a descriptive tool; it does not forecast future price direction.

### Common window lengths
| Category | Typical windows |
|----------|-----------------|
| Short‑term | 5, 10, 20 |
| Medium‑term | 50, 100 |
| Long‑term | 150, 200 |

Using multiple SMAs simultaneously helps traders confirm signals and reduce noise.

## Text Formula
For a single security at time *t* and a window of *N* periods, the Simple Moving Average is defined as:

**SMA(N)ₜ = (1 / N) × Σ_{i=0}^{N‑1} Close_{t‑i}**

Where:

- **Close_{t‑i}** is the closing price *i* periods ago.
- **Σ** denotes the sum of the *N* most recent closing prices.
- The result is divided by *N* to produce the average.

When applied to multiple securities, the calculation is performed independently for each symbol by grouping the data by `symbol` before applying the rolling mean.

## Python Code

```python
import pandas as pd

def compute_sma(df: pd.DataFrame, windows: list[int] = [20, 50, 200]) -> pd.DataFrame:
    """
    Calculate Simple Moving Averages (SMA) for each symbol in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input data with columns: symbol, date, open, high, low, close.
    windows : list[int], optional
        List of window lengths (in periods) for which SMAs are computed.
        Default is [20, 50, 200].

    Returns
    -------
    pd.DataFrame
        Original DataFrame enriched with SMA columns named 'sma_<window>'.
        If a window cannot be computed (e.g., insufficient rows), the column
        will contain NaN for those rows.

    Notes
    -----
    - The function groups by 'symbol' to ensure calculations are independent.
    - It uses Pandas' rolling window to compute the arithmetic mean of 'close'.
    """
    # Ensure the date column is sorted (needed for correct rolling window)
    df = df.sort_values(['symbol', 'date']).reset_index(drop=True)

    # Create a copy to avoid mutating the original DataFrame
    result = df.copy()

    for n in windows:
        col_name = f'sma_{n}'
        # Use groupby + transform to keep the original index while computing rolling mean
        result[col_name] = (
            df.groupby('symbol')['close']
              .transform(lambda x: x.rolling(window=n, min_periods=n).mean())
        )

    return result
```
```json
{ "model_code": "l3hb7nm4tcd8", "topic": "Simple Moving Average", "timer_secs": 18.82, "tokens_in": 591, "tokens_out": 1866, "cost_tokens_in": 0.00017730, "cost_tokens_out": 0.00223920, "cost_tokens_tot": 0.00241650 }
```