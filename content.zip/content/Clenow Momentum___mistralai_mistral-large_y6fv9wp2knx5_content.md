# Clenow Momentum

## Overview

Clenow Momentum is a trend-following indicator developed by Andreas Clenow, a quantitative trader and author of *Stocks on the Move*. Introduced in the early 2010s, this indicator combines price momentum with volatility scaling to identify strong, persistent trends in equities. On a chart, Clenow Momentum appears as a single line oscillating around a zero axis, with positive values signaling upward momentum and negative values indicating downward momentum. Unlike traditional momentum measures, it incorporates volatility normalization to reduce false signals in choppy markets.

## Details

Clenow Momentum is designed to capture the strength of a trend while adjusting for the asset's volatility. The core idea is that strong trends exhibit consistent price movement relative to their historical volatility. The indicator is particularly useful for systematic traders looking to avoid whipsaws in mean-reverting markets.

### How It Works
1. **Momentum Calculation**: The indicator starts with a raw momentum measure, typically the percentage change in price over a lookback period (e.g., 20 or 50 days).
2. **Volatility Scaling**: The raw momentum is divided by the asset's historical volatility (e.g., 20-day standard deviation of returns) to normalize the signal. This step ensures that assets with higher volatility don't dominate the ranking simply due to their larger price swings.
3. **Smoothing**: The volatility-scaled momentum is often smoothed with a moving average (e.g., 5-day) to reduce noise and highlight persistent trends.

### Interpretation
- **Positive Values**: Suggest an upward trend. The higher the value, the stronger the trend.
- **Negative Values**: Indicate a downward trend. The lower the value, the stronger the downtrend.
- **Zero Crossings**: A move from negative to positive may signal a potential long entry, while a move from positive to negative may suggest a short entry or exit.
- **Extreme Values**: Values far from zero (e.g., > 2 or < -2) may indicate overbought or oversold conditions, though Clenow Momentum is not primarily an overbought/oversold oscillator.

### Limitations
- **Lag**: Like all trend-following indicators, Clenow Momentum lags price action. It excels in trending markets but may produce false signals during consolidations or reversals.
- **Volatility Sensitivity**: The indicator's reliance on volatility scaling can lead to erratic behavior during periods of sudden volatility spikes or drops.
- **Parameter Sensitivity**: The choice of lookback periods for momentum and volatility can significantly impact performance. Shorter periods increase responsiveness but also noise, while longer periods may miss early trend changes.

## Text Formula

The Clenow Momentum (CM) for a given day `t` is calculated as follows:

1. **Raw Momentum (M)**:
   ```
   M_t = (Close_t / Close_{t-n}) - 1
   ```
   where `n` is the momentum lookback period (e.g., 20 days).

2. **Volatility (V)**:
   ```
   V_t = StandardDeviation(Returns_{t-n:t})
   ```
   where `Returns` are the daily percentage returns over the same `n` period.

3. **Volatility-Scaled Momentum (VSM)**:
   ```
   VSM_t = M_t / V_t
   ```

4. **Smoothed Clenow Momentum (CM)** (optional):
   ```
   CM_t = SMA(VSM_t, m)
   ```
   where `SMA` is a simple moving average over `m` days (e.g., 5 days).

## Python Code

```python
import pandas as pd
import numpy as np

def calculate_clenow_momentum(df, momentum_period=20, volatility_period=20, smoothing_period=5):
    """
    Calculate Clenow Momentum for one or more symbols in a DataFrame.

    Parameters:
    - df: DataFrame with columns ['symbol', 'date', 'open', 'high', 'low', 'close']
    - momentum_period: Lookback period for raw momentum (default: 20)
    - volatility_period: Lookback period for volatility (default: 20)
    - smoothing_period: Lookback period for smoothing (default: 5)

    Returns:
    - DataFrame with original columns plus 'clenow_momentum' and 'clenow_momentum_raw'
    """
    # Ensure the DataFrame is sorted by symbol and date
    df = df.sort_values(['symbol', 'date']).copy()

    # Calculate daily returns for volatility calculation
    df['return'] = df.groupby('symbol')['close'].pct_change()

    # Calculate raw momentum: (close_t / close_{t-n}) - 1
    df['raw_momentum'] = df.groupby('symbol')['close'].transform(
        lambda x: x / x.shift(momentum_period) - 1
    )

    # Calculate volatility: standard deviation of returns over volatility_period
    df['volatility'] = df.groupby('symbol')['return'].transform(
        lambda x: x.rolling(volatility_period).std()
    )

    # Avoid division by zero; replace zero volatility with a small value
    df['volatility'] = df['volatility'].replace(0, np.nan)
    df['volatility'] = df['volatility'].fillna(method='ffill').fillna(1e-6)

    # Calculate volatility-scaled momentum
    df['clenow_momentum_raw'] = df['raw_momentum'] / df['volatility']

    # Smooth the momentum (optional)
    df['clenow_momentum'] = df.groupby('symbol')['clenow_momentum_raw'].transform(
        lambda x: x.rolling(smoothing_period).mean()
    )

    # Drop intermediate columns
    df = df.drop(columns=['return', 'raw_momentum', 'volatility'], errors='ignore')

    return df
```

### Notes on the Code:
- The function handles multiple symbols by grouping calculations by `symbol`.
- Volatility is calculated as the standard deviation of daily returns over the `volatility_period`.
- Zero or near-zero volatility is handled by forward-filling and replacing with a small value to avoid division errors.
- The smoothed Clenow Momentum (`clenow_momentum`) is optional but included as it is commonly used. The raw version (`clenow_momentum_raw`) is also returned for flexibility.
- The input DataFrame must include the columns `symbol`, `date`, `open`, `high`, `low`, and `close`. The output adds `clenow_momentum` and `clenow_momentum_raw`.
```json
{ "model_code": "y6fv9wp2knx5", "topic": "Clenow Momentum", "timer_secs": 21.50, "tokens_in": 571, "tokens_out": 1438, "cost_tokens_in": 0.00114200, "cost_tokens_out": 0.00862800, "cost_tokens_tot": 0.00977000 }
```