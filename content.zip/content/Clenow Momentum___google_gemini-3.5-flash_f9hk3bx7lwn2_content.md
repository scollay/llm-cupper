# Clenow Momentum

## Overview
Clenow Momentum is a sophisticated trend-following metric designed to identify and rank assets exhibiting the strongest and most stable trends. Introduced by hedge fund manager and author Andreas Clenow in his seminal 2015 book, *Stocks on the Move*, this indicator departs from traditional momentum oscillators like the Relative Strength Index (RSI) or Rate of Change (ROC). Instead of plotting as an oscillator bounded between 0 and 100, Clenow Momentum appears as a continuous numerical score. 

While traditional momentum indicators are highly sensitive to the specific start and end dates of their lookback windows, Clenow Momentum utilizes log-linear regression over a specified period—typically 90 days—to analyze every single data point in the window. This approach allows traders to measure both the velocity of a price trend and its consistency, filtering out highly volatile, erratic price moves in favor of smooth, steady appreciation.

## Details
To understand Clenow Momentum, one must first understand the limitations of traditional momentum metrics. Standard momentum calculations simply measure the percentage change in price from point A to point B. If a stock trades flat for 89 days and then gaps up 20% on day 90 due to a temporary news event, a standard 90-day momentum indicator will flag the stock as having high momentum. In reality, this trend is highly unstable and prone to immediate reversal.

Clenow Momentum solves this "endpoint bias" by fitting an exponential regression line to the asset's closing prices over the lookback period. The calculation relies on two primary statistical outputs: the slope of the regression line and the coefficient of determination (`R²`).

### The Mechanics of Log-Linear Regression
Stock prices naturally grow geometrically rather than linearly; a $1 move on a $10 stock is far more significant than a $1 move on a $100 stock. To account for this, Clenow Momentum first transforms the daily closing prices by taking their natural logarithm. 

By performing a linear regression on the log-transformed prices against a simple time index, the resulting slope represents the daily continuously compounded growth rate of the asset. To make this figure intuitive for financial analysis, the daily slope is annualized assuming 252 trading days in a year. This annualized slope tells the trader the theoretical yearly return of the asset if the current trend continues at its current pace.

### The Volatility Filter: R-Squared
The annualized slope alone is not enough to determine trend quality. A highly volatile stock can have a steep slope but experience massive, gut-wrenching drawdowns along the way. To filter for stability, Clenow multiplies the annualized slope by the regression's coefficient of determination, or `R²`.

The `R²` value ranges from 0.0 to 1.0:
* An `R²` of 1.0 indicates a perfect fit, meaning the stock price increased in a perfectly straight, uninterrupted line.
* An `R²` of 0.0 indicates complete randomness, meaning the price action has no linear relationship with time.

By multiplying the annualized slope by `R²`, the Clenow Momentum Score heavily penalizes assets with erratic, volatile price swings and rewards assets that climb in a smooth, steady, and predictable channel.

### Practical Application and Interpretation
In practice, active traders use Clenow Momentum as a ranking tool rather than a simple buy/sell trigger. A typical systematic momentum strategy involves:
1. Defining a broad universe of liquid assets (such as the S&P 500 or a basket of highly liquid ETFs).
2. Calculating the Clenow Momentum Score for every asset in the universe using a 90-day lookback window.
3. Sorting the universe from highest score to lowest score.
4. Purchasing the top-ranking assets (e.g., the top 20%) and holding them until they fall below a certain percentile threshold.
5. Sizing positions using volatility-targeting methods, such as the Average True Range (ATR), to ensure equal risk contribution across the portfolio.

### Where the Interpretation Breaks Down
While highly effective in sustained bull markets, Clenow Momentum has distinct vulnerabilities:
* **Lag at Major Inflection Points:** Because regression averages price action over a 90-day window, the indicator is slow to react to sudden, structural market reversals. A stock can drop significantly before its Clenow Momentum Score falls enough to trigger an exit.
* **Mean-Reverting Environments:** In choppy, sideways, or highly volatile markets, the indicator can generate frequent whipsaws. High-scoring stocks may quickly mean-revert, leading to buying at local tops.
* **Survivorship and Selection Bias:** The score is relative. If the entire market regime is bearish, even the highest-ranked stocks in a universe may have negative or weak absolute momentum. Traders must often pair the ranking system with an absolute trend filter, such as requiring the asset to be trading above its 200-day moving average.

## Text Formula

To calculate the Clenow Momentum Score over a lookback period of $N$ days:

1. **Log Transform:** Calculate the natural log of the closing prices for each day $t$ in the lookback window:
   $$y_t = \ln(\text{Close}_t) \quad \text{for } t = 0, 1, 2, \dots, N-1$$

2. **Time Index:** Define the independent variable $x$ as a sequence of integers representing time:
   $$x_t = t \quad \text{for } t = 0, 1, 2, \dots, N-1$$

3. **Linear Regression:** Fit a linear regression line ($\hat{y} = m \cdot x + b$) to find the daily slope ($m$) and intercept ($b$):
   $$m = \frac{N \sum (x_t \cdot y_t) - \sum x_t \sum y_t}{N \sum (x_t^2) - (\sum x_t)^2}$$
   $$b = \frac{\sum y_t - m \sum x_t}{N}$$

4. **Coefficient of Determination ($R^2$):** Calculate the ratio of explained variance to total variance:
   $$R^2 = 1 - \frac{\sum (y_t - \hat{y}_t)^2}{\sum (y_t - \bar{y})^2}$$
   *Where $\bar{y}$ is the mean of $y_t$, and $\hat{y}_t = m \cdot x_t + b$.*

5. **Annualized Slope:** Convert the daily log slope to an annualized percentage return:
   $$\text{Annualized Slope} = e^{m \cdot 252} - 1$$

6. **Clenow Momentum Score:** Multiply the annualized slope by the coefficient of determination:
   $$\text{Clenow Momentum Score} = \text{Annualized Slope} \times R^2$$

## Python Code

```python
import numpy as np
import pandas as pd

def calculate_clenow_momentum(df, window=90):
    """
    Calculates the Clenow Momentum Score for a multi-symbol DataFrame.
    
    Parameters:
    df (pd.DataFrame): Input DataFrame containing 'symbol', 'date', and 'close' columns.
    window (int): The lookback period for the regression (default is 90 days).
    
    Returns:
    pd.DataFrame: The input DataFrame sorted by symbol and date with an added 
                  'clenow_momentum' column.
    """
    # Ensure the DataFrame is sorted correctly to maintain time-series integrity
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    # Calculate the natural log of the closing price
    df['log_close'] = np.log(df['close'])
    
    def calc_single_window_score(y):
        """
        Helper function to calculate the Clenow Score on a 1D numpy array of log prices.
        """
        n = len(y)
        x = np.arange(n)
        
        # Perform linear regression: y = mx + b
        slope, intercept = np.polyfit(x, y, 1)
        
        # Calculate predictions and mean for R-squared calculation
        y_pred = slope * x + intercept
        y_mean = np.mean(y)
        
        # Calculate sum of squares
        ss_tot = np.sum((y - y_mean) ** 2)
        
        # Handle edge case of flat price action to avoid division by zero
        if ss_tot == 0:
            r_squared = 0.0
        else:
            ss_res = np.sum((y - y_pred) ** 2)
            r_squared = 1.0 - (ss_res / ss_tot)
        
        # Annualize the daily log slope
        # Annualized Return = exp(daily_slope * 252) - 1
        annualized_slope = np.exp(slope * 252) - 1
        
        # Calculate final Clenow Momentum Score
        score = annualized_slope * r_squared
        return score

    # Apply the rolling calculation independently to each symbol group
    df['clenow_momentum'] = (
        df.groupby('symbol', group_keys=False)['log_close']
        .rolling(window=window)
        .apply(calc_single_window_score, raw=True)
    )
    
    # Clean up temporary column
    df = df.drop(columns=['log_close'])
    
    return df
```
```json
{ "model_code": "f9hk3bx7lwn2", "topic": "Clenow Momentum", "timer_secs": 31.97, "tokens_in": 566, "tokens_out": 6311, "cost_tokens_in": 0.00084900, "cost_tokens_out": 0.05679900, "cost_tokens_tot": 0.05764800 }
```