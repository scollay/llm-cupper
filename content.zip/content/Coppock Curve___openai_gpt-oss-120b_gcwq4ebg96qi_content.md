# Coppock Curve

## Overview
The Coppock Curve is a long‑term momentum indicator designed to spot major buying opportunities in equity markets. It appears on a price chart as a smooth line that typically hovers near zero, dipping into negative territory before turning upward. Developed by Edwin Sullivan Coppock in 1962 while working at the **U.S. Federal Reserve**, the curve was originally intended to identify “buy‑the‑dip” moments in broad market indices. Because it blends two rate‑of‑change (ROC) calculations with a weighted moving average, the Coppock Curve reacts slowly, making it most useful for investors with a multi‑month horizon.

## Details
### How the indicator is built
1. **Two rate‑of‑change components** – The classic Coppock uses a 14‑period ROC and an 11‑period ROC, both expressed as percentages.  
   - `ROC14 = (Close_t – Close_{t‑14}) / Close_{t‑14} × 100`  
   - `ROC11 = (Close_t – Close_{t‑11}) / Close_{t‑11} × 100`  

2. **Summation** – The two ROC values are added together for each bar:  
   `SumROC_t = ROC14_t + ROC11_t`.

3. **Smoothing** – The summed ROC series is smoothed with a 10‑period **Weighted Moving Average (WMA)**, which gives more weight to recent observations. The result is the Coppock Curve value for that bar:  
   `Coppock_t = WMA_{10}(SumROC_t)`.

The WMA formula assigns a weight equal to the observation’s position in the window (1 for the oldest, 10 for the most recent). This weighting reduces lag compared with a simple moving average while preserving the indicator’s long‑term character.

### Typical interpretation
- **Zero‑line cross** – When the curve crosses **above zero**, it is taken as a bullish signal, suggesting that the market’s long‑term momentum has turned positive. Conversely, a cross **below zero** is a bearish signal, though many traders ignore the latter because the Coppock was originally intended only as a buying tool.
- **Trend confirmation** – A rising Coppock that stays above zero reinforces an uptrend; a falling Coppock below zero confirms a downtrend. The steeper the slope, the stronger the implied momentum shift.
- **Divergence** – Some analysts watch for price‑Coppock divergence (e.g., price makes a new low while the Coppock does not), treating it as an early warning of a potential reversal.

### Where interpretation breaks down
- **Lag and whipsaws** – The 10‑period WMA smooths out short‑term noise, but it also delays the signal. In fast‑moving markets, the Coppock may lag by several weeks, causing traders to miss the optimal entry point.
- **Zero‑line focus** – Relying solely on zero‑line crosses can be misleading. The curve can stay above zero for extended periods while the market stalls, producing false “buy” signals. Many practitioners add a secondary filter (e.g., a longer‑term moving average of price) to confirm the trend.
- **Parameter rigidity** – The original 14‑/11‑/10‑period settings work well for broad U.S. indices, but they may be too sluggish for sector ETFs, commodities, or non‑U.S. markets. Adjusting the ROC lengths or the WMA window can improve relevance, but it also changes the statistical properties of the indicator.
- **Non‑trend markets** – In sideways or range‑bound environments, the Coppock often hovers near zero, generating frequent crossovers that add little value. In such conditions, traders typically suspend Coppock‑based entries.

### Practical usage tips
- **Combine with price action** – Look for the Coppock to cross above zero **near a support level** or after a bullish candlestick pattern. This confluence reduces the chance of entering on a temporary bounce.
- **Use multi‑symbol analysis** – Because the Coppock is a market‑wide momentum gauge, comparing the curve across several indices or sector ETFs can reveal relative strength. A sector whose Coppock is rising while the broad market’s curve is flat may be a candidate for outperformance.
- **Back‑test with realistic slippage** – The lag inherent in the indicator means that a back‑test should incorporate realistic execution delays (e.g., entering at the next day’s open after a zero‑line cross).

## Text Formula
```
ROC_n(t) = 100 × (Close_t – Close_{t‑n}) / Close_{t‑n}
SumROC(t) = ROC_14(t) + ROC_11(t)
WMA_k(t) = ( Σ_{i=1}^{k} i × SumROC_{t‑k+i} ) / (k × (k+1) / 2 )
Coppock(t) = WMA_10(t)
```
Where:
- `n` is the look‑back period for each ROC (14 and 11).
- `k` is the WMA smoothing window (10).
- `t` indexes the current bar (date).

## Python Code
```python
import pandas as pd
import numpy as np

def calculate_coppock(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate the Coppock Curve for one or more symbols.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data containing at least the columns:
        - 'symbol' : identifier for each security
        - 'date'   : trading date (datetime or string)
        - 'close'  : closing price
    
    Returns
    -------
    pd.DataFrame
        Original dataframe plus three new columns:
        - 'roc_14'   : 14‑period rate of change (percentage)
        - 'roc_11'   : 11‑period rate of change (percentage)
        - 'coppock'  : Coppock Curve value (10‑period WMA of ROC sum)
    """
    # Ensure proper ordering within each symbol
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df.sort_values(['symbol', 'date'], inplace=True)

    # Helper to compute weighted moving average
    def wma(series: pd.Series, window: int) -> pd.Series:
        """
        Weighted moving average where weights increase linearly:
        weight_i = i for i = 1 .. window (oldest to newest).
        """
        weights = np.arange(1, window + 1)
        # Use rolling.apply for custom weighting
        return series.rolling(window).apply(
            lambda x: np.dot(x, weights) / weights.sum(),
            raw=True
        )

    # Compute ROC for each look‑back period per symbol
    def compute_symbol(group: pd.DataFrame) -> pd.DataFrame:
        group = group.copy()
        group['roc_14'] = 100.0 * (group['close'] - group['close'].shift(14)) / group['close'].shift(14)
        group['roc_11'] = 100.0 * (group['close'] - group['close'].shift(11)) / group['close'].shift(11)
        # Sum of the two ROC series
        group['roc_sum'] = group['roc_14'] + group['roc_11']
        # 10‑period weighted moving average of the sum
        group['coppock'] = wma(group['roc_sum'], window=10)
        # Drop the intermediate column; keep only required outputs
        return group.drop(columns=['roc_sum'])

    # Apply per symbol
    result = df.groupby('symbol', group_keys=False).apply(compute_symbol)

    # Optional: reorder columns for readability
    cols = ['symbol', 'date', 'open', 'high', 'low', 'close',
            'roc_14', 'roc_11', 'coppock']
    # Preserve any extra columns that may exist
    extra_cols = [c for c in result.columns if c not in cols]
    result = result[cols + extra_cols]

    return result
```
```json
{ "model_code": "gcwq4ebg96qi", "topic": "Coppock Curve", "timer_secs": 17.99, "tokens_in": 561, "tokens_out": 1741, "cost_tokens_in": 0.00002188, "cost_tokens_out": 0.00031338, "cost_tokens_tot": 0.00033526 }
```