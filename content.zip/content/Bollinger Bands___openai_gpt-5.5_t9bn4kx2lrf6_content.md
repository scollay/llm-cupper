# Bollinger Bands

## Overview

Bollinger Bands are a volatility-based technical indicator plotted directly on a price chart. They consist of a moving average, typically a 20-period simple moving average, with an upper band and lower band placed a specified number of standard deviations above and below it.

The indicator was developed by John Bollinger in the early 1980s. Its main purpose is to show whether price is high or low relative to its recent trading range, while adapting automatically as volatility expands or contracts.

## Details

Bollinger Bands are built around a simple idea: markets alternate between periods of lower and higher volatility. Instead of using fixed-percentage envelopes, Bollinger Bands widen when price volatility rises and narrow when volatility falls.

The standard setting is:

- 20-period simple moving average as the middle band
- 2 standard deviations above the moving average as the upper band
- 2 standard deviations below the moving average as the lower band

These defaults are common, but not mandatory. Shorter windows make the bands more responsive and noisier. Longer windows make them smoother but slower. A larger standard deviation multiplier creates wider bands and fewer touches; a smaller multiplier creates tighter bands and more frequent signals.

### How Bollinger Bands appear on a chart

On a chart, Bollinger Bands form a channel around price:

- The **middle band** tracks the short- to intermediate-term trend.
- The **upper band** represents a high relative price zone.
- The **lower band** represents a low relative price zone.
- The **band width** expands and contracts with volatility.

Unlike a static support-and-resistance channel, Bollinger Bands are dynamic. The upper and lower bands move every period as both the moving average and standard deviation update.

### Common interpretations

A frequent mistake is assuming that touching the upper band is automatically bearish or touching the lower band is automatically bullish. Bollinger Bands do not, by themselves, define overbought or oversold in the same way that a bounded oscillator might. Price can ride the upper band for a long time in a strong uptrend, or ride the lower band during a persistent downtrend.

Traders usually interpret Bollinger Bands in context.

#### Band touches

A move to the upper band shows that price is high relative to its recent average. A move to the lower band shows that price is low relative to its recent average.

In a range-bound market, traders may look for reversals after price tests an outer band, especially if other evidence supports exhaustion. In a trending market, however, band touches may confirm strength rather than signal reversal.

For example:

- Repeated closes near the upper band can indicate sustained buying pressure.
- Repeated closes near the lower band can indicate sustained selling pressure.
- A failure to reach the opposite band after a reversal can suggest weakening momentum.

#### The squeeze

A **Bollinger Band squeeze** occurs when the bands contract significantly, reflecting unusually low recent volatility. Traders watch squeezes because volatility contraction is often followed by volatility expansion.

A squeeze does not predict direction. It only signals that a larger move may be developing. Traders typically wait for a breakout above resistance, below support, or beyond the bands themselves, often using volume, trend structure, or momentum confirmation.

A common problem with squeeze trades is false breakouts. Price may briefly move outside a band, attract breakout traders, and then reverse back into the range. For that reason, many traders require confirmation such as a close beyond the band, expansion in volume, or follow-through over multiple bars.

#### Walking the bands

In strong trends, price may “walk the band.” In an uptrend, price can repeatedly close near or above the upper band while the middle band slopes higher. In a downtrend, price can remain near or below the lower band while the middle band slopes lower.

This is where simple mean-reversion interpretations often break down. A price close above the upper band may look extended, but in a strong trend it can represent momentum continuation. Traders often combine Bollinger Bands with trend filters, moving average slope, price structure, or momentum indicators to avoid fading powerful trends too early.

#### %B

The indicator **%B** measures where the close sits relative to the bands. It converts the band position into a normalized value:

- `%B = 1` means the close is at the upper band.
- `%B = 0` means the close is at the lower band.
- `%B = 0.5` means the close is at the middle band.
- `%B > 1` means the close is above the upper band.
- `%B < 0` means the close is below the lower band.

Traders use %B to compare band position across symbols or timeframes. It is also useful for scans, because it turns the visual relationship between price and bands into a numeric value.

#### Bandwidth

**Bandwidth** measures the distance between the upper and lower bands relative to the middle band. It is commonly used to identify squeezes and volatility expansions.

A low bandwidth reading means the bands are narrow relative to recent prices. A rising bandwidth reading means volatility is expanding. Because different securities trade at different price levels, bandwidth is more comparable than the raw dollar distance between the bands.

### Where Bollinger Bands break down

Bollinger Bands are descriptive, not predictive. They summarize recent price behavior, but they do not identify the cause of a move or guarantee what comes next.

Their main weaknesses include:

- **Trend persistence:** Price can remain near an outer band for extended periods.
- **False breakouts:** A move outside the bands may quickly reverse.
- **Lag:** The middle band and standard deviation are based on historical prices.
- **Parameter sensitivity:** Different window lengths and multipliers can change signals materially.
- **No directional bias during squeezes:** Tight bands suggest potential movement, not direction.

For active traders, Bollinger Bands are often most useful as a framework: they define relative price location and volatility conditions. The signal quality usually improves when bands are combined with price action, volume, market regime, and risk management rules.

## Text Formula

Let:

- `Close_t` = closing price at time `t`
- `N` = lookback period, commonly 20
- `K` = standard deviation multiplier, commonly 2
- `SMA_t` = simple moving average of closing prices over the last `N` periods
- `StdDev_t` = standard deviation of closing prices over the last `N` periods

Middle Band:

`Middle Band_t = SMA_t = (Close_t + Close_{t-1} + ... + Close_{t-N+1}) / N`

Standard Deviation:

`StdDev_t = sqrt((1 / N) * sum from i=0 to N-1 of (Close_{t-i} - SMA_t)^2)`

Upper Band:

`Upper Band_t = Middle Band_t + (K * StdDev_t)`

Lower Band:

`Lower Band_t = Middle Band_t - (K * StdDev_t)`

%B:

`%B_t = (Close_t - Lower Band_t) / (Upper Band_t - Lower Band_t)`

Bandwidth:

`Bandwidth_t = (Upper Band_t - Lower Band_t) / Middle Band_t`

When there are fewer than `N` observations, Bollinger Band values are typically left undefined.

## Python Code

```python
import numpy as np
import pandas as pd


def add_bollinger_bands(df, window=20, num_std=2.0, ddof=0):
    """
    Calculate Bollinger Bands for one or more symbols.

    Required input DataFrame columns:
    symbol, date, open, high, low, close

    Parameters
    ----------
    df : pandas.DataFrame
        Price data containing one or more symbols.
    window : int, default 20
        Lookback period for the simple moving average and standard deviation.
    num_std : float, default 2.0
        Standard deviation multiplier for the upper and lower bands.
    ddof : int, default 0
        Delta degrees of freedom for standard deviation.
        ddof=0 matches the population standard deviation formula in the article.

    Returns
    -------
    pandas.DataFrame
        Original DataFrame with added columns:
        bb_middle, bb_std, bb_upper, bb_lower, bb_percent_b, bb_bandwidth
    """
    required_columns = {"symbol", "date", "open", "high", "low", "close"}
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        raise ValueError(f"Input DataFrame is missing required columns: {sorted(missing_columns)}")

    if window <= 0:
        raise ValueError("window must be a positive integer")

    if num_std < 0:
        raise ValueError("num_std must be non-negative")

    out = df.copy()
    out["_original_order"] = np.arange(len(out))

    out = out.sort_values(["symbol", "date", "_original_order"])

    grouped_close = out.groupby("symbol", group_keys=False)["close"]

    out["bb_middle"] = grouped_close.transform(
        lambda s: s.rolling(window=window, min_periods=window).mean()
    )

    out["bb_std"] = grouped_close.transform(
        lambda s: s.rolling(window=window, min_periods=window).std(ddof=ddof)
    )

    out["bb_upper"] = out["bb_middle"] + (num_std * out["bb_std"])
    out["bb_lower"] = out["bb_middle"] - (num_std * out["bb_std"])

    band_range = out["bb_upper"] - out["bb_lower"]

    out["bb_percent_b"] = np.where(
        band_range != 0,
        (out["close"] - out["bb_lower"]) / band_range,
        np.nan
    )

    out["bb_bandwidth"] = np.where(
        out["bb_middle"] != 0,
        band_range / out["bb_middle"],
        np.nan
    )

    out = out.sort_values("_original_order").drop(columns="_original_order")

    return out
```
```json
{ "model_code": "t9bn4kx2lrf6", "topic": "Bollinger Bands", "timer_secs": 39.02, "tokens_in": 559, "tokens_out": 2560, "cost_tokens_in": 0.00279500, "cost_tokens_out": 0.07680000, "cost_tokens_tot": 0.07959500 }
```