# Simple Moving Average

## Overview
The Simple Moving Average (SMA) is a technical indicator that calculates the arithmetic mean of a security's price over a specified number of periods. It appears on a chart as a single, smooth line overlaid on the price action, filtering out short-term volatility to reveal the underlying trend. As one of the most foundational tools in technical analysis, the SMA forms the building block for countless other indicators. While the concept of averaging prices dates back centuries to early statistical methods, the specific application of moving averages in financial markets was popularized in the mid-20th century by analysts like J. Welles Wilder and Richard Donchian.

## Details

### How It Works
The SMA adds together the closing prices of a security over a set lookback period and divides the total by the number of periods. As a new period closes, the oldest price is dropped from the calculation and the newest price is added. This creates a "moving" average that slides forward in time. 

Because it assigns equal weight to every price in the lookback window, the SMA is inherently a lagging indicator. It smoothly reflects past price action but reacts slowly to sudden market shifts. The length of the lookback period determines the lag: a `20`-period SMA hugs price closely and reacts quickly, while a `200`-period SMA is smoother, slower, and represents long-term momentum.

### Common Interpretations
Traders typically use the SMA to identify trend direction, determine dynamic support and resistance levels, and generate entry and exit signals.

*   **Trend Identification:** If price is consistently trading above a rising SMA, the market is in an uptrend. Conversely, if price is below a falling SMA, the market is in a downtrend. 
*   **Support and Resistance:** Widely watched SMAs—such as the `50`-day and `200`-day—often act as psychological support in uptrends and resistance in downtrends. 
*   **Crossovers:** Traders watch for two types of crossovers. A **price crossover** occurs when price moves above or below an SMA, signaling a potential change in trend. A **moving average crossover** involves two SMAs of different lengths. When a short-term SMA crosses above a long-term SMA (a "Golden Cross"), it is a bullish signal; when it crosses below (a "Death Cross"), it is bearish.

### Limitations and Breakdowns
The SMA's primary weakness stems from its equal weighting of data. Because the price from `20` periods ago impacts the line just as much as yesterday's price, the SMA can lag significantly behind current market reality. 

This lag causes the SMA to break down in two specific scenarios:
1.  **The Drop-off Effect:** When an extreme price spike or drop exits the lookback window, the SMA can suddenly jump or dip even if the current price is flat. This creates a false signal that reflects the expiration of old data rather than a genuine change in current momentum.
2.  **Ranging Markets:** In a sideways, choppy market, price will repeatedly whip back and forth across the SMA. This generates a rapid succession of false crossover signals, leading to a string of losing trades if the indicator is used mechanically. 

Because of these limitations, active traders often pair the SMA with momentum indicators like the Relative Strength Index (RSI) or replace it with the Exponential Moving Average (EMA), which assigns greater weight to recent prices to reduce lag.

## Text Formula
The Simple Moving Average for a given period `n` at the current time `t` is calculated as:

`SMA_t = (P_t + P_{t-1} + P_{t-2} + ... + P_{t-n+1}) / n`

Where:
*   `SMA_t` is the Simple Moving Average value at time `t`
*   `P_t` is the closing price at time `t`
*   `n` is the number of periods in the lookback window

## Python Code
```python
import pandas as pd

def calculate_sma(df, periods=[20, 50]):
    """
    Calculates the Simple Moving Average (SMA) for one or more symbols.
    
    Parameters:
    df (pd.DataFrame): DataFrame with columns: symbol, date, open, high, low, close.
                       Can contain data for one or multiple symbols.
    periods (list): List of integers representing the lookback periods for the SMA.
    
    Returns:
    pd.DataFrame: The original DataFrame with new columns appended for each SMA period,
                  formatted as 'sma_{period}'.
    """
    # Ensure the dataframe is sorted by symbol and date to prevent look-ahead bias
    df = df.sort_values(by=['symbol', 'date']).copy()
    
    for period in periods:
        col_name = f'sma_{period}'
        
        # Group by symbol to ensure SMA is calculated independently for each asset,
        # then use a rolling window to calculate the arithmetic mean.
        # min_periods=period ensures the SMA is only calculated when a full
        # period of data is available, preventing partial and misleading values.
        df[col_name] = df.groupby('symbol')['close'].transform(
            lambda x: x.rolling(window=period, min_periods=period).mean()
        )
        
    return df
```
```json
{ "model_code": "c5kw9bt2vrj6", "topic": "Simple Moving Average", "timer_secs": 52.59, "tokens_in": 559, "tokens_out": 2772, "cost_tokens_in": 0.00054782, "cost_tokens_out": 0.00853776, "cost_tokens_tot": 0.00908558 }
```