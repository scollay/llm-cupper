# Coppock Curve

## Overview
The Coppock Curve is a long‑term momentum oscillator developed by economist Edwin Sedgwick Coppock in 1962. Originally designed to identify buying opportunities in the S&P 500 after prolonged bear markets, it appears on a chart as a single line that oscillates around a zero centerline, typically plotted in a separate pane below price. Although built from monthly data, it is now commonly applied to weekly and daily timeframes by adjusting the lookback periods.

## Details
Edwin Coppock, founder of a Texas‑based investment advisory firm, approached the problem of timing market recoveries from an unusual angle. He asked the Episcopal Church how long it typically takes a person to recover from a deep emotional loss. The answer — 11 to 14 months — became the backbone of his indicator. Coppock reasoned that the stock market, much like a grieving individual, needs a similar “mourning period” before it is ready to turn upward with conviction.

**How It Works**  
The Coppock Curve combines two rates of change (ROC) of price — an 11‑period and a 14‑period ROC — sums them, and then smooths the result with a 10‑period weighted moving average (WMA). The use of a WMA (with linearly increasing weights) gives more influence to recent data while still preserving the lag that keeps the indicator focused on major trend shifts. The calculation yields a smoothed, detrended momentum line that dwells below zero during bear phases and crosses into positive territory only when multi‑month strength is evident.

Although the original design used monthly closing prices (11 months, 14 months, 10‑month WMA), traders frequently substitute weekly or daily closes. When shifting timescales, the lookback parameters are often kept at 11 and 14 and the smoothing period at 10, but the interpretation must adapt to the new frequency. Daily data, for instance, will generate more frequent crosses and more noise; the indicator then serves as a faster momentum gauge rather than a strict long‑term buy signal.

**Interpretation**  
The classic — and only signal Coppock himself endorsed — is a buy when the Curve crosses above zero after an extended stay in negative territory. The logic is simple: once enough upward momentum has accumulated to pull the smoothed sum of two long‑term ROCs above zero, a sustainable recovery is likely underway. Some technicians also look for a “W”‑shaped bottom in the Curve itself before the zero‑line crossover, treating that pattern as an early confirmation.

Many traders extend the interpretation beyond the original buy‑only mandate:

- A *crossover below zero* is sometimes used as an exit or caution signal. While not intended by Coppock, it can protect profits during major trend reversals — though it rarely captures the exact peak.
- *Divergences* between price and the Coppock Curve may provide leading information. For example, if price makes a lower low but the Coppock Curve makes a higher low, it suggests weakening downside momentum and a possible turnaround.
- The indicator is often combined with a long‑term moving average or trend filter. Buying only when the Curve is above zero and price is above its 200‑period moving average can reduce false signals.

**Where Interpretation Breaks Down**  
Because the Coppock Curve is heavily smoothed, it inherently lags. In a fast, V‑shaped recovery, the curve may not turn positive until a substantial portion of the rally has already occurred. In choppy, range‑bound markets, it can whipsaw around the zero line, generating a succession of false starts. The indicator also offers no sell timing: it can remain positive for years during a secular bull market while significant corrections unfold, giving no hint of interim danger.

Additionally, the original 11/14/10 parameter set was calibrated to the rhythm of mid‑20th‑century U.S. equities. In modern, more volatile markets or on other asset classes (commodities, currencies), traders often experiment with shorter periods — e.g., 10 and 12 with an 8‑period WMA — to better match the cycle length. No single parameter set fits all markets, and over‑optimization can erode the indicator’s historical reliability.

**Summary of Practical Use**  
- *Primary signal*: Buy when the Coppock Curve crosses from negative to positive.  
- *Secondary signal*: Watch for positive divergence or a W‑bottom pattern in the Curve itself.  
- *Avoid acting on the indicator alone*: Combine with trend, volume, or volatility filters to reduce whipsaws.  
- *Do not expect sell signals*: The Curve was designed as a one‑way gauge for entry; exits require a different framework.

## Text Formula
Let *Close<sub>t</sub>* be the closing price at time *t*. Define the rate of change over *n* periods as:

*ROC<sub>n</sub>(t) = ( (Close<sub>t</sub> / Close<sub>t‑n</sub>) – 1 ) × 100*

Then the raw Coppock value before smoothing is:

*Raw<sub>t</sub> = ROC<sub>11</sub>(t) + ROC<sub>14</sub>(t)*

The Coppock Curve is a 10‑period weighted moving average of *Raw*:

*Coppock Curve<sub>t</sub> = WMA<sub>10</sub>(Raw<sub>t</sub>)*

Where the weighted moving average of a series *S* over window *w* with linearly increasing weights is:

*WMA<sub>w</sub>(S<sub>t</sub>) = ( 1·S<sub>t‑w+1</sub> + 2·S<sub>t‑w+2</sub> + … + w·S<sub>t</sub> ) / (1+2+…+w)*

For *w=10*, the denominator (sum of weights) is 55.

## Python Code
```python
"""
Calculate the Coppock Curve for one or more symbols.

Expects a pandas DataFrame with exactly these columns:
    symbol | date | open | high | low | close
The DataFrame may contain data for multiple symbols.
All observations for a symbol are processed independently
after sorting by date.
"""

import pandas as pd
import numpy as np

def coppock_curve(df, roc_short=11, roc_long=14, wma_period=10):
    """
    Compute the Coppock Curve and return the DataFrame with a new
    'coppock_curve' column.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: 'symbol', 'date', 'close'
    roc_short : int, default 11
        Lookback period for the short rate of change.
    roc_long : int, default 14
        Lookback period for the long rate of change.
    wma_period : int, default 10
        Smoothing period for the weighted moving average.

    Returns
    -------
    pd.DataFrame
        The input DataFrame with an added 'coppock_curve' column.
    """
    # Work on a copy to avoid side effects
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['symbol', 'date'])

    # 1. Calculate the two rates of change (percent) within each symbol
    df['roc_s'] = df.groupby('symbol')['close'].pct_change(periods=roc_short) * 100
    df['roc_l'] = df.groupby('symbol')['close'].pct_change(periods=roc_long) * 100

    # 2. Sum the two ROCs
    df['roc_sum'] = df['roc_s'] + df['roc_l']

    # 3. Apply a weighted moving average (linearly increasing weights)
    weights = np.arange(1, wma_period + 1)
    weight_sum = weights.sum()

    def wma(series, window):
        """Compute weighted moving average of a series."""
        return series.rolling(window).apply(
            lambda x: np.sum(weights * x) / weight_sum if len(x) == window else np.nan,
            raw=True
        )

    # 4. Compute Coppock Curve per symbol
    df['coppock_curve'] = df.groupby('symbol')['roc_sum'].transform(
        lambda g: wma(g, wma_period)
    )

    # Clean up temporary columns
    df.drop(columns=['roc_s', 'roc_l', 'roc_sum'], inplace=True)

    return df
```
```json
{ "model_code": "m4n8jp5xq7vh", "topic": "Coppock Curve", "timer_secs": 86.74, "tokens_in": 560, "tokens_out": 4344, "cost_tokens_in": 0.00024080, "cost_tokens_out": 0.00377928, "cost_tokens_tot": 0.00402008 }
```