## Detailed Reasoning
**Clarity (3):** The article is well organized under the required headings and uses helpful subheadings and bullets, especially in “Common Interpretations” and “Where Interpretation Breaks Down.” The explanation is pitched appropriately for knowledgeable traders and reads like a concise reference article rather than a beginner tutorial.

**Accuracy (2):** The main Bollinger Bands explanation is correct, including the middle, upper, lower bands, %B, and bandwidth. However, the Text Formula defines standard deviation with denominator `n` while the Python code uses Pandas `.std()` default `ddof=1`, which computes sample standard deviation with denominator `n-1`; this makes the formula and code inconsistent. The statement that “standard deviation assumes a roughly normal price distribution” is also imprecise, since standard deviation itself does not require normality, though some interpretations of two-standard-deviation bands may imply it.

**Depth (3):** The article covers construction, chart appearance, creator/date, common interpretations, derived metrics, and several meaningful limitations. It also explains practical breakdowns such as trend-following behavior, squeezes, parameter sensitivity, lag, and false signals, giving the piece appropriate substance for active traders.

**Adherence (3):** The required H1 title and four exact `##` section headings are present, and the article is close to the requested 1000-word length without obvious padding. It uses clean Markdown, no hyperlinks, no raw HTML, no images, and no tables. The Python appears inside one correctly opened and closed `python` fenced code block.

**Code (2):** The code handles multiple symbols independently using `groupby("symbol")`, sorts each group by date, and returns all values discussed: middle band, upper band, lower band, %B, and bandwidth. The main issue is the rolling standard deviation convention: `.std()` defaults to `ddof=1`, contradicting the formula’s population standard deviation using denominator `n`. The function would generally run on valid input, though it does not restore the original row order after per-symbol date sorting despite claiming alignment with original rows.

**Flags:**  
formula_code_mismatch: The formula uses population standard deviation with denominator `n`, but the code uses Pandas’ default sample standard deviation.  
wrong_stat_convention: The statistical convention in code is inconsistent with the stated formula.  
factual_error: The article says standard deviation assumes a roughly normal distribution, which is not strictly true.

```json
{"model_code":"gcwq4ebg96qi","scores":{"clarity":3,"accuracy":2,"depth":3,"adherence":3,"code":2},"flags":["formula_code_mismatch","wrong_stat_convention","factual_error"],"summary":"Strong article structure and coverage, but the formula and Python code use inconsistent standard deviation conventions."}
```

```json
{"model_code": "gcwq4ebg96qi", "cost_in_per_million": 0.039, "cost_out_per_million": 0.18, "class": "midrange", "cost": "low", "country": "United States"}
```

```json
{ "model_code": "gcwq4ebg96qi", "topic": "Bollinger Bands", "timer_secs": 24.25, "tokens_in": 620, "tokens_out": 2001, "cost_tokens_in": 0.00002418, "cost_tokens_out": 0.00036018, "cost_tokens_tot": 0.00038436 }
```