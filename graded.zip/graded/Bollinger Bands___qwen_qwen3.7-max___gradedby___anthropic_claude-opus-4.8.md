## Detailed Reasoning
**Clarity (score 3):** The article is well-organized with clear subheadings under Details (Mechanics, Trading Interpretations, Limitations), logical sequencing, and effective bulleted lists for the four strategies. Inline emphasis is used sparingly and appropriately. Reads exactly like a clean Investopedia explainer.

**Accuracy (score 3):** The explanation, formula, and code are all consistent. Middle = 20-SMA, upper/lower = ±2 std, bandwidth = (upper−lower)/middle all match across prose, formula, and code. The note about ~95% within two standard deviations is correctly framed as a theoretical/normal-distribution premise. The W-bottom/M-top and walking-the-bands descriptions are accurate. `ddof=0` (population std) correctly matches typical charting-platform convention.

**Depth (score 3):** Strong substance for the audience: covers construction, multiple interpretation strategies, pattern recognition, and a genuinely thoughtful limitations section (lagging nature, mean-reversion failure in trends, use with other tools). Includes the derived Bandwidth metric and explains its purpose.

**Adherence (score 3):** All five required elements present with exact headings (`## Overview`, `## Details`, `## Text Formula`, `## Python Code`) and a real H1 title. No tables, links, HTML, or images. Code is in a single proper ```python fence. Length is roughly 750–850 words — somewhat under the ~1000 target but reasonably close given conciseness was requested; minor.

**Code (score 3):** Code documents the required input format without simulating data, groups by `symbol` so each asset is handled independently, sorts chronologically, and computes all four described values (`bb_middle`, `bb_upper`, `bb_lower`, `bb_bandwidth`). `transform` with rolling preserves index alignment correctly, `min_periods=window` avoids partial-window artifacts, and it would run without error on valid input. Complete and correct.

**Flags:**
- under_length: article runs roughly 750–850 words, modestly under the ~1000 target.
- exceptional_code: correct per-symbol grouping, index-safe transforms, all described values computed.

```json
{"model_code":"l8nf5cm3wph7","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["under_length","exceptional_code"],"summary":"Excellent, internally consistent Bollinger Bands explainer with correct per-symbol code; only minor weakness is being somewhat under the 1000-word target."}
```

```json
{"model_code": "l8nf5cm3wph7", "cost_in_per_million": 1.25, "cost_out_per_million": 3.75, "class": "frontier", "cost": "high", "country": "China"}
```

```json
{ "model_code": "l8nf5cm3wph7", "topic": "Bollinger Bands", "timer_secs": 68.88, "tokens_in": 580, "tokens_out": 4272, "cost_tokens_in": 0.00072500, "cost_tokens_out": 0.01602000, "cost_tokens_tot": 0.01674500 }
```