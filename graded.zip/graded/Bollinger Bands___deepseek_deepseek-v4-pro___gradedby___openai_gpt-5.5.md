## Detailed Reasoning
**Clarity (3):** The article is clearly organized with the exact major sections, useful subheadings such as “How the indicator is built” and “The Bollinger Squeeze,” and readable bullets for common interpretations. The prose is pitched well for knowledgeable traders and avoids a wall-of-text structure.

**Accuracy (2):** The core Bollinger Bands calculation is accurate and internally consistent for the three main bands: SMA plus/minus a population standard deviation multiplier, and the code uses `std(ddof=0)` accordingly. However, the article introduces derived metrics, **Bandwidth** and **%b**, but the Text Formula does not define them, and the code does not compute them; additionally, “Bandwidth” is described only as raw `upper - lower`, whereas the common Bollinger BandWidth measure is often normalized by the middle band.

**Depth (3):** The explanation covers construction, mean-reversion use, trend “walking the band,” squeezes, parameter sensitivity, and major limitations such as false breakouts and poor reversal signals in trends. This is substantive and appropriate for an Investopedia-style reference article.

**Adherence (2):** The required title and four `##` headings are present and exactly named, and the article avoids banned hyperlinks, HTML, images, and tables. The main adherence issue is that the Text Formula does not show how to calculate all indicator values mentioned in the article, specifically Bandwidth and `%b`; the inline usage example also places Python snippets outside the required single Python code fence.

**Code (2):** The function would generally run on a valid multi-symbol DataFrame, sorts by `symbol` and `date`, groups by symbol, and correctly computes the middle, upper, and lower bands with population standard deviation. It does not compute or return `bandwidth` or `%b`, even though the article discusses them as monitored Bollinger Band values, so the implementation is incomplete.

**Flags:**  
incomplete_outputs: The code returns only `middle_band`, `upper_band`, and `lower_band`, omitting Bandwidth and `%b` mentioned in the article.  
format_violation: The usage example includes inline Python snippets outside the single required fenced Python code block.  
note: Text Formula omits formulas for Bandwidth and `%b`.

```json
{"model_code":"m4n8jp5xq7vh","scores":{"clarity":3,"accuracy":2,"depth":3,"adherence":2,"code":2},"flags":["incomplete_outputs","format_violation","note: Text Formula omits formulas for Bandwidth and %b"],"summary":"Strong explanation and correct core bands, but formula and code omit the mentioned Bandwidth and %b values."}
```

```json
{"model_code": "m4n8jp5xq7vh", "cost_in_per_million": 0.43, "cost_out_per_million": 0.87, "class": "frontier", "cost": "med", "country": "China"}
```

```json
{ "model_code": "m4n8jp5xq7vh", "topic": "Bollinger Bands", "timer_secs": 97.17, "tokens_in": 561, "tokens_out": 3275, "cost_tokens_in": 0.00024123, "cost_tokens_out": 0.00284925, "cost_tokens_tot": 0.00309048 }
```