## Detailed Reasoning
**Clarity (3):** The article is clearly organized under the required headings, with readable bullet points explaining the three bands and common interpretations. The language is accessible and Investopedia-like, though somewhat brief for the intended active-trader audience.

**Accuracy (2):** The core description of Bollinger Bands is correct: SMA middle band, upper/lower bands based on standard deviations, and volatility-driven expansion/contraction. However, the Text Formula defines standard deviation using division by `n` while the Python code uses Pandas `rolling().std()` default `ddof=1`, creating a formula-code mismatch; “bandwidth” is also presented as a raw band difference, whereas Bollinger BandWidth is commonly normalized by the middle band.

**Depth (1):** The article covers basic components, interpretation, squeeze behavior, and trend caveats, but it is quite shallow for knowledgeable traders and roughly 400 words instead of about 1000. It omits richer discussion of default settings, confirmation tools, volatility regimes, false breakout handling, and limitations of overbought/oversold readings.

**Adherence (2):** The required title and four exact `##` headings are present, and the Python code is correctly placed in one fenced `python` block with no prohibited formatting in the article. The main issue is substantial under-length relative to the “about 1000 words” target, and the code does not explicitly document the required input format beyond using the expected columns.

**Code (2):** The code would generally run on a valid Pandas DataFrame and handles multiple symbols independently with `groupby('symbol').transform(...)`, returning SMA, standard deviation, upper band, lower band, bandwidth, and percent_b. Its main flaw is that it computes sample standard deviation by default, contradicting the text formula’s population standard deviation; it also does not handle zero bandwidth explicitly.

**Flags:**  
under_length: The article is roughly 400 words, far below the requested about 1000 words.  
formula_code_mismatch: Text formula uses population standard deviation divided by `n`, while code uses Pandas sample standard deviation by default.  
wrong_stat_convention: The standard-deviation convention is inconsistent and not specified clearly.  

```json
{"model_code":"n7gx4mc8btf3","scores":{"clarity":3,"accuracy":2,"depth":1,"adherence":2,"code":2},"flags":["under_length","formula_code_mismatch","wrong_stat_convention"],"summary":"Clear and correctly structured, but much too short and inconsistent on the standard-deviation convention."}
```

```json
{"model_code": "n7gx4mc8btf3", "cost_in_per_million": 0.15, "cost_out_per_million": 0.6, "class": "midrange", "cost": "low", "country": "United States"}
```

```json
{ "model_code": "n7gx4mc8btf3", "topic": "Bollinger Bands", "timer_secs": 8.16, "tokens_in": 561, "tokens_out": 670, "cost_tokens_in": 0.00008415, "cost_tokens_out": 0.00040200, "cost_tokens_tot": 0.00048615 }
```