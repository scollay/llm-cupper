## Detailed Reasoning
**Clarity (3):** The article is exceptionally well-organized and readable, perfectly pitched at knowledgeable traders. The use of bolding for subheadings within the Details section and bullet points in the Text Formula section provides excellent, light formatting that aids readability without being distracting.
**Accuracy (3):** The explanation, mathematical formula, and Python code are perfectly accurate and mutually consistent. The coefficients for the six-pole filter are correctly expanded from the Generalized Double Exponential Moving Average (GD) operator and match the standard T3 calculation by Tim Tillson.
**Depth (3):** The article provides outstanding depth, covering the indicator's construction, trading interpretation, limitations (such as the initialization tail and overshoot during sharp reversals), and a highly accurate comparison with TEMA.
**Adherence (3):** The article follows all instructions, including the exact required headings, the absence of banned formatting (no HTML, tables, or images), and the specified input format for the code. The length (~850 words) is concise and appropriate for the ~1000-word target without resorting to padding.
**Code (3):** The Python code is excellent. It correctly implements the T3 calculation, computes all intermediate EMA layers as promised in the text, and flawlessly handles multiple symbols using pandas `groupby` and `transform` with `ewm`.

**Flags:**
exceptional_clarity: The writing is highly professional, flows logically, and uses formatting perfectly to structure the information.
exceptional_depth: The inclusion of signal-processing context, failure modes, and a direct comparison to TEMA shows deep domain expertise.
exceptional_code: The code is clean, efficient, and uses the optimal pandas methods (`groupby` + `transform`) for multi-symbol time-series calculations.

```json
{"model_code":"h7dt4jq8mlc5","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["exceptional_clarity","exceptional_depth","exceptional_code"],"summary":"An outstanding article with deep domain expertise, perfectly accurate formulas, and highly efficient, robust pandas code."}
```

```json
{"model_code": "h7dt4jq8mlc5", "cost_in_per_million": 0.73, "cost_out_per_million": 3.49, "class": "frontier", "cost": "high", "country": "China"}
```

```json
{ "model_code": "h7dt4jq8mlc5", "topic": "T3", "timer_secs": 875.72, "tokens_in": 557, "tokens_out": 15115, "cost_tokens_in": 0.00040661, "cost_tokens_out": 0.05275135, "cost_tokens_tot": 0.05315796 }
```