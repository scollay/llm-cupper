## Detailed Reasoning
**Clarity (3):** The article is exceptionally well-written, logically structured, and perfectly pitched for an audience of active traders. The use of subheadings, bullet points, and light formatting makes it highly readable without feeling cluttered.
**Accuracy (3):** The explanation of the T3 Moving Average, the derivation of its coefficients, and the mathematical formula are completely accurate. The prose, text formula, and Python code are perfectly consistent with one another and correctly implement Tim Tillson's original logic.
**Depth (3):** The article provides excellent depth, covering the mechanics of the volume factor, practical trading interpretations (trend identification, crossovers, dual systems), and crucial limitations like whipsaws and overshooting. It delivers substantial value without unnecessary padding.
**Adherence (3):** The submission follows all instructions flawlessly. It includes the five required sections with exact headings, adheres to the formatting constraints (no tables, HTML, or images), and meets the target length of approximately 1000 words while remaining concise.
**Code (3):** The Python code is robust, well-documented, and correctly implements the T3 formula. It properly handles multi-symbol DataFrames using `groupby` and `transform` to prevent data leakage, uses standard EMA calculations (`ewm(span=n, adjust=False)`), and would run without errors on the specified input.

**Flags:**
exceptional_clarity: The writing is highly professional, engaging, and perfectly formatted.
exceptional_depth: The breakdown of the volume factor and the specific limitations of the indicator are highly insightful.
exceptional_code: The code is clean, efficient, and handles multi-symbol data elegantly using `transform`.

```json
{"model_code":"t5pz4nm8vqj7","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["exceptional_clarity","exceptional_depth","exceptional_code"],"summary":"An outstanding submission with perfect math, excellent trading insights, and robust, production-ready code."}
```

```json
{"model_code": "t5pz4nm8vqj7", "cost_in_per_million": 2.0, "cost_out_per_million": 12.0, "class": "frontier", "cost": "premium", "country": "United States"}
```

```json
{ "model_code": "t5pz4nm8vqj7", "topic": "T3", "timer_secs": 45.98, "tokens_in": 565, "tokens_out": 5968, "cost_tokens_in": 0.00113000, "cost_tokens_out": 0.07161600, "cost_tokens_tot": 0.07274600 }
```