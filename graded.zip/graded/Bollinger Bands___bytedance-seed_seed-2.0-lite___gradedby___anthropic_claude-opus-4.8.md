## Detailed Reasoning
**Clarity (score 3):** The article is well-organized with logical flow from overview to mechanics, interpretations, pitfalls, formula, and code. The use of subheadings within Details, numbered lists for use cases, and bulleted pitfalls genuinely aids readability without being decorative. Inline code for column names and variables is appropriate.

**Accuracy (score 3):** The prose, formula, and code are mutually consistent. The middle band is a 20-period SMA, upper/lower bands are ±2 standard deviations, and the text correctly specifies sample standard deviation — matching `.std()` in pandas which defaults to `ddof=1` (sample). The "~95% within 2 SD" claim is the conventional approximation and is appropriately hedged. No mathematical errors found.

**Depth (score 3):** Excellent substance for the audience: covers mechanics, four interpretation modes, the squeeze, trend-riding, and four concrete pitfalls including lagging nature, parameter mismatch across timeframes, and inability to predict gap shocks. This goes well beyond surface-level explanation appropriate to knowledgeable traders.

**Adherence (score 3):** All five required elements present with exact headings (`## Overview`, `## Details`, `## Text Formula`, `## Python Code`) and a proper H1 title. No tables, hyperlinks, HTML, or images. Code is in a single proper ```python fence with only code/comments inside. Length is roughly 850–900 words, slightly under 1000 but within acceptable range. Input format documented as required without simulating data.

**Code (score 2):** The code correctly computes all three bands per symbol using `groupby(...).apply()` with sample std, matching the text. However, `df.groupby('symbol', group_keys=False).apply(add_bands)` mutates groups in place and in newer pandas versions emits a DeprecationWarning (apply on grouping columns); it would still run. A more notable concern: with `group_keys=False` the result preserves original index alignment, which is fine. The code does not return `open`/`high`/`low` issues — it works. Minor: no explicit sort enforcement (relies on documented precondition), and `apply` modifying the original group is slightly fragile but functional. Solid with minor issues.

**Flags:**
- exceptional_depth — four interpretation modes plus four well-chosen pitfalls including lag and parameter sensitivity.
- note: slightly under target length (~850–900 words) but acceptable.

```json
{"model_code":"q5bk8xem5pb6","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":2},"flags":["exceptional_depth","note: ~850-900 words, slightly under 1000 target but acceptable"],"summary":"Accurate, well-structured Bollinger Bands explainer with consistent prose/formula/code; minor pandas apply fragility is the only real weakness."}
```

```json
{"model_code": "q5bk8xem5pb6", "cost_in_per_million": 0.25, "cost_out_per_million": 2.0, "class": "lightweight", "cost": "med", "country": "China"}
```

```json
{ "model_code": "q5bk8xem5pb6", "topic": "Bollinger Bands", "timer_secs": 286.41, "tokens_in": 627, "tokens_out": 4721, "cost_tokens_in": 0.00015675, "cost_tokens_out": 0.00944200, "cost_tokens_tot": 0.00959875 }
```