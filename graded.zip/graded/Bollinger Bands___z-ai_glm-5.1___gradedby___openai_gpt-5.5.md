## Detailed Reasoning
**Clarity (3):** The article is well organized with the exact required major sections and helpful subsections such as “Core Mechanics,” “Interpretation,” and “Limitations and Breakdowns.” The explanations are readable for active traders and the light use of bullets and bold labels improves scanning without becoming decorative.

**Accuracy (3):** The Bollinger Bands description, creator attribution to John Bollinger in the early 1980s, standard formulas, and interpretations are correct. The text formula and code agree on using an SMA, population rolling standard deviation with `ddof=0`, upper/lower bands, BandWidth, and `%B`.

**Depth (3):** The article covers mechanics, common trading interpretations, derived values, and meaningful caveats such as band-walking in trends, squeeze direction uncertainty, lag, volatility shocks, fat tails, and parameter sensitivity. This is appropriate depth for a concise Investopedia-style explainer.

**Adherence (3):** The required H1 title and four exact `##` headings are present, and the article uses clean Markdown without hyperlinks, HTML, images, or tables. The length is in the expected range for a concise “about 1000 words” reference article when including the formula and code, and the Python appears inside one proper `python` fenced block.

**Code (3):** The code would run on a valid Pandas DataFrame with `symbol`, `date`, `open`, `high`, `low`, and `close`, sorts by symbol/date, and applies rolling calculations independently per symbol. It returns all indicator values discussed—middle, upper, lower, BandWidth, and `%B`—with formula-consistent population standard deviation.

**Flags:** exceptional_clarity — The sectioning and explanations are especially readable and trader-focused.
**Flags:** exceptional_code — The implementation is concise, multi-symbol aware, formula-consistent, and likely to run correctly.

```json
{"model_code":"c5kw9bt2vrj6","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["exceptional_clarity","exceptional_code"],"summary":"A clear, accurate Bollinger Bands explainer with complete formula-code consistency and robust multi-symbol Pandas implementation."}
```

```json
{"model_code": "c5kw9bt2vrj6", "cost_in_per_million": 0.98, "cost_out_per_million": 3.08, "class": "frontier", "cost": "high", "country": "China"}
```

```json
{ "model_code": "c5kw9bt2vrj6", "topic": "Bollinger Bands", "timer_secs": 108.35, "tokens_in": 560, "tokens_out": 3064, "cost_tokens_in": 0.00054880, "cost_tokens_out": 0.00943712, "cost_tokens_tot": 0.00998592 }
```