## Detailed Reasoning
**Clarity (3):** Excellent organization with clear subheadings (Core Mechanics, Common Trading Interpretations, Limitations), numbered and bulleted lists, and tasteful bold for terms like *The Squeeze*. Inline code for column names is used appropriately. The prose is pitched well for knowledgeable traders without being a wall of text.

**Accuracy (3):** The explanation of bands, volatility expansion/contraction, the squeeze, walking the band, %B, and the fat-tails caveat are all correct. The formula uses population standard deviation (÷n), and the code matches with `ddof=0`. Prose, formula, and code are mutually consistent — %B formula `(close - lower)/(upper - lower)` matches text. No detectable errors.

**Depth (3):** Strong substance: mechanism, parameter effects (n, k), three interpretation patterns, %B as a normalizing metric, and four meaningful limitations (false squeezes, normal-distribution assumption, regime mismatch, lag). This goes well beyond surface-level for the target audience.

**Adherence (3):** All five required elements present with exact `##` headings (Overview, Details, Text Formula, Python Code) and a real H1 title. No tables, hyperlinks, HTML, or images. Code is in a single proper ```python fence with prose outside. Length is roughly 950–1000 words — on target. Documents the required input columns without simulating data.

**Code (3):** Correctly groups by `symbol` with `group_keys=False`, sorts by date, uses `rolling(window=n, min_periods=n)` for both SMA and population std (`ddof=0`), computes upper/lower bands and %B. Computes every value the article describes. `groupby(...).apply` returns properly aligned rows; would run without error on one or more symbols. Minor: a DeprecationWarning in newer pandas for apply on grouping column, but no error. Edge handling (NaN before n rows) is correct.

**Flags:**
- exceptional_depth: four well-explained limitations plus %B and parameter discussion exceed typical explainer depth.
- exceptional_clarity: clean, well-structured formatting throughout.

```json
{"model_code":"gt4ov003vwua","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["exceptional_depth","exceptional_clarity"],"summary":"Accurate, well-structured, complete Bollinger Bands article with consistent prose/formula/code and correct per-symbol grouped calculation."}
```

```json
{"model_code": "gt4ov003vwua", "cost_in_per_million": 0.063, "cost_out_per_million": 0.21, "class": "frontier", "cost": "low", "country": "China"}
```

```json
{ "model_code": "gt4ov003vwua", "topic": "Bollinger Bands", "timer_secs": 103.18, "tokens_in": 565, "tokens_out": 9177, "cost_tokens_in": 0.00003560, "cost_tokens_out": 0.00192717, "cost_tokens_tot": 0.00196276 }
```