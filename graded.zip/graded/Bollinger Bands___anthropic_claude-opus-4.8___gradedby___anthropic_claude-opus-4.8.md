## Detailed Reasoning
**Clarity (3):** Well-organized with logical flow from construction to derived measures to interpretation to breakdown points. Subheadings within Details, bulleted/numbered lists, and inline code for column names all aid readability without decoration. Pitched well for knowledgeable traders.

**Accuracy (3):** The formulas are correct: middle band is SMA, upper/lower bands use k·stddev, bandwidth = (UB−LB)/MB, %B = (Close−LB)/(UB−LB). It correctly specifies population standard deviation (ddof=0), and the code matches (`std(ddof=0)`). Prose, formula, and code are mutually consistent. Interpretation caveats (walking the band, fat tails) are accurate.

**Depth (3):** Covers mechanism, both standard interpretations (mean reversion and Squeeze/breakout), the middle band as trend reference, derived measures, and substantial limitations (relative not absolute levels, fat tails, curve-fitting, use with non-correlated indicators). Genuinely complete for the audience and length.

**Adherence (3):** All required headings present and exact (`## Overview`, `## Details`, `## Text Formula`, `## Python Code`); H1 is the indicator name. No tables, hyperlinks, HTML, or images. Code is in one proper `python` fence. Length is roughly 850–950 words, near target. Input format documented as required without simulating data.

**Code (3):** Uses `groupby("symbol")[...].transform(...)` with rolling operations, which preserves index alignment across symbols and processes each independently. Sorts by symbol/date first. Computes all five described values. Handles NaN warmup correctly. The closing prose after the fence is fine (prose belongs outside the fence). No logic bugs or crash risks on valid input.

**Flags:**
- exceptional_depth: thorough coverage of mechanism, interpretation, and multiple genuine caveats.
- exceptional_code: correct per-symbol grouped rolling with proper ddof and index alignment.

```json
{"model_code":"r8f5wn2cv6tj","scores":{"clarity":3,"accuracy":3,"depth":3,"adherence":3,"code":3},"flags":["exceptional_depth","exceptional_code"],"summary":"Accurate, complete, well-organized Bollinger Bands article; code correctly handles per-symbol grouping with population stddev and computes all described values."}
```

```json
{"model_code": "r8f5wn2cv6tj", "cost_in_per_million": 5.0, "cost_out_per_million": 25.0, "class": "frontier", "cost": "premium", "country": "United States"}
```

```json
{ "model_code": "r8f5wn2cv6tj", "topic": "Bollinger Bands", "timer_secs": 30.78, "tokens_in": 846, "tokens_out": 2491, "cost_tokens_in": 0.00423000, "cost_tokens_out": 0.06227500, "cost_tokens_tot": 0.06650500 }
```